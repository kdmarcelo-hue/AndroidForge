
package com.marcelo.virtuselm;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    BluetoothAdapter adapter;
    BluetoothDevice selected;
    BluetoothSocket socket;
    InputStream in;
    OutputStream out;
    TextView log, txtDevice;
    Button identify, readOnly;
    Handler handler = new Handler(Looper.getMainLooper());

    static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        log = findViewById(R.id.log);
        txtDevice = findViewById(R.id.txtDevice);
        identify = findViewById(R.id.btnIdentify);
        readOnly = findViewById(R.id.btnReadOnly);

        adapter = BluetoothAdapter.getDefaultAdapter();

        findViewById(R.id.btnDevices).setOnClickListener(v -> chooseDevice());
        findViewById(R.id.btnConnect).setOnClickListener(v -> connect());
        identify.setOnClickListener(v -> identifyElm());
        readOnly.setOnClickListener(v -> readOnlyTest());
        findViewById(R.id.btnClear).setOnClickListener(v -> log.setText(""));

        requestBtPermissions();
    }

    void requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN}, 10);
        }
    }

    void chooseDevice() {
        if (adapter == null) { add("Bluetooth não disponível."); return; }
        if (!adapter.isEnabled()) { add("Ative o Bluetooth do Android."); return; }
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBtPermissions(); return;
        }
        Set<BluetoothDevice> bonded = adapter.getBondedDevices();
        if (bonded.isEmpty()) { add("Nenhum dispositivo pareado. Pareie o ELM nas configurações Bluetooth do Android primeiro."); return; }

        ArrayList<String> names = new ArrayList<>();
        ArrayList<BluetoothDevice> devs = new ArrayList<>();
        for (BluetoothDevice d : bonded) {
            names.add((d.getName()==null?"(sem nome)":d.getName()) + "\n" + d.getAddress());
            devs.add(d);
        }
        new AlertDialog.Builder(this).setTitle("Dispositivos pareados")
            .setItems(names.toArray(new String[0]), (di, which) -> {
                selected = devs.get(which);
                txtDevice.setText("Selecionado: " + selected.getName() + "\n" + selected.getAddress());
                add("Selecionado: " + selected.getName());
            }).show();
    }

    void connect() {
        if (selected == null) { add("Selecione o ELM primeiro."); return; }
        new Thread(() -> {
            try {
                if (adapter != null) adapter.cancelDiscovery();
                socket = selected.createRfcommSocketToServiceRecord(SPP);
                socket.connect();
                in = socket.getInputStream();
                out = socket.getOutputStream();
                add("CONECTADO via Bluetooth SPP.");
                identify.setEnabled(true);
                readOnly.setEnabled(true);
                send("ATZ");
                sleep(1200);
                readAvailable();
            } catch(Exception e) {
                add("ERRO DE CONEXÃO: " + e.getClass().getSimpleName() + " - " + e.getMessage());
                close();
            }
        }).start();
    }

    void identifyElm() {
        new Thread(() -> {
            try {
                send("ATE0"); sleep(300); readAvailable();
                send("ATL0"); sleep(300); readAvailable();
                send("ATS0"); sleep(300); readAvailable();
                send("ATI"); sleep(500); readAvailable();
                send("ATDP"); sleep(500); readAvailable();
                send("ATSP0"); sleep(500); readAvailable();
                add("Identificação concluída. Nenhum comando de escrita foi enviado.");
            } catch(Exception e) { add("ERRO: "+e.getMessage()); }
        }).start();
    }

    void readOnlyTest() {
        new Thread(() -> {
            try {
                add("Teste somente leitura iniciado.");
                send("0100");
                sleep(1000);
                readAvailable();
                send("010C");
                sleep(700);
                readAvailable();
                send("010D");
                sleep(700);
                readAvailable();
                add("Teste concluído. Nenhum comando de escrita/adaptação foi enviado.");
            } catch(Exception e) { add("ERRO: "+e.getMessage()); }
        }).start();
    }

    synchronized void send(String s) throws IOException {
        if (out == null) throw new IOException("Não conectado");
        add(">> " + s);
        out.write((s + "\r").getBytes(StandardCharsets.US_ASCII));
        out.flush();
    }

    void readAvailable() throws IOException {
        long end = System.currentTimeMillis() + 1500;
        StringBuilder sb = new StringBuilder();
        while (System.currentTimeMillis() < end) {
            while (in != null && in.available() > 0) {
                int c = in.read();
                if (c >= 0) sb.append((char)c);
                if (c == '>') { end = System.currentTimeMillis() + 100; break; }
            }
            sleep(30);
        }
        if (sb.length() > 0) add("<< " + sb.toString().replace("\r","\n"));
        else add("<< (sem resposta)");
    }

    void close() {
        try { if(socket!=null) socket.close(); } catch(Exception ignored){}
        socket=null; in=null; out=null;
        handler.post(() -> { identify.setEnabled(false); readOnly.setEnabled(false); });
    }

    void add(String s) {
        handler.post(() -> {
            log.append(s + "\n");
            ((ScrollView)log.getParent()).post(() -> ((ScrollView)log.getParent()).fullScroll(ScrollView.FOCUS_DOWN));
        });
    }

    void sleep(long ms) {
        try { Thread.sleep(ms); } catch(InterruptedException ignored){}
    }

    @Override protected void onDestroy() { close(); super.onDestroy(); }
}
