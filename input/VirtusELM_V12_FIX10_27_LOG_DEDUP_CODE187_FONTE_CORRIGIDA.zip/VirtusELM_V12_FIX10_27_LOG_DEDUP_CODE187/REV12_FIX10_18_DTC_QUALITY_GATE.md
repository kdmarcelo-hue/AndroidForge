# V12 FIX10.18 — DTC Evidence Quality Gate

## Objetivo
Aumentar a segurança da etapa de preservação de evidências antes da limpeza OBD-II Mode 04.

## Alterações
- O relatório de investigação EPC registra uma contagem de respostas positivas OBD reconhecidas.
- O relatório diferencia uma conexão ELM aberta de uma comunicação OBD positiva observada.
- A autorização interna para avançar à confirmação de limpeza exige transporte ELM real **e** ao menos uma resposta positiva OBD reconhecida, além do salvamento bem-sucedido do relatório.
- Se o relatório for salvo, mas não houver resposta positiva reconhecida, a limpeza permanece bloqueada.
- Mantidos os fluxos de leitura, relatório RAW e confirmação explícita antes de Mode 04.

## Limitações
- Este critério não prova que todos os módulos foram consultados nem que todos os DTCs foram obtidos.
- Uma resposta positiva OBD não garante que os dados de freeze frame ou UDS estejam completos.
- Não testar limpeza real apenas para validar a interface. Após qualquer limpeza autorizada, ler novamente os DTCs e comparar os resultados.
