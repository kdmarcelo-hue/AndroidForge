# V12 FIX10.24 — Performance: paleta refinada e indicadores coloridos (Code184)

## Alterações nesta revisão
- Tema Performance com base grafite/preto e contornos vermelhos, sem preenchimento vermelho pesado nos clusters.
- Contorno vermelho mantido nos controles do modo Performance, incluindo seleção de combustível e navegação inferior.
- Cabeçalho fixo acompanha o modo: logo V e subtítulo V12 • DIAGNÓSTICO mudam para vermelho na Performance; o tema azul original é restaurado fora dela. A imagem do carro é preservada, sem redesenho.
- Indicadores ganharam símbolos compactos com acentos cromáticos distintos: potência vermelho, torque âmbar, 0–60 azul, 0–100 violeta, boost verde, qualidade amarelo, RPM ciano, velocidade verde, duração magenta e sessões branco.
- Mantidos textos, cálculos, histórico, combustível de sessão e fluxo de teste existentes.

## Limite de validação
Este é um pacote de fonte para subir ao Git. A alteração de UI não foi validada em dispositivo físico; compile com o workflow Android do repositório e confira a tela em execução antes de distribuir o APK. Os símbolos são caracteres vetoriais/Unicode estilizados no texto da interface, não arquivos de ícone independentes.


## Correcao visual da tela Performance (mesmo nome de entrega)
- O cartao de combustivel deixou de usar o preenchimento azul `CARD2`; agora usa fundo grafite/preto e contorno vermelho, alinhado ao restante da tela Performance.
- O estado `PRONTO PARA TESTE` usa vermelho para manter a identidade visual da tela.
- Nenhuma regra de medicao, selecao de combustivel ou navegacao foi alterada.
- Esta alteracao de fonte precisa ser compilada e instalada para validacao visual no tablet.
