#!/usr/bin/env python3
"""Offline static contract checks for VirtusELM V12; does not communicate with a vehicle."""
import json, re, sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
JAVA = (ROOT/'app/src/main/java/com/marcelo/virtuselm/MainActivity.java').read_text(encoding='utf-8')
GRADLE = (ROOT/'app/build.gradle').read_text(encoding='utf-8')
LIB = json.loads((ROOT/'app/src/main/assets/dtc_vag.json').read_text(encoding='utf-8'))

class BenchContractTests(unittest.TestCase):
    def test_version_restored_to_code180_baseline(self):
        self.assertRegex(GRADLE, r'versionCode\s+180')
        self.assertIn('12.0-FIX10.20-PERFORMANCE-GRAPH-HISTORY-CODE180', GRADLE)

    def test_dtc_startup_auto_update_and_integrity(self):
        self.assertIn('checkDtcLibraryUpdateSilently();', JAVA)
        self.assertIn('expected.equals(sha256(bytes))', JAVA)
        self.assertIn('parsed.containsKey(code)', JAVA)
        self.assertIn('arr.length()==0', JAVA)

    def test_pull_comparison_requires_valid_data(self):
        self.assertIn('buildPullComparison(fp,ft,lastPerf0060,lastPerf0100,fQuality,fSamples)', JAVA)
        self.assertIn('quality<50 || samples<20', JAVA)
        self.assertIn('PUXADA CONCLUÍDA', JAVA)

    def test_gate_invalidated_on_disconnect(self):
        method = JAVA.split('private void disconnect(){',1)[1].split('private void startAutomaticConnectionSequence()',1)[0]
        self.assertIn('epcEvidenceSavedThisSession=false; lastEpcEvidenceFile="";', method)

    def test_gate_invalidated_on_new_connection_attempt(self):
        method = JAVA.split('private void connect(){',1)[1].split('private void connectWorker()',1)[0]
        self.assertIn('epcEvidenceSavedThisSession=false; lastEpcEvidenceFile="";', method)

    def test_gate_invalidated_on_automatic_connection_worker(self):
        method = JAVA.split('private void connectWorker(){',1)[1].split('private void connect(',1)[0]
        self.assertIn('epcEvidenceSavedThisSession=false; lastEpcEvidenceFile="";', method)

    def test_mode04_authorization_consumed_before_transmission(self):
        method = JAVA.split('private void clearAllDtc(){',1)[1].split('private void clearSelectedDtc()',1)[0]
        self.assertIn('if(!epcEvidenceSavedThisSession)', method)
        self.assertLess(method.index('epcEvidenceSavedThisSession=false; lastEpcEvidenceFile="";'), method.index('send("04",2500)'))

    def test_save_failure_revokes_authorization(self):
        method = JAVA.split('private void investigateEpc(){',1)[1].split('private void dtcFreeze()',1)[0]
        self.assertLess(method.index('saveEpcEvidenceReport(evidenceName,report)'), method.index('epcEvidenceSavedThisSession=eligibleForClear;'))
        failure = method.split('catch(Exception saveError)',1)[1]
        self.assertIn('epcEvidenceSavedThisSession=false;', failure)

    def test_isotp_parser_checks_sequence_length_and_buffer_full(self):
        method = JAVA.split('private IsoTpPayload reassembleIsoTp(',1)[1].split('private static final class UdsDtcRecord',1)[0]
        self.assertIn('seq!=nextSequence', method)
        self.assertIn('payload.size()>=result.expectedLength', method)
        self.assertIn('result.bufferFull', method)
        self.assertIn('result.complete=false', method)

    def test_uds_dtc_parser_requires_positive_5902(self):
        method = JAVA.split('private ArrayList<UdsDtcRecord> parseUdsDtcRecords(',1)[1].split('private String udsStatusFlags',1)[0]
        self.assertIn('(p[0]&255)!=0x59||(p[1]&255)!=0x02', method)
        self.assertIn('i+=4', method)

    def test_negative_uds_response_not_called_no_fault(self):
        self.assertIn('A rejeição não prova ausência de DTCs', JAVA)
        self.assertIn('isso não significa ausência de falhas', JAVA)

    def test_dtc_library_json_valid_unique_codes(self):
        entries = LIB.get('dtcs')
        self.assertIsInstance(entries, list)
        self.assertGreater(len(entries), 0)
        codes=[]
        for entry in entries:
            self.assertTrue(entry.get('code'))
            self.assertTrue(entry.get('description'))
            codes.append(entry['code'].upper())
        self.assertEqual(len(codes), len(set(codes)), 'DTC library has duplicate code keys')

    def test_no_automated_test_source_was_present_in_code178(self):
        # This is a transparent inventory check: app test source is not part of the baseline.
        tests = list((ROOT/'app/src').glob('test/**/*.java')) + list((ROOT/'app/src').glob('androidTest/**/*.java'))
        self.assertEqual(tests, [])

if __name__ == '__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(BenchContractTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)
