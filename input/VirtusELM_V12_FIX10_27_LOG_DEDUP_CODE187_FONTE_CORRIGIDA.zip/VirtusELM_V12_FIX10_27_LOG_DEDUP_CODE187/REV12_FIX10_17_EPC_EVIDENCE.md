# V12.0-FIX10.17 — EPC/DTC Evidence Preservation (Code177)

## Scope
- Preserves the FIX10.16.1 history screen and SAF-selected log-folder workflow.
- `INVESTIGAR EPC` continues collecting OBD Mode 03/07/0A, status/readiness, VIN, freeze-frame requests and UDS 0x19/0x02 status-mask responses.
- Automatically writes the complete EPC report, including RAW responses and ISO-TP interpretation, to `Download/VirtusELM/logs/VirtusELM_EPC_Evidence_yyyyMMdd_HHmmss_SSS.txt`.
- A saved report captured while a real ELM transport is confirmed is required in the current app session before Mode 04 can be requested.
- If report saving fails, or the scan is from simulation/no real ELM transport, Mode 04 remains blocked.
- Mode 04 still requires a separate explicit confirmation; it remains a global OBD-II DTC-clear request and can reset readiness monitors.
- UDS negative responses now include common NRC descriptions (including NRC 0x31 Request Out Of Range) without treating a rejection as evidence that no DTCs exist.
- The DTC panel uses a warning color when no code was decoded; the text explicitly avoids equating that state with “no faults.”

## Safety boundary
Read-only investigation only until the user explicitly confirms Mode 04 after evidence has been saved. No UDS clearing, coding, adaptation, Security Access, or arbitrary CAN actuation is added.

## Validation status
Source/ZIP integrity can be checked locally. Android compilation and vehicle-side behavior must still be validated by the GitHub Actions Build Android workflow and a controlled real-vehicle test. Do not treat the source change alone as proof of a successful build or a correct diagnosis.
