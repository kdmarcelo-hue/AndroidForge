# Relatório de auditoria — Code181 e pacote Code182

## Code181 — achados confirmados no código-fonte

1. `versionCode` era 181 e `versionName` era `12.0-FIX10.21-GEAR-SHIFT-ESTIMATOR`.
2. `buildPerformanceScreen()` criava o botão `CALIBRAR PEDAL • 0% / 100%`; portanto, a calibração não havia sido movida para Configurações.
3. `getRawPerformancePedalPct()` retornava APP D quando disponível e, caso contrário, usava `lastThrottle`. Isso misturava fontes distintas sem informar a troca.
4. `getPerformanceEthanolPct()` lia `performance_ethanol_pct`, sem uma preferência separada para combustível padrão com 100% etanol.
5. `showEthanolDialog()` salvava a seleção feita em Performance no SharedPreferences, portanto ela não era limitada à sessão atual.
6. A tela Performance não tinha a identidade visual preto/vermelho solicitada.

## Code182 — mudanças no pacote-fonte

- Versão Android incrementada para 182.
- Combustível padrão configurável e persistente em Configurações; padrão inicial de 100% etanol.
- Seleção rápida em Performance limitada à memória da sessão e separada do padrão.
- Calibração removida de Performance e colocada em Configurações.
- Fonte APP D/E/F ou throttle selecionável; sem fallback silencioso e com invalidação do valor em cache ao trocar a fonte.
- Tela Performance com base preta e acentos vermelhos.
- Estimador de troca de marcha da Code181 preservado.

## Resultados de bancada disponíveis

- Auditoria estática: 15/15 verificações passaram.
- Modelo comportamental do estimador: 4/4 cenários passaram.
- Integridade ZIP: teste de arquivo sem erros.

## Limitação importante

Não foi possível compilar nem executar o APK localmente neste ambiente: o pacote não inclui `gradlew`, e o ambiente não tem Gradle/Android SDK instalados. Logo, **Code182 é neste momento um pacote-fonte auditado, não um APK validado**. O workflow AndroidForge precisa compilar o ZIP e o APK resultante ainda precisa ser aberto no dispositivo. A falha de inicialização relatada para o APK 181 não pode ser diagnosticada com certeza sem a mensagem de erro ou logcat; os achados acima explicam as alterações ausentes, não provam a causa de um eventual crash.
