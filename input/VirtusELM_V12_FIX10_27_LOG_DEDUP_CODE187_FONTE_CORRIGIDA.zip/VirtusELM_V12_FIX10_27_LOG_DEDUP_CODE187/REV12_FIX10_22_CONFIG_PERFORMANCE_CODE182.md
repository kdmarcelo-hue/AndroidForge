# VIRTUS ELM V12 — FIX10.22 / Code182

## Auditoria da Code181
A Code181 era identificada como `12.0-FIX10.21-GEAR-SHIFT-ESTIMATOR` e não continha as alterações solicitadas de Configurações/Performance: a calibração permanecia na tela Performance; o combustível era guardado como preferência persistente de teste, sem padrão de 100% etanol; não havia separação entre padrão e escolha temporária da sessão; e a leitura de pedal podia substituir APP D por throttle sem informar a troca.

## Alterações desta versão
- Combustível padrão em Configurações, persistido localmente, inicializado em 100% etanol.
- Seletor de combustível em Performance aplica somente à sessão atual e não altera a preferência padrão.
- Calibração movida para Configurações.
- Fonte de pedal explicitamente selecionável: APP D (0149), APP E (014A), APP F (014B) ou throttle (0111). Não há fallback silencioso; ao trocar a fonte, a leitura em cache dessa fonte é invalidada; sem nova resposta da fonte selecionada, o sinal fica indisponível.
- A tela Performance passa a usar identidade visual preto/vermelho, mantendo gráficos e controles de teste.
- Mantém o estimador de troca de marcha da Code181 e o modo somente leitura.

## Verificações
- `python tests/bench_fix10_20.py`: auditoria estática das novas preferências, posição dos controles, seleção explícita do PID, tema e proteção contra comandos de atuação.
- `python tests/test_gear_shift_estimator.py`: cenários comportamentais do estimador.
- A compilação final e a inicialização no aparelho ainda precisam ser confirmadas pelo workflow AndroidForge e teste em dispositivo. Build verde não substitui teste de execução.
