# VIRTUS ELM V12 — FIX10.20 / Code180 (baseline restored)

## Baseline/version
The package identifier is deliberately restored to `versionCode 180` and `12.0-FIX10.20-PERFORMANCE-GRAPH-HISTORY-CODE180`, per user request. This is intended for uninstall/reinstall workflow; it is not an in-place upgrade over Code181/182.

## Retained app behavior
- Performance graph/history persistence and CSV history remain present.
- Default ethanol preference is local and starts at 100%; the Performance selection is session-only.
- Pedal source is explicit (APP D/E/F or throttle) and has no silent cross-signal fallback.
- Pedal calibration is in Configurations and is tied to the selected PID.
- Gear-shift estimator remains heuristic and needs real-car validation.
- App remains read-only for vehicle actuation/coding/adaptation/security access.

## DTC library hardening in this source package
- Startup performs a silent HTTPS manifest check after bundled/external local library loading.
- Remote updates require a higher semantic version, HTTP success, matching manifest/library version, SHA-256 match, nonempty schema and DTC list, unique valid codes and descriptions.
- Failed network checks leave the bundled/external offline library available.
- Manual update remains available from Settings/diagnostics.

## Verification status
Static and behavioral bench tests are included under `tests/` and `tools/`. These tests do not replace an Android build, launch on device, live ELM testing, or a real-car performance run. No claim of those validations is made by this package alone.
