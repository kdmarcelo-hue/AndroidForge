# Auditoria — FIX10.27 / CODE187: deduplicação segura dos logs

## Causa identificada
A rotina anterior de importação dos CSVs embarcados verificava somente o nome exato. Quando o MediaStore cria nomes alternativos (como `(1)` ou `(2)`), a checagem pode não reconhecer as cópias.

## Alterações
- Antes da importação dos históricos, examina os arquivos em `Download/VirtusELM/logs/`.
- Calcula SHA-256 do conteúdo completo e agrupa somente arquivos com o mesmo hash e a mesma extensão.
- Mantém o arquivo com nome canônico quando existe e tenta excluir as cópias idênticas. Também cobre nomes numerados pelo Android.
- A importação dos três CSVs embarcados só ocorre se o conteúdo exato ainda não estiver presente, mesmo que esteja sob nome alternativo.
- A deduplicação não usa apenas tamanho/nome/data e não toca em outras pastas. Arquivos com conteúdo diferente são preservados.
- Se a gravação de um CSV via MediaStore falhar, o item parcial é excluído.
- Versão: `versionCode 187`, `12.0-FIX10.27-LOG-DEDUP-CODE187`.

## Verificações feitas
- Auditoria estática dos caminhos MediaStore (Android 10+) e arquivos diretos (Android 6–9).
- Conferida integridade do ZIP e presença da rotina geral de deduplicação.
- SHA-256 calculado sobre bytes, com extensão igual como requisito adicional.

## Não verificado
Não foi compilado nem executado em dispositivo neste ambiente. O ZIP não inclui `gradlew`/`gradle-wrapper.jar`; a compilação final deve ser confirmada no GitHub Actions e depois testada no tablet.
