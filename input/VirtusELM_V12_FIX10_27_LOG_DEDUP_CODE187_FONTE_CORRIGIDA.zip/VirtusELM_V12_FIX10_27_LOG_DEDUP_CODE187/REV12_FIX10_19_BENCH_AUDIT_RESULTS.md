# Code179 — relatório de auditoria de bancada

Data da auditoria: 2026-10-21
Base examinada: ZIP Code178 disponibilizado no repositório GitHub e artefatos da execução 39677886204.

## Evidências verificadas
- Execução GitHub 39677886204: Build APK concluído com sucesso.
- A tarefa `gradle assembleDebug` concluiu com `BUILD SUCCESSFUL`.
- APK do Code178 dentro do artefato: `app-debug.apk`, 394.644 bytes.
- O projeto Code178 não continha fontes em `app/src/test` ou `app/src/androidTest`.

## Achado de segurança corrigido no Code179
A autorização `epcEvidenceSavedThisSession` era consumida apenas quando a evidência não era elegível ou falhava ao salvar. Ela não era invalidada explicitamente ao desconectar/reconectar nem após enviar Mode 04. Isso contrariava o rótulo “desta sessão” e permitia reutilizar uma autorização antiga.

Code179 invalida a autorização na desconexão, em novas tentativas de conexão (incluindo o worker usado pela auto-conexão) e imediatamente antes de enviar Mode 04. Uma nova tentativa de limpeza exige novo relatório elegível.

## Testes executados neste ambiente
Comando: `python tools/bench_audit.py`
Resultado: **11/11 verificações estáticas passaram**.

As verificações cobrem: versionamento, invalidação do gate em conexão manual/automática e desconexão, consumo do gate antes de Mode 04, revogação em falha de gravação, condições de remontagem ISO-TP, formato básico dos registros UDS 59 02, interpretação de NRC sem declarar ausência de falhas e integridade estrutural da biblioteca JSON.

## Limites explícitos
- São testes estáticos de contrato, não testes instrumentados da Activity em Android.
- Não foi possível compilar Code179 neste ambiente porque não há Android SDK/Gradle local configurado. O build de Code178 não comprova compilação de Code179.
- Não foi executado teste elétrico/OBD real, nem foi transmitido Mode 04.
- A biblioteca local continua pequena; não se deve inferir que um código sem descrição não existe.

## Procedimento de veículo sugerido
1. Instalar Code179 somente depois de o GitHub Actions concluir a compilação com sucesso; confirmar `versionCode 179`/`FIX10.19` na tela Sobre, se disponível.
2. Com o veículo parado em local seguro e ignição conforme instrução do veículo, conectar o ELM. Não conduzir enquanto opera o app.
3. Executar INVESTIGAR EPC uma vez e aguardar a conclusão. Confirmar que o arquivo `VirtusELM_EPC_Evidence_*.txt` existe em `Download/VirtusELM/logs/`.
4. Conferir no relatório: protocolo, RAW de Mode 03/07/0A, status OBD, VIN, freeze frame, respostas UDS/ISO-TP e marcações de resposta incompleta/BUFFER FULL.
5. Desconectar e reconectar sem gerar novo relatório; a limpeza deve continuar bloqueada. Repetir também após reconexão automática, se ela ocorrer.
6. Sem enviar limpeza real, verificar que a autorização não persiste após iniciar uma nova sessão. **Não pressionar “APAGAR TODOS” como teste.**
7. Guardar relatório e log. Se EPC/perda de potência reaparecer, não fazer puxadas de desempenho; interromper o teste e procurar diagnóstico automotivo.
