#!/usr/bin/env python3
"""Static bench audit for V12 FIX10.20 / Code180 baseline. No vehicle/ELM required."""
from pathlib import Path
import re
ROOT = Path(__file__).resolve().parents[1]
JAVA = (ROOT / "app/src/main/java/com/marcelo/virtuselm/MainActivity.java").read_text(encoding="utf-8")
GRADLE = (ROOT / "app/build.gradle").read_text(encoding="utf-8")
checks=[]
def check(name, condition): checks.append((name,bool(condition)))
check("Version code restored to 180 baseline", re.search(r"versionCode\s+180\b",GRADLE))
check("Version name restored to FIX10.20 Code180", "12.0-FIX10.20-PERFORMANCE-GRAPH-HISTORY-CODE180" in GRADLE)
check("Default fuel is saved locally with 100% ethanol default", 'PREF_DEFAULT_ETHANOL,100' in JAVA and 'putInt(PREF_DEFAULT_ETHANOL,p)' in JAVA)
check("Session fuel override is in-memory only", 'private volatile int performanceEthanolOverride = -1;' in JAVA and 'performanceEthanolOverride=p;' in JAVA and 'putInt(PREF_PERF_ETHANOL' not in JAVA)
check("Fuel selector is available in Performance", 'SELECIONAR COMBUSTÍVEL • SÓ ESTA SESSÃO' in JAVA and 'showEthanolDialog()' in JAVA)
check("Pedal calibration is in Configurations", 'CALIBRAÇÃO DO PEDAL' in JAVA[JAVA.index('private LinearLayout buildConfigScreen'):JAVA.index('private LinearLayout buildDataScreen')])
check("Pedal calibration button removed from Performance", 'CALIBRAR PEDAL • 0% / 100%' not in JAVA)
check("Pedal source selection explicitly supports D/E/F/throttle", all(x in JAVA for x in ['"0149"','"014A"','"014B"','"0111"']) and 'showPedalSourceDialog' in JAVA)
check("No silent fallback from APP D to throttle", 'return lastPedalD>=0?lastPedalD:lastThrottle' not in JAVA and 'private double getRawPerformancePedalPct(){ String src=getPedalSource();' in JAVA)
check("Calibration dialog identifies selected source and raw channels", 'Fonte selecionada: "+getPedalSourceLabel()' in JAVA and 'APP E: ' in JAVA)
check("Performance screen uses black/red theme", 'screen.setBackgroundColor(Color.rgb(8,8,10))' in JAVA and 'Color.rgb(255,65,75)' in JAVA)
check("Graph footer preserves PERFORMANCE left and DATA right", 'Button performance=btn("← PERFORMANCE"); Button data=btn("DADOS →")' in JAVA)
check("Performance historical graph remains available", 'bindClick(data,()->showPerformanceTestGraph())' in JAVA and 'private void showPerformanceTestGraph(){showScreen(5);loadLastPerformanceGraph();}' in JAVA)
check("Gear shift estimator remains on each OBD loop", 'gearShifts=shiftEstimator.update(rpm,speed,now);' in JAVA and JAVA.index('gearShifts=shiftEstimator.update(rpm,speed,now);') < JAVA.index('if(speed>=0 && gpsNs>0 && gpsNs!=lastProcessedGpsNs)'))
check("No actuator/coding/security access in performance test loop", all(x not in JAVA[JAVA.index('private void startPerformanceTest()'):JAVA.index('private double getRawPerformancePedalPct()')] for x in ['send("04"','send("2E','send("27']))
check("DTC library auto-check runs after bundled/local load", 'loadExternalDtcLibrary(); ui(()->updateDtcLibraryStatus()); checkDtcLibraryUpdateSilently();' in JAVA)
check("DTC remote update verifies SHA-256 before use", 'expected.equals(sha256(bytes))' in JAVA)
check("DTC parser rejects empty/invalid/duplicate libraries", 'arr.length()==0' in JAVA and 'parsed.containsKey(code)' in JAVA and 'throw new IOException("Código/descrição DTC inválido' in JAVA)
check("DTC auto-update failure preserves offline fallback", 'mantendo biblioteca local' in JAVA)
check("Performance shows explicit incomplete data instead of fake values", 'dados insuficientes' in JAVA and 'não concluído' in JAVA)
for name,ok in checks: print(('PASS' if ok else 'FAIL')+' | '+name)
print(f'RESULT: {sum(ok for _,ok in checks)}/{len(checks)} checks passed')
raise SystemExit(0 if all(ok for _,ok in checks) else 1)
