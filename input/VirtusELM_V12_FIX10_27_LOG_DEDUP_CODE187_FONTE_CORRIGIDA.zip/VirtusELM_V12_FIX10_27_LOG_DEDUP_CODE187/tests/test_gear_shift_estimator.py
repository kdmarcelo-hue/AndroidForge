#!/usr/bin/env python3
"""Behavioral bench model for the V12 upshift estimator; no car or ELM required."""

class Estimator:
    def __init__(self):
        self.pr=-1; self.ps=-1; self.cr=-1; self.cs=-1; self.cn=0; self.ln=0; self.n=0
    def update(self, rpm, speed, t):
        if rpm < 900 or speed < 0 or t <= 0:
            self.pr, self.ps = rpm, speed
            return self.n
        if self.cn:
            age=t-self.cn
            speed_ok=speed >= self.cs-1.5 and speed >= self.ps-1.5
            recovered=rpm >= self.cr+max(250, self.cr*.06)
            if age <= 2.5 and recovered and speed_ok and (not self.ln or t-self.ln>=1.2):
                self.n+=1; self.ln=t; self.cn=0
            elif age>2.5 or speed<self.cs-3:
                self.cn=0
        if not self.cn and self.pr>=3000 and rpm>=1000 and rpm<=self.pr-500 and speed>=self.ps-1.5 and (not self.ln or t-self.ln>=1.2):
            self.cr,self.cs,self.cn=rpm,speed,t
        self.pr,self.ps=rpm,speed
        return self.n

def run(samples):
    e=Estimator()
    for t,rpm,speed in samples: e.update(rpm,speed,t)
    return e.n

# Drop and recovery while speed rises -> one shift.
assert run([(1.0,3500,30),(1.2,3700,31),(1.4,2600,32),(1.6,2700,33),(1.8,3000,34)]) == 1
# RPM drop while vehicle speed falls -> do not start a shift candidate.
assert run([(1.0,3500,50),(1.2,3600,49),(1.4,2500,46),(1.6,2800,44),(1.8,3100,42)]) == 0
# Drop without a plausible RPM recovery -> no confirmed shift.
assert run([(1.0,3500,30),(1.2,3600,31),(1.4,2500,32),(1.6,2450,33),(1.8,2400,34),(2.0,2380,35)]) == 0
# A single event cannot be counted multiple times without a new drop/recovery cycle.
assert run([(1.0,3500,30),(1.2,3700,31),(1.4,2600,32),(1.6,2800,33),(1.8,3100,34),(2.0,3200,35)]) == 1
print('PASS | upshift with speed rising -> 1')
print('PASS | RPM drop with falling speed -> 0')
print('PASS | no RPM recovery -> 0')
print('PASS | one event counted once -> 1')
print('RESULT: 4/4 behavioral cases passed')
