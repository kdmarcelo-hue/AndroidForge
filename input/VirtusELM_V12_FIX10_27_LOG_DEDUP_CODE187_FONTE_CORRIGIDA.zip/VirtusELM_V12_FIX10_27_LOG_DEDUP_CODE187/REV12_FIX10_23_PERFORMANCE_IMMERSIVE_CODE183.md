# V12 — FIX10.23 / Code183: tema imersivo Performance

## Objetivo
Corrigir a inconsistência visual observada na captura do modo Performance, em que o cabeçalho fixo e a navegação inferior permaneciam azuis enquanto a tela central já usava detalhes vermelhos.

## Alterações desta revisão
- Introduz o estado visual `performanceImmersive`, ativado ao entrar na tela Performance (screen 6) e desativado ao sair.
- Aplica gradiente vermelho escuro/preto e contorno vermelho ao cabeçalho fixo e à navegação inferior; ícones e rótulos da navegação passam a usar vermelho/branco no modo Performance.
- Reestiliza botões e cartões de métricas da tela Performance com fundos preto/vinho e acentos vermelhos, mantendo o destaque amarelo do estado armado/aguardando.
- Ao sair da tela Performance, restaura a paleta azul padrão da moldura fixa e dos botões.
- Incrementa a versão para `12.0-FIX10.23-PERFORMANCE-IMMERSIVE-CODE183` / versionCode 183.

## Requisitos visuais preservados
1. Pronto para teste: tema vermelho/preto.
2. Armado/aguardando início: destaque amarelo no status.
3. Puxada em andamento: manter status de execução destacado; dados reais continuam sendo fornecidos pela aquisição existente.
4. Conclusão: manter o tema esportivo e apresentar apenas resultados calculados a partir das amostras válidas.
5. Sair de Performance: retornar ao tema normal.

## Limites da validação
A alteração foi aplicada na fonte Java e no `versionCode`/`versionName`. É necessário executar o workflow Android Build e validar a tela no dispositivo/emulador. Esta documentação não declara que a interface foi testada visualmente nem que a compilação foi executada após a alteração. A cor vermelha não representa autorização para executar testes de aceleração em via pública.
