# Auditoria de entrega — VIRTUS ELM V12 FIX10.20 / Code180

## Alterações nesta entrega
- Restaurado `versionCode 180` e `versionName 12.0-FIX10.20-PERFORMANCE-GRAPH-HISTORY-CODE180`, conforme solicitado.
- Mantida seleção explícita de fonte do pedal (APP D/E/F ou throttle), sem fallback silencioso entre sinais.
- Mantida preferência de etanol padrão (100% inicial) e seleção de combustível temporária por sessão.
- Adicionada verificação silenciosa da biblioteca DTC na inicialização.
- Endurecida a validação de biblioteca DTC: schema/versão/códigos não vazios, códigos válidos e únicos, SHA-256 do manifesto e versão do JSON alinhada antes de persistir.
- Falha de rede mantém a biblioteca local/offline disponível.
- Ao finalizar a puxada, a UI diferencia dados insuficientes e apresenta comparação com até três puxadas anteriores comparáveis; melhorias são explicitadas sem declarar recorde quando não houver evidência.
- Mantida a proteção read-only para atuação, coding, adaptation e security access.

## Testes executados localmente
- `tests/bench_fix10_20.py`: **20/20** verificações estáticas aprovadas.
- `tests/test_gear_shift_estimator.py`: **4/4** casos comportamentais aprovados.
- `tools/bench_audit.py`: **13/13** testes aprovados.
- JSON da biblioteca/manifesto: parse válido.
- SHA-256 do manifesto confere com `library/dtc_vag.json`.
- Asset DTC embutido confere byte a byte com a biblioteca do repositório.

## Limites da auditoria
- **Não foi possível executar build Android local** neste ambiente: não há `gradle` instalado nem distribuição Gradle 8.7 em cache; o ZIP também não contém `gradlew`.
- Portanto, este pacote é **código-fonte auditado por testes locais, não APK compilado/validado**. A compilação deve ser confirmada pelo workflow AndroidForge.
- A atualização DTC em tempo real depende de o manifesto/JSON estarem publicados no caminho configurado do repositório. A checagem automática falha silenciosamente e preserva a biblioteca local se a rede/endpoint falhar.
- O estimador de troca de marcha e as medições de performance continuam exigindo validação em carro real; potência/torque são estimativas e não substituem dinamômetro.
- Code180 é intencional para reinstalação limpa. Não é atualização in-place sobre Code181/182; desinstalar antes remove os dados privados do app, então exporte/preserve os CSVs antes se precisar deles.
