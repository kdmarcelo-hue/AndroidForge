# Auditoria de bancada — FIX10.20 / Code180

Data: 2026-10-24

## Resultado
- 17/17 verificações estáticas automatizadas aprovadas (`python3 tests/bench_fix10_20.py`).
- A análise sintática do `javac` não indicou erros de sintaxe Java; o `javac` local não consegue compilar a aplicação porque não há Android SDK/`android.jar` instalado.
- APK ainda não foi compilado neste ambiente. A compilação Android oficial deve ser feita pelo workflow AndroidForge.
- Nenhum teste físico com ELM327, GPS ou veículo foi realizado.

## Correções incluídas
1. Separação de modos: menu GRÁFICOS e aba GRÁFICOS em DADOS continuam mostrando telemetria ao vivo; VER GRÁFICOS DO TESTE abre o histórico da puxada.
2. Rodapé da tela de gráficos dividido em dois botões: PERFORMANCE à esquerda e DADOS à direita.
3. Captura de amostras apenas durante a puxada, a partir do instante de início identificado pelo GPS, até a finalização.
4. Ponto de referência em tempo zero com velocidade igual a zero; RPM, pedal e boost permanecem com os valores disponíveis, sem zeragem artificial.
5. Registro de amostras `PERFORMANCE_SAMPLE` no CSV de cada puxada e recarga do último gráfico após reiniciar o aplicativo.
6. O gráfico histórico não recebe atualizações da telemetria ao vivo e não inventa dados quando não existem amostras.
7. Leitura periódica de PID 0149 durante o teste, com PID 0111 como fallback quando a leitura de pedal não responde, evitando consultas extras a cada iteração.
8. Calibração manual e reversível de pedal: valor bruto de pedal solto vira 0%; valor bruto no fim de curso vira 100%. A escala só é normalizada depois que ambos os pontos forem registrados.

## Limitações que devem permanecer explícitas
- CSVs antigos de puxadas não têm amostras históricas; não é possível reconstruir uma curva real retroativamente a partir apenas do tempo final e dos máximos. O gráfico não inventa uma curva estimada.
- O gráfico histórico em si contém velocidade GPS, RPM, pedal normalizado e boost medidos. Leituras indisponíveis são lacunas, não valores estimados.
- A calibração do pedal depende de leituras reais e deve ser executada com o veículo imobilizado. Não presumir que 88% bruto equivale a 100% sem fazer a calibração.
- Antes do teste na rua/pista, compilar o APK, instalar, confirmar a navegação e fazer a primeira puxada em local legal e seguro. Não realizar teste de aceleração em via pública.
