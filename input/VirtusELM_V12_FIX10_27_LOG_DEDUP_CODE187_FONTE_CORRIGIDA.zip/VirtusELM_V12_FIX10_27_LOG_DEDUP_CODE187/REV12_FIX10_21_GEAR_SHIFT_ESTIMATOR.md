# V12 FIX10.21 — estimador de troca de marcha

## Correção
A estimativa anterior só avaliava a queda de RPM quando chegava uma amostra nova de GPS. Isso podia perder a queda rápida, pois RPM é consultado pelo OBD em outro ritmo.

O novo estimador avalia RPM em cada ciclo OBD. Uma queda de pelo menos 500 RPM, partindo de 3000 RPM ou mais, inicia um candidato quando a velocidade não caiu mais que 1,5 km/h. A troca só é confirmada se o RPM recuperar pelo menos 250 RPM ou 6% (o maior dos dois) em até 2,5 s e a velocidade permanecer coerente. Há tolerância para ruído e intervalo de 1,2 s entre confirmações. Candidatos expirados ou acompanhados por queda relevante de velocidade são descartados.

A contagem continua sendo estimativa, não leitura direta da marcha engrenada: velocidade GPS pode atualizar mais lentamente que RPM e condições como patinagem, embreagem ou reduções podem criar padrões semelhantes. Não há comandos de atuação, codificação ou alteração da ECU.

## Validação de bancada
- `python tests/bench_fix10_20.py`: verificações estáticas da integração e das proteções.
- `python tests/test_gear_shift_estimator.py`: quatro sequências comportamentais (troca provável, desaceleração, ausência de recuperação e prevenção de duplicação).
- APK deve ser compilado pelo workflow AndroidForge; compilação local não foi possível porque o pacote não contém `gradlew`.
