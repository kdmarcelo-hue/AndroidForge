# V12 FIX10.19 — Session-scoped DTC evidence gate

## Achado da auditoria Code178
O estado `epcEvidenceSavedThisSession` era invalidado quando o relatório não era elegível ou falhava ao salvar, mas não era invalidado ao desconectar/reconectar. Isso permitia que uma evidência de uma conexão anterior continuasse habilitando a tela de confirmação de Mode 04 numa sessão posterior. Além disso, após enviar Mode 04, a autorização permanecia marcada e poderia ser reutilizada.

## Correção aplicada
- Invalida autorização e nome do relatório quando o usuário inicia uma desconexão.
- Invalida autorização no início de cada nova tentativa de conexão.
- Consome a autorização imediatamente antes de transmitir Mode 04, de modo que nova tentativa exige nova investigação e relatório.
- Preserva o nome do arquivo usado no resultado da operação já iniciada.
- Incrementa `versionCode` para 179 e define `12.0-FIX10.19-SESSION-GATE-FIX`.

## Limitação
Esta correção restringe a autorização à sessão e a uma tentativa de limpeza; não valida mecanicamente que todos os módulos do veículo foram consultados. A limpeza real não deve ser usada como teste de bancada.
