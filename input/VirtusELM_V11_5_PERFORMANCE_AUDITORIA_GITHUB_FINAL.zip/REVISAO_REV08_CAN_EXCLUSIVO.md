# V11.0 REV08 — CAN EXCLUSIVO + SERIALIZAÇÃO DE I/O

## Objetivo
Corrigir a concorrência entre o polling OBD/telemetria e o `Monitor All` do ELM327.

## Alterações
- Toda comunicação Bluetooth/ELM do dashboard agora é enfileirada no `ExecutorService` único de I/O.
- Ao iniciar CAN Monitor, `monitoring=true` e `operationRunning=true` são reservados antes do trabalho ser enfileirado.
- A rotina CAN não dispara mais `0100` nem qualquer bateria de PIDs antes do `AT MA`.
- O protocolo é detectado com `ATDP` e fixado em `ATSP6` para CAN 11/500 (ou `ATSP7` para CAN 29/500).
- Configuração mínima antes do monitor: `ATE0`, `ATH1`, `ATS1`, `ATL0`, `ATAT1`.
- Buffer de entrada é drenado antes do `AT MA`.
- Durante `AT MA`, o polling OBD permanece bloqueado.
- Ao finalizar, a captura espera o prompt antes de liberar o modo OBD.
- Em timeout, a conexão é fechada e a reconexão automática é mantida.

## Segurança
O modo continua somente leitura. Não há comandos de atuação, coding, adaptation, security access ou CAN arbitrário.

## UI preservada
A identidade visual da V11.0 REV07 permanece como base. Esta revisão não altera o desenho do dashboard além do necessário para manter o layout de conexão.

## Limitação
O projeto não contém o Gradle Wrapper completo (`gradlew`/`gradle-wrapper.jar`). O workflow do GitHub Actions existente usa Gradle 8.7 diretamente e continua disponível.
