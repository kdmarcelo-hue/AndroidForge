# VIRTUS ELM — V11.1 — AJUSTE FINAL DO CABEÇALHO

## Objetivo
Corrigir exclusivamente o corte inferior percebido no texto branco `VIRTUS` no cabeçalho principal, sem alterar a composição restante.

## Alterações
- `VIRTUS` reduzido de 18sp para 16sp.
- Bloco textual do cabeçalho deslocado 3dp para cima.
- Alturas internas do título/subtítulo/slogan ajustadas apenas para acomodar o novo posicionamento.
- Imagem do Virtus, logo, conexão, telemetria, Dados/Logs, diagnóstico, CAN e demais funções mantidos.

## Regra
Nenhuma outra alteração funcional ou visual fora do bloco textual do cabeçalho.
