package com.marcelo.virtuselm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

public class RecordingKeepAliveService extends Service {
    private static final String CHANNEL_ID = "virtus_elm_recording";
    private static final int NOTIFICATION_ID = 1101;
    @Override public void onCreate(){ super.onCreate();
        if(Build.VERSION.SDK_INT>=26){ NotificationManager nm=getSystemService(NotificationManager.class); if(nm!=null) nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID,"VIRTUS ELM — Gravação",NotificationManager.IMPORTANCE_LOW)); }
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL_ID):new Notification.Builder(this);
        b.setContentTitle("VIRTUS ELM — gravação ativa").setContentText("Registrando MAP, BARO, BOOST, RPM e telemetria").setSmallIcon(com.marcelo.virtuselm.R.drawable.ic_app_logo).setOngoing(true).setCategory(Notification.CATEGORY_SERVICE);
        if(Build.VERSION.SDK_INT>=29) startForeground(NOTIFICATION_ID,b.build(),android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE); else startForeground(NOTIFICATION_ID,b.build());
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){ return START_NOT_STICKY; }
    @Override public void onDestroy(){ super.onDestroy(); stopForeground(true); }
    @Override public IBinder onBind(Intent intent){ return null; }
}
