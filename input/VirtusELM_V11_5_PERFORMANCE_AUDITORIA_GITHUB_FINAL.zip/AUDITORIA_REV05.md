# VIRTUS ELM — V11.0 — AUDITORIA REV05

## Objetivo
Revisão da interface V11.0 e correção do encerramento da Activity durante tentativas repetidas de conexão Bluetooth.

## Falha funcional encontrada
A Activity possuía o campo `status`, mas ele nunca era inicializado. `setStatus()` executava `status.setText(...)` na thread principal. A rotina de conexão chama `setStatus()` em vários caminhos (inclusive falha, Bluetooth desligado, ELM ausente e início da conexão). Isso podia gerar `NullPointerException` e encerrar a Activity.

### Correção
- `setStatus()` passou a ser null-safe.
- Foi criado um objeto de status interno, mantido fora da composição visual principal.
- O botão de conexão agora fica desabilitado durante toda a tentativa de conexão, inclusive durante a inicialização AT do ELM.
- `toggleConnection()` bloqueia reentrada quando `connectAttempt` ou `operationRunning` estiver ativo.
- A tentativa de conexão é desabilitada imediatamente antes de solicitar permissão Bluetooth, evitando duplo clique/reentrada.
- Ao falhar uma conexão, o botão retorna explicitamente ao estado `CONECTAR ELM`.
- Nenhum erro de conexão deve chamar `finish()`, `finishAffinity()` ou encerrar a Activity.

## Ajustes de layout
- Navegação inferior retirada do overlay sobre o conteúdo; agora ocupa uma área própria no rodapé da tela.
- Maior área útil para os ícones da navegação inferior.
- Hero/header reduzido para aproximar a proporção da referência aprovada.
- Barra de conexão redimensionada para evitar corte de `ELM327 v1.5`, estado e botão.
- Cards de telemetria dimensionados com tipografia separada para título, valor e unidade.
- Cards de módulos redimensionados e tipografia reduzida de forma controlada para manter títulos completos.
- Botões operacionais com largura mínima zero, padding reduzido e autosize para evitar truncamento.
- Mantida rolagem vertical.

## Preservação funcional
A revisão é de apresentação e robustez de conexão. A arquitetura funcional da V10.9/V11.0 foi preservada: OBD-II somente leitura, VIN, PIDs, DTC/Freeze Frame, CAN Monitor All passivo, marcadores, análise, log, watchdog e reconexão automática.

## Bluetooth
O projeto continua usando `BLUETOOTH_CONNECT` para comunicação com dispositivo Bluetooth já pareado. Não foi adicionada descoberta Bluetooth desnecessária.

## Build
AGP 8.5.2 / Gradle 8.7 / compileSdk 34 / targetSdk 34 / minSdk 23.

A compilação Android completa não é executável neste ambiente por ausência do Android SDK/Gradle. O projeto foi auditado estaticamente e permanece configurado para o workflow GitHub existente.

## Complemento — feedback de interação
- Todos os controles acionáveis da tela foram centralizados em `bindClick(...)`.
- Clique produz feedback háptico por `View.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)` sem exigir a permissão VIBRATE.
- Botões mantêm estado visual `pressed` por `StateListDrawable`.
- Cards de MÓDULOS e itens da navegação inferior também receberam estado visual `pressed`.
- O feedback háptico ocorre uma vez por ativação, evitando vibração dupla.
