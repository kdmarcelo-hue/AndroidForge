# V11.0 REV09 — Build Fix

## Motivo
O GitHub Actions reportou falha de compilação em `MainActivity.java` com 50 erros `cannot find symbol`, todos decorrentes das variáveis do módulo de gravação de telemetria que não estavam presentes na cópia efetivamente compilada pelo workflow.

Variáveis declaradas explicitamente nesta revisão:
- `recordingActive`
- `recordingWriter`
- `recordingFile`
- `recordingStartMs`
- `recordingSamples`
- `recordingTick`
- `recordingMaxBoost`

## Outras correções administrativas
- `settings.gradle`: `rootProject.name` atualizado para `VirtusELM_V11_0`.

## CAN
A arquitetura CAN exclusiva da REV08 foi preservada. Esta revisão não altera a política somente leitura nem a lógica de captura CAN; corrige apenas a integridade de compilação.
