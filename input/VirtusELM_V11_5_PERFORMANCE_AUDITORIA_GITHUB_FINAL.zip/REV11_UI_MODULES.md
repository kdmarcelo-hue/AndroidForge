REV11 — AJUSTE VISUAL DOS MÓDULOS

- Corrige corte de títulos/subtítulos nos cards de MÓDULOS.
- Títulos agora podem ocupar até 2 linhas.
- Subtítulos agora podem ocupar até 2 linhas.
- Reduz a área do ícone e da seta para liberar largura ao texto.
- Aumenta a altura dos cards para acomodar o texto sem clipping.
- Cria ic_vehicle.xml e usa o ícone de veículo explicitamente em VIRTUS / VAG.
- Não altera a lógica OBD/CAN, Bluetooth, telemetria ou segurança somente leitura.
