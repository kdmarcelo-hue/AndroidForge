# VIRTUS ELM V11.0 — REV05 UI + TELEMETRIA AUDITADA

## Correções desta revisão
- Identificação visual do veículo corrigida para **Volkswagen Virtus 1.0 TSI • Stage 2**.
- VIN: parser ISO-TP Mode 09 02 revisado para ignorar cabeçalho CAN/PCI das linhas de primeiro e consecutive frame, evitando caracteres espúrios.
- Cards de módulos: tipografia autoajustável, área de texto ampliada e remoção de truncamento/reticências.
- Botões: autoajuste de texto preservado; dimensões mantidas para a composição aprovada.
- Barra de RPM customizada de 0–8.000 rpm:
  - 0–4.000: verde claro;
  - 4.000–6.000: amarelo;
  - 6.000–8.000: vermelho;
  - segmentos inativos permanecem visíveis em baixa intensidade na mesma faixa de cor.
- Telemetria/CSV, watchdog, CAN passivo, proteção de conexão, feedback tátil e manter tela ligada preservados.

## Critério
A revisão continua sendo **V11.0**; trata-se de ajuste de UI/telemetria, sem alteração do versionName.
