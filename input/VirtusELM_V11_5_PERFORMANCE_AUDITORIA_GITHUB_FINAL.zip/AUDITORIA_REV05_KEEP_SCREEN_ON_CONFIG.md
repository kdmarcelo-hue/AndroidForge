# VIRTUS ELM V11.0 — REV05 — CONFIGURAÇÃO DE TELA

## Alteração
A preferência **MANTER TELA LIGADA** foi adicionada ao menu CONFIGURAÇÕES.

- Padrão inicial: **ON**.
- Persistência: `SharedPreferences`.
- ON: aplica `WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON`.
- OFF: remove a flag e devolve o comportamento normal de timeout da tela do Android.
- A opção é reaplicada em `onResume()`.
- O item Config da navegação inferior agora leva à seção CONFIGURAÇÕES.
- O controle fornece feedback háptico ao ser acionado.

## Segurança/energia
Não foi usado `WakeLock` para esta função. A implementação usa a flag da `Window`, apropriada quando a tela deve permanecer ativa somente enquanto a Activity está visível.

## Preservação
Nenhuma rotina OBD/CAN, reconexão, diagnóstico, polling ou captura foi removida nesta alteração.
