# V11.0 — REV12 — ALINHAMENTO FINAL DO CABEÇALHO

## Objetivo
Corrigir exclusivamente a composição textual do cabeçalho após o teste visual da REV11.

## Alterações
- Mantido o espaço reservado à imagem do Virtus exatamente em `125dp x 70dp`.
- Mantida a posição vertical do carro, já aprovada visualmente.
- `VIRTUS` reduzido para 18sp para eliminar corte.
- `VIRTUS` centralizado horizontalmente no bloco textual.
- `V11.0 • DIAGNÓSTICO` centralizado no mesmo eixo.
- `LEITURA • ANÁLISE • CAN` centralizado no mesmo eixo.
- Removido o font padding dos três textos para melhorar alinhamento vertical.
- Nenhuma alteração na comunicação Bluetooth, OBD-II, telemetria, CAN Monitor ou regras de somente leitura.
- Nenhuma alteração no tamanho da célula/imagem do carro.
