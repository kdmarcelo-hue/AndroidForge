# V11.0 — REV07 — AJUSTE FINO DO CABEÇALHO E CONEXÃO

## Alterações aprovadas

### 1. Cabeçalho
- Título principal reduzido para `VIRTUS`.
- Mantido `V11.0 • DIAGNÓSTICO`.
- Mantido `LEITURA • ANÁLISE • CAN` imediatamente abaixo do subtítulo, dentro do mesmo bloco textual.
- Removida a composição `VIRTUS ELM` para eliminar o corte do `M`.
- Removido o texto gráfico `M / G` que fazia parte do PNG do carro.
- Criado `v11_car_header_clean.png`, com a área gráfica `M / G` recortada.
- Carro alinhado verticalmente para baixo, apoiado visualmente na base da célula do cabeçalho, evitando aparência de estar flutuando.

### 2. Barra de conexão
Nova ordem visual:

`OFFLINE` → `Bluetooth` → `CONECTAR ELM`

- Estado OFFLINE permanece no primeiro bloco.
- Ícone Bluetooth centralizado no segundo bloco.
- Botão CONECTAR ELM no terceiro bloco.
- Larguras passaram a usar pesos proporcionais em vez de larguras fixas.
- Objetivo: eliminar o corte da borda direita do botão em telas estreitas.

### 3. Cabeçalho do painel de RPM
- `RPM DO MOTOR` alterado para `ROTAÇÃO DO MOTOR`, evitando repetição desnecessária com o valor `0 rpm`.
- Removido o texto fixo `VIRTUS 1.0 TSI • STAGE 2` do estado inicial.
- O perfil `VIRTUS 1.0 TSI • STAGE 2` somente aparece quando o VIN lido corresponde ao VIN de referência do veículo do projeto.
- Para outro VIN, não é exibido `STAGE 2` nem perfil específico do veículo.

### 4. Identificação inferior do veículo
- Estado inicial: `VEÍCULO NÃO IDENTIFICADO`.
- Para o VIN de referência do projeto: `Volkswagen Virtus 1.0 TSI • Stage 2`.
- Para outro VIN: `VEÍCULO IDENTIFICADO`, sem atribuir Stage 2 ou modelo específico sem validação.

## Escopo
Alterações exclusivamente de UI/apresentação e identificação condicionada ao VIN. Nenhuma alteração intencional na lógica de Bluetooth, OBD-II, telemetria, DTC, CAN, gravação ou diagnóstico.

## Build
O projeto continua sem `gradlew`/wrapper JAR no pacote original. A REV07 foi aplicada ao código-fonte e empacotada; APK novo não foi compilado neste ambiente.
