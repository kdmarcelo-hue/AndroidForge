# V11.0 REV10 — Build fix

Correção baseada no log real do GitHub Actions da REV09.

Erro encontrado:
`ImageView` não possui `setGravity(int)`. O gravity deve ser aplicado ao `LayoutParams`, que já era configurado no código.

Correção:
- removido `car.setGravity(Gravity.CENTER_HORIZONTAL|Gravity.BOTTOM)`;
- mantido `carLp.gravity=Gravity.BOTTOM`;
- nenhuma alteração na lógica OBD/CAN, telemetria ou interface além dessa correção de compilação.

REV10 mantém a arquitetura CAN exclusiva da REV08/REV09.
