# VIRTUS ELM — V11.0 — REVISÃO 04 — UI

Base funcional preservada. Esta revisão é predominantemente visual e de ergonomia, usando como referência direta o mockup aprovado da V11.0.

## Correções principais
- Layout dimensionado em `dp` em vez de dimensões fixas em pixels para evitar compressão/clipping em telas Android de alta densidade.
- Hero/header reorganizado para aproximar logo, título, subtítulo, carro e slogan da referência.
- Conexão Bluetooth reorganizada em uma única linha: ELM327, estado OBD e ação de conexão/desconexão.
- Botão de desconexão passa a ter identidade vermelha quando conectado.
- Dashboard reorganizado na mesma ordem visual da referência: velocidade, boost, tensão, carga; MAP, BARO, throttle, combustível.
- Inclusão visual e leitura OBD somente leitura para velocidade, carga, temperatura do líquido e temperatura de admissão.
- Módulos com ícones vetoriais, títulos, subtítulos e setas, sem Unicode/emoji como ícone principal.
- Cabeçalho MÓDULOS e texto “SELECIONE UMA FUNÇÃO” alinhados na mesma linha.
- Navegação inferior com ícones vetoriais maiores e rótulos legíveis.
- Botões interativos mantêm área mínima adequada; o Android recomenda pelo menos 48dp para alvos de toque. [Android Developers]
- Nenhuma função de atuação, coding, adaptation, security access ou CAN arbitrário foi adicionada.

## Observação de build
A auditoria estática foi executada neste ambiente. Não há Android SDK/build-tools instalados localmente para executar uma compilação Android completa; o build reproduzível continua sendo o pipeline do GitHub.
