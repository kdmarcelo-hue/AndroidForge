# V11.0 — REV06 — CORREÇÃO DO CABEÇALHO

## Alteração

Correção exclusiva da composição do cabeçalho da tela inicial para eliminar corte/sobreposição de textos em telas estreitas.

### Antes
- `VIRTUS ELM` — 26sp
- `V11.0 • DIAGNÓSTICO VAG` — 12sp
- `LEITURA • ANÁLISE • DESEMPENHO • CAN` — 10sp
- Logo 70dp
- Carro 155x70dp

### REV06
- `VIRTUS ELM` — 22sp
- `V11.0 • DIAGNÓSTICO` — 10.5sp
- `LEITURA • ANÁLISE • CAN` — 9sp
- Logo 58x58dp
- Carro 125x58dp
- Padding do cabeçalho reduzido

## Objetivo

Priorizar 100% de legibilidade e integridade textual. Nenhuma palavra deve ser cortada ou invadir a área da imagem do Virtus.

## Escopo

Somente composição visual do cabeçalho. Nenhuma alteração foi feita na lógica de Bluetooth, OBD-II, telemetria, DTC, CAN, gravação ou diagnóstico.

## Observação de build

O ZIP original não contém o script `gradlew`, apenas `gradle-wrapper.properties`; portanto esta revisão foi aplicada ao código-fonte, mas o APK não foi recompilado neste ambiente.
