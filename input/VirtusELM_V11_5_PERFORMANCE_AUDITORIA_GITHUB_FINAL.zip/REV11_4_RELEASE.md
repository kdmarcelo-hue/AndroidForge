# VirtusELM V11.4

Base: V11.2 multi-screen architecture.

## Included
- VersionCode 114 / VersionName 11.4.
- Fixed header preserved; VIRTUS logo V uses electric cyan/blue tint.
- Header car image anchored to the bottom edge of the header area.
- Engine cluster gains oil temperature readout below the RPM segmented bar.
- Oil temperature uses OBD-II PID 015C when the ECU exposes it; parser applies A - 40 °C.
- Oil temperature is recorded in CSV as `oil_temp_c`.
- Oil level field is reserved as `oil_level` and remains `—` until a validated VAG/G266 CAN path is identified. No value is fabricated.
- DADOS screen gains secondary navigation: TELEMETRIA / GRÁFICOS / LOGS.
- New GRÁFICOS screen with one large live graph and selectable RPM / BOOST / THROTTLE / VELOCIDADE series.
- Existing Bluetooth/OBD polling, recording, passive CAN monitor, diagnostics, keep-screen-on and fixed top/bottom navigation remain in place.

## Safety / data integrity
Read-only architecture is preserved. No actuation, coding, adaptation, Security Access or arbitrary CAN transmission was added.

## Build
GitHub Actions workflow builds `assembleDebug` with JDK 17 and Gradle 8.7 and uploads `VirtusELM-V11.4-debug`.
