# V11.2 — Interface Multitelas

## Objetivo
Transformar a interface em uma estrutura de três regiões persistentes:

1. Cabeçalho fixo no topo: identidade VIRTUS, versão, leitura/análise/CAN e imagem do veículo.
2. Área central dinâmica: somente o conteúdo da tela selecionada é trocado.
3. Menu fixo no rodapé: Início, Dados, Diagnóstico, CAN e Config.

## Navegação
- Removido o botão visual `VOLTAR` da tela Dados/Logs.
- A navegação entre telas é feita pelo menu inferior.
- O cabeçalho e o menu permanecem visíveis durante a navegação.
- Trocar de tela apenas altera a visibilidade da área central.

## Continuidade operacional
A navegação não chama reset, disconnect, reconnect, stopRecording, stopMonitor ou qualquer rotina de aquisição. Conexão Bluetooth, polling OBD, captura CAN e gravação de telemetria continuam independentes da tela exibida.

## Telas centrais
- Início: conexão, dashboard, módulos e resultado.
- Dados: gravação, CSV e log técnico com rolagem interna.
- Diagnóstico: rotinas OBD-II/DTC.
- CAN: captura/análise CAN somente leitura.
- Config: preferências do aplicativo.

## Preservado da V11.1
- PID 010F separado do PID 0105, com parser `A - 40 °C` para temperatura de admissão.
- Log técnico em área fixa com rolagem interna.
- Gravação de telemetria e CSV.
- Arquitetura de leitura somente, sem atuação/coding/adaptation/Security Access/CAN arbitrário.
- Cabeçalho otimizado da V11.1.
