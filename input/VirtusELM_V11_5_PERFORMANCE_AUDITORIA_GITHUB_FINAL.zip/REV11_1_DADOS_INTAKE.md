# V11.0 REV11.1 — Dados/Logs + Temperatura de Admissão

## Alterações

1. **Menu Dados separado da tela principal**
   - O botão inferior `Dados` abre uma tela própria.
   - O módulo `GRAVAÇÃO DE DADOS` também abre essa tela.
   - O log técnico foi removido da página principal.
   - Os controles de gravação de telemetria (iniciar/finalizar, resumo e copiar CSV) ficam nessa tela.

2. **Log técnico com área fixa e rolagem interna**
   - A janela do log ocupa uma área de altura flexível dentro da tela Dados, sem aumentar a altura da página principal.
   - O conteúdo do log cresce dentro de um `ScrollView` interno.
   - Ao chegar uma nova linha, a área é rolada para o final automaticamente.
   - `COPIAR LOG` e `LIMPAR LOG` ficam fora do log e continuam acessíveis.
   - `RESULTADO` também fica na tela Dados.

3. **Temperatura de admissão — PID 010F**
   - Corrigido o parser: PID `010F` usa a fórmula OBD-II `A - 40 °C`.
   - O parser de temperatura do líquido (`0105`) continua separado.
   - Isso corrige o caso em que `TEMP. ADMISSÃO` permanecia em `— °C` apesar da consulta `010F` ser executada.

## Preservado

- Cabeçalho REV12 aprovado.
- Posição/tamanho da imagem do Virtus.
- Interface de conexão/Bluetooth.
- Telemetria OBD-II.
- Identificação por VIN e perfil Stage 2.
- CAN Monitor exclusivo da REV08/REV10.
- Parser CAN e somente leitura.
- DTC, diagnóstico e demais módulos.
- Não foi alterada nenhuma rotina de atuação, coding, adaptation, Security Access ou transmissão CAN arbitrária.
