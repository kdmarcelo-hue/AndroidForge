# VIRTUS ELM V11.0 — REV05 — KEEP SCREEN ON

## Correção
Adicionado `WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON` na Activity principal.

A flag é aplicada em `onCreate()` e reaplicada em `onResume()`.

## Comportamento esperado
Enquanto a Activity estiver visível, o Android não deverá desligar/escurecer a tela por inatividade causada pelo timeout normal do sistema.

Isso não força o aparelho a permanecer ligado em situações controladas pelo sistema, como desligamento manual da tela, encerramento da Activity ou políticas de economia de energia do fabricante.

## Base técnica
A documentação oficial do Android recomenda `FLAG_KEEP_SCREEN_ON` para impedir que a janela da Activity faça a tela entrar em modo de suspensão enquanto ela estiver em uso.
