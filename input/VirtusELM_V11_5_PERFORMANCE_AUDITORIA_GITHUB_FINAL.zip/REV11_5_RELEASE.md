# VirtusELM V11.5 — Performance + Auditoria Visual

- V11.5 / versionCode 115.
- Home auditada: cards com dimensões/alinhamentos internos uniformes e títulos sem quebra arbitrária.
- Cabeçalho ajustado: carro ancorado na base e composição VIRTUS/versão revisada.
- Card SENSORES substituído por PERFORMANCE, mantendo a posição e identidade visual.
- Performance abre diretamente pelo card da Home, sem novo item na barra inferior.
- Novo módulo Performance: 0–100 km/h, boost máximo e estimativa preliminar de potência/torque baseada em dinâmica longitudinal.
- A potência é explicitamente apresentada como estimativa, com ressalva sobre massa, inclinação, aderência e condições do teste.
- Mantido o princípio somente leitura; nenhum comando de atuação/coding/adaptation/security access/CAN arbitrário foi adicionado.
- Demais módulos, telemetria, gráficos, logs, diagnóstico, CAN e gravação preservados.

## Observação de validação
A fonte foi revisada e empacotada para GitHub. A compilação Android completa deve ser confirmada pelo workflow do GitHub Actions, pois este ambiente não possui Gradle/SDK Android local executável.


## Correção final pós-build
- Corrigido erro de compilação `cannot find symbol WHITE` no método `perfValue`.
- Cluster de óleo/nível equalizado com o cluster de líquido/admissão: mesma altura (185dp) e mesma largura (peso 1:1).
- Abas do módulo GRÁFICOS ajustadas para quatro larguras iguais, com largura mínima de botão zerada para evitar corte de VELOCIDADE.
- Cabeçalho: carro ancorado na base com ajuste mínimo de posição.
