# VirtusELM V11.5 — Performance + Auditoria Visual

- V11.5 / versionCode 115.
- Home auditada: cards com dimensões/alinhamentos internos uniformes e títulos sem quebra arbitrária.
- Cabeçalho ajustado: carro ancorado na base e composição VIRTUS/versão revisada.
- Card SENSORES substituído por PERFORMANCE, mantendo a posição e identidade visual.
- Performance abre diretamente pelo card da Home, sem novo item na barra inferior.
- Novo módulo Performance: 0–100 km/h, boost máximo e estimativa preliminar de potência/torque baseada em dinâmica longitudinal.
- A potência é explicitamente apresentada como estimativa, com ressalva sobre massa, inclinação, aderência e condições do teste.
- Mantido o princípio somente leitura; nenhum comando de atuação/coding/adaptation/security access/CAN arbitrário foi adicionado.
- Demais módulos, telemetria, gráficos, logs, diagnóstico, CAN e gravação preservados.

## Observação de validação
A fonte foi revisada e empacotada para GitHub. A compilação Android completa deve ser confirmada pelo workflow do GitHub Actions, pois este ambiente não possui Gradle/SDK Android local executável.
