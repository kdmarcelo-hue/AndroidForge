package com.marcelo.virtuselm;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    BluetoothAdapter adapter; BluetoothSocket socket; InputStream in; OutputStream out;
    TextView log,status,liveData; Button connect,testEcu,readVehicle,readDtc,readVin,full;
    Handler h=new Handler(Looper.getMainLooper());
    static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        log=findViewById(R.id.log); status=findViewById(R.id.status); liveData=findViewById(R.id.liveData);
        connect=findViewById(R.id.btnConnect); testEcu=findViewById(R.id.btnTestEcu);
        readVehicle=findViewById(R.id.btnReadVehicle); readDtc=findViewById(R.id.btnReadDtc);
        readVin=findViewById(R.id.btnReadVin); full=findViewById(R.id.btnFull);
        adapter=BluetoothAdapter.getDefaultAdapter();
        connect.setOnClickListener(v->startConnection()); testEcu.setOnClickListener(v->testEcu());
        readVehicle.setOnClickListener(v->readVehicle()); readDtc.setOnClickListener(v->readDtc());
        readVin.setOnClickListener(v->readVin()); full.setOnClickListener(v->fullDiagnostic());
        findViewById(R.id.btnClear).setOnClickListener(v->log.setText("")); setButtons(false); requestBt();
    }
    void requestBt(){ if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
        requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},10); }
    void startConnection(){
        if(adapter==null){msg("Bluetooth não disponível.");return;} if(!adapter.isEnabled()){msg("Ative o Bluetooth do celular.");return;}
        if(Build.VERSION.SDK_INT>=31 && (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)){requestBt();return;}
        new Thread(()->{ try{
            setStatus("PROCURANDO ELM..."); msg("Procurando ELM..."); BluetoothDevice elm=null;
            Set<BluetoothDevice> paired=adapter.getBondedDevices(); for(BluetoothDevice d:paired){String n=d.getName();if(n!=null&&isElmName(n)){elm=d;break;}}
            if(elm==null){msg("ELM não está pareado. Iniciando descoberta Bluetooth..."); final Object lock=new Object(); final BluetoothDevice[] found={null};
                BroadcastReceiver receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){if(BluetoothDevice.ACTION_FOUND.equals(i.getAction())){BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);if(d!=null){String n=d.getName();if(n!=null&&isElmName(n)){found[0]=d;synchronized(lock){lock.notifyAll();}}}}}};
                registerReceiver(receiver,new IntentFilter(BluetoothDevice.ACTION_FOUND)); adapter.startDiscovery(); synchronized(lock){lock.wait(12000);}
                try{unregisterReceiver(receiver);}catch(Exception ignored){} adapter.cancelDiscovery(); elm=found[0];
            }
            if(elm==null){msg("Nenhum ELM identificado.");setStatus("NÃO ENCONTRADO");return;}
            msg("ELM encontrado: "+elm.getName()); adapter.cancelDiscovery(); socket=elm.createRfcommSocketToServiceRecord(SPP); socket.connect();
            in=socket.getInputStream(); out=socket.getOutputStream(); msg("Bluetooth conectado.");
            send("ATZ"); Thread.sleep(1200); read(1800); send("ATE0"); Thread.sleep(300); read(1000); send("ATI"); Thread.sleep(400); read(1000);
            send("ATDP"); Thread.sleep(400); read(1000); send("ATSP0"); Thread.sleep(400); read(1000); send("ATAT1"); Thread.sleep(300); read(1000);
            setStatus("CONECTADO AO ELM"); setButtons(true); msg("Inicialização concluída. V0.6.0 — somente leitura.");
        }catch(Exception e){msg("Falha: "+e.getMessage());setStatus("NÃO CONECTADO");setButtons(false);close();}}).start();
    }
    boolean isElmName(String n){String u=n.toUpperCase(Locale.ROOT);return u.contains("ELM")||u.contains("OBD")||u.contains("V-LINK")||u.contains("OBDLINK");}
    void testEcu(){run("TESTANDO ECU...",()->{String r=sendRead("0100",5000);if(norm(r).contains("4100")){setStatus("ECU RESPONDEU");live("PID 0100: ECU respondeu.\n\n"+display(r));}else{setStatus("RESPOSTA INCONCLUSIVA");live("Resposta: \n"+display(r));}msg("Teste OBD-II concluído. Nenhum comando de escrita foi enviado.");});}
    void readVehicle(){run("LENDO VEÍCULO...",()->{
        String supported=sendRead("0100",5000); Set<Integer> pids=parseSupportedPids(supported); StringBuilder s=new StringBuilder();
        s.append("SUPORTE PID 01-20\n"); s.append(pids.isEmpty()?"Não foi possível decodificar.\n":"PIDs: "+pids+"\n\n");
        int[] jobs={0x04,0x05,0x0B,0x0C,0x0D,0x0F,0x10,0x11,0x1F,0x2F,0x33,0x42};
        for(int pid:jobs) if(pids.contains(pid)){String cmd=String.format(Locale.ROOT,"01%02X",pid);String r=sendRead(cmd,3000);String val=decode(pid,r);if(val!=null)s.append(label(pid)).append(": ").append(val).append("\n");}
        live(s.toString());setStatus("LEITURA CONCLUÍDA");msg("Dados OBD-II decodificados. Nenhuma escrita/adaptação/limpeza foi enviada.");
    });}
    void readDtc(){run("LENDO DTC...",()->{String r=sendRead("03",5000);String d=decodeDtc(r);live("CÓDIGOS DE FALHA\n\n"+d);setStatus("DTC CONCLUÍDO");msg("DTC lidos somente para diagnóstico. Nenhum código foi apagado.");});}
    void readVin(){run("LENDO VIN...",()->{String r=sendRead("0902",7000);String vin=decodeVin(r);live("VIN\n\n"+vin);setStatus("VIN CONCLUÍDO");msg("Leitura VIN somente leitura; disponibilidade depende da ECU/veículo.");});}
    void fullDiagnostic(){run("DIAGNÓSTICO COMPLETO...",()->{StringBuilder all=new StringBuilder();String p=sendRead("0100",5000);all.append("PID 0100\n").append(display(p)).append("\n\n");Set<Integer> ps=parseSupportedPids(p);int[] jobs={0x04,0x05,0x0B,0x0C,0x0D,0x0F,0x10,0x11,0x1F,0x2F,0x33,0x42};for(int pid:jobs)if(ps.contains(pid)){String r=sendRead(String.format(Locale.ROOT,"01%02X",pid),3000);String v=decode(pid,r);if(v!=null)all.append(label(pid)).append(": ").append(v).append("\n");}String dtc=sendRead("03",5000);all.append("\nDTC\n").append(decodeDtc(dtc)).append("\n");String vin=sendRead("0902",7000);all.append("\nVIN\n").append(decodeVin(vin));live(all.toString());setStatus("DIAGNÓSTICO CONCLUÍDO");msg("Diagnóstico completo finalizado. Nenhum comando de escrita, atuador, codificação, adaptação ou limpeza foi enviado.");});}
    interface Job{void go()throws Exception;}
    void run(String state,Job job){new Thread(()->{try{if(!connected()){msg("ELM não está conectado.");setStatus("NÃO CONECTADO");return;}setButtons(false);setStatus(state);job.go();}catch(Exception e){msg("Falha: "+e.getMessage());setStatus("FALHA");}finally{setButtons(true);}}).start();}
    Set<Integer> parseSupportedPids(String r){Set<Integer>s=new HashSet<>();String h=norm(r);int pos=h.indexOf("4100");if(pos<0||h.length()<pos+12)return s;try{long bits=Long.parseLong(h.substring(pos+4,pos+12),16);for(int i=0;i<32;i++)if((bits&(1L<<(31-i)))!=0)s.add(1+i);}catch(Exception ignored){}return s;}
    String decode(int pid,String r){String h=norm(r),key=String.format(Locale.ROOT,"41%02X",pid);int p=h.indexOf(key);if(p<0)return null;String d=h.substring(p+4);try{switch(pid){case 4:return String.format(Locale.ROOT,"%.1f %%",Integer.parseInt(d.substring(0,2),16)*100.0/255);case 5:return (Integer.parseInt(d.substring(0,2),16)-40)+" °C";case 11:return Integer.parseInt(d.substring(0,2),16)+" kPa";case 12:return String.format(Locale.ROOT,"%.0f rpm",Integer.parseInt(d.substring(0,4),16)/4.0);case 13:return Integer.parseInt(d.substring(0,2),16)+" km/h";case 15:return (Integer.parseInt(d.substring(0,2),16)-40)+" °C";case 16:return String.format(Locale.ROOT,"%.1f g/s",Integer.parseInt(d.substring(0,4),16)/100.0);case 17:return String.format(Locale.ROOT,"%.1f %%",Integer.parseInt(d.substring(0,2),16)*100.0/255);case 31:return Integer.parseInt(d.substring(0,4),16)+" s";case 47:return String.format(Locale.ROOT,"%.1f %%",Integer.parseInt(d.substring(0,2),16)*100.0/255);case 51:return Integer.parseInt(d.substring(0,2),16)+" kPa";case 66:return String.format(Locale.ROOT,"%.3f V",Integer.parseInt(d.substring(0,4),16)/1000.0);default:return null;}}catch(Exception e){return null;}}
    String label(int p){switch(p){case 4:return "Carga motor";case 5:return "Temp. arrefecimento";case 11:return "MAP";case 12:return "RPM";case 13:return "Velocidade";case 15:return "Temp. admissão";case 16:return "MAF";case 17:return "Acelerador";case 31:return "Tempo ligado";case 47:return "Nível combustível";case 51:return "Pressão barométrica";case 66:return "Tensão módulo";default:return String.format(Locale.ROOT,"PID %02X",p);}}
    String decodeDtc(String r){String h=norm(r);int p=h.indexOf("43");if(p<0)return "Nenhum DTC decodificável / resposta não disponível.\n\n"+display(r);String d=h.substring(p+2);if(d.length()<4)return "Resposta DTC sem códigos.\n";StringBuilder s=new StringBuilder();for(int i=0;i+4<=d.length();i+=4){String x=d.substring(i,i+4);if(x.equals("0000"))continue;int a=Integer.parseInt(x.substring(0,1),16);String[] t={"P","C","B","U"};String code=t[(a>>2)&3]+String.format(Locale.ROOT,"%X",a&3)+x.substring(1);s.append(code).append("\n");}return s.length()>0?s.toString():"Nenhum DTC ativo retornado.\n";}
    String decodeVin(String r){String h=norm(r);StringBuilder hex=new StringBuilder();for(int i=0;i+2<=h.length();i+=2){String b=h.substring(i,i+2);if(b.matches("[0-9A-F]{2}"))hex.append(b);}String hs=hex.toString();int p=hs.indexOf("4902");if(p<0)return "VIN não retornado pela ECU.\n\n"+display(r);String d=hs.substring(p+4);StringBuilder out=new StringBuilder();for(int i=0;i+2<=d.length();i+=2){int v=Integer.parseInt(d.substring(i,i+2),16);if(v>=32&&v<=126)out.append((char)v);}String vin=out.toString().replaceAll("[^A-Z0-9]","");return vin.length()>=11?vin:"VIN não pôde ser reconstruído com segurança a partir da resposta.\n";}
    boolean connected(){return out!=null&&socket!=null&&socket.isConnected();}
    synchronized void send(String x)throws Exception{if(out==null)throw new Exception("ELM desconectado");msg(">> "+x);out.write((x+"\r").getBytes(StandardCharsets.US_ASCII));out.flush();}
    String sendRead(String x,long t)throws Exception{send(x);return readResponse(t);}
    void read(long t)throws Exception{String b=readResponse(t);msg("<< "+display(b));}
    String readResponse(long timeoutMs)throws Exception{long end=System.currentTimeMillis()+timeoutMs;long quiet=0;StringBuilder b=new StringBuilder();while(System.currentTimeMillis()<end){boolean got=false;while(in!=null&&in.available()>0){int c=in.read();if(c>=0){b.append((char)c);got=true;}}if(b.indexOf(">")>=0 && !got)break;if(got)quiet=System.currentTimeMillis()+250;else if(quiet>0&&System.currentTimeMillis()>quiet)break;Thread.sleep(25);}return b.toString();}
    String norm(String s){return s.toUpperCase(Locale.ROOT).replaceAll("[\\r\\n\\s]","");}
    String display(String s){return s.length()>0?s.replace("\r","\n"):("(sem resposta)");}
    void close(){try{if(socket!=null)socket.close();}catch(Exception ignored){}socket=null;in=null;out=null;setButtons(false);}
    void msg(String s){h.post(()->log.append(s+"\n"));}
    void live(String s){h.post(()->liveData.setText(s));}
    void setStatus(String s){h.post(()->status.setText("Status: "+s));}
    void setButtons(boolean enabled){h.post(()->{testEcu.setEnabled(enabled);readVehicle.setEnabled(enabled);readDtc.setEnabled(enabled);readVin.setEnabled(enabled);full.setEnabled(enabled);});}
    protected void onDestroy(){close();super.onDestroy();}
}
