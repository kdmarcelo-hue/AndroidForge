# AUDITORIA V10.7

Base derivada diretamente da V10.6 auditada, sem remoção das funções existentes.

## Alterações
- Versão/nomenclatura atualizadas para V10.7.
- PID 0133 (pressão barométrica) incluído no painel e no polling.
- BOOST calculado como `(MAP - BARO) / 100`, em bar, em vez de assumir 101,325 kPa fixos.
- BOOST MÁX. reiniciado a cada nova conexão e acumulado durante a sessão.
- BARO exibido no painel.
- Finalização do Monitor All aguarda até 8 s pelo prompt antes de forçar reconexão.
- Marcadores agora armazenam contagem por ID CAN.
- Novos marcadores: START/STOP e PORTA-MALAS.
- Análise diferencial lista os IDs que aumentaram de tráfego entre marcadores, sem transmitir quadros CAN.
- Feedback visual dos botões e interface arredondada/rolável preservados.

## Segurança
A V10.7 continua sem envio de quadros CAN arbitrários, comandos de atuação, coding, adaptation ou security access. O objetivo desta versão é transformar ações físicas no veículo em evidência observável na rede CAN.
