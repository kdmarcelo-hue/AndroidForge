package com.marcelo.virtuselm;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private TextView status, log, tvConnection, tvProtocol, tvVin, tvEcu, tvSummary;
    private Button connect, autoDiag, ecu, data, dtc, o2, obd, vin, body, quick, ignitionTest, copyLog, clearLog;
    private Button monitorCan, markLock, markUnlock, stopMonitor, analyzeEvents;

    private BluetoothSocket socket;
    private OutputStream out;
    private InputStream in;
    private final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    // Um único executor para TODA a comunicação: elimina operações concorrentes no mesmo ELM/socket.
    private final ExecutorService ioExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "elm-io");
        t.setDaemon(true);
        return t;
    });

    private final AtomicInteger sectionId = new AtomicInteger(0);
    private final StringBuilder sessionLog = new StringBuilder(8192);
    private volatile boolean operationRunning = false;

    // Captura CAN é uma sessão exclusiva: durante ela nenhum comando OBD é permitido.
    private final ExecutorService monitorExecutor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "can-monitor");
        t.setDaemon(true);
        return t;
    });
    private final AtomicBoolean monitoring = new AtomicBoolean(false);
    private final List<MonitorFrame> monitorFrames = new ArrayList<>();
    private final List<MonitorMarker> monitorMarkers = new ArrayList<>();
    private int monitorFrameCount = 0;
    private int monitorIdCount = 0;
    private final Set<String> monitorIds = new HashSet<>();

    private static final Pattern CAN_COMPACT = Pattern.compile("(?i)(7E[0-9A-F])([0-9A-F]{2,32})");
    private static final Pattern CAN_SPACED = Pattern.compile("(?i)(7E[0-9A-F])\\s+((?:[0-9A-F]{2}\\s*){2,64})");
    private static final Pattern VIN_ASCII = Pattern.compile("[A-HJ-NPR-Z0-9]{17}");
    private static final Pattern MONITOR_CAN = Pattern.compile("^([0-9A-Fa-f]{3}|[0-9A-Fa-f]{8})\\s+((?:[0-9A-Fa-f]{2}\\s*){1,64})$");

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        installCrashRecorder();

        status = findViewById(R.id.tvStatus);
        tvConnection = findViewById(R.id.tvConnection);
        tvProtocol = findViewById(R.id.tvProtocol);
        tvVin = findViewById(R.id.tvVinValue);
        tvEcu = findViewById(R.id.tvEcuValue);
        tvSummary = findViewById(R.id.tvSummary);
        log = findViewById(R.id.tvLog);
        connect = findViewById(R.id.btnConnect);
        autoDiag = findViewById(R.id.btnAutoDiagnostic);
        ecu = findViewById(R.id.btnEcu);
        data = findViewById(R.id.btnData);
        dtc = findViewById(R.id.btnDtc);
        o2 = findViewById(R.id.btnO2);
        obd = findViewById(R.id.btnStatus);
        vin = findViewById(R.id.btnVin);
        body = findViewById(R.id.btnBody);
        quick = findViewById(R.id.btnQuick);
        ignitionTest = findViewById(R.id.btnIgnitionTest);
        copyLog = findViewById(R.id.btnCopyLog);
        clearLog = findViewById(R.id.btnClearLog);
        monitorCan = findViewById(R.id.btnMonitorCan);
        markLock = findViewById(R.id.btnMarkLock);
        markUnlock = findViewById(R.id.btnMarkUnlock);
        stopMonitor = findViewById(R.id.btnStopMonitor);
        analyzeEvents = findViewById(R.id.btnAnalyzeEvents);

        setDiagnosticButtons(false);

        connect.setOnClickListener(v -> startOperation("CONECTAR AO ELM", "btnConnect", this::connectElm));
        autoDiag.setOnClickListener(v -> startOperation("DIAGNÓSTICO AUTOMÁTICO — SOMENTE LEITURA", "btnAutoDiagnostic", this::automaticDiagnostic));
        ecu.setOnClickListener(v -> startOperation("TESTAR ECU — OBD-II", "btnEcu", this::testEcu));
        data.setOnClickListener(v -> startOperation("LER DADOS DO VEÍCULO", "btnData", this::readData));
        dtc.setOnClickListener(v -> startOperation("LER DTC + FREEZE FRAME", "btnDtc", this::readDtcFreeze));
        o2.setOnClickListener(v -> startOperation("TESTAR MONITORAMENTO DA SONDA", "btnO2", this::readModes));
        obd.setOnClickListener(v -> startOperation("STATUS OBD / READINESS", "btnStatus", this::readObdStatus));
        vin.setOnClickListener(v -> startOperation("LER VIN / INFO DO VEÍCULO", "btnVin", this::readVin));
        body.setOnClickListener(v -> startOperation("INVESTIGAR CARROCERIA — SOMENTE LEITURA", "btnBody", this::bodyReadOnly));
        quick.setOnClickListener(v -> startOperation("DIAGNÓSTICO RÁPIDO — SOMENTE LEITURA", "btnQuick", this::quickDiagnostic));
        ignitionTest.setOnClickListener(v -> startOperation("TESTE ELM COM IGNIÇÃO DESLIGADA — SOMENTE LEITURA", "btnIgnitionTest", this::ignitionOffDiagnostic));
        copyLog.setOnClickListener(v -> copySessionLog());
        clearLog.setOnClickListener(v -> clearSessionLog());
        monitorCan.setOnClickListener(v -> startCanMonitor());
        markLock.setOnClickListener(v -> markCanEvent("LOCK_INTERNO"));
        markUnlock.setOnClickListener(v -> markCanEvent("UNLOCK_INTERNO"));
        stopMonitor.setOnClickListener(v -> requestStopCanMonitor());
        analyzeEvents.setOnClickListener(v -> analyzeCanEvents());

        uiLog("V10.0 CAN INVESTIGATOR carregada. Base V9 preservada + captura CAN passiva. SOMENTE LEITURA.");
        setCanButtons(false);
    }

    private void startOperation(String label, String buttonId, Runnable work) {
        if (operationRunning) {
            uiLog("[IGNORADO] Operação já em andamento: " + label + " (" + buttonId + ")");
            return;
        }
        operationRunning = true;
        appendSectionHeader(label, buttonId);
        setAllButtonsForOperation(true);
        ioExecutor.execute(() -> {
            String result = "concluído";
            try {
                work.run();
            } catch (Throwable t) {
                result = "exceção: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage());
                uiLog("EXCEÇÃO NÃO TRATADA: " + t.getClass().getName() + ": " + safe(t.getMessage()));
                setStatus("erro inesperado — veja o log");
            } finally {
                appendSectionEnd(result);
                runOnUiThread(() -> {
                    operationRunning = false;
                    setAllButtonsForOperation(false);
                });
            }
        });
    }

    private void setAllButtonsForOperation(boolean running) {
        runOnUiThread(() -> {
            connect.setEnabled(!running);
            boolean diag = !running && isConnected();
            autoDiag.setEnabled(diag);
            ecu.setEnabled(diag); data.setEnabled(diag); dtc.setEnabled(diag); o2.setEnabled(diag);
            obd.setEnabled(diag); vin.setEnabled(diag); body.setEnabled(diag); quick.setEnabled(diag);
            // O teste de ignição desligada também pode ser feito somente com o ELM conectado.
            ignitionTest.setEnabled(!running && isConnected());
            copyLog.setEnabled(!running);
            clearLog.setEnabled(!running && !monitoring.get());
            setCanButtons(false);
        });
    }

    private void setDiagnosticButtons(boolean enabled) {
        connect.setEnabled(!operationRunning);
        autoDiag.setEnabled(enabled);
        ecu.setEnabled(enabled); data.setEnabled(enabled); dtc.setEnabled(enabled); o2.setEnabled(enabled);
        obd.setEnabled(enabled); vin.setEnabled(enabled); body.setEnabled(enabled); quick.setEnabled(enabled);
        ignitionTest.setEnabled(enabled);
        copyLog.setEnabled(true); clearLog.setEnabled(true);
        setCanButtons(false);
    }

    private void appendSectionHeader(String label, String buttonId) {
        String block;
        synchronized (sessionLog) {
            int id = sectionId.incrementAndGet();
            String time = now();
            block = "\n════════════════════════════════════════════════════════════\n" +
                    String.format(Locale.US, "[%02d] %s\n", id, label) +
                    "Button ID: " + buttonId + " | Início: " + time + "\n" +
                    "════════════════════════════════════════════════════════════\n";
            sessionLog.append(block);
        }
        uiLogOnly(block);
    }

    private void appendSectionEnd(String result) {
        String block = "Fim: " + now() + " | Resultado: " + result + "\n" +
                "────────────────────────────────────────────────────────────\n";
        synchronized (sessionLog) { sessionLog.append(block); }
        uiLogOnly(block);
    }

    private void uiLog(String s) {
        String line = s + (s.endsWith("\n") ? "" : "\n");
        synchronized (sessionLog) { sessionLog.append(line); }
        runOnUiThread(() -> uiLogOnly(line));
    }

    private void uiLogOnly(String s) {
        if (log != null) log.append(s);
    }

    private void appendSessionOnly(String s) {
        synchronized (sessionLog) { sessionLog.append(s).append(s.endsWith("\n") ? "" : "\n"); }
    }

    private void setStatus(String s) {
        runOnUiThread(() -> {
            status.setText("Status: " + s);
            if (tvConnection != null) tvConnection.setText(isConnected() ? "CONECTADO" : "DESCONECTADO");
        });
    }

    private void copySessionLog() {
        synchronized (sessionLog) {
            ClipboardManager cb = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cb == null) {
                setStatus("clipboard indisponível");
                return;
            }
            cb.setPrimaryClip(ClipData.newPlainText("VIRTUS ELM — LOG COMPLETO", sessionLog.toString()));
        }
        setStatus("LOG COMPLETO COPIADO");
        if (Build.VERSION.SDK_INT <= 32) Toast.makeText(this, "Log completo copiado", Toast.LENGTH_SHORT).show();
    }

    private void clearSessionLog() {
        if (monitoring.get()) {
            setStatus("pare a captura CAN antes de limpar o log");
            return;
        }
        runOnUiThread(() -> {
            synchronized (sessionLog) {
                sessionLog.setLength(0);
                sectionId.set(0);
                log.setText("");
                String block = "════════════════════════════════════════════════════════════\n" +
                        "[00] INÍCIO DE NOVA SESSÃO — LOG LIMPO\n" +
                        "Button ID: btnClearLog | Início: " + now() + "\n" +
                        "════════════════════════════════════════════════════════════\n";
                sessionLog.append(block);
                log.append(block);
            }
            status.setText("Status: LOG LIMPO — nova sessão");
        });
    }

    private void setCanButtons(boolean active) {
        boolean connected = isConnected();
        if (active) {
            connect.setEnabled(false);
            autoDiag.setEnabled(false); ecu.setEnabled(false); data.setEnabled(false); dtc.setEnabled(false);
            o2.setEnabled(false); obd.setEnabled(false); vin.setEnabled(false); body.setEnabled(false); quick.setEnabled(false); ignitionTest.setEnabled(false);
        } else if (!operationRunning) {
            boolean diag = connected;
            connect.setEnabled(true);
            autoDiag.setEnabled(diag); ecu.setEnabled(diag); data.setEnabled(diag); dtc.setEnabled(diag); o2.setEnabled(diag);
            obd.setEnabled(diag); vin.setEnabled(diag); body.setEnabled(diag); quick.setEnabled(diag); ignitionTest.setEnabled(diag);
        }
        if (monitorCan != null) monitorCan.setEnabled(connected && !operationRunning && !active);
        if (markLock != null) markLock.setEnabled(active);
        if (markUnlock != null) markUnlock.setEnabled(active);
        if (stopMonitor != null) stopMonitor.setEnabled(active);
        if (analyzeEvents != null) analyzeEvents.setEnabled(!active && !operationRunning && !monitorMarkers.isEmpty());
    }

    private void startCanMonitor() {
        if (operationRunning || monitoring.get()) return;
        operationRunning = true;
        appendSectionHeader("INVESTIGADOR CAN — TRAVAMENTO INTERNO", "btnMonitorCan");
        setAllButtonsForOperation(true);
        ioExecutor.execute(() -> {
            boolean started = false;
            try {
                if (!isConnected()) throw new IOException("ELM não conectado");
                resetMonitorState();
                uiLog("CAPTURA PASSIVA: nenhum comando de LOCK/UNLOCK será transmitido.");
                uiLog("Teste recomendado: motor ligado + botão físico interno LOCK/UNLOCK.");
                synchronized (this) {
                    // Limpa filtros/endereço antes de Monitor All. Estes são comandos ELM, não comandos do veículo.
                    send("AT AR", 900);
                    send("ATH1", 900);
                    send("ATS1", 900);
                    send("ATL0", 900);
                    if (out == null || in == null || socket == null || !socket.isConnected()) throw new IOException("socket indisponível");
                    out.write("AT MA\r".getBytes(StandardCharsets.US_ASCII));
                    out.flush();
                }
                monitoring.set(true);
                started = true;
                runOnUiThread(() -> {
                    operationRunning = false;
                    setStatus("CAPTURA CAN ATIVA — MOTOR LIGADO / OBSERVAÇÃO");
                    setAllButtonsForOperation(false);
                    setCanButtons(true);
                });
                monitorExecutor.execute(this::monitorCanLoop);
            } catch (Throwable t) {
                monitoring.set(false);
                uiLog("FALHA AO INICIAR CAPTURA: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()));
                setStatus("falha ao iniciar captura — sessão mantida");
                runOnUiThread(() -> {
                    operationRunning = false;
                    setAllButtonsForOperation(false);
                    setCanButtons(false);
                });
            } finally {
                if (!started) appendSectionEnd("não iniciada");
            }
        });
    }

    private void monitorCanLoop() {
        InputStream monitorIn = in;
        if (monitorIn == null) return;
        ByteArrayOutputStream pending = new ByteArrayOutputStream(2048);
        byte[] buf = new byte[1024];
        try {
            while (monitoring.get()) {
                int available = monitorIn.available();
                if (available <= 0) {
                    Thread.sleep(20);
                    continue;
                }
                int n = monitorIn.read(buf, 0, Math.min(available, buf.length));
                if (n < 0) throw new IOException("fim do stream Bluetooth (-1) durante captura");
                if (n == 0) continue;
                pending.write(buf, 0, n);
                String text = pending.toString("US-ASCII").replace("\u0000", "");
                int cut;
                while ((cut = firstLineBreak(text)) >= 0) {
                    String line = text.substring(0, cut).trim();
                    int delete = cut + 1;
                    while (delete < text.length() && (text.charAt(delete) == '\r' || text.charAt(delete) == '\n')) delete++;
                    text = text.substring(delete);
                    pending.reset();
                    pending.write(text.getBytes(StandardCharsets.US_ASCII));
                    if (!line.isEmpty() && !line.equals(">") && !line.equalsIgnoreCase("STOPPED")) consumeCanMonitorLine(line);
                }
            }
        } catch (Throwable t) {
            if (monitoring.get()) {
                uiLog("CAPTURA INTERROMPIDA: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()));
                setStatus("captura interrompida — veja o log");
            }
        } finally {
            monitoring.set(false);
            uiLog("=== FIM DA CAPTURA CAN PASSIVA ===");
            uiLog("FRAMES CAN: " + monitorFrameCount + " | IDs CAN: " + monitorIdCount + " | MARCADORES: " + monitorMarkers.size());
            if (!monitorIds.isEmpty()) uiLog("TOP IDs: " + topMonitorIds());
            analyzeCanEvents();
            runOnUiThread(() -> {
                operationRunning = false;
                setAllButtonsForOperation(false);
                setCanButtons(false);
                setStatus(isConnected() ? "CAPTURA PARADA — LOG PRONTO" : "CAPTURA PARADA — ELM DESCONECTADO");
            });
            appendSectionEnd("captura finalizada");
        }
    }

    private int firstLineBreak(String s) {
        int r = s.indexOf('\r');
        int n = s.indexOf('\n');
        if (r < 0) return n;
        if (n < 0) return r;
        return Math.min(r, n);
    }

    private void consumeCanMonitorLine(String line) {
        Matcher m = MONITOR_CAN.matcher(line);
        if (!m.matches()) {
            if (!line.equalsIgnoreCase("SEARCHING...") && !line.equalsIgnoreCase("NO DATA")) uiLog("MONITOR RAW: " + line);
            return;
        }
        String id = m.group(1).toUpperCase(Locale.US);
        String data = m.group(2).trim().replaceAll("\\s+", " ").toUpperCase(Locale.US);
        long now = android.os.SystemClock.elapsedRealtime();
        monitorFrameCount++;
        monitorIds.add(id);
        monitorIdCount = monitorIds.size();
        MonitorFrame frame = new MonitorFrame(monitorFrameCount, now, id, data);
        synchronized (monitorFrames) {
            monitorFrames.add(frame);
            if (monitorFrames.size() > 6000) monitorFrames.remove(0);
        }
        String frameLine = String.format(Locale.US, "CAN[%05d] %s  %s", frame.seq, id, data);
        appendSessionOnly(frameLine);
        // O tráfego CAN pode ser muito intenso: o log completo é preservado no clipboard,
        // mas a tela recebe apenas uma amostra para não sobrecarregar a Main Thread.
        if (frame.seq <= 80 || (frame.seq % 20) == 0) runOnUiThread(() -> uiLogOnly(frameLine + "\n"));
        if ((monitorFrameCount % 20) == 0) runOnUiThread(() -> updateMonitorCounters());
    }

    private void updateMonitorCounters() {
        if (tvEcu != null) tvEcu.setText("CAN IDs: " + monitorIdCount + " | Frames: " + monitorFrameCount);
    }

    private void markCanEvent(String type) {
        if (!monitoring.get()) return;
        MonitorMarker marker = new MonitorMarker(type, android.os.SystemClock.elapsedRealtime(), monitorFrameCount);
        synchronized (monitorMarkers) { monitorMarkers.add(marker); }
        uiLog(">>> MARCADOR " + type + " | frame #" + monitorFrameCount + " <<<");
        uiLog("Marcador local. Nenhum comando foi enviado ao veículo.");
        updateMonitorCounters();
    }

    private void requestStopCanMonitor() {
        if (!monitoring.get()) return;
        monitoring.set(false);
        // O ELM documenta que qualquer caractere interrompe AT MA. O próprio thread de captura envia CR para evitar dois leitores.
        monitorExecutor.execute(() -> {
            try {
                synchronized (this) {
                    if (out != null) {
                        out.write('\r');
                        out.flush();
                    }
                }
            } catch (Throwable t) {
                uiLog("PARADA CAN: " + t.getClass().getSimpleName() + ": " + safe(t.getMessage()));
            }
        });
        setStatus("parando captura CAN...");
    }

    private void resetMonitorState() {
        synchronized (monitorFrames) { monitorFrames.clear(); }
        synchronized (monitorMarkers) { monitorMarkers.clear(); }
        monitorFrameCount = 0;
        monitorIdCount = 0;
        monitorIds.clear();
        runOnUiThread(() -> updateMonitorCounters());
    }

    private String topMonitorIds() {
        Map<String, Integer> counts = new LinkedHashMap<>();
        synchronized (monitorFrames) {
            for (MonitorFrame f : monitorFrames) counts.put(f.id, counts.getOrDefault(f.id, 0) + 1);
        }
        List<Map.Entry<String,Integer>> entries = new ArrayList<>(counts.entrySet());
        entries.sort((a,b) -> Integer.compare(b.getValue(), a.getValue()));
        StringBuilder out = new StringBuilder();
        for (int i=0; i<Math.min(12, entries.size()); i++) {
            if (i>0) out.append(", ");
            out.append(entries.get(i).getKey()).append("=").append(entries.get(i).getValue());
        }
        return out.toString();
    }

    private void analyzeCanEvents() {
        List<MonitorMarker> markers;
        List<MonitorFrame> frames;
        synchronized (monitorMarkers) { markers = new ArrayList<>(monitorMarkers); }
        synchronized (monitorFrames) { frames = new ArrayList<>(monitorFrames); }
        if (markers.isEmpty() || frames.isEmpty()) return;
        uiLog("=== ANÁLISE DE EVENTOS LOCK / UNLOCK — OBSERVAÇÃO ===");
        for (MonitorMarker marker : markers) {
            Map<String,Integer> counts = new LinkedHashMap<>();
            for (MonitorFrame f : frames) {
                long delta = f.elapsedMs - marker.elapsedMs;
                if (delta >= -1000 && delta <= 1500) counts.put(f.id, counts.getOrDefault(f.id,0)+1);
            }
            List<Map.Entry<String,Integer>> entries = new ArrayList<>(counts.entrySet());
            entries.sort((a,b) -> Integer.compare(b.getValue(), a.getValue()));
            StringBuilder top = new StringBuilder();
            for (int i=0; i<Math.min(8, entries.size()); i++) {
                if (i>0) top.append(", ");
                top.append(entries.get(i).getKey()).append("=").append(entries.get(i).getValue());
            }
            uiLog("EVENTO " + marker.type + " | janela -1000/+1500 ms | IDs candidatos: " + (top.length()==0 ? "nenhum" : top));
        }
        uiLog("A análise é apenas uma correlação temporal; não identifica por si só módulo, comando ou payload de atuação.");
    }

    private static final class MonitorFrame {
        final int seq; final long elapsedMs; final String id; final String data;
        MonitorFrame(int seq, long elapsedMs, String id, String data) { this.seq=seq; this.elapsedMs=elapsedMs; this.id=id; this.data=data; }
    }

    private static final class MonitorMarker {
        final String type; final long elapsedMs; final int frameSeq;
        MonitorMarker(String type, long elapsedMs, int frameSeq) { this.type=type; this.elapsedMs=elapsedMs; this.frameSeq=frameSeq; }
    }

    private boolean ensureBluetoothPermission() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, 10));
            return false;
        }
        return true;
    }

    private BluetoothDevice findElm() {
        if (!ensureBluetoothPermission()) return null;
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) { setStatus("Bluetooth não disponível"); return null; }
        if (!adapter.isEnabled()) { setStatus("Bluetooth desligado"); return null; }
        for (BluetoothDevice d : adapter.getBondedDevices()) {
            String n = d.getName();
            String u = n == null ? "" : n.toUpperCase(Locale.US);
            if (u.contains("ELM") || u.contains("OBD") || u.contains("V-LINK") || u.contains("OBDLINK")) return d;
        }
        return null;
    }

    private void connectElm() {
        BluetoothDevice d = findElm();
        if (d == null) {
            uiLog("ERRO: nenhum dispositivo ELM/OBD conhecido encontrado.");
            setStatus("ELM não encontrado entre dispositivos conhecidos");
            return;
        }
        try {
            closeSocket();
            String name = d.getName();
            setStatus("conectando a " + name);
            uiLog("ELM encontrado: " + name);
            socket = d.createRfcommSocketToServiceRecord(SPP);
            socket.connect();
            out = socket.getOutputStream();
            in = socket.getInputStream();
            initializeElm();
            setStatus("CONECTADO — ELM PRONTO");
            if (tvProtocol != null) tvProtocol.setText("ISO 15765-4 CAN 11/500");
            if (tvConnection != null) tvConnection.setText("CONECTADO");
            uiLog("RESULTADO: Bluetooth conectado e ELM inicializado.");
        } catch (Exception e) {
            setStatus("falha de conexão");
            uiLog("ERRO DE CONEXÃO: " + e.getClass().getName() + ": " + safe(e.getMessage()));
            closeSocket();
        }
    }

    private void initializeElm() throws Exception {
        uiLog("--- INICIALIZAÇÃO ELM ---");
        send("ATZ", 3000);
        send("ATE0", 1500);
        send("ATL0", 1000);
        send("ATS0", 1000);
        send("ATH1", 1000);
        send("ATAT1", 1000);
        send("ATI", 1500);
        send("ATDP", 1500);
        send("ATSP0", 1500);
        uiLog("--- FIM DA INICIALIZAÇÃO ELM ---");
    }

    /** Envia uma única solicitação por vez. Nenhum botão executa send() em paralelo. */
    private synchronized String send(String cmd, long timeoutMs) throws Exception {
        if (out == null || in == null || socket == null || !socket.isConnected()) throw new IOException("socket fechado");
        String c = cmd + "\r";
        out.write(c.getBytes(StandardCharsets.US_ASCII));
        out.flush();
        uiLog(">> " + cmd);

        long end = System.currentTimeMillis() + timeoutMs;
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[512];
        while (System.currentTimeMillis() < end) {
            int available = in.available();
            if (available > 0) {
                int n = in.read(buf, 0, Math.min(available, buf.length));
                if (n < 0) throw new IOException("fim do stream Bluetooth (-1)");
                if (n > 0) {
                    b.write(buf, 0, n);
                    String partial = b.toString("US-ASCII");
                    if (partial.indexOf('>') >= 0) break;
                }
            } else {
                Thread.sleep(35);
            }
        }
        String r = normalizeElmResponse(b.toString("US-ASCII"));
        uiLog("<< " + (r.isEmpty() ? "[sem resposta]" : r));
        return r;
    }

    private String normalizeElmResponse(String raw) {
        return raw.replace("\u0000", "")
                .replace("\r", "\n")
                .replace(">", "")
                .replaceAll("\\n{2,}", "\\n")
                .trim();
    }

    private boolean isConnected() {
        try { return socket != null && socket.isConnected() && in != null && out != null; }
        catch (Exception e) { return false; }
    }

    private void testEcu() {
        try {
            setStatus("ECU em teste");
            String r = send("0100", 3500);
            logCanAnalysis("0100", r);
            setStatus(extractCanPayloads(r).isEmpty() ? "ELM respondeu — ECU não respondeu" : "ECU RESPONDEU");
        } catch (Exception e) {
            recoverCommunication(e);
        }
    }

    private void readData() {
        try {
            setStatus("lendo dados");
            Set<Integer> p = new HashSet<>();
            int[] supportBases = {0x01, 0x21, 0x41, 0x61};
            for (int base : supportBases) {
                String c = String.format(Locale.US, "01%02X", base - 1);
                String supported = send(c, 2800);
                logCanAnalysis(c, supported);
                p.addAll(parseSupportedPids(supported, base));
            }
            uiLog("PIDs suportados detectados: " + p);
            int[] ids = {4,5,11,12,13,15,16,17,31,47,51,66};
            for (int id : ids) {
                if (p.contains(id)) {
                    String c = String.format(Locale.US, "01%02X", id);
                    String r = send(c, 2500);
                    logCanAnalysis(c, r);
                    decodePidPerEcu(id, r);
                } else {
                    uiLog("PID " + String.format(Locale.US, "%02X", id) + ": não indicado como suportado pelos bitmaps consultados.");
                }
            }
            setStatus("dados lidos");
        } catch (Exception e) { recoverCommunication(e); }
    }

    private Set<Integer> parseSupportedPids(String raw, int firstPid) {
        Set<Integer> result = new HashSet<>();
        int supportPid = firstPid - 1;
        for (CanPayload msg : extractCanPayloads(raw)) {
            if (msg.payload.size() >= 6 && msg.payload.get(0) == 0x41 && msg.payload.get(1) == supportPid) {
                long bits = ((long)msg.payload.get(2) << 24) | ((long)msg.payload.get(3) << 16) |
                        ((long)msg.payload.get(4) << 8) | msg.payload.get(5);
                for (int i = 0; i < 32; i++) if ((bits & (1L << (31-i))) != 0) result.add(firstPid + i);
            }
        }
        return result;
    }

    private void decodePidPerEcu(int id, String raw) {
        String pid = String.format(Locale.US, "%02X", id);
        for (CanPayload msg : extractCanPayloads(raw)) {
            List<Integer> b = msg.payload;
            if (b.size() < 3 || b.get(0) != 0x41 || b.get(1) != id) continue;
            int A = b.get(2), B = b.size() > 3 ? b.get(3) : 0;
            String v;
            switch (id) {
                case 4: v = fmt((A * 100.0 / 255.0), "%.1f %% carga"); break;
                case 5: v = (A - 40) + " °C arrefecimento"; break;
                case 11: v = A + " kPa MAP"; break;
                case 12: v = fmt(((A * 256 + B) / 4.0), "%.0f rpm"); break;
                case 13: v = A + " km/h"; break;
                case 15: v = (A - 40) + " °C admissão"; break;
                case 16: v = fmt(((A * 256 + B) / 100.0), "%.2f g/s MAF"); break;
                case 17: v = fmt((A * 100.0 / 255.0), "%.1f %% acelerador"); break;
                case 31: v = (A * 256 + B) + " s runtime"; break;
                case 47: v = fmt((A * 100.0 / 255.0), "%.1f %% combustível"); break;
                case 51: v = A + " kPa pressão barométrica"; break;
                case 66: v = fmt(((A * 256 + B) / 1000.0), "%.3f V módulo"); break;
                default: v = "bytes=" + hex(b);
            }
            uiLog("ECU " + msg.canId + " | PID " + pid + ": " + v);
        }
    }

    private String fmt(double value, String pattern) { return String.format(Locale.US, pattern, value); }

    private void readDtcFreeze() {
        try {
            setStatus("lendo DTC");
            String d = send("03", 3500);
            logCanAnalysis("03", d);
            decodeDtcPerEcu(d);

            String f = send("0200", 3000);
            logCanAnalysis("0200", f);
            if (f.toUpperCase(Locale.US).contains("NO DATA")) uiLog("FREEZE FRAME: nenhum dado disponível para PID 0200.");

            // Alguns módulos podem responder a modos 02 com dados; sem dados não é erro de comunicação.
            for (int i = 1; i <= 10; i++) {
                String x = send(String.format(Locale.US, "02%02X00", i), 1600);
                logCanAnalysis(String.format(Locale.US, "02%02X00", i), x);
                if (x.toUpperCase(Locale.US).contains("NO DATA")) break;
            }
            setStatus("DTC + freeze frame concluídos");
        } catch (Exception e) { recoverCommunication(e); }
    }

    private void decodeDtcPerEcu(String raw) {
        boolean any = false;
        for (CanPayload msg : extractCanPayloads(raw)) {
            List<Integer> b = msg.payload;
            if (b.size() < 2 || b.get(0) != 0x43) continue;
            List<String> codes = new ArrayList<>();
            for (int i = 1; i + 1 < b.size(); i += 2) {
                int x = b.get(i), y = b.get(i+1);
                if (x == 0 && y == 0) continue;
                String pre = "PCBU".substring((x >> 6) & 3, ((x >> 6) & 3) + 1);
                codes.add(pre + String.format(Locale.US, "%04X", ((x & 0x3F) << 8) | y));
            }
            any = true;
            uiLog("ECU " + msg.canId + " | DTC: " + (codes.isEmpty() ? "nenhum DTC armazenado" : join(codes)));
        }
        if (!any) uiLog("DTC: resposta não decodificada.");
    }

    private void readModes() {
        try {
            setStatus("lendo monitores");
            String[] modes = {"05", "06", "07", "0A"};
            for (String m : modes) {
                String r = send(m, 3000);
                logCanAnalysis(m, r);
                decodeSimpleDtcMode(m, r);
            }
            setStatus("monitores consultados");
        } catch (Exception e) { recoverCommunication(e); }
    }

    private void decodeSimpleDtcMode(String mode, String raw) {
        int expected = Integer.parseInt(mode, 16) + 0x40;
        for (CanPayload msg : extractCanPayloads(raw)) {
            if (!msg.payload.isEmpty() && msg.payload.get(0) == expected) {
                if (msg.payload.size() == 2 && msg.payload.get(1) == 0) {
                    uiLog("ECU " + msg.canId + " | Modo " + mode + ": nenhum DTC reportado.");
                }
            }
        }
    }

    private void readObdStatus() {
        try {
            setStatus("lendo readiness");
            String[] cmds = {"0101", "0102", "0106", "0107", "0110"};
            for (String c : cmds) {
                String r = send(c, 2800);
                logCanAnalysis(c, r);
            }
            setStatus("status OBD lido");
        } catch (Exception e) { recoverCommunication(e); }
    }

    private void readVin() {
        try {
            setStatus("lendo VIN");
            String r = send("0902", 6000);
            logCanAnalysis("0902", r);
            String v = parseVinIsoTp(r);
            if (v.isEmpty()) {
                uiLog("VIN: não identificado/validado.");
                setStatus("VIN não validado — veja RAW/ISO-TP no log");
            } else {
                uiLog("VIN IDENTIFICADO: " + v);
                runOnUiThread(() -> tvVin.setText(v));
                setStatus("VIN identificado");
            }
        } catch (Exception e) { recoverCommunication(e); }
    }

    private String parseVinIsoTp(String raw) {
        for (CanPayload msg : extractCanPayloads(raw)) {
            List<Integer> b = msg.payload;
            if (b.size() >= 20 && b.get(0) == 0x49 && b.get(1) == 0x02) {
                StringBuilder ascii = new StringBuilder();
                for (int i = 2; i < b.size(); i++) {
                    int v = b.get(i);
                    if (v >= 32 && v <= 126) ascii.append((char)v);
                }
                Matcher m = VIN_ASCII.matcher(ascii.toString());
                if (m.find()) return m.group();
            }
        }
        // Fallback: procura uma sequência ASCII de 17 caracteres nas respostas, sem inventar VIN.
        StringBuilder ascii = new StringBuilder();
        for (CanPayload msg : extractCanPayloads(raw)) {
            for (int v : msg.payload) if (v >= 32 && v <= 126) ascii.append((char)v);
        }
        Matcher m = VIN_ASCII.matcher(ascii.toString());
        return m.find() ? m.group() : "";
    }

    private void bodyReadOnly() {
        try {
            setStatus("investigação de carroceria");
            uiLog("=== CARROCERIA: SOMENTE LEITURA ===");
            uiLog("Nenhum LOCK/UNLOCK, segurança, adaptação, codificação ou atuação será enviado.");
            uiLog("OBD-II padrão não fornece um PID genérico para trava central.");
            String r = send("0100", 3000);
            logCanAnalysis("0100", r);
            uiLog("Próxima etapa: identificar módulos/protocolos específicos do veículo apenas por leitura segura.");
            setStatus("investigação registrada");
        } catch (Exception e) { recoverCommunication(e); }
    }

    private void quickDiagnostic() {
        try {
            setStatus("diagnóstico rápido em execução");
            uiLog("=== DIAGNÓSTICO RÁPIDO — SOMENTE LEITURA ===");
            String ecuResp = send("0100", 3000);
            logCanAnalysis("0100", ecuResp);
            String dataResp = send("010C", 2500);
            logCanAnalysis("010C", dataResp);
            decodePidPerEcu(12, dataResp);
            String speedResp = send("010D", 2500);
            logCanAnalysis("010D", speedResp);
            decodePidPerEcu(13, speedResp);
            String tempResp = send("0105", 2500);
            logCanAnalysis("0105", tempResp);
            decodePidPerEcu(5, tempResp);
            String dtcResp = send("03", 3000);
            logCanAnalysis("03", dtcResp);
            decodeDtcPerEcu(dtcResp);
            String vinResp = send("0902", 6000);
            logCanAnalysis("0902", vinResp);
            String v = parseVinIsoTp(vinResp);
            uiLog("VIN: " + (v.isEmpty() ? "não validado" : v));
            setStatus("DIAGNÓSTICO RÁPIDO CONCLUÍDO");
        } catch (Exception e) { recoverCommunication(e); }
    }

    private void automaticDiagnostic() {
        try {
            setStatus("diagnóstico automático em execução");
            uiLog("=== DIAGNÓSTICO AUTOMÁTICO — SOMENTE LEITURA ===");

            String ecuResp = send("0100", 3500);
            logCanAnalysis("0100", ecuResp);
            int ecuCount = extractCanPayloads(ecuResp).size();
            runOnUiThread(() -> tvEcu.setText(ecuCount + " resposta(s) CAN"));

            int[] ids = {4,5,11,12,13,15,17,31,47,51,66};
            for (int id : ids) {
                String c = String.format(Locale.US, "01%02X", id);
                String r = send(c, 2500);
                logCanAnalysis(c, r);
                decodePidPerEcu(id, r);
            }

            String dtc = send("03", 3500);
            logCanAnalysis("03", dtc);
            decodeDtcPerEcu(dtc);

            String pending = send("07", 3000);
            logCanAnalysis("07", pending);
            decodeSimpleDtcMode("07", pending);

            String permanent = send("0A", 3000);
            logCanAnalysis("0A", permanent);
            decodeSimpleDtcMode("0A", permanent);

            String vinResp = send("0902", 6000);
            logCanAnalysis("0902", vinResp);
            String v = parseVinIsoTp(vinResp);
            if (!v.isEmpty()) {
                uiLog("VIN IDENTIFICADO: " + v);
                runOnUiThread(() -> tvVin.setText(v));
            } else uiLog("VIN: não identificado/validado.");

            String readiness = send("0101", 3000);
            logCanAnalysis("0101", readiness);

            runOnUiThread(() -> tvSummary.setText("Leitura automática concluída — consulte o resumo e o log técnico."));
            setStatus("DIAGNÓSTICO AUTOMÁTICO CONCLUÍDO");
        } catch (Exception e) { recoverCommunication(e); }
    }

    /** Teste especificamente útil para separar "ELM sem alimentação" de "ECU/CAN adormecida". */
    private void ignitionOffDiagnostic() {
        try {
            setStatus("teste ELM / ignição desligada");
            uiLog("=== TESTE COM IGNIÇÃO DESLIGADA ===");
            uiLog("O app não tenta acordar, energizar ou comandar módulos do veículo.");
            uiLog("Objetivo: verificar se o ELM permanece alimentado e responde aos próprios comandos.");
            String ati = send("ATI", 1800);
            uiLog("ELM/ATI: " + (ati.isEmpty() ? "sem resposta" : ati));
            String proto = send("ATDP", 1800);
            uiLog("PROTOCOLO: " + (proto.isEmpty() ? "sem resposta" : proto));
            String ecuResp = send("0100", 2500);
            logCanAnalysis("0100", ecuResp);
            if (extractCanPayloads(ecuResp).isEmpty()) {
                uiLog("CONCLUSÃO TÉCNICA: ELM respondeu aos próprios comandos; não foi detectada resposta CAN/ECU ao 0100 com a ignição desligada.");
            } else {
                uiLog("CONCLUSÃO TÉCNICA: foi detectada resposta CAN/ECU mesmo com a ignição desligada.");
            }
            setStatus("teste de ignição desligada concluído");
        } catch (Exception e) { recoverCommunication(e); }
    }

    private void logCanAnalysis(String command, String raw) {
        List<CanPayload> msgs = extractCanPayloads(raw);
        if (msgs.isEmpty()) {
            uiLog("CAN/ISO-TP | " + command + ": nenhuma resposta CAN estruturada detectada.");
            return;
        }
        for (CanPayload msg : msgs) {
            uiLog("CAN " + msg.canId + " | " + command + " | payload=" + hex(msg.payload) +
                    (msg.multiFrame ? " | ISO-TP multi-frame" : " | ISO-TP single-frame"));
        }
    }

    /** Reagrupa respostas ISO-TP do ELM por CAN ID. Suporta SF e FF/CF, inclusive VIN 0902. */
    private List<CanPayload> extractCanPayloads(String raw) {
        Map<String, List<String>> framesById = new LinkedHashMap<>();
        String[] lines = raw.replace('\r', '\n').split("\\n");
        for (String line : lines) {
            String s = line.trim().replace(" ", "");
            if (s.isEmpty()) continue;
            Matcher compact = CAN_COMPACT.matcher(s);
            if (compact.find()) {
                String id = compact.group(1).toUpperCase(Locale.US);
                String dataHex = compact.group(2).toUpperCase(Locale.US);
                List<String> list = framesById.get(id);
                if (list == null) { list = new ArrayList<>(); framesById.put(id, list); }
                list.add(dataHex);
                continue;
            }
            Matcher spaced = CAN_SPACED.matcher(line.trim());
            if (spaced.find()) {
                String id = spaced.group(1).toUpperCase(Locale.US);
                String dataHex = spaced.group(2).replaceAll("\\s+", "").toUpperCase(Locale.US);
                List<String> list = framesById.get(id);
                if (list == null) { list = new ArrayList<>(); framesById.put(id, list); }
                list.add(dataHex);
            }
        }

        List<CanPayload> outList = new ArrayList<>();
        for (Map.Entry<String, List<String>> e : framesById.entrySet()) {
            List<String> frames = e.getValue();
            if (frames.isEmpty()) continue;
            List<Integer> first = bytes(frames.get(0));
            if (first.isEmpty()) continue;
            int pci = first.get(0);
            int type = (pci >> 4) & 0xF;
            if (type == 0) { // Single Frame: low nibble = payload length
                int len = pci & 0x0F;
                List<Integer> payload = slice(first, 1, Math.min(first.size(), 1 + len));
                outList.add(new CanPayload(e.getKey(), payload, false));
            } else if (type == 1 && first.size() >= 2) { // First Frame
                int total = ((pci & 0x0F) << 8) | first.get(1);
                List<Integer> payload = new ArrayList<>(slice(first, 2, first.size()));
                int expectedSeq = 1;
                for (int i = 1; i < frames.size() && payload.size() < total; i++) {
                    List<Integer> cf = bytes(frames.get(i));
                    if (cf.isEmpty() || ((cf.get(0) >> 4) & 0xF) != 2) continue;
                    int seq = cf.get(0) & 0x0F;
                    if (seq != (expectedSeq & 0x0F)) uiLog("ISO-TP " + e.getKey() + ": sequência esperada " + (expectedSeq & 0x0F) + ", recebida " + seq);
                    expectedSeq++;
                    payload.addAll(slice(cf, 1, cf.size()));
                }
                if (payload.size() > total) payload = new ArrayList<>(payload.subList(0, total));
                outList.add(new CanPayload(e.getKey(), payload, true));
            } else {
                uiLog("ISO-TP " + e.getKey() + ": PCI não suportado/inesperado = " + String.format(Locale.US, "%02X", pci));
            }
        }
        return outList;
    }

    private List<Integer> bytes(String hex) {
        List<Integer> b = new ArrayList<>();
        String h = hex.replaceAll("[^0-9A-Fa-f]", "");
        if ((h.length() & 1) != 0) return b;
        for (int i = 0; i + 1 < h.length(); i += 2) b.add(Integer.parseInt(h.substring(i, i+2), 16));
        return b;
    }

    private List<Integer> slice(List<Integer> src, int from, int to) {
        return new ArrayList<>(src.subList(Math.max(0, from), Math.max(Math.max(0, from), Math.min(src.size(), to))));
    }

    private String hex(List<Integer> b) {
        StringBuilder s = new StringBuilder();
        for (int v : b) s.append(String.format(Locale.US, "%02X ", v));
        return s.toString().trim();
    }

    private String join(List<String> list) {
        StringBuilder s = new StringBuilder();
        for (String x : list) { if (s.length() > 0) s.append(' '); s.append(x); }
        return s.toString();
    }

    private void recoverCommunication(Exception e) {
        uiLog("COMUNICAÇÃO: " + e.getClass().getName() + ": " + safe(e.getMessage()));
        uiLog("SESSÃO ENCERRADA: o app não fará reconexão automática durante uma operação.");
        closeSocket();
        setStatus("socket perdido — reconecte pelo botão CONECTAR AO ELM");
    }

    private void closeSocket() {
        try { if (in != null) in.close(); } catch (Exception ignored) {}
        try { if (out != null) out.close(); } catch (Exception ignored) {}
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        in = null; out = null; socket = null;
    }

    private String now() { return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date()); }
    private String safe(String s) { return s == null ? "" : s; }

    private static final class CanPayload {
        final String canId;
        final List<Integer> payload;
        final boolean multiFrame;
        CanPayload(String canId, List<Integer> payload, boolean multiFrame) {
            this.canId = canId; this.payload = payload; this.multiFrame = multiFrame;
        }
    }

    private void installCrashRecorder() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try {
                getPreferences(MODE_PRIVATE).edit()
                        .putString("last_crash", thread.getName() + ": " + error.getClass().getName() + ": " + safe(error.getMessage()))
                        .apply();
            } catch (Throwable ignored) {}
            if (previous != null) previous.uncaughtException(thread, error);
        });
        String last = getPreferences(MODE_PRIVATE).getString("last_crash", "");
        if (last != null && !last.isEmpty()) {
            uiLog("ÚLTIMO ENCERRAMENTO INESPERADO: " + last);
            getPreferences(MODE_PRIVATE).edit().remove("last_crash").apply();
        }
    }

    @Override protected void onDestroy() {
        closeSocket();
        monitoring.set(false);
        monitorExecutor.shutdownNow();
        ioExecutor.shutdownNow();
        super.onDestroy();
    }
}
