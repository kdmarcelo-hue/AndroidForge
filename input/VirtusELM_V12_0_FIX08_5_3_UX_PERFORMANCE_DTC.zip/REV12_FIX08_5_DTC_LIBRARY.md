# V12.0-FIX08.5 — DTC Library 1.1

## Objetivo
Tornar a biblioteca DTC visível, consultável e atualizável pelo próprio aplicativo, mantendo a atualização controlada.

## Alterações
- Nova tela `BIBLIOTECA DTC • CONSULTA E ATUALIZAÇÃO`.
- Pesquisa por código, descrição, sistema e referência VAG.
- Consulta detalhada por toque.
- Botão `ATUALIZAR` visível.
- Atualização via HTTPS somente do manifesto e arquivo publicados no repositório do projeto.
- Validação de versão, conteúdo e SHA-256 antes da substituição.
- Biblioteca externa em `Download/VirtusELM/library/dtc_vag.json`.
- Biblioteca embarcada permanece como fallback.
- Biblioteca externa antiga não pode sobrescrever uma versão embarcada mais nova.
- Biblioteca ampliada para 33 registros iniciais, incluindo códigos OBD-II comuns e códigos VAG selecionados/documentados.
- Mantida a separação entre código recebido, descrição de biblioteca e diagnóstico confirmado.

## Segurança funcional
Nenhum comando de escrita, coding, adaptation, Security Access ou atuação foi adicionado.

## Fontes de referência usadas na curadoria inicial
- SAE J2012 — definições e formato de DTC OBD.
- Ross-Tech Wiki — referências VAG e descrições documentadas de códigos selecionados.

## Próximo passo
Validar no aparelho:
1. Diagnóstico → Biblioteca DTC.
2. Pesquisar `P0133`.
3. Abrir o registro.
4. Verificar versão `1.1.0` e quantidade de códigos.
5. Pressionar `ATUALIZAR`.
