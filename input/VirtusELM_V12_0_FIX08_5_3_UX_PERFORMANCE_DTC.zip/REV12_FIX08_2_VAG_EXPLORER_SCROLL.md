# REV12 FIX08.2 — VAG Explorer / Resultado com rolagem explícita

## Objetivo
Corrigir a apresentação dos quadros internos do VAG Diagnostic Explorer 2.1 e do RESULTADO DO TESTE sem alterar a lógica de comunicação, diagnóstico, CAN, ELM ou VAG.

## Ajustes
- VAG Explorer: área interna ampliada para 220 dp.
- VAG Explorer: barra vertical de rolagem habilitada e mantida visível durante a tela.
- VAG Explorer: overscroll condicionado ao conteúdo.
- RESULTADO DO TESTE: área interna ampliada para 190 dp.
- RESULTADO DO TESTE: barra vertical de rolagem habilitada e mantida visível durante a tela.
- Nenhuma alteração em comandos OBD, CAN, UDS, DTC ou descoberta de módulos.

## Próxima etapa planejada — biblioteca DTC
A próxima evolução deve separar claramente:
1. código DTC recebido;
2. descrição local conhecida;
3. origem/evidência (OBD genérico ou módulo VAG identificado);
4. família/sistema;
5. severidade/observação;
6. fonte e versão da biblioteca.

A biblioteca pode ser persistida em `Download/VirtusELM/` em arquivo leve (preferencialmente JSON), permitindo atualização sem embutir uma grande base no APK. O aplicativo deve manter uma base interna mínima como fallback e nunca inventar uma descrição quando o código não estiver cadastrado.

## Versão
- versionCode: 149
- versionName: 12.0-FIX08.2
