# V12 FIX08.3 — Scroll global do Diagnóstico

- Removidos os ScrollViews internos dos cartões VAG Diagnostic Explorer e RESULTADO DO TESTE.
- Os TextViews agora expandem conforme o conteúdo.
- A rolagem fica sob responsabilidade do ScrollView principal da tela de Diagnóstico, permitindo arrastar a tela normalmente com o dedo.
- Nenhuma lógica CAN/ELM/OBD/VAG foi alterada.
- versionCode: 150
- versionName: 12.0-FIX08.3
