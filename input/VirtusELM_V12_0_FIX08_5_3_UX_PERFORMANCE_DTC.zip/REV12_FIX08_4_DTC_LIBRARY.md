# V12.0-FIX08.4 — DTC Library 1.0

- versionCode: 151
- versionName: 12.0-FIX08.4
- Mantido o scroll global do FIX08.3.
- Biblioteca local em `app/src/main/assets/dtc_vag.json`.
- Cópia persistente: `Download/VirtusELM/library/dtc_vag.json`.
- Atualização controlada por `library/library_info.json`.
- Validação por versão + SHA-256 antes de aceitar nova biblioteca.
- O aplicativo não faz busca genérica na internet.
- Biblioteca inicial: 6 códigos genéricos com referência VAG documentada.

SHA-256 v1.0.0: `e513894ac550c1d9f20911a0e581cd355ded4453f7a1e8900b62cf0c0650b7ab`
