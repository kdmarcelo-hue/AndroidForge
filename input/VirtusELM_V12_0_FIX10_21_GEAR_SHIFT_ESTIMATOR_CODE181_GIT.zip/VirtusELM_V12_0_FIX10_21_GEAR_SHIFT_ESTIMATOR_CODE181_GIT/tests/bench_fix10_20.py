#!/usr/bin/env python3
"""Static bench checks for VIRTUS ELM V12 FIX10.20. No vehicle/ELM required."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
JAVA = (ROOT / "app/src/main/java/com/marcelo/virtuselm/MainActivity.java").read_text(encoding="utf-8")
GRADLE = (ROOT / "app/build.gradle").read_text(encoding="utf-8")
checks = []

def check(name, condition, detail=""):
    checks.append((name, bool(condition), detail))

check("Version code incremented to 181", re.search(r"versionCode\s+181\b", GRADLE))
check("Version name identifies gear-shift estimator", "12.0-FIX10.21-GEAR-SHIFT-ESTIMATOR" in GRADLE)
check("Graph footer has PERFORMANCE left and DATA right", 'Button performance=btn("← PERFORMANCE"); Button data=btn("DADOS →")' in JAVA)
check("Performance screen opens the historical loader", "bindClick(data,()->showPerformanceTestGraph())" in JAVA and "private void showPerformanceTestGraph(){showScreen(5);loadLastPerformanceGraph();}" in JAVA)
check("General GRÁFICOS tab remains live telemetry", "GRÁFICO COMBINADO • DADOS AO VIVO" in JAVA and "private void showGraphScreen(){" in JAVA)
check("Live graph updates stop while historical graph is shown", "private void updateGraph(){ if(historicalGraphMode)return;" in JAVA)
check("Test samples are captured only after test start timestamp", "if(t0>0){ double elapsed=Math.max(0,(now-t0)/1e9)" in JAVA)
check("Pedal PID 0149 is read during the test loop", 'parsePercentPid(send("0149",220),"0149")' in JAVA and "if(samples%3==0)" in JAVA)
check("Throttle PID 0111 is read during the test loop", 'parseThrottle(send("0111",220))' in JAVA)
check("Pedal calibration stores zero and full scale", "PREF_PEDAL_CAL_MIN" in JAVA and "PREF_PEDAL_CAL_MAX" in JAVA and "(raw-lo)*100.0/(hi-lo)" in JAVA)
check("Pull CSV persists per-sample records", 'csv.append("PERFORMANCE_SAMPLE;")' in JAVA and 'w.write("PERFORMANCE_SAMPLE;' in JAVA)
check("CSV includes elapsed seconds and GPS source columns", 'samples;elapsed_s\\n' in JAVA and ';;GPS;' in JAVA)
check("Graph reload reads persisted sample records", 'line.startsWith("PERFORMANCE_SAMPLE;")' in JAVA and 'historyNumber(f,header,"elapsed_s")' in JAVA)
check("Historical x-axis uses elapsed time", "historicalGraphMode&&times.length==a.length" in JAVA and "times[i]/maxTime" in JAVA)
check("No fabricated live graph is shown when no test samples exist", "SEM GRÁFICO DE TESTE" in JAVA)
check("Viewing during an active test is explicitly blocked", "TESTE EM ANDAMENTO • finalize a puxada" in JAVA)
check("No actuator/coding/security access added in test loop", all(x not in JAVA[JAVA.index("private void startPerformanceTest()") : JAVA.index("private double getRawPerformancePedalPct()")] for x in ['send("04"','send("AT SH','send("2E','send("27']))

for name, ok, detail in checks:
    print(("PASS" if ok else "FAIL") + " | " + name + (" | " + detail if detail else ""))
print(f"RESULT: {sum(ok for _,ok,_ in checks)}/{len(checks)} checks passed")
raise SystemExit(0 if all(ok for _,ok,_ in checks) else 1)

# Regression checks for the shift estimator: evaluate RPM on every OBD loop, not only GPS updates.
check("Shift estimator is evaluated on every OBD loop", "gearShifts=shiftEstimator.update(rpm,speed,now);" in JAVA and JAVA.index("gearShifts=shiftEstimator.update(rpm,speed,now);") < JAVA.index("if(speed>=0 && gpsNs>0 && gpsNs!=lastProcessedGpsNs)"))
check("Shift estimator requires high RPM and abrupt drop", "prevRpm>=3000 && rpm>=1000 && rpm <= prevRpm-500" in JAVA)
check("Shift estimator confirms RPM recovery and speed consistency", "rpmRecovered" in JAVA and "speedConsistent" in JAVA and "candidateSpeed-1.5" in JAVA)
check("Shift estimator rejects stale candidates and applies cooldown", "2500000000L" in JAVA and "1200000000L" in JAVA)
check("Old GPS-gated shift counter removed", "(gpsNs-lastShiftNs)>600000000L" not in JAVA)
