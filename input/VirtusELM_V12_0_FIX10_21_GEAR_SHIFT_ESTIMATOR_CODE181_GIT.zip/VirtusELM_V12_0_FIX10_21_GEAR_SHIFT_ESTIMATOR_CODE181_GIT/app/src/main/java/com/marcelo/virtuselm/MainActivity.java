package com.marcelo.virtuselm;

import android.Manifest;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.ContentUris;
import android.database.Cursor;
import android.content.pm.PackageManager;
import android.os.*;
import android.text.method.ScrollingMovementMethod;
import android.view.*;
import android.widget.*;
import android.text.TextUtils;
import android.content.Intent;
import android.os.Build;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.content.ClipData;
import android.content.ContentValues;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.os.Environment;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter bt; private BluetoothSocket socket; private InputStream in; private OutputStream out;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextView status, stats, log, result, canTable, canFilterHint, canDiag;
    private LinearLayout dataScreen, homeScreen, diagnosticScreen, canScreen, configScreen, graphScreen, performanceScreen;
    private ScrollView logScroll, diagnosticScroll;
    private FrameLayout appContainer;
    private LinearLayout mainShell;
    private TextView resultHome;
    private int currentScreen=0;
    // ===== V12 — BASE CONSOLIDADA =====
    // Menu ativo preservado; V12 mantém a navegação consolidada.
    private final ArrayList<LinearLayout> navItems=new ArrayList<>();
    private final ArrayList<ImageView> navIcons=new ArrayList<>();
    private final ArrayList<TextView> navLabels=new ArrayList<>();
    private static final int SIM_CYAN=Color.rgb(0,194,255);
    private final int NAV_ACTIVE=Color.rgb(35,185,255);
    private final int NAV_INACTIVE=Color.rgb(175,205,230);
    private TextView dashConn, dashVin, dashIgnition, dashRpm, dashFuel, dashVolt, dashMap, dashBaro, dashBoost, dashBoostMax, dashThrottle, dashCan, dashSpeed, dashLoad, dashCoolant, dashIntake, dashOilTemp, dashOilLevel, dataLiveTelemetry;
    private RpmSegmentBar rpmBar;
    private Button connectButton;
    private TextView healthChip;
    private int noDataCycles = 0;
    private boolean recoveringSession = false;
    private final ScheduledExecutorService dashboardExec = Executors.newSingleThreadScheduledExecutor();
    private volatile boolean dashboardPolling = false;
    private volatile boolean stopRequested = false;
    private volatile long stopDeadline = 0;
    private String lastVin = "—";
    private static final String PROFILE_VIN = "9BWDH6BZ3RP002201";
    private double lastRpm = 0, lastFuel = -1, lastVolt = -1, lastThrottle = -1, lastPedalD = -1, lastPedalE = -1, lastPedalF = -1, lastMap = -1, lastBaro = -1, lastBoost = -1, maxBoost = -1, lastSpeed = -1, lastGpsSpeed = -1, lastLoad = -1, lastCoolant = -1, lastIntake = -1, lastOilTemp = -1;
    private LocationManager locationManager;
    private volatile long gpsLastElapsedNs = 0L;
    private volatile float gpsAccuracyM = Float.MAX_VALUE;
    private volatile boolean gpsHasFix = false;
    private LocationListener gpsListener;
    private static final int REQ_GPS_LOCATION = 30;
    private String lastOilLevel = "—";
    private boolean ecuResponding = false;
    private final StringBuilder technical = new StringBuilder();
    private final Object logLock = new Object();
    private volatile boolean monitoring = false;
    private volatile boolean operationRunning = false;
    private long rawCount=0, frameCount=0, rxBytes=0;
    private final LinkedHashSet<String> ids = new LinkedHashSet<>();
    private final LinkedHashMap<String,Long> idCounts = new LinkedHashMap<>();
    private final Object canDataLock = new Object();
    private final ArrayDeque<String> recentCanFrames = new ArrayDeque<>();
    private EditText canFilterInput;
    private long lastStatsUi=0, lastMonitorUi=0;
    private final List<Marker> markers = new ArrayList<>();
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);
    private String lastProtocol="";
    private volatile boolean intentionalDisconnect = false;
    private volatile boolean reconnecting = false;
    private volatile boolean connected = false;
    private volatile boolean connectAttempt = false;
    // ===== V12.0 FIX 01 — CONEXÃO AUTOMÁTICA COM SIMULAÇÃO DE PARTIDA =====
    private volatile boolean autoConnectActive = false;
    private int autoConnectAttempts = 0;
    // ===== V12 — MODO SIMULAÇÃO PRESERVADO =====
    private volatile boolean simulationMode = false;
    private long simulationStartMs = 0L;
    private final ArrayList<SimSample> simulationSamples = new ArrayList<>();
    private int simulationIndex = 0;
    private String simulationSource = "perfil interno de demonstração";
    private static class SimSample {
        double rpm,speed,map,baro,throttle,load,coolant,intake,fuel,volt,oil;
        SimSample(double r,double s,double m,double b,double t,double l,double c,double i,double f,double v,double o){rpm=r;speed=s;map=m;baro=b;throttle=t;load=l;coolant=c;intake=i;fuel=f;volt=v;oil=o;}
    }
    // Estado da gravação de telemetria — permanece independente da navegação V11.4.
    private volatile boolean recordingActive = false;
    private BufferedWriter recordingWriter = null;
    private File recordingFile = null;
    private long recordingStartMs = 0L;
    private int recordingSamples = 0;
    private int recordingTick = 0;
    private double recordingMaxBoost = -999.0;
    private static final String PREFS_UI = "virtus_elm_ui";
    private static final String PREF_KEEP_SCREEN = "keep_screen_on";
    private static final String PREF_HAPTIC = "haptic_feedback";
    private static final String PREF_PERF_ETHANOL = "performance_ethanol_pct";
    private static final String PREF_REALTIME_DATA = "realtime_data_enabled";
    private static final String PREF_TECH_LOG = "technical_log_enabled";
    private static final String PREF_PERF_HISTORY = "performance_history_enabled";
    private static final String PREF_PEDAL_CAL_MIN = "performance_pedal_cal_min";
    private static final String PREF_PEDAL_CAL_MAX = "performance_pedal_cal_max";
    private static final String PREF_AUTO_SIM = "simulation_auto_enabled";
    private static final String PREF_AUTO_CONNECT = "auto_connect_elm";
    private static final String PREF_PRESSURE_UNIT = "pressure_unit";
    private static final String PREF_SPEED_UNIT = "speed_unit";
    private BufferedWriter historyWriter = null;
    private Uri historyUri = null;
    private File historyLegacyFile = null;
    private long historySamples = 0L;
    private double lastPerfPower = -1, lastPerfTorque = -1, lastPerf0100 = -1, lastPerf0060 = -1, lastPerfQuality = -1, lastPerfPullDuration = -1;
    private int lastPerfGearShifts = 0;
    private String lastPerfSpeedGrid = "";
    private GraphView graphView;
    private CombinedGraphView combinedGraphView;
    private String graphMetric = "BOOST";
    private final ArrayDeque<Float> combinedRpmValues=new ArrayDeque<>();
    private final ArrayDeque<Float> combinedSpeedValues=new ArrayDeque<>();
    private final ArrayDeque<Float> combinedThrottleValues=new ArrayDeque<>();
    private final ArrayDeque<Float> combinedPedalValues=new ArrayDeque<>();
    private final ArrayDeque<Float> combinedBoostValues=new ArrayDeque<>();
    private final ArrayDeque<Float> combinedTimeValues=new ArrayDeque<>();
    private volatile boolean historicalGraphMode=false;
    private TextView graphHistoryStatus, graphHeaderTitle;
    private static class PerfGraphSample { final double t,rpm,speed,pedal,boost; PerfGraphSample(double t,double rpm,double speed,double pedal,double boost){this.t=t;this.rpm=rpm;this.speed=speed;this.pedal=pedal;this.boost=boost;} }

    /** Estimates upshifts from the high-rate OBD RPM stream, then confirms recovery against speed. */
    private static class GearShiftEstimator {
        private double prevRpm=-1, prevSpeed=-1, candidateRpm=-1, candidateSpeed=-1;
        private long prevNs=0, candidateNs=0, lastConfirmedNs=0;
        private int shifts=0;
        int update(double rpm, double speed, long nowNs) {
            if (rpm < 900 || speed < 0 || nowNs <= 0) { prevRpm=rpm; prevSpeed=speed; prevNs=nowNs; return shifts; }
            if (candidateNs > 0) {
                long age=nowNs-candidateNs;
                boolean speedConsistent = speed >= candidateSpeed-1.5 && speed >= prevSpeed-1.5;
                boolean rpmRecovered = rpm >= candidateRpm + Math.max(250.0, candidateRpm*0.06);
                if (age <= 2500000000L && rpmRecovered && speedConsistent && (lastConfirmedNs==0 || nowNs-lastConfirmedNs>=1200000000L)) {
                    shifts++; lastConfirmedNs=nowNs; candidateNs=0;
                } else if (age > 2500000000L || speed < candidateSpeed-3.0) {
                    candidateNs=0;
                }
            }
            if (candidateNs==0 && prevRpm>=3000 && rpm>=1000 && rpm <= prevRpm-500 && speed >= prevSpeed-1.5 && (lastConfirmedNs==0 || nowNs-lastConfirmedNs>=1200000000L)) {
                candidateRpm=rpm; candidateSpeed=speed; candidateNs=nowNs;
            }
            prevRpm=rpm; prevSpeed=speed; prevNs=nowNs;
            return shifts;
        }
    }
    private final ArrayList<PerfGraphSample> activePerfGraphSamples=new ArrayList<>();
    private final ArrayList<PerfGraphSample> lastPerfGraphSamples=new ArrayList<>();
    private TextView perfPower, perfTorque, perf0100, perf0060, perfFuel, perfBoost, perfStatus, perfConfidence, perfQuality;
    private TextView devPedalResult;
    private final ArrayList<Button> graphButtons=new ArrayList<>();
    private final ArrayList<Button> dataTabButtons=new ArrayList<>();
    private TextView dtcStatusView, dtcCodesView, dtcRawView;
    private LinearLayout dtcListContainer;
    private Button clearDtcButton, selectDtcButton;
    private boolean dataLogsTab = false;
    private LinearLayout dataTelemetryContent, dataLogsContent;
    private boolean dtcSelectionMode = false;
    private final LinkedHashSet<String> selectedDtcCodes = new LinkedHashSet<>();
    private final LinkedHashSet<String> lastDtcCodes = new LinkedHashSet<>();
    private final LinkedHashSet<String> simulatedDtcCodes = new LinkedHashSet<>(Arrays.asList("P0133"));
    // EPC/DTC evidence gate: real Mode 04 is blocked until an EPC evidence report is saved in this app session.
    private volatile boolean epcEvidenceSavedThisSession = false;
    private volatile String lastEpcEvidenceFile = "";
    private static final String DTC_LIBRARY_MANIFEST_URL = "https://raw.githubusercontent.com/kdmarcelo-hue/AndroidForge/main/library/library_info.json";
    private final LinkedHashMap<String,String> dtcLibraryDescriptions = new LinkedHashMap<>();
    private String dtcLibraryVersion = "1.0.0";
    private TextView dtcLibraryStatusView;
    private TextView dtcConfigStatusView;
    private LinearLayout dtcLibraryScreen;
    private LinearLayout dtcLibraryListContainer;
    private EditText dtcLibrarySearch;
    private final LinkedHashMap<String,JSONObject> dtcLibraryRecords = new LinkedHashMap<>();
    private TextView vagExplorerResult, diagnosticResult;
    private Button perfEthanolButton;
    private volatile boolean performanceRunning=false;
    private volatile boolean performanceStop=false;
    // ===== V12.0-FIX05 — HISTÓRICO / PERFORMANCE 2.0 =====
    private LinearLayout historyScreen;
    private static final int REQ_HISTORY_TREE = 741;
    private final LinkedHashMap<String,Uri> historyFileUris = new LinkedHashMap<>();
    private Uri historyTreeUri = null;
    private TextView perfMaxRpm, perfMaxSpeed, perfDuration, perfSessionCount;
    private double lastPerfMaxRpm=-1, lastPerfMaxSpeed=-1, lastPerfMaxBoost=-1, lastPerfDuration=-1;
    private final ArrayList<String> historySessionNames=new ArrayList<>();

    /** Barra de RPM segmentada: 0–4k verde, 4–6k amarelo, 6–8k vermelho; segmentos inativos permanecem na mesma família de cor em baixa intensidade. */
    /** Gráfico LIVE com escala fixa por parâmetro, grade e unidade. */
    private class GraphView extends View {
        private final Paint line=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint grid=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final ArrayDeque<Float> values=new ArrayDeque<>();
        private float min=0,max=1;
        private String metric="BOOST", unit="bar";
        GraphView(Context c){
            super(c); setBackgroundColor(Color.rgb(2,20,38));
            line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(5f);
            grid.setStyle(Paint.Style.STROKE); grid.setStrokeWidth(1f);
            text.setColor(Color.rgb(165,195,220)); text.setTextSize(11f*c.getResources().getDisplayMetrics().scaledDensity);
            text.setTextAlign(Paint.Align.RIGHT);
            setWillNotDraw(false);
            configure("BOOST");
        }
        private void configure(String m){
            metric=m;
            if("RPM".equals(m)){min=0;max=8000;unit="rpm";}
            else if("BOOST".equals(m)){
                boolean kpa="kPa".equals(getPressureUnit());
                min=0; max=kpa?300:3; unit=kpa?"kPa":"bar";
            }
            else if("THROTTLE".equals(m)){min=0;max=100;unit="%";}
            else if("VELOCIDADE".equals(m)){boolean mph="mph".equals(getSpeedUnit());min=0;max=mph?174.0f:280;unit=mph?"mph":"km/h";}
            values.clear(); invalidate();
        }
        void setMetric(String m){configure(m);}
        void add(float v){if(Float.isNaN(v)||v<-999)return; values.add(v); while(values.size()>120)values.removeFirst(); invalidate();}
        String range(){return String.format(Locale.US,"0–%s %s",("RPM".equals(metric)?"8000": "BOOST".equals(metric)?(getPressureUnit().equals("kPa")?"300":"3,0"):"THROTTLE".equals(metric)?"100":(getSpeedUnit().equals("mph")?"174":"280")),unit);}
        String unit(){return unit;}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth(),h=getHeight();
            float left=dpLocal(48), top=dpLocal(10), right=w-dpLocal(8), bottom=h-dpLocal(12);
            float plotW=Math.max(1,right-left), plotH=Math.max(1,bottom-top);
            int divisions=5;
            grid.setColor(Color.rgb(25,70,105));
            for(int i=0;i<=divisions;i++){float y=top+plotH*i/divisions; c.drawLine(left,y,right,y,grid);}
            for(int i=0;i<=divisions;i++){float y=top+plotH*i/divisions; double val=max-(max-min)*i/(double)divisions; String lab=label(val); c.drawText(lab,left-dpLocal(5),y+dpLocal(4),text);}
            if(values.size()<2)return;
            line.setColor(Color.rgb(0,210,255));
            float dx=plotW/(values.size()-1f), prevY=0; int i=0;
            for(float v:values){float clamped=Math.max(min,Math.min(max,v)); float x=left+i*dx; float y=bottom-(clamped-min)/(max-min)*plotH; if(i>0)c.drawLine(left+(i-1)*dx,prevY,x,y,line); prevY=y; i++;}
        }
        private String label(double v){
            if("RPM".equals(metric)) return String.format(Locale.US,"%.0f",v);
            if("BOOST".equals(metric)) return String.format(Locale.US,"%.1f",v);
            return String.format(Locale.US,"%.0f",v);
        }
        private float dpLocal(float v){return v*getResources().getDisplayMetrics().density;}
    }

    /** Gráfico combinado com quatro eixos visuais independentes: velocidade/throttle à esquerda e boost/RPM à direita. */
    private class CombinedGraphView extends View {
        private final Paint grid=new Paint(Paint.ANTI_ALIAS_FLAG), line=new Paint(Paint.ANTI_ALIAS_FLAG), text=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int SPEED=Color.rgb(55,150,255), THROTTLE=Color.WHITE, BOOST=Color.rgb(255,190,0), RPM=Color.rgb(0,220,180);
        CombinedGraphView(Context c){ super(c); setBackgroundColor(Color.rgb(2,20,38)); grid.setStyle(Paint.Style.STROKE); grid.setStrokeWidth(1f); line.setStyle(Paint.Style.STROKE); text.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); setWillNotDraw(false); }
        private float dp(float v){return v*getResources().getDisplayMetrics().density;}
        private void axisLabel(Canvas c,String s,float x,float y,int color,Paint.Align align){ text.setTextSize(9f*getResources().getDisplayMetrics().scaledDensity); text.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); text.setTextAlign(align); text.setColor(color); c.drawText(s,x,y,text); }
        private void tick(Canvas c,String s,float x,float y,int color,Paint.Align align){ text.setTextSize(8f*getResources().getDisplayMetrics().scaledDensity); text.setTypeface(android.graphics.Typeface.DEFAULT); text.setTextAlign(align); text.setColor(color); c.drawText(s,x,y,text); }
        private void drawSeries(Canvas c,ArrayDeque<Float> vals,float min,float max,int color,float left,float top,float pw,float ph){
            if(vals.size()<2)return; line.setColor(color); line.setStrokeWidth(dp(2.2f));
            Float[] a=vals.toArray(new Float[0]); Float[] times=combinedTimeValues.toArray(new Float[0]); float dx=pw/Math.max(1,a.length-1); float maxTime=times.length>0?Math.max(0.001f,times[times.length-1]):0; float px=0,py=0; boolean have=false;
            for(int i=0;i<a.length;i++){
                float v=a[i]==null?Float.NaN:a[i]; if(Float.isNaN(v)||v<min){have=false;continue;}
                float n=Math.max(0,Math.min(1,(v-min)/(max-min))); float x=(historicalGraphMode&&times.length==a.length)?left+Math.max(0,Math.min(1,times[i]/maxTime))*pw:left+i*dx; float y=top+ph-n*ph;
                if(have)c.drawLine(px,py,x,y,line); px=x; py=y; have=true;
            }
        }
        private String fmt(double v,int decimals){return decimals==0?String.format(Locale.US,"%.0f",v):String.format(Locale.US,"%.1f",v);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth(),h=getHeight();
            float left=dp(58), right=w-dp(58), top=dp(38), bottom=h-dp(28); float pw=Math.max(1,right-left), ph=Math.max(1,bottom-top);
            // Cabeçalhos dos quatro eixos — substituem a legenda antiga.
            axisLabel(c,"VELOCIDADE",dp(5),dp(13),SPEED,Paint.Align.LEFT); axisLabel(c,"PEDAL",dp(5),dp(25),THROTTLE,Paint.Align.LEFT);
            axisLabel(c,"BOOST",w-dp(5),dp(13),BOOST,Paint.Align.RIGHT); axisLabel(c,"RPM",w-dp(5),dp(25),RPM,Paint.Align.RIGHT);
            grid.setColor(Color.rgb(25,70,105));
            for(int i=0;i<=7;i++){float y=top+ph*i/7f;c.drawLine(left,y,right,y,grid);}
            for(int i=0;i<=7;i++){
                float y=top+ph*i/7f; double f=1-i/7.0;
                tick(c,fmt(280*f,0),dp(5),y+dp(3),SPEED,Paint.Align.LEFT);
                tick(c,fmt(100*f,0),dp(43),y+dp(3),THROTTLE,Paint.Align.RIGHT);
                tick(c,fmt(3*f,1),w-dp(43),y+dp(3),BOOST,Paint.Align.LEFT);
                tick(c,fmt(8000*f,0),w-dp(5),y+dp(3),RPM,Paint.Align.RIGHT);
            }
            drawSeries(c,combinedSpeedValues,0,280,SPEED,left,top,pw,ph);
            drawSeries(c,combinedPedalValues,0,100,THROTTLE,left,top,pw,ph);
            drawSeries(c,combinedBoostValues,0,3,BOOST,left,top,pw,ph);
            drawSeries(c,combinedRpmValues,0,8000,RPM,left,top,pw,ph);
            text.setTextSize(8f*getResources().getDisplayMetrics().scaledDensity); text.setTypeface(android.graphics.Typeface.DEFAULT); text.setTextAlign(Paint.Align.CENTER); text.setColor(Color.rgb(130,165,195)); c.drawText("TEMPO (s)",w/2f,h-dp(7),text);
        }
        void add(float rpm,float speed,float pedal,float boost){ addOne(combinedRpmValues,rpm,8000); addOne(combinedSpeedValues,speed<0?Float.NaN:speed,280); addOne(combinedPedalValues,pedal,100); addOne(combinedBoostValues,boost,3); invalidate(); }
        private void addOne(ArrayDeque<Float> q,float v,float max){ if(Float.isNaN(v)){q.add(Float.NaN);} else if(v<0)return; else q.add(Math.min(max,v)); while(q.size()>(historicalGraphMode?1200:180))q.removeFirst(); }
        void clear(){combinedRpmValues.clear();combinedSpeedValues.clear();combinedThrottleValues.clear();combinedPedalValues.clear();combinedBoostValues.clear();combinedTimeValues.clear();invalidate();}
    }

    private static class RpmSegmentBar extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); private float rpm=0f;
        private final int green=Color.rgb(120,235,150), greenDim=Color.rgb(18,62,42);
        private final int yellow=Color.rgb(255,210,80), yellowDim=Color.rgb(70,58,20);
        private final int red=Color.rgb(255,82,92), redDim=Color.rgb(70,24,30);
        RpmSegmentBar(Context c){super(c); paint.setStyle(Paint.Style.FILL); setWillNotDraw(false);}
        void setRpm(double v){rpm=(float)Math.max(0,Math.min(8000,v)); invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth(),h=getHeight(); float gap=dpLocal(3); int n=32; float sw=(w-gap*(n-1))/n; float active=(rpm/8000f)*n;
            for(int i=0;i<n;i++){ float x=i*(sw+gap); float center=(i+0.5f)/n*8000f; boolean on=i<active; int color=center<4000? (on?green:greenDim) : center<6000? (on?yellow:yellowDim) : (on?red:redDim); paint.setColor(color); c.drawRoundRect(new RectF(x,1,x+sw,h-1),2,2,paint); }
        }
        private float dpLocal(float v){return v*getResources().getDisplayMetrics().density;}
    }

    /** Escala da barra de RPM: cada número fica centrado exatamente sobre uma das posições de referência da barra. */
    private static class RpmScaleView extends View {
        private final Paint text=new Paint(Paint.ANTI_ALIAS_FLAG);
        RpmScaleView(Context c){super(c); text.setColor(Color.rgb(165,195,220)); text.setTextSize(9f*c.getResources().getDisplayMetrics().scaledDensity); text.setTextAlign(Paint.Align.CENTER); text.setTypeface(android.graphics.Typeface.DEFAULT); setWillNotDraw(false);}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth(),h=getHeight(); float gap=3f*getResources().getDisplayMetrics().density; int n=32; float sw=(w-gap*(n-1))/n; float first=sw/2f; float last=(n-1)*(sw+gap)+sw/2f; Paint.FontMetrics fm=text.getFontMetrics(); float baseline=h/2f-(fm.ascent+fm.descent)/2f; for(int i=0;i<=8;i++){float x=first+(last-first)*(i/8f); c.drawText(String.valueOf(i),x,baseline,text);} }
    }

    static class Marker {
        String type; long raw, frames, bytes, when; Map<String,Long> idsAt;
        Marker(String t,long r,long f,long b,Map<String,Long> counts){
            type=t; raw=r; frames=f; bytes=b; when=System.currentTimeMillis(); idsAt=new LinkedHashMap<>(counts);
        }
    }

    @Override public void onCreate(Bundle b){ super.onCreate(b); applyKeepScreenPreference(); buildUi(); initializeDtcLibrary(); try { bt=BluetoothAdapter.getDefaultAdapter(); } catch(Exception e) { bt=null; } resetSession(); append("[00] INÍCIO DE NOVA SESSÃO — V12.0"); append("BASE COMPLETA V12 + simulação configurável + conexão automática + unidades configuráveis."); append("SOMENTE LEITURA: nenhum comando de atuação, coding, adaptation, security access ou CAN arbitrário é transmitido."); io.execute(()->seedBundledPerformanceHistory()); startDashboardPolling(); if(isAutoConnectEnabled()||isAutoSimulationEnabled()) startAutomaticConnectionSequence(); }

    private static final int BLUE = Color.rgb(13, 71, 161);
    private static final int BLUE_DARK = Color.rgb(7, 45, 99);
    private static final int BLUE_LIGHT = Color.rgb(232, 240, 254);
    private static final int BLUE_BORDER = Color.rgb(144, 180, 220);
    private static final int TEXT = Color.rgb(35, 45, 55);

    private int dp(float v){ return Math.round(v * getResources().getDisplayMetrics().density); }

    /** Feedback padrão para toda área realmente interativa. O toque háptico pode ser desativado em Configurações. */
    private void bindClick(View v, final Runnable action){
        v.setClickable(true);
        v.setFocusable(true);
        v.setHapticFeedbackEnabled(isHapticEnabled());
        v.setOnClickListener(view->{
            if(isHapticEnabled()) view.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            if(action!=null) action.run();
        });
    }

    private android.graphics.drawable.Drawable pressableBg(int normalColor,int pressedColor,int strokeColor,float radius){
        android.graphics.drawable.GradientDrawable normal=new android.graphics.drawable.GradientDrawable();
        normal.setColor(normalColor); normal.setCornerRadius(dp(radius)); normal.setStroke(dp(1),strokeColor);
        android.graphics.drawable.GradientDrawable pressed=new android.graphics.drawable.GradientDrawable();
        pressed.setColor(pressedColor); pressed.setCornerRadius(dp(radius)); pressed.setStroke(dp(2),Color.rgb(0,210,255));
        android.graphics.drawable.StateListDrawable states=new android.graphics.drawable.StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed},pressed);
        states.addState(new int[]{},normal);
        return states;
    }

    private TextView tv(String s,float size){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,size); t.setTextColor(TEXT);
        t.setIncludeFontPadding(true); t.setPadding(dp(8),dp(5),dp(8),dp(5)); return t;
    }
    private Button btn(String s){
        Button b=new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextSize(11); b.setTextColor(Color.rgb(235,248,255));
        b.setGravity(Gravity.CENTER); b.setSingleLine(true); b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(dp(50)); b.setMinimumHeight(dp(50)); b.setPadding(dp(5),dp(1),dp(5),dp(1)); b.setIncludeFontPadding(false); b.setHorizontallyScrolling(false);
        if(Build.VERSION.SDK_INT>=26){ b.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP); }
        android.graphics.drawable.GradientDrawable normal=new android.graphics.drawable.GradientDrawable();
        normal.setColor(Color.rgb(7,38,70)); normal.setCornerRadius(dp(24)); normal.setStroke(dp(1), Color.rgb(25,125,195));
        android.graphics.drawable.GradientDrawable pressed=new android.graphics.drawable.GradientDrawable();
        pressed.setColor(Color.rgb(10,70,115)); pressed.setCornerRadius(dp(24)); pressed.setStroke(dp(2), Color.rgb(0,200,255));
        android.graphics.drawable.StateListDrawable states=new android.graphics.drawable.StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, pressed); states.addState(new int[]{}, normal);
        b.setBackground(states); b.setStateListAnimator(null); b.setSoundEffectsEnabled(true);
        return b;
    }
    private void addFull(LinearLayout r, View v){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(dp(6),dp(3),dp(6),dp(3)); r.addView(v,lp);
    }
    private void addTight(LinearLayout r, View v){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(dp(4),dp(1),dp(4),dp(1)); r.addView(v,lp);
    }
    private LinearLayout row(){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(dp(4),0,dp(4),0); return r;
    }
    private void addHalf(LinearLayout r, Button b){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(3),0,dp(3),0);
        r.addView(b,lp);
    }
    private void addThird(LinearLayout r, Button b){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(2),0,dp(2),0);
        r.addView(b,lp);
    }
    private LinearLayout section(String title){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();
        bg.setColor(BLUE);
        bg.setCornerRadius(dp(18));
        box.setBackground(bg);
        box.setPadding(dp(14),dp(12),dp(14),dp(12));
        TextView t=tv(title,20);
        t.setTextColor(Color.WHITE);
        t.setTypeface(null,android.graphics.Typeface.BOLD);
        t.setGravity(Gravity.CENTER); t.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        box.addView(t,new LinearLayout.LayoutParams(-1,-2));
        return box;
    }
    private void buildUi(){
        final int BG = Color.rgb(1,10,22), CARD = Color.rgb(3,25,49), CARD2 = Color.rgb(4,31,60);
        final int CYAN = Color.rgb(0,194,255), CYAN2 = Color.rgb(45,142,255), WHITE = Color.rgb(242,248,255), MUTED = Color.rgb(145,181,210);

        // Estrutura V11.4: cabeçalho fixo + área central de conteúdo + menu fixo.
        appContainer=new FrameLayout(this); appContainer.setBackgroundColor(BG);
        LinearLayout shell=new LinearLayout(this); shell.setOrientation(LinearLayout.VERTICAL); shell.setBackgroundColor(BG);

        // CABEÇALHO FIXO — identidade do aplicativo permanece na tela durante toda a navegação.
        LinearLayout hero=card(Color.rgb(2,20,43));
        GradientDrawable hb=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(4,38,82),Color.rgb(2,12,28)});
        hb.setCornerRadius(dp(20)); hb.setStroke(dp(1),CYAN2); hero.setBackground(hb); hero.setPadding(dp(10),dp(3),dp(10),dp(3));
        LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=icon(R.drawable.v11_logo,CYAN); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); brand.addView(logo,new LinearLayout.LayoutParams(dp(60),dp(60)));
        LinearLayout bt=new LinearLayout(this); bt.setOrientation(LinearLayout.VERTICAL); bt.setGravity(Gravity.CENTER_VERTICAL); bt.setPadding(dp(6),0,0,0);
        TextView title=tv("VIRTUS",10.5f); title.setTextColor(WHITE); title.setTypeface(null,android.graphics.Typeface.BOLD); title.setSingleLine(true); title.setGravity(Gravity.CENTER); title.setIncludeFontPadding(false);
        TextView sub=tv("V12  •  DIAGNÓSTICO",9.5f); sub.setTextColor(CYAN); sub.setTypeface(null,android.graphics.Typeface.BOLD); sub.setSingleLine(true); sub.setGravity(Gravity.CENTER); sub.setIncludeFontPadding(false);
        TextView strap=tv("LEITURA  •  ANÁLISE  •  CAN",8.2f); strap.setTextColor(MUTED); strap.setSingleLine(true); strap.setGravity(Gravity.CENTER); strap.setIncludeFontPadding(false); strap.setPadding(0,0,0,0);
        bt.addView(title,new LinearLayout.LayoutParams(-1,dp(23))); bt.addView(sub,new LinearLayout.LayoutParams(-1,dp(20))); bt.addView(strap,new LinearLayout.LayoutParams(-1,dp(20))); bt.setTranslationY(-dp(1));
        brand.addView(bt,new LinearLayout.LayoutParams(0,dp(70),1));
        // ===== V12.0-FIX06 — TOQUE NO VIRTUS / PISCADA DO FAROL =====
        // Mantém a imagem e o enquadramento originais; apenas adiciona uma camada
        // transparente sobre os faróis para o efeito visual de luz alta.
        FrameLayout carFrame=new FrameLayout(this);
        LinearLayout.LayoutParams carLp=new LinearLayout.LayoutParams(dp(145),dp(78)); carLp.gravity=Gravity.BOTTOM;
        ImageView car=new ImageView(this); car.setImageResource(R.drawable.v11_car_header_clean); car.setScaleType(ImageView.ScaleType.FIT_CENTER); car.setTranslationY(dp(1));
        carFrame.addView(car,new FrameLayout.LayoutParams(-1,-1));
        HeadlightFlashView headlightFlash=new HeadlightFlashView(this);
        carFrame.addView(headlightFlash,new FrameLayout.LayoutParams(-1,-1));
        carFrame.setContentDescription("Virtus — tocar para piscar os faróis");
        carFrame.setClickable(true);
        carFrame.setOnClickListener(v -> triggerHeadlightFlashAndSafeCacheClear(headlightFlash));
        brand.addView(carFrame,carLp); hero.addView(brand);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(100)); hp.setMargins(dp(8),dp(5),dp(8),dp(5)); shell.addView(hero,hp);

        // ÁREA CENTRAL — somente esta região troca de tela.
        FrameLayout contentHost=new FrameLayout(this); shell.addView(contentHost,new LinearLayout.LayoutParams(-1,0,1));

        homeScreen=buildHomeScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        diagnosticScreen=buildDiagnosticScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        canScreen=buildCanScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        configScreen=buildConfigScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        dataScreen=buildDataScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        graphScreen=buildGraphScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        performanceScreen=buildPerformanceScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        historyScreen=buildHistoryScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        dtcLibraryScreen=buildDtcLibraryScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        contentHost.addView(homeScreen,screenLp()); contentHost.addView(dataScreen,screenLp()); contentHost.addView(diagnosticScreen,screenLp()); contentHost.addView(canScreen,screenLp()); contentHost.addView(configScreen,screenLp()); contentHost.addView(graphScreen,screenLp()); contentHost.addView(performanceScreen,screenLp()); contentHost.addView(historyScreen,screenLp()); contentHost.addView(dtcLibraryScreen,screenLp());
        dataScreen.setVisibility(View.GONE); diagnosticScreen.setVisibility(View.GONE); canScreen.setVisibility(View.GONE); configScreen.setVisibility(View.GONE); graphScreen.setVisibility(View.GONE); performanceScreen.setVisibility(View.GONE); historyScreen.setVisibility(View.GONE); dtcLibraryScreen.setVisibility(View.GONE);

        // MENU FIXO — navegação troca somente o conteúdo central.
        LinearLayout nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setGravity(Gravity.CENTER); nav.setPadding(dp(4),dp(5),dp(4),dp(5)); nav.setBackground(cardBg(Color.rgb(3,24,47),24,CYAN2));
        addNav(nav,R.drawable.ic_home,"Início",NAV_ACTIVE,()->showHomeScreen());
        addNav(nav,R.drawable.ic_chart,"Dados",NAV_INACTIVE,()->showDataScreen());
        addNav(nav,R.drawable.ic_engine,"Diagnóstico",NAV_INACTIVE,()->showDiagnosticScreen());
        addNav(nav,R.drawable.ic_can,"CAN",NAV_INACTIVE,()->showCanScreen());
        addNav(nav,R.drawable.ic_settings,"Config",NAV_INACTIVE,()->showConfigScreen());
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(104)); np.setMargins(dp(5),dp(4),dp(5),dp(8)); shell.addView(nav,np);

        mainShell=shell; setContentView(shell); currentScreen=0;
    }

    private LinearLayout.LayoutParams screenLp(){ return new LinearLayout.LayoutParams(-1,-1); }

    /**
     * FIX06: efeito visual de farol alto + limpeza somente do cache temporário
     * pertencente ao próprio aplicativo. Não toca em SharedPreferences, banco,
     * arquivos persistentes, histórico CSV ou dados de configuração.
     */
    private void triggerHeadlightFlashAndSafeCacheClear(HeadlightFlashView flash){
        if(flash!=null) flash.flash();
        io.execute(() -> {
            int removed=0;
            try{ removed += clearCacheContents(getCacheDir()); }catch(Exception ignored){}
            try{ if(getExternalCacheDir()!=null) removed += clearCacheContents(getExternalCacheDir()); }catch(Exception ignored){}
            final int count=removed;
            main.post(() -> {
                if(isTechLogEnabled()){ append("FIX06: toque no Virtus — piscada de farol executada; cache temporário interno limpo: "+count+" item(ns).\n"); }
            });
        });
    }

    private int clearCacheContents(File dir){
        if(dir==null || !dir.exists() || !dir.isDirectory()) return 0;
        File[] children=dir.listFiles();
        if(children==null) return 0;
        int removed=0;
        for(File child:children){
            if(deleteRecursively(child)) removed++;
        }
        return removed;
    }

    private boolean deleteRecursively(File f){
        if(f==null || !f.exists()) return false;
        if(f.isDirectory()){
            File[] children=f.listFiles();
            if(children!=null) for(File child:children) deleteRecursively(child);
        }
        return f.delete();
    }

    /** Camada transparente sobre a imagem do Virtus; coordenadas normalizadas
     * pelos faróis da arte 313x170 usada no cabeçalho. */
    private static class HeadlightFlashView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF left=new RectF(), right=new RectF();
        private float flashAlpha=0f;
        private long start=0L;
        private boolean running=false;
        private final Runnable ticker=new Runnable(){ @Override public void run(){
            long elapsed=System.currentTimeMillis()-start;
            if(elapsed>=520){ flashAlpha=0f; running=false; invalidate(); return; }
            if(elapsed<90) flashAlpha=elapsed/90f;
            else if(elapsed<300) flashAlpha=1f;
            else flashAlpha=1f-((elapsed-300)/220f);
            invalidate(); postDelayed(this,16);
        }};
        HeadlightFlashView(Context c){ super(c); setWillNotDraw(false); setClickable(false); }
        void flash(){
            removeCallbacks(ticker); start=System.currentTimeMillis(); running=true; flashAlpha=0f; invalidate(); post(ticker);
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            if(!running && flashAlpha<=0f) return;
            float w=getWidth(), h=getHeight();
            // FIX06.3: faróis deslocados ligeiramente para baixo; brilho concentrado no centro óptico;
            // o efeito fica sobre os faróis, não sobre o capô/parabrisa.
            float lx=w*0.027f, ly=h*0.60f, rx=w*0.47f, ry=h*0.60f;
            float lw=w*0.065f, rw=w*0.095f, hh=h*0.095f;
            paint.setStyle(Paint.Style.FILL);
            // FIX06.3: brilho +20% e núcleo central mais intenso, como uma lâmpada real.
            for(int i=3;i>=1;i--){
                float a=Math.min(1f,flashAlpha*(0.12f*i));
                paint.setColor(Color.argb((int)(255*a),255,255,255));
                float padX=(3-i)*w*0.012f, padY=(3-i)*h*0.010f;
                left.set(lx-lw/2-padX,ly-hh/2-padY,lx+lw/2+padX,ly+hh/2+padY);
                right.set(rx-rw/2-padX,ry-hh/2-padY,rx+rw/2+padX,ry+hh/2+padY);
                c.drawOval(left,paint); c.drawOval(right,paint);
            }
            // Núcleo quente/branco: menor e mais concentrado no centro óptico.
            float coreAlpha=flashAlpha;
            paint.setColor(Color.argb((int)(255*coreAlpha),255,255,255));
            float cl=w*0.032f, cr=w*0.042f, ch=h*0.052f;
            left.set(lx-cl/2,ly-ch/2,lx+cl/2,ly+ch/2);
            right.set(rx-cr/2,ry-ch/2,rx+cr/2,ry+ch/2);
            c.drawOval(left,paint); c.drawOval(right,paint);
        }
    }

    private LinearLayout buildHomeScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout wrap=new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.setBackgroundColor(BG);
        ScrollView page=new ScrollView(this); page.setFillViewport(true); page.setBackgroundColor(BG); page.setClipToPadding(false);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(10),dp(4),dp(10),dp(16)); page.addView(root,new ScrollView.LayoutParams(-1,-2)); wrap.addView(page,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout conn=card(CARD); conn.setPadding(dp(10),dp(8),dp(10),dp(8)); LinearLayout cr=row();
        healthChip=healthChip("● OFFLINE",Color.rgb(255,88,88),Color.rgb(61,16,24)); LinearLayout.LayoutParams healthLp=new LinearLayout.LayoutParams(0,dp(58),1.12f); healthLp.setMargins(0,0,dp(3),0); cr.addView(healthChip,healthLp);
        ImageView bti=icon(R.drawable.ic_bluetooth,CYAN); LinearLayout.LayoutParams btLp=new LinearLayout.LayoutParams(0,dp(58),0.48f); btLp.setMargins(dp(3),0,dp(3),0); cr.addView(bti,btLp);
        status=tv("Pronto",9); status.setTextColor(MUTED); status.setSingleLine(true); status.setVisibility(View.GONE);
        connectButton=btn("CONECTAR ELM"); connectButton.setTextSize(11); bindClick(connectButton,()->toggleConnection()); connectButton.setMinWidth(0); connectButton.setMinimumWidth(0); LinearLayout.LayoutParams connectLp=new LinearLayout.LayoutParams(0,dp(52),1.12f); connectLp.setMargins(dp(3),0,0,0); cr.addView(connectButton,connectLp); conn.addView(cr); addFull(root,conn);

        LinearLayout live=card(CARD); live.setPadding(dp(10),dp(9),dp(10),dp(10)); LinearLayout dashHead=row(); TextView dl=tv("ROTAÇÃO DO MOTOR",13); dl.setTextColor(WHITE); dl.setTypeface(null,android.graphics.Typeface.BOLD); dashHead.addView(dl,new LinearLayout.LayoutParams(0,dp(30),1));
        TextView model=tv("",10.5f); model.setSingleLine(true); if(Build.VERSION.SDK_INT>=26){ model.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP); } model.setTextColor(WHITE); model.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); model.setTag("vehicleProfile"); dashHead.addView(model,new LinearLayout.LayoutParams(dp(160),dp(30))); live.addView(dashHead);
        LinearLayout cluster=card(CARD2); cluster.setPadding(dp(10),dp(5),dp(10),dp(8));
        LinearLayout rpmTop=row(); dashRpm=tv("0 rpm",39); dashRpm.setTextColor(WHITE); dashRpm.setTypeface(null,android.graphics.Typeface.BOLD); dashRpm.setSingleLine(true); rpmTop.addView(dashRpm,new LinearLayout.LayoutParams(0,dp(72),1)); dashIgnition=tv("IG: —",12); dashIgnition.setTextColor(CYAN); dashIgnition.setTypeface(null,android.graphics.Typeface.BOLD); dashIgnition.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); rpmTop.addView(dashIgnition,new LinearLayout.LayoutParams(dp(72),dp(72))); cluster.addView(rpmTop);
        rpmBar=new RpmSegmentBar(this); cluster.addView(rpmBar,new LinearLayout.LayoutParams(-1,dp(18))); RpmScaleView scale=new RpmScaleView(this); cluster.addView(scale,new LinearLayout.LayoutParams(-1,dp(24)));
        LinearLayout oilRow=row(); dashOilTemp=tv("🛢️ — °C",12); dashOilTemp.setTextColor(CYAN); dashOilTemp.setTypeface(null,android.graphics.Typeface.BOLD); dashOilTemp.setGravity(Gravity.CENTER_VERTICAL); dashOilLevel=tv("NÍVEL —",10); dashOilLevel.setTextColor(Color.rgb(145,181,210)); dashOilLevel.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); oilRow.addView(dashOilTemp,new LinearLayout.LayoutParams(0,dp(30),1)); oilRow.addView(dashOilLevel,new LinearLayout.LayoutParams(0,dp(30),1)); cluster.addView(oilRow);
        LinearLayout tempRow=row(); dashCoolant=tv("TEMP. LÍQUIDO\n— °C",11); dashCoolant.setTextColor(WHITE); tempRow.addView(dashCoolant,new LinearLayout.LayoutParams(0,dp(58),1)); dashIntake=tv("TEMP. ADMISSÃO\n— °C",11); dashIntake.setTextColor(WHITE); dashIntake.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); tempRow.addView(dashIntake,new LinearLayout.LayoutParams(0,dp(58),1)); cluster.addView(tempRow);
        live.addView(cluster,new LinearLayout.LayoutParams(-1,dp(205)));
        LinearLayout g1=row(); dashSpeed=metric("VELOCIDADE","— km/h",WHITE,CYAN); dashBoost=metric("BOOST","— bar",WHITE,CYAN); dashVolt=metric("TENSÃO","— V",WHITE,CYAN); dashLoad=metric("CARGA MOTOR","— %",WHITE,CYAN); addHalfView(g1,dashSpeed);addHalfView(g1,dashBoost);addHalfView(g1,dashVolt);addHalfView(g1,dashLoad); live.addView(g1);
        LinearLayout g2=row(); dashMap=metric("MAP","— kPa",WHITE,CYAN); dashBaro=metric("BARO","— kPa",WHITE,CYAN); dashThrottle=metric("THROTTLE","— %",WHITE,CYAN); dashFuel=metric("COMBUSTÍVEL","— %",WHITE,CYAN); addHalfView(g2,dashMap);addHalfView(g2,dashBaro);addHalfView(g2,dashThrottle);addHalfView(g2,dashFuel); live.addView(g2);
        LinearLayout vehicle=row(); dashVin=tv("VIN: —\nVEÍCULO NÃO IDENTIFICADO",10.5f); dashVin.setTextColor(WHITE); dashVin.setGravity(Gravity.CENTER_VERTICAL); dashVin.setBackground(cardBg(CARD2,16,CYAN2)); vehicle.addView(dashVin,new LinearLayout.LayoutParams(0,dp(62),2)); dashCan=tv("PROTOCOLO\nCAN 11/500",11); dashCan.setTextColor(WHITE); dashCan.setGravity(Gravity.CENTER); dashCan.setBackground(cardBg(CARD2,16,CYAN2)); vehicle.addView(dashCan,new LinearLayout.LayoutParams(0,dp(62),1)); live.addView(vehicle); addFull(root,live);

        LinearLayout modHeader=row(); TextView modHead=tv("MÓDULOS",22); modHead.setTextColor(WHITE); modHead.setTypeface(null,android.graphics.Typeface.BOLD); modHead.setPadding(dp(8),dp(10),dp(8),dp(2)); modHeader.addView(modHead,new LinearLayout.LayoutParams(0,dp(46),1)); TextView modHint=tv("SELECIONE UMA FUNÇÃO",10); modHint.setTextColor(CYAN); modHint.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); modHint.setPadding(dp(8),dp(10),dp(8),dp(2)); modHeader.addView(modHint,new LinearLayout.LayoutParams(dp(170),dp(46))); addFull(root,modHeader);
        LinearLayout m1=row(); addModule(m1,R.drawable.ic_engine,"DIAGNÓSTICO","Códigos de falhas (DTC)",CYAN,()->showDiagnosticScreen()); addModule(m1,R.drawable.ic_gauge,"PERFORMANCE","Potência • torque • testes",Color.rgb(0,220,180),()->showPerformanceScreen()); addFull(root,m1);
        LinearLayout m2=row(); addModule(m2,R.drawable.ic_chart,"GRÁFICOS","Análise e histórico",Color.rgb(150,100,255),()->showGraphScreen()); addModule(m2,R.drawable.ic_can,"CAN INVESTIGATOR","Captura e análise CAN",Color.rgb(255,190,0),()->showCanScreen()); addFull(root,m2);
        LinearLayout m3=row(); addModule(m3,R.drawable.ic_document,"GRAVAÇÃO DE DADOS","Logs e exportação (CSV)",Color.rgb(255,80,90),()->showDataScreen()); addModule(m3,R.drawable.ic_vehicle,"VIRTUS / VAG","Informações do veículo",CYAN2,()->{showHomeScreen();vehicleData();}); addFull(root,m3);
        resultHome=tv("RESULTADO: —",11); resultHome.setTextColor(WHITE); resultHome.setPadding(dp(12),dp(8),dp(12),dp(8)); resultHome.setBackground(cardBg(CARD2,16,CYAN2)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(80)); rp.setMargins(dp(6),dp(3),dp(6),dp(8)); root.addView(resultHome,rp);
        return wrap;
    }

    private LinearLayout buildDiagnosticScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG);
        diagnosticScroll=new ScrollView(this); diagnosticScroll.setFillViewport(false); diagnosticScroll.setBackgroundColor(BG); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(0,0,0,dp(10)); diagnosticScroll.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(diagnosticScroll,new LinearLayout.LayoutParams(-1,0,1));
        diagSection=section("DIAGNÓSTICO • ORGANIZADO POR FUNÇÃO"); addFull(root,diagSection);
        TextView hint=tv("Leitura OBD-II, VAG e DTC separados por área. CAN possui tela própria na navegação inferior.",9); hint.setTextColor(MUTED); hint.setPadding(dp(4),dp(2),dp(4),dp(8)); addFull(root,hint);
        addDiagSection(root,CARD2,CYAN,"OBD-II • LEITURA RÁPIDA",new String[]{"DIAGNÓSTICO RÁPIDO","LER DADOS","DTC","VIN"},new Runnable[]{()->quickDiagnostic(),()->vehicleData(),()->readDtc(),()->readVin()});
        addDiagSection(root,CARD2,CYAN,"VAG • EXPLORAÇÃO E EVIDÊNCIA",new String[]{"VAG DIAGNOSTIC EXPLORER","VAG SCAN UDS","ESTUDO DE MÓDULOS"},new Runnable[]{()->vagDiagnosticExplorer(),()->vagFocusedScan(),()->bodyStudy()});
        addDiagSection(root,CARD2,CYAN,"EPC • CAPTURA DE EVIDÊNCIAS",new String[]{"INVESTIGAR EPC","DTC + FREEZE FRAME"},new Runnable[]{()->investigateEpc(),()->dtcFreeze()});
        addDiagSection(root,CARD2,CYAN,"DTC • ANÁLISE",new String[]{"LER DTCs","STATUS / READINESS","MONITORAMENTO SONDA","BIBLIOTECA DTC"},new Runnable[]{()->readDtc(),()->obdStatus(),()->o2Test(),()->showDtcLibraryScreen()});
        addDiagSection(root,CARD2,CYAN,"TESTES E DIAGNÓSTICO AVANÇADO",new String[]{"DIAGNÓSTICO COMPLETO","IGNIÇÃO OFF"},new Runnable[]{()->automaticDiagnostic(),()->ignitionOffTest()});
        LinearLayout fault=card(CARD2); fault.setPadding(dp(12),dp(9),dp(12),dp(9)); TextView ft=tv("QUADRO DE FALHAS • DTC",13); ft.setTextColor(CYAN); ft.setTypeface(null,android.graphics.Typeface.BOLD); fault.addView(ft);
        dtcStatusView=tv("STATUS: AGUARDANDO LEITURA",10); dtcStatusView.setTextColor(WHITE); dtcStatusView.setTypeface(null,android.graphics.Typeface.BOLD); fault.addView(dtcStatusView);
        dtcCodesView=tv("CÓDIGOS: nenhum DTC lido nesta sessão",11); dtcCodesView.setTextColor(MUTED); dtcCodesView.setPadding(dp(4),dp(4),dp(4),dp(4)); fault.addView(dtcCodesView);
        ScrollView dtcCodesScroll=new ScrollView(this); dtcCodesScroll.setFillViewport(true); dtcCodesScroll.setVerticalScrollBarEnabled(true); dtcCodesScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS); dtcCodesScroll.setBackgroundColor(Color.TRANSPARENT);
        dtcListContainer=new LinearLayout(this); dtcListContainer.setOrientation(LinearLayout.VERTICAL); dtcListContainer.setPadding(dp(2),dp(2),dp(2),dp(2)); dtcCodesScroll.addView(dtcListContainer,new ScrollView.LayoutParams(-1,-2)); LinearLayout.LayoutParams dtcScrollLp=new LinearLayout.LayoutParams(-1,dp(118)); dtcScrollLp.setMargins(0,dp(2),0,dp(2)); fault.addView(dtcCodesScroll,dtcScrollLp);
        dtcRawView=tv("RAW: —",8.5f); dtcRawView.setTextColor(MUTED); dtcRawView.setTypeface(android.graphics.Typeface.MONOSPACE); dtcRawView.setMaxLines(4); fault.addView(dtcRawView);
        LinearLayout dtcActions=row(); clearDtcButton=btn("APAGAR TODOS"); clearDtcButton.setTextColor(Color.rgb(255,210,210)); bindClick(clearDtcButton,()->clearAllDtc()); selectDtcButton=btn("SELECIONAR DTCs"); selectDtcButton.setTextColor(CYAN); bindClick(selectDtcButton,()->toggleDtcSelectionMode()); addHalf(dtcActions,clearDtcButton); addHalf(dtcActions,selectDtcButton); addFull(fault,dtcActions); addFull(root,fault);
        LinearLayout vagCard=card(CARD2); vagCard.setPadding(dp(12),dp(9),dp(12),dp(9)); TextView vt=tv("VAG DIAGNOSTIC EXPLORER • SOMENTE LEITURA",12); vt.setTextColor(CYAN); vt.setTypeface(null,android.graphics.Typeface.BOLD); vagCard.addView(vt); vagExplorerResult=tv("Aguardando exploração. Nenhum comando de escrita será enviado.",9); vagExplorerResult.setTextColor(MUTED); vagExplorerResult.setTypeface(android.graphics.Typeface.MONOSPACE); vagExplorerResult.setTextIsSelectable(true); vagExplorerResult.setPadding(0,dp(5),0,dp(5)); vagExplorerResult.setSingleLine(false); vagCard.addView(vagExplorerResult,new LinearLayout.LayoutParams(-1,-2)); addFull(root,vagCard);
        LinearLayout diagResultCard=card(CARD2); diagResultCard.setPadding(dp(12),dp(8),dp(12),dp(8)); TextView drh=tv("RESULTADO DO TESTE",11); drh.setTextColor(CYAN); drh.setTypeface(null,android.graphics.Typeface.BOLD); diagResultCard.addView(drh); diagnosticResult=tv("Nenhum teste executado nesta sessão.",9); diagnosticResult.setTextColor(WHITE); diagnosticResult.setTypeface(android.graphics.Typeface.MONOSPACE); diagnosticResult.setTextIsSelectable(true); diagnosticResult.setPadding(0,dp(5),0,dp(5)); diagnosticResult.setSingleLine(false); diagResultCard.addView(diagnosticResult,new LinearLayout.LayoutParams(-1,-2)); addFull(root,diagResultCard);
        return screen;
    }
    private void addDiagSection(LinearLayout root,int cardColor,int accent,String title,String[] labels,Runnable[] actions){
        LinearLayout box=card(cardColor); box.setPadding(dp(10),dp(7),dp(10),dp(8));
        TextView h=tv(title,11.5f); h.setTextColor(accent); h.setTypeface(null,android.graphics.Typeface.BOLD); h.setGravity(Gravity.CENTER); h.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        box.addView(h,new LinearLayout.LayoutParams(-1,dp(32)));
        LinearLayout row=null;
        final int BUTTON_H=dp(78);
        for(int i=0;i<labels.length;i++){
            if(i%2==0){
                row=row();
                box.addView(row,new LinearLayout.LayoutParams(-1,BUTTON_H));
            }
            Button b=diagButton(labels[i],accent);
            bindClick(b,actions[i]);
            if(i==labels.length-1 && labels.length%2==1){
                // Último item ímpar ocupa a largura inteira, mantendo a mesma altura visual.
                row.removeAllViews();
                LinearLayout.LayoutParams full=new LinearLayout.LayoutParams(-1,BUTTON_H);
                full.setMargins(dp(3),0,dp(3),0);
                row.addView(b,full);
            }else addHalf(row,b);
        }
        addFull(root,box);
    }

    private Button diagButton(String label,int accent){
        Button b=btn(label); b.setTextSize(9.5f); b.setSingleLine(false); b.setGravity(Gravity.CENTER); b.setPadding(dp(6),dp(5),dp(6),dp(5));
        b.setMinHeight(dp(74)); b.setMinimumHeight(dp(74));
        int iconRes=diagIconFor(label);
        if(iconRes!=0){
            android.graphics.drawable.Drawable d=getDrawable(iconRes);
            if(d!=null){ d=d.mutate(); if(Build.VERSION.SDK_INT>=21)d.setTint(accent); b.setCompoundDrawablesWithIntrinsicBounds(null,d,null,null); b.setCompoundDrawablePadding(dp(3)); }
        }
        return b;
    }

    private int diagIconFor(String label){
        String s=label==null?"":label.toUpperCase(Locale.US);
        if(s.contains("VIN")) return R.drawable.ic_vehicle;
        if(s.contains("SONDA") || s.contains("READINESS")) return R.drawable.ic_gauge;
        if(s.contains("CAN") || s.contains("UDS")) return R.drawable.ic_can;
        if(s.contains("BIBLIOTECA") || s.contains("FREEZE") || s.contains("LER DADOS")) return R.drawable.ic_document;
        if(s.contains("ESTUDO") || s.contains("MÓDULOS")) return R.drawable.ic_engine;
        if(s.contains("IGNIÇÃO")) return R.drawable.ic_settings;
        if(s.contains("DIAGNÓSTICO") || s.equals("DTC")) return R.drawable.ic_engine;
        return R.drawable.ic_chart;
    }

    private LinearLayout buildCanScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG); ScrollView sv=new ScrollView(this); sv.setFillViewport(true); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); sv.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        canSection=section("CAN INVESTIGATOR • SOMENTE LEITURA"); addFull(root,canSection);
        LinearLayout canStatus=card(CARD2); canStatus.setPadding(dp(12),dp(10),dp(12),dp(10)); TextView cst=tv("STATUS DA CAPTURA CAN",12); cst.setTextColor(CYAN); cst.setTypeface(null,android.graphics.Typeface.BOLD); canStatus.addView(cst); stats=tv("RAW: 0 • FRAMES: 0 • IDs: 0 • BYTES: 0",18); stats.setTextColor(WHITE); stats.setTypeface(null,android.graphics.Typeface.BOLD); stats.setSingleLine(true); canStatus.addView(stats); TextView canHint=tv("Monitor All • sem transmissão CAN arbitrária",10); canHint.setTextColor(MUTED); canStatus.addView(canHint); addFull(root,canStatus);
        LinearLayout diag=card(CARD2); diag.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView dt=tv("DIAGNÓSTICO DO MOTOR CAN",11); dt.setTextColor(CYAN); dt.setTypeface(null,android.graphics.Typeface.BOLD); diag.addView(dt);
        canDiag=tv("ELM: —\nPROTOCOLO: —\nCMD: —\nRX: —\nESTADO: pronto",9); canDiag.setTextColor(MUTED); canDiag.setTypeface(android.graphics.Typeface.MONOSPACE); canDiag.setPadding(0,dp(4),0,0); diag.addView(canDiag); addFull(root,diag);
        LinearLayout r6=row(); Button cap=btn("▶  CAPTURAR CAN"); bindClick(cap,()->startMonitor()); Button stop=btn("■  FINALIZAR"); bindClick(stop,()->stopMonitor()); addHalf(r6,cap); addHalf(r6,stop); addFull(root,r6);
        LinearLayout analyzer=card(CARD2); analyzer.setPadding(dp(12),dp(10),dp(12),dp(10));
        TextView at=tv("CAN INVESTIGATOR 2.1 • CAN LAB • TRÁFEGO EM TEMPO REAL",12); at.setTextColor(CYAN); at.setTypeface(null,android.graphics.Typeface.BOLD); analyzer.addView(at);
        TextView ah=tv("Top IDs por frequência • diagnóstico ATMA/ATMR/ATCRA • somente leitura",9); ah.setTextColor(MUTED); analyzer.addView(ah);
        canFilterInput=new EditText(this); canFilterInput.setSingleLine(true); canFilterInput.setHint("Filtrar ID ou dados (ex.: 7E8 / 3E)"); canFilterInput.setTextColor(WHITE); canFilterInput.setHintTextColor(MUTED); canFilterInput.setTextSize(11); canFilterInput.setPadding(dp(10),0,dp(10),0); canFilterInput.setBackground(cardBg(Color.rgb(3,24,43),12,CYAN2)); analyzer.addView(canFilterInput,new LinearLayout.LayoutParams(-1,dp(44)));
        canTable=tv("AGUARDANDO CAPTURA CAN…",10); canTable.setTextColor(WHITE); canTable.setTextSize(10); canTable.setTypeface(android.graphics.Typeface.MONOSPACE); canTable.setPadding(dp(4),dp(8),dp(4),dp(4)); canTable.setGravity(Gravity.TOP|Gravity.START); analyzer.addView(canTable,new LinearLayout.LayoutParams(-1,dp(168)));
        canFilterHint=tv("0 IDs • 0 frames • análise atualizada durante a captura",9); canFilterHint.setTextColor(MUTED); analyzer.addView(canFilterHint); addFull(root,analyzer);
        canFilterInput.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){updateCanTable();} public void afterTextChanged(android.text.Editable e){}});
        LinearLayout r7=row(); Button lock=btn("LOCK"); bindClick(lock,()->mark("LOCK")); Button unlock=btn("UNLOCK"); bindClick(unlock,()->mark("UNLOCK")); addHalf(r7,lock); addHalf(r7,unlock); addFull(root,r7);
        LinearLayout r8=row(); Button ss=btn("START / STOP"); bindClick(ss,()->mark("START-STOP")); Button trunk=btn("PORTA-MALAS"); bindClick(trunk,()->mark("PORTA-MALAS")); addHalf(r8,ss); addHalf(r8,trunk); addFull(root,r8);
        LinearLayout r9=row(); Button farol=btn("FAROL / OUTRO"); bindClick(farol,()->mark("FAROL-OUTRO")); Button analyze=btn("ANALISAR DIFERENÇAS"); bindClick(analyze,()->analyze()); addHalf(r9,farol); addHalf(r9,analyze); addFull(root,r9);
        LinearLayout r10=row(); Button clearCan=btn("LIMPAR CAPTURA"); bindClick(clearCan,()->clearCanCapture()); Button copyCan=btn("COPIAR RESUMO CAN"); bindClick(copyCan,()->copyCanSummary()); addHalf(r10,clearCan); addHalf(r10,copyCan); addFull(root,r10);
        return screen;
    }

    private LinearLayout buildConfigScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG); ScrollView sv=new ScrollView(this); sv.setFillViewport(true); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); sv.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        configSection=section("CONFIGURAÇÕES"); addFull(root,configSection);
        LinearLayout keepRow=card(CARD2); keepRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout keepInner=new LinearLayout(this); keepInner.setOrientation(LinearLayout.HORIZONTAL); keepInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout keepTexts=new LinearLayout(this); keepTexts.setOrientation(LinearLayout.VERTICAL); keepTexts.setGravity(Gravity.CENTER_VERTICAL);
        TextView keepTitle=tv("MANTER TELA LIGADA",13); keepTitle.setTextColor(WHITE); keepTitle.setTypeface(null,android.graphics.Typeface.BOLD); keepTitle.setSingleLine(true); TextView keepSub=tv("Evita o desligamento automático enquanto o VIRTUS ELM estiver aberto",9); keepSub.setTextColor(Color.rgb(145,181,210)); keepSub.setSingleLine(false); keepTexts.addView(keepTitle); keepTexts.addView(keepSub); keepInner.addView(keepTexts,new LinearLayout.LayoutParams(0,-2,1));
        android.widget.Switch keepSwitch=new android.widget.Switch(this); keepSwitch.setText(""); keepSwitch.setChecked(isKeepScreenOnEnabled()); keepSwitch.setHapticFeedbackEnabled(isHapticEnabled()); keepSwitch.setOnCheckedChangeListener((buttonView,isChecked)->{ if(isHapticEnabled()) buttonView.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_KEEP_SCREEN,isChecked).apply(); applyKeepScreenPreference(); toast(isChecked ? "Tela permanecerá ligada" : "Desligamento automático restaurado"); }); keepInner.addView(keepSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); keepRow.addView(keepInner); addFull(root,keepRow);
        LinearLayout hapticRow=card(CARD2); hapticRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout hapticInner=new LinearLayout(this); hapticInner.setOrientation(LinearLayout.HORIZONTAL); hapticInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout hapticTexts=new LinearLayout(this); hapticTexts.setOrientation(LinearLayout.VERTICAL); hapticTexts.setGravity(Gravity.CENTER_VERTICAL);
        TextView hapticTitle=tv("FEEDBACK TÁTIL",13); hapticTitle.setTextColor(WHITE); hapticTitle.setTypeface(null,android.graphics.Typeface.BOLD); hapticTitle.setSingleLine(true); TextView hapticSub=tv("Ativa ou desativa a vibração ao tocar nos controles",9); hapticSub.setTextColor(MUTED); hapticSub.setSingleLine(false); hapticTexts.addView(hapticTitle); hapticTexts.addView(hapticSub); hapticInner.addView(hapticTexts,new LinearLayout.LayoutParams(0,-2,1));
        android.widget.Switch hapticSwitch=new android.widget.Switch(this); hapticSwitch.setText(""); hapticSwitch.setChecked(isHapticEnabled()); hapticSwitch.setHapticFeedbackEnabled(isHapticEnabled()); hapticSwitch.setOnCheckedChangeListener((buttonView,isChecked)->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_HAPTIC,isChecked).apply(); buttonView.setHapticFeedbackEnabled(isChecked); if(isChecked) buttonView.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); toast(isChecked ? "Feedback tátil ativado" : "Feedback tátil desativado"); }); hapticInner.addView(hapticSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); hapticRow.addView(hapticInner); addFull(root,hapticRow);
        LinearLayout rtRow=card(CARD2); rtRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout rtInner=new LinearLayout(this); rtInner.setOrientation(LinearLayout.HORIZONTAL); rtInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout rtTexts=new LinearLayout(this); rtTexts.setOrientation(LinearLayout.VERTICAL); rtTexts.setGravity(Gravity.CENTER_VERTICAL); TextView rtTitle=tv("DADOS EM TEMPO REAL",13); rtTitle.setTextColor(WHITE); rtTitle.setTypeface(null,android.graphics.Typeface.BOLD); TextView rtSub=tv("Atualiza os painéis e gráficos com os dados recebidos do ELM",9); rtSub.setTextColor(MUTED); rtTexts.addView(rtTitle); rtTexts.addView(rtSub); rtInner.addView(rtTexts,new LinearLayout.LayoutParams(0,-2,1)); android.widget.Switch rtSwitch=new android.widget.Switch(this); rtSwitch.setText(""); rtSwitch.setChecked(isRealtimeDataEnabled()); rtSwitch.setHapticFeedbackEnabled(isHapticEnabled()); rtSwitch.setOnCheckedChangeListener((v,c)->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_REALTIME_DATA,c).apply(); if(c) ui(()->updateDashboard()); toast(c?"Dados em tempo real ativados":"Dados em tempo real desativados"); }); rtInner.addView(rtSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); rtRow.addView(rtInner); addFull(root,rtRow);
        LinearLayout tlRow=card(CARD2); tlRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout tlInner=new LinearLayout(this); tlInner.setOrientation(LinearLayout.HORIZONTAL); tlInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout tlTexts=new LinearLayout(this); tlTexts.setOrientation(LinearLayout.VERTICAL); tlTexts.setGravity(Gravity.CENTER_VERTICAL); TextView tlTitle=tv("LOG TÉCNICO",13); tlTitle.setTextColor(WHITE); tlTitle.setTypeface(null,android.graphics.Typeface.BOLD); TextView tlSub=tv("Registra comunicações e eventos internos do aplicativo. Desative para evitar log técnico volumoso",9); tlSub.setTextColor(MUTED); tlTexts.addView(tlTitle); tlTexts.addView(tlSub); tlInner.addView(tlTexts,new LinearLayout.LayoutParams(0,-2,1)); android.widget.Switch tlSwitch=new android.widget.Switch(this); tlSwitch.setText(""); tlSwitch.setChecked(isTechLogEnabled()); tlSwitch.setHapticFeedbackEnabled(isHapticEnabled()); tlSwitch.setOnCheckedChangeListener((v,c)->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_TECH_LOG,c).apply(); toast(c?"Log técnico ativado":"Log técnico desativado"); }); tlInner.addView(tlSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); tlRow.addView(tlInner); addFull(root,tlRow);
        LinearLayout phRow=card(CARD2); phRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout phInner=new LinearLayout(this); phInner.setOrientation(LinearLayout.HORIZONTAL); phInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout phTexts=new LinearLayout(this); phTexts.setOrientation(LinearLayout.VERTICAL); phTexts.setGravity(Gravity.CENTER_VERTICAL); TextView phTitle=tv("HISTÓRICO DE PERFORMANCE",13); phTitle.setTextColor(WHITE); phTitle.setTypeface(null,android.graphics.Typeface.BOLD); TextView phSub=tv("Salva automaticamente a telemetria de desempenho em armazenamento público persistente",9); phSub.setTextColor(MUTED); phTexts.addView(phTitle); phTexts.addView(phSub); phInner.addView(phTexts,new LinearLayout.LayoutParams(0,-2,1)); android.widget.Switch phSwitch=new android.widget.Switch(this); phSwitch.setText(""); phSwitch.setChecked(isPerformanceHistoryEnabled()); phSwitch.setHapticFeedbackEnabled(isHapticEnabled()); phSwitch.setOnCheckedChangeListener((v,c)->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_PERF_HISTORY,c).apply(); if(c&&connected) openPerformanceHistory(); else if(!c) closePerformanceHistory(); toast(c?"Histórico de performance ativado":"Histórico de performance desativado"); }); phInner.addView(phSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); phRow.addView(phInner); addFull(root,phRow);
        LinearLayout simRow=card(CARD2); simRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout simInner=new LinearLayout(this); simInner.setOrientation(LinearLayout.HORIZONTAL); simInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout simTexts=new LinearLayout(this); simTexts.setOrientation(LinearLayout.VERTICAL); simTexts.setGravity(Gravity.CENTER_VERTICAL); TextView simTitle=tv("SIMULAÇÃO AUTOMÁTICA",13); simTitle.setTextColor(WHITE); simTitle.setTypeface(null,android.graphics.Typeface.BOLD); TextView simSub=tv("Quando o ELM não estiver disponível, inicia o modo simulação automaticamente",9); simSub.setTextColor(MUTED); simTexts.addView(simTitle); simTexts.addView(simSub); simInner.addView(simTexts,new LinearLayout.LayoutParams(0,-2,1)); android.widget.Switch simSwitch=new android.widget.Switch(this); simSwitch.setText(""); simSwitch.setChecked(isAutoSimulationEnabled()); simSwitch.setHapticFeedbackEnabled(isHapticEnabled()); simSwitch.setOnCheckedChangeListener((v,c)->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_AUTO_SIM,c).apply(); if(c&&!simulationMode&&!connected){ io.execute(()->startSimulationMode("configuração — simulação automática ativada")); } else if(!c&&simulationMode){ simulationMode=false; connected=false; ecuResponding=false; closeSocket(); ui(()->updateDashboard()); } toast(c?"Simulação automática ativada":"Simulação automática desativada"); }); simInner.addView(simSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); simRow.addView(simInner); addFull(root,simRow);
        LinearLayout acRow=card(CARD2); acRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout acInner=new LinearLayout(this); acInner.setOrientation(LinearLayout.HORIZONTAL); acInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout acTexts=new LinearLayout(this); acTexts.setOrientation(LinearLayout.VERTICAL); acTexts.setGravity(Gravity.CENTER_VERTICAL); TextView acTitle=tv("CONEXÃO AUTOMÁTICA ELM",13); acTitle.setTextColor(WHITE); acTitle.setTypeface(null,android.graphics.Typeface.BOLD); TextView acSub=tv("Procura e tenta conectar o ELM automaticamente ao iniciar o aplicativo",9); acSub.setTextColor(MUTED); acTexts.addView(acTitle); acTexts.addView(acSub); acInner.addView(acTexts,new LinearLayout.LayoutParams(0,-2,1)); android.widget.Switch acSwitch=new android.widget.Switch(this); acSwitch.setText(""); acSwitch.setChecked(isAutoConnectEnabled()); acSwitch.setHapticFeedbackEnabled(isHapticEnabled()); acSwitch.setOnCheckedChangeListener((v,c)->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_AUTO_CONNECT,c).apply(); autoConnectActive=c; if(c&&!connected&&!intentionalDisconnect) dashboardExec.schedule(this::automaticConnectionAttempt,200,TimeUnit.MILLISECONDS); toast(c?"Conexão automática ELM ativada":"Conexão automática ELM desativada"); }); acInner.addView(acSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); acRow.addView(acInner); addFull(root,acRow);
        addConfigChoice(root,CARD2,WHITE,MUTED,"UNIDADE DE PRESSÃO","Exibição de pressão e boost",getPressureUnit(),new String[]{"bar","kPa"},PREF_PRESSURE_UNIT);
        addConfigChoice(root,CARD2,WHITE,MUTED,"UNIDADE DE VELOCIDADE","Exibição de velocidade",getSpeedUnit(),new String[]{"km/h","mph"},PREF_SPEED_UNIT);
        LinearLayout devRow=card(CARD2); devRow.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView devTitle=tv("DESENVOLVIMENTO",13); devTitle.setTextColor(WHITE); devTitle.setTypeface(null,android.graphics.Typeface.BOLD); devRow.addView(devTitle);
        TextView devSub=tv("Leitura somente — comparação de pedal do acelerador e posições da borboleta",9); devSub.setTextColor(MUTED); devRow.addView(devSub);
        Button devPedal=btn("TESTE DO ACELERADOR"); bindClick(devPedal,()->showAcceleratorTest()); devRow.addView(devPedal,new LinearLayout.LayoutParams(-1,dp(48)));
        devPedalResult=tv("Nenhum teste executado.",8.5f); devPedalResult.setTextColor(MUTED); devPedalResult.setTypeface(android.graphics.Typeface.MONOSPACE); devPedalResult.setPadding(0,dp(6),0,0); devRow.addView(devPedalResult); addFull(root,devRow);
        LinearLayout dtcLibRow=card(CARD2); dtcLibRow.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView dtcLibTitle=tv("BIBLIOTECA DTC",13); dtcLibTitle.setTextColor(WHITE); dtcLibTitle.setTypeface(null,android.graphics.Typeface.BOLD); dtcLibRow.addView(dtcLibTitle);
        dtcConfigStatusView=tv("Carregando biblioteca local...",9); dtcConfigStatusView.setTextColor(MUTED); dtcLibRow.addView(dtcConfigStatusView);
        Button dtcUpdate=btn("ATUALIZAR BIBLIOTECA DTC"); bindClick(dtcUpdate,()->updateDtcLibraryFromNetwork()); dtcLibRow.addView(dtcUpdate,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView dtcLibSub=tv("Atualização controlada por HTTPS. O aplicativo consulta somente a biblioteca do projeto, valida versão e SHA-256 e mantém a cópia anterior se a validação falhar.",8.5f); dtcLibSub.setTextColor(MUTED); dtcLibRow.addView(dtcLibSub); addFull(root,dtcLibRow);
        Button dtcLibOpenCfg=btn("ABRIR BIBLIOTECA DTC"); dtcLibOpenCfg.setTextColor(CYAN); bindClick(dtcLibOpenCfg,()->showDtcLibraryScreen()); dtcLibRow.addView(dtcLibOpenCfg,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout resetRow=card(CARD2); resetRow.setPadding(dp(12),dp(8),dp(12),dp(8)); TextView resetTitle=tv("SISTEMA",13); resetTitle.setTextColor(WHITE); resetTitle.setTypeface(null,android.graphics.Typeface.BOLD); resetRow.addView(resetTitle); Button reset=btn("RESTAURAR CONFIGURAÇÕES PADRÃO"); bindClick(reset,()->resetPreferencesToDefault()); resetRow.addView(reset,new LinearLayout.LayoutParams(-1,dp(48))); TextView resetSub=tv("ON: simulação automática • conexão automática • tela ligada • feedback tátil • dados em tempo real • histórico de performance",8.5f); resetSub.setTextColor(MUTED); resetRow.addView(resetSub); addFull(root,resetRow);
        return screen;
    }

    private double parsePercentPid(String raw, String pid){
        try{ Matcher m=Pattern.compile("41\\s*"+pid.substring(2)+"\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(raw==null?"":raw); if(m.find()) return Integer.parseInt(m.group(1),16)*100.0/255.0; }catch(Exception ignored){} return -1;
    }
    private String rawPidValue(String raw, String pid){
        if(raw==null||raw.trim().isEmpty())return "SEM RESPOSTA"; return raw.trim().replaceAll("\\s+"," ");
    }
    private void showAcceleratorTest(){
        if(!connected && !simulationMode){ toast("Conecte o ELM antes do teste"); return; }
        if(devPedalResult!=null)devPedalResult.setText("LENDO PIDs 49/4A/4B • THROTTLE 11/45/47/48/4C…");
        io.execute(()->{
            String[] pids={"0149","014A","014B","0111","0145","0147","0148","014C"};
            StringBuilder outText=new StringBuilder("TESTE DO ACELERADOR • SOMENTE LEITURA\n\n");
            for(String pid:pids){ String raw=send(pid,900); double pct=parsePercentPid(raw,pid); outText.append(pid).append("  ").append(rawPidValue(raw,pid)).append("  ").append(pct>=0?String.format(Locale.US,"%.1f %%",pct):"não interpretado").append("\n"); }
            String d=send("0149",900), e=send("014A",900), f=send("014B",900), th=send("0111",900);
            lastPedalD=parsePercentPid(d,"0149"); lastPedalE=parsePercentPid(e,"014A"); lastPedalF=parsePercentPid(f,"014B"); lastThrottle=parseThrottle(th);
            outText.append("\nPEDAL D: ").append(fmtDev(lastPedalD)).append("\nPEDAL E: ").append(fmtDev(lastPedalE)).append("\nPEDAL F: ").append(fmtDev(lastPedalF)).append("\nTHROTTLE 11: ").append(fmtDev(lastThrottle)).append("\n");
            outText.append("\nPara validar: repita em repouso e depois com 25%, 50%, 75% e 100% do pedal. O gráfico de performance usa o pedal quando houver leitura válida; o throttle continua disponível aqui.");
            final String result=outText.toString(); ui(()->{ if(devPedalResult!=null)devPedalResult.setText(result); new AlertDialog.Builder(this).setTitle("TESTE DO ACELERADOR").setMessage(result).setPositiveButton("OK",null).show(); });
        });
    }
    private String fmtDev(double v){return v>=0?String.format(Locale.US,"%.1f %%",v):"—";}

    private void addConfigChoice(LinearLayout root,int CARD2,int WHITE,int MUTED,String title,String sub,String current,String[] options,String prefKey){
        LinearLayout row=card(CARD2); row.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout inner=new LinearLayout(this); inner.setOrientation(LinearLayout.HORIZONTAL); inner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setGravity(Gravity.CENTER_VERTICAL); TextView t=tv(title,13); t.setTextColor(WHITE); t.setTypeface(null,android.graphics.Typeface.BOLD); TextView st=tv(sub,9); st.setTextColor(MUTED); texts.addView(t); texts.addView(st); inner.addView(texts,new LinearLayout.LayoutParams(0,-2,1)); Button choice=btn(current); choice.setTextSize(11); bindClick(choice,()->{ AlertDialog.Builder b=new AlertDialog.Builder(this); b.setTitle(title); b.setSingleChoiceItems(options,Arrays.asList(options).indexOf(getSharedPreferences(PREFS_UI,MODE_PRIVATE).getString(prefKey,options[0])),(d,which)->{ String v=options[which]; getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putString(prefKey,v).apply(); choice.setText(v); d.dismiss(); if(PREF_PRESSURE_UNIT.equals(prefKey)){ if(graphView!=null)graphView.setMetric(graphMetric); updateGraphScaleInfo(); } else if(PREF_SPEED_UNIT.equals(prefKey)){ if(graphView!=null)graphView.setMetric(graphMetric); updateGraphScaleInfo(); } toast(title+": "+v); }); b.setNegativeButton("CANCELAR",null); b.show(); }); inner.addView(choice,new LinearLayout.LayoutParams(dp(96),dp(48))); row.addView(inner); addFull(root,row);
    }

    private void resetPreferencesToDefault(){
        getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_KEEP_SCREEN,true).putBoolean(PREF_HAPTIC,true).putBoolean(PREF_REALTIME_DATA,true).putBoolean(PREF_TECH_LOG,false).putBoolean(PREF_PERF_HISTORY,true).putBoolean(PREF_AUTO_SIM,true).putBoolean(PREF_AUTO_CONNECT,true).putString(PREF_PRESSURE_UNIT,"bar").putString(PREF_SPEED_UNIT,"km/h").apply(); applyKeepScreenPreference(); autoConnectActive=true; if(!connected&&!simulationMode) io.execute(()->startSimulationMode("restauração das configurações padrão")); if(graphView!=null)graphView.setMetric(graphMetric); updateGraphScaleInfo(); toast("Configurações padrão restauradas");
    }

    private LinearLayout buildDataScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG);
        ScrollView page=new ScrollView(this); page.setFillViewport(false); page.setBackgroundColor(BG); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(0,0,0,dp(8)); page.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(page,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout header=card(CARD); header.setPadding(dp(10),dp(8),dp(10),dp(8)); TextView h=tv("DADOS / LOGS",18); h.setTextColor(WHITE); h.setTypeface(null,android.graphics.Typeface.BOLD); h.setGravity(Gravity.CENTER); header.addView(h,new LinearLayout.LayoutParams(-1,dp(42)));
        LinearLayout tabs=row(); dataTabButtons.clear(); Button telemetry=btn("TELEMETRIA"); Button graphs=btn("GRÁFICOS"); Button logsBtn=btn("LOGS"); dataTabButtons.add(telemetry); dataTabButtons.add(graphs); dataTabButtons.add(logsBtn);
        bindClick(telemetry,()->{dataLogsTab=false;setSelectedButton(telemetry,true);setSelectedButton(graphs,false);setSelectedButton(logsBtn,false);showDataScreen();});
        bindClick(graphs,()->{dataLogsTab=false;setSelectedButton(telemetry,false);setSelectedButton(graphs,true);setSelectedButton(logsBtn,false);showGraphScreen();});
        bindClick(logsBtn,()->{dataLogsTab=true;setSelectedButton(telemetry,false);setSelectedButton(graphs,false);setSelectedButton(logsBtn,true);showDataScreen();});
        addHalf(tabs,telemetry);addHalf(tabs,graphs);addHalf(tabs,logsBtn); header.addView(tabs); addFull(root,header);

        dataTelemetryContent=new LinearLayout(this); dataTelemetryContent.setOrientation(LinearLayout.VERTICAL);
        LinearLayout telemetryPanel=card(CARD2); telemetryPanel.setPadding(dp(10),dp(8),dp(10),dp(8));
        TextView telemetryTitle=tv("TELEMETRIA • AO VIVO",12); telemetryTitle.setTextColor(CYAN); telemetryTitle.setTypeface(null,android.graphics.Typeface.BOLD); telemetryTitle.setGravity(Gravity.CENTER); telemetryPanel.addView(telemetryTitle,new LinearLayout.LayoutParams(-1,dp(28)));
        dataLiveTelemetry=tv("Aguardando dados…",10); dataLiveTelemetry.setTextColor(WHITE); dataLiveTelemetry.setTypeface(android.graphics.Typeface.MONOSPACE); dataLiveTelemetry.setPadding(dp(6),dp(8),dp(6),dp(6)); telemetryPanel.addView(dataLiveTelemetry); addFull(dataTelemetryContent,telemetryPanel);

        LinearLayout rec=card(CARD2); rec.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView rt=tv("GRAVAÇÃO DE TELEMETRIA",12); rt.setTextColor(CYAN); rt.setTypeface(null,android.graphics.Typeface.BOLD); rt.setGravity(Gravity.CENTER); rec.addView(rt,new LinearLayout.LayoutParams(-1,dp(26)));
        TextView rs=tv("MAP / BARO / BOOST / RPM em alta frequência",9); rs.setTextColor(MUTED); rs.setGravity(Gravity.CENTER); rec.addView(rs,new LinearLayout.LayoutParams(-1,dp(24)));
        TextView rf=tv("STATUS: aguardando gravação",9); rf.setTextColor(MUTED); rf.setGravity(Gravity.CENTER); rf.setTag("recordFile"); rec.addView(rf,new LinearLayout.LayoutParams(-1,dp(24)));
        LinearLayout recButtons=row(); Button recStart=btn("INICIAR"); Button recStop=btn("FINALIZAR"); Button recSummary=btn("RESUMO"); bindClick(recStart,()->startRecording()); bindClick(recStop,()->stopRecording()); bindClick(recSummary,()->showRecordingSummary()); addThird(recButtons,recStart); addThird(recButtons,recStop); addThird(recButtons,recSummary); rec.addView(recButtons,new LinearLayout.LayoutParams(-1,dp(50))); addFull(dataTelemetryContent,rec);
        root.addView(dataTelemetryContent,new LinearLayout.LayoutParams(-1,-2));

        dataLogsContent=new LinearLayout(this); dataLogsContent.setOrientation(LinearLayout.VERTICAL);
        LinearLayout logHeader=card(CARD2); logHeader.setPadding(dp(10),dp(6),dp(10),dp(6)); TextView lt=tv("LOG TÉCNICO — ATUALIZAÇÃO EM TEMPO REAL",11); lt.setTextColor(CYAN); lt.setTypeface(null,android.graphics.Typeface.BOLD); lt.setGravity(Gravity.CENTER); logHeader.addView(lt,new LinearLayout.LayoutParams(-1,dp(32))); addFull(dataLogsContent,logHeader);
        TextView logInfo=tv("Comunicações e eventos internos do aplicativo. Útil para diagnóstico e validação; pode ser desativado em Configurações.",9); logInfo.setTextColor(MUTED); logInfo.setGravity(Gravity.CENTER); logInfo.setPadding(dp(6),0,dp(6),dp(4)); addFull(dataLogsContent,logInfo);
        logScroll=new ScrollView(this); logScroll.setFillViewport(true); logScroll.setMinimumHeight(dp(220)); logScroll.setBackground(cardBg(Color.rgb(2,20,38),18,Color.rgb(25,80,120))); logScroll.setClipToPadding(true); log=tv("",10); log.setTextColor(Color.rgb(185,210,230)); log.setTextIsSelectable(true); log.setPadding(dp(12),dp(12),dp(12),dp(12)); log.setMinHeight(dp(196)); logScroll.addView(log,new ScrollView.LayoutParams(-1,-1)); LinearLayout.LayoutParams lsp=new LinearLayout.LayoutParams(-1,dp(220)); lsp.setMargins(dp(6),dp(4),dp(6),dp(4)); dataLogsContent.addView(logScroll,lsp);
        LinearLayout tools=row(); Button copy=btn("COPIAR LOG"); bindClick(copy,()->copyLog()); Button clear=btn("LIMPAR LOG"); bindClick(clear,()->clearLog()); addHalf(tools,copy); addHalf(tools,clear); addFull(dataLogsContent,tools);
        result=tv("RESULTADO: —",10); result.setTextColor(WHITE); result.setTypeface(android.graphics.Typeface.MONOSPACE); result.setTextIsSelectable(true); result.setPadding(dp(12),dp(8),dp(12),dp(8)); result.setBackground(cardBg(CARD2,16,CYAN2)); ScrollView resultScroll=new ScrollView(this); resultScroll.setFillViewport(false); resultScroll.addView(result,new ScrollView.LayoutParams(-1,-2)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(150)); rp.setMargins(dp(6),0,dp(6),dp(6)); dataLogsContent.addView(resultScroll,rp);
        root.addView(dataLogsContent,new LinearLayout.LayoutParams(-1,-2));
        dataTelemetryContent.setVisibility(View.VISIBLE); dataLogsContent.setVisibility(View.GONE);
        return screen;
    }

    private LinearLayout buildGraphScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(3),dp(10),dp(8)); screen.setBackgroundColor(BG);
        LinearLayout header=card(CARD); header.setPadding(dp(10),dp(5),dp(10),dp(5));
        graphHeaderTitle=tv("GRÁFICO COMBINADO • DADOS AO VIVO",16); graphHeaderTitle.setTextColor(WHITE); graphHeaderTitle.setTypeface(null,android.graphics.Typeface.BOLD); graphHeaderTitle.setGravity(Gravity.CENTER);
        header.addView(graphHeaderTitle,new LinearLayout.LayoutParams(-1,dp(34)));
        screen.addView(header,new LinearLayout.LayoutParams(-1,dp(48)));
        graphHistoryStatus=tv("AGUARDANDO TESTE • este gráfico exibirá somente amostras da última puxada",9); graphHistoryStatus.setTextColor(Color.rgb(255,190,0)); graphHistoryStatus.setGravity(Gravity.CENTER); screen.addView(graphHistoryStatus,new LinearLayout.LayoutParams(-1,dp(30)));
        combinedGraphView=new CombinedGraphView(this); screen.addView(combinedGraphView,new LinearLayout.LayoutParams(-1,0,1));
        TextView note=tv("HISTÓRICO DA PUXADA • escalas: velocidade 0–280 km/h • pedal calibrado 0–100% • boost 0–3 bar • RPM 0–8.000. Estimativas não substituem medições.",8.5f);
        note.setTextColor(MUTED); note.setGravity(Gravity.CENTER); note.setPadding(dp(6),dp(3),dp(6),dp(3)); screen.addView(note,new LinearLayout.LayoutParams(-1,dp(34)));
        LinearLayout nav=row(); Button performance=btn("← PERFORMANCE"); Button data=btn("DADOS →"); bindClick(performance,()->showPerformanceScreen()); bindClick(data,()->showDataScreen()); addHalf(nav,performance); addHalf(nav,data); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(48)); bp.setMargins(dp(2),dp(2),dp(2),dp(2)); screen.addView(nav,bp);
        return screen;
    }

    private LinearLayout buildPerformanceScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG);
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(0,0,0,dp(12)); sv.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout h=card(CARD); h.setPadding(dp(12),dp(2),dp(12),dp(2)); TextView ht=tv("🏁 PERFORMANCE",19); ht.setTextColor(WHITE); ht.setTypeface(null,android.graphics.Typeface.BOLD); ht.setGravity(Gravity.CENTER); h.addView(ht,new LinearLayout.LayoutParams(-1,dp(34))); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(42)); hp.setMargins(dp(4),dp(1),dp(4),dp(1)); root.addView(h,hp);
        LinearLayout vals=row(); perfPower=perfValue("POTÊNCIA ESTIMADA","— cv",CYAN); perfTorque=perfValue("TORQUE ESTIMADO","— Nm",Color.rgb(0,220,180)); addHalfView(vals,perfPower); addHalfView(vals,perfTorque); addTight(root,vals);
        LinearLayout vals2=row(); perf0060=perfValue("0–60 km/h","— s",Color.rgb(80,150,255)); perf0100=perfValue("0–100 km/h","— s",Color.rgb(150,100,255)); addHalfView(vals2,perf0060); addHalfView(vals2,perf0100); addTight(root,vals2); LinearLayout vals3=row(); perfBoost=perfValue("BOOST MÁX.","— bar",Color.rgb(255,190,0)); perfQuality=perfValue("QUALIDADE AQUISIÇÃO","— %",Color.rgb(0,220,180)); addHalfView(vals3,perfBoost); addHalfView(vals3,perfQuality); addTight(root,vals3);
        LinearLayout pstats=row(); perfMaxRpm=perfValue("RPM MÁX.","— rpm",CYAN); perfMaxSpeed=perfValue("VELOCIDADE MÁX.","— km/h",Color.rgb(0,220,180)); addHalfView(pstats,perfMaxRpm); addHalfView(pstats,perfMaxSpeed); addTight(root,pstats);
        LinearLayout pstats2=row(); perfDuration=perfValue("DURAÇÃO", "— s", Color.rgb(150,100,255)); perfSessionCount=perfValue("SESSÕES", "—", Color.rgb(255,190,0)); addHalfView(pstats2,perfDuration); addHalfView(pstats2,perfSessionCount); addTight(root,pstats2);
        LinearLayout meta=card(CARD2); meta.setPadding(dp(12),dp(10),dp(12),dp(10));
        perfFuel=tv("COMBUSTÍVEL DO TESTE: "+getPerformanceEthanolLabel(),10); perfFuel.setTextColor(WHITE); perfFuel.setGravity(Gravity.CENTER_VERTICAL); perfFuel.setSingleLine(true); meta.addView(perfFuel,new LinearLayout.LayoutParams(-1,dp(32)));
        perfEthanolButton=btn("DEFINIR ETANOL"); bindClick(perfEthanolButton,()->showEthanolDialog()); meta.addView(perfEthanolButton,new LinearLayout.LayoutParams(-1,dp(48)));
        perfConfidence=tv("CONFIANÇA: —",10); perfConfidence.setTextColor(MUTED); perfConfidence.setGravity(Gravity.CENTER_VERTICAL); meta.addView(perfConfidence,new LinearLayout.LayoutParams(-1,dp(30)));
        perfStatus=tv("PRONTO PARA TESTE",10); perfStatus.setTextColor(CYAN); perfStatus.setTypeface(null,android.graphics.Typeface.BOLD); perfStatus.setGravity(Gravity.CENTER); meta.addView(perfStatus,new LinearLayout.LayoutParams(-1,dp(32))); addTight(root,meta);
        Button calibratePedal=btn("CALIBRAR PEDAL • 0% / 100%"); bindClick(calibratePedal,()->showPedalCalibrationDialog()); addTight(root,calibratePedal);
        // FIX10.12 UI: a altura do contêiner acompanha os botões; evita que o controle seguinte cubra a borda inferior.
        LinearLayout actions=row();
        actions.setClipChildren(false); actions.setClipToPadding(false);
        actions.setPadding(dp(4),dp(2),dp(4),dp(2));
        Button start=btn("🏁 INICIAR 0–60 / 0–100 / 0–280");
        start.setSingleLine(true); start.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,10);
        start.setAutoSizeTextTypeWithDefaults(Button.AUTO_SIZE_TEXT_TYPE_NONE);
        start.setIncludeFontPadding(true); start.setGravity(Gravity.CENTER);
        start.setMinHeight(dp(48)); start.setMinimumHeight(dp(48));
        start.setPadding(dp(4),dp(2),dp(4),dp(2));
        Button stop=btn("■ FINALIZAR");
        stop.setSingleLine(true); stop.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,10);
        stop.setAutoSizeTextTypeWithDefaults(Button.AUTO_SIZE_TEXT_TYPE_NONE);
        stop.setIncludeFontPadding(true); stop.setGravity(Gravity.CENTER);
        stop.setMinHeight(dp(48)); stop.setMinimumHeight(dp(48));
        stop.setPadding(dp(4),dp(2),dp(4),dp(2));
        bindClick(start,()->startPerformanceTest()); bindClick(stop,()->stopPerformanceTest());
        LinearLayout.LayoutParams startLp=new LinearLayout.LayoutParams(0,dp(48),1); startLp.setMargins(dp(3),dp(1),dp(3),dp(1)); actions.addView(start,startLp);
        LinearLayout.LayoutParams stopLp=new LinearLayout.LayoutParams(0,dp(48),1); stopLp.setMargins(dp(3),dp(1),dp(3),dp(1)); actions.addView(stop,stopLp);
        actions.setMinimumHeight(dp(54));
        LinearLayout.LayoutParams actionsLp=new LinearLayout.LayoutParams(-1,dp(54)); actionsLp.setMargins(dp(4),dp(2),dp(4),dp(2)); root.addView(actions,actionsLp);
        Button data=btn("VER GRÁFICOS DO TESTE"); data.setMinHeight(dp(54)); data.setMinimumHeight(dp(54)); data.setPadding(dp(6),dp(4),dp(6),dp(4)); bindClick(data,()->showPerformanceTestGraph()); addTight(root,data);
        Button hist=btn("🗂 HISTÓRICO DE SESSÕES"); hist.setMinHeight(dp(54)); hist.setMinimumHeight(dp(54)); hist.setPadding(dp(6),dp(4),dp(6),dp(4)); bindClick(hist,()->showHistoryScreen()); addTight(root,hist);
        TextView note=tv("0–60 e 0–100 são exibidos no mesmo ensaio; a curva continua além de 100 km/h até FINALIZAR, registrando cruzamentos de 10 em 10 km/h até 280 km/h. A QUALIDADE DA AQUISIÇÃO não é precisão física: considera partida próxima de zero, conclusão dos alvos e continuidade das amostras. Inclinação da via não é medida nesta versão; compare testes do mesmo carro em condições equivalentes. O VIN é salvo no histórico para separar veículos.",9); note.setTextColor(MUTED); note.setGravity(Gravity.CENTER); note.setPadding(dp(10),dp(8),dp(10),dp(8)); addTight(root,note);
        return screen;
    }
    private TextView perfValue(String label,String value,int accent){ TextView t=tv("",10); t.setTextColor(Color.rgb(242,248,255)); t.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setPadding(dp(8),dp(6),dp(8),dp(4)); t.setBackground(cardBg(Color.rgb(5,34,64),16,accent)); setPerfText(t,label,value); return t; }
    private void setPerfText(TextView t,String label,String value){
        if(t==null)return;
        String v=value==null?"—":value.trim();
        String unit=""; String number=v;
        String[] units={"km/h","rpm","bar","Nm","CV","s"};
        for(String u:units){ if(number.toLowerCase(Locale.US).endsWith(" "+u.toLowerCase(Locale.US))){ unit=" "+number.substring(number.length()-u.length()); number=number.substring(0,number.length()-u.length()).trim(); break; } }
        android.text.SpannableString sp=new android.text.SpannableString(label+"\n\n"+number+unit);
        int valueStart=label.length()+2; int valueEnd=valueStart+number.length();
        sp.setSpan(new android.text.style.AbsoluteSizeSpan(21,true),valueStart,valueEnd,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sp.setSpan(new android.text.style.ForegroundColorSpan(Color.WHITE),valueStart,valueEnd,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if(!unit.isEmpty()){ int us=valueEnd; int ue=sp.length(); sp.setSpan(new android.text.style.AbsoluteSizeSpan(10,true),us,ue,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); sp.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(165,195,220)),us,ue,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); }
        sp.setSpan(new android.text.style.AbsoluteSizeSpan(10,true),0,label.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sp.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(235,248,255)),0,label.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        t.setText(sp);
    }

    private LinearLayout buildHistoryScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG);
        LinearLayout head=card(CARD); head.setPadding(dp(12),dp(8),dp(12),dp(8)); TextView t=tv("🗂 HISTÓRICO DE SESSÕES",18); t.setTextColor(WHITE); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setGravity(Gravity.CENTER); head.addView(t,new LinearLayout.LayoutParams(-1,dp(34))); TextView st=tv("Arquivos persistentes • puxadas e telemetria",9); st.setTextColor(MUTED); st.setGravity(Gravity.CENTER); head.addView(st,new LinearLayout.LayoutParams(-1,dp(24))); screen.addView(head,new LinearLayout.LayoutParams(-1,dp(72)));
        Button best=btn("🏆 3 MELHORES PUXADAS"); best.setMinHeight(dp(48)); best.setMinimumHeight(dp(48)); bindClick(best,()->showBestPullsDialog()); addFull(screen,best);
        ScrollView sv=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setTag("historyList"); sv.addView(list,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout folderRow=row(); Button chooseFolder=btn("📁 ESCOLHER PASTA DE LOGS"); bindClick(chooseFolder,()->chooseHistoryFolder()); addFull(screen,chooseFolder);
        TextView folderHint=tv("Pasta padrão: Download/VirtusELM/logs • escolha essa pasta uma vez para liberar leitura e exclusão dos CSVs antigos",8.5f); folderHint.setTextColor(MUTED); folderHint.setGravity(Gravity.CENTER); folderHint.setPadding(dp(4),dp(2),dp(4),dp(6)); addFull(screen,folderHint);
        LinearLayout acts=row(); Button refresh=btn("↻ ATUALIZAR ARQUIVOS"); bindClick(refresh,()->refreshHistorySessions()); Button back=btn("← PERFORMANCE"); bindClick(back,()->showPerformanceScreen()); addHalf(acts,refresh); addHalf(acts,back); addFull(screen,acts); return screen;
    }
    private LinearLayout buildDtcLibraryScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG);
        LinearLayout head=card(CARD); head.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView title=tv("BIBLIOTECA DTC • CONSULTA E ATUALIZAÇÃO",16); title.setTextColor(WHITE); title.setTypeface(null,android.graphics.Typeface.BOLD); head.addView(title,new LinearLayout.LayoutParams(-1,dp(38)));
        TextView info=tv("Base controlada do VirtusELM • códigos OBD-II e referências VAG documentadas",9); info.setTextColor(MUTED); head.addView(info);
        dtcLibraryStatusView=tv("Carregando biblioteca...",10); dtcLibraryStatusView.setTextColor(CYAN); dtcLibraryStatusView.setTypeface(null,android.graphics.Typeface.BOLD); head.addView(dtcLibraryStatusView);
        screen.addView(head,new LinearLayout.LayoutParams(-1,dp(90)));
        LinearLayout acts=row(); Button update=btn("ATUALIZAR"); update.setTextColor(CYAN); bindClick(update,()->updateDtcLibraryFromNetwork()); Button back=btn("← DIAGNÓSTICO"); bindClick(back,()->showDiagnosticScreen()); addHalf(acts,update); addHalf(acts,back); addFull(screen,acts);
        dtcLibrarySearch=new EditText(this); dtcLibrarySearch.setHint("Pesquisar código ou descrição..."); dtcLibrarySearch.setTextColor(WHITE); dtcLibrarySearch.setHintTextColor(MUTED); dtcLibrarySearch.setSingleLine(true); dtcLibrarySearch.setTextSize(13); dtcLibrarySearch.setPadding(dp(12),0,dp(12),0); dtcLibrarySearch.setBackground(cardBg(CARD2,16,CYAN2)); dtcLibrarySearch.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderDtcLibraryList();} public void afterTextChanged(android.text.Editable e){}}); screen.addView(dtcLibrarySearch,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView hint=tv("Toque em um código para consultar detalhes. A atualização usa HTTPS + SHA-256 e somente substitui a biblioteca após validação.",8.5f); hint.setTextColor(MUTED); hint.setPadding(dp(4),dp(6),dp(4),dp(6)); screen.addView(hint);
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); dtcLibraryListContainer=new LinearLayout(this); dtcLibraryListContainer.setOrientation(LinearLayout.VERTICAL); sv.addView(dtcLibraryListContainer,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        return screen;
    }
    private void renderDtcLibraryList(){ if(dtcLibraryListContainer==null)return; dtcLibraryListContainer.removeAllViews(); String q=dtcLibrarySearch==null?"":dtcLibrarySearch.getText().toString().trim().toUpperCase(Locale.US); int shown=0; synchronized(dtcLibraryRecords){ for(Map.Entry<String,JSONObject> e:dtcLibraryRecords.entrySet()){ JSONObject o=e.getValue(); String code=e.getKey(); String desc=o.optString("description",""); String hay=(code+" "+desc+" "+o.optString("system","")+" "+o.optString("vag_reference","")).toUpperCase(Locale.US); if(!q.isEmpty()&&!hay.contains(q))continue; LinearLayout item=card(Color.rgb(4,28,55)); item.setPadding(dp(10),dp(8),dp(10),dp(8)); TextView a=tv(code,13); a.setTextColor(Color.rgb(0,194,255)); a.setTypeface(null,android.graphics.Typeface.BOLD); TextView b=tv(desc,10); b.setTextColor(Color.rgb(242,248,255)); b.setSingleLine(false); TextView c=tv((o.optString("type","OBD-II").toUpperCase(Locale.US))+" • "+o.optString("system","—")+(o.has("vag_reference")?" • VAG "+o.optString("vag_reference"):""),8.5f); c.setTextColor(Color.rgb(145,181,210)); item.addView(a); item.addView(b); item.addView(c); bindClick(item,()->showDtcLibraryRecord(code)); dtcLibraryListContainer.addView(item,new LinearLayout.LayoutParams(-1,-2)); LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)item.getLayoutParams(); lp.setMargins(0,0,0,dp(6)); item.setLayoutParams(lp); if(++shown>=250)break; } } if(shown==0){TextView empty=tv(q.isEmpty()?"Nenhum código carregado.":"Nenhum DTC encontrado para: "+q,10);empty.setTextColor(Color.rgb(145,181,210));empty.setGravity(Gravity.CENTER);empty.setPadding(dp(12),dp(30),dp(12),dp(30));dtcLibraryListContainer.addView(empty);} }
    private void showDtcLibraryRecord(String code){ JSONObject o; synchronized(dtcLibraryRecords){o=dtcLibraryRecords.get(code);} if(o==null){showDtcDetails(code);return;} String desc=o.optString("description","Descrição não disponível na biblioteca DTC atual."); new AlertDialog.Builder(this).setTitle(code).setMessage(desc).setPositiveButton("OK",null).show(); }
    private boolean isVirtusLogsRelativePath(String rawPath){
        if(rawPath==null)return false;
        String p=rawPath.replace('\\','/').trim().toLowerCase(Locale.US);
        while(p.endsWith("/"))p=p.substring(0,p.length()-1);
        return p.equals("download/virtuselm/logs") || p.endsWith("/download/virtuselm/logs");
    }
    private Uri getSavedHistoryTree(){
        String saved=getSharedPreferences(PREFS_UI,MODE_PRIVATE).getString("history_tree_uri","");
        if(saved==null||saved.isEmpty())return null;
        try{return Uri.parse(saved);}catch(Exception e){return null;}
    }
    private void chooseHistoryFolder(){
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        if(Build.VERSION.SDK_INT>=26){Uri current=getSavedHistoryTree();if(current!=null)intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI,current);}
        try{startActivityForResult(intent,REQ_HISTORY_TREE);}catch(Exception e){toast("Não foi possível abrir o seletor de pastas");}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQ_HISTORY_TREE||resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri tree=data.getData();
        try{
            String docId=DocumentsContract.getTreeDocumentId(tree);
            String normalized=docId==null?"":docId.replace('\\','/').toLowerCase(Locale.US);
            if(!normalized.endsWith("/virtuselm/logs")&&!normalized.endsWith(":download/virtuselm/logs")){
                new AlertDialog.Builder(this).setTitle("PASTA INCORRETA").setMessage("Selecione a pasta Download/VirtusELM/logs para o aplicativo listar, abrir e apagar os CSVs corretos.").setPositiveButton("OK",null).show();return;
            }
            int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(tree,flags);
            getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putString("history_tree_uri",tree.toString()).apply();
            historyTreeUri=tree;refreshHistorySessions();toast("Pasta de logs vinculada com acesso persistente");
        }catch(Exception e){toast("Não foi possível guardar o acesso à pasta: "+e.getClass().getSimpleName());}
    }
    private ArrayList<String> listPersistentHistoryFiles(){
        LinkedHashSet<String> found=new LinkedHashSet<>(); historyFileUris.clear();
        // SAF: lista inclusive CSVs antigos que o MediaStore pode ocultar por causa do armazenamento restrito.
        Uri tree=getSavedHistoryTree(); historyTreeUri=tree;
        if(tree!=null){Cursor c=null;try{
            String rootId=DocumentsContract.getTreeDocumentId(tree);
            Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,rootId);
            String[] pr={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
            c=getContentResolver().query(children,pr,null,null,DocumentsContract.Document.COLUMN_DISPLAY_NAME+" ASC");
            if(c!=null){int idIdx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID),nameIdx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME),mimeIdx=c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                while(c.moveToNext()){String name=nameIdx>=0?c.getString(nameIdx):null;String mime=mimeIdx>=0?c.getString(mimeIdx):"";String id=idIdx>=0?c.getString(idIdx):null;
                    if(name!=null&&name.toLowerCase(Locale.US).endsWith(".csv")&&id!=null){found.add(name);historyFileUris.put(name,DocumentsContract.buildDocumentUriUsingTree(tree,id));}
                }
            }
        }catch(Exception e){append("HISTÓRICO: SAF não conseguiu listar a pasta vinculada — "+e.getClass().getSimpleName());}finally{if(c!=null)c.close();}}
        if(Build.VERSION.SDK_INT>=29){Cursor c=null;try{
            Uri collection=MediaStore.Files.getContentUri("external");String[] pr={MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.RELATIVE_PATH};
            c=getContentResolver().query(collection,pr,null,null,MediaStore.MediaColumns.DATE_MODIFIED+" DESC");
            if(c!=null){int idIdx=c.getColumnIndex(MediaStore.MediaColumns._ID),nameIdx=c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME),pathIdx=c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);
                while(c.moveToNext()){String name=nameIdx>=0?c.getString(nameIdx):null;String path=pathIdx>=0?c.getString(pathIdx):null;
                    if(name!=null&&name.toLowerCase(Locale.US).endsWith(".csv")&&isVirtusLogsRelativePath(path)){if(!found.contains(name)&&idIdx>=0)historyFileUris.put(name,ContentUris.withAppendedId(collection,c.getLong(idIdx)));found.add(name);}
                }
            }
        }catch(Exception e){append("HISTÓRICO: MediaStore falhou — "+e.getClass().getSimpleName());}finally{if(c!=null)c.close();}}
        try{File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs");File[] fs=dir.listFiles((d,n)->n.toLowerCase(Locale.US).endsWith(".csv"));if(fs!=null){Arrays.sort(fs,(a,b)->Long.compare(b.lastModified(),a.lastModified()));for(File f:fs)if(f.isFile())found.add(f.getName());}}catch(Exception e){append("HISTÓRICO: leitura direta indisponível — "+e.getClass().getSimpleName());}
        ArrayList<String> names=new ArrayList<>(found);Collections.sort(names,(a,b)->b.compareToIgnoreCase(a));return names;
    }
    private void refreshHistorySessions(){
        // Rebuild the list from the persistent folder and verify that each indexed CSV can actually be opened.
        loadHistorySessions(); int count=historySessionNames.size(), readable=0;
        for(String name:new ArrayList<>(historySessionNames)){try(InputStream in=openPersistentHistoryInput(name)){if(in!=null){in.read();readable++;}}catch(Exception e){append("HISTÓRICO: arquivo listado mas sem leitura confirmada: "+name);}}
        String folder=getSavedHistoryTree()!=null?"pasta vinculada":"Download/VirtusELM/logs";
        toast("Histórico atualizado • "+count+" CSV listado(s) • "+readable+" acessível(is) • "+folder);
    }
    private InputStream openPersistentHistoryInput(String name) throws IOException{
        Uri selected=historyFileUris.get(name);
        if(selected!=null){try{InputStream stream=getContentResolver().openInputStream(selected);if(stream!=null)return stream;}catch(Exception e){append("HISTÓRICO: SAF/MediaStore não abriu "+name+" — "+e.getClass().getSimpleName());}}
        if(Build.VERSION.SDK_INT>=29){Cursor c=null;try{Uri collection=MediaStore.Files.getContentUri("external");String[] pr={MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.RELATIVE_PATH};c=getContentResolver().query(collection,pr,MediaStore.MediaColumns.DISPLAY_NAME+"=?",new String[]{name},MediaStore.MediaColumns.DATE_MODIFIED+" DESC");if(c!=null){int idIdx=c.getColumnIndex(MediaStore.MediaColumns._ID),nameIdx=c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME),pathIdx=c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);while(c.moveToNext()){String candidate=nameIdx>=0?c.getString(nameIdx):null;String path=pathIdx>=0?c.getString(pathIdx):null;if(name.equals(candidate)&&isVirtusLogsRelativePath(path)&&idIdx>=0){InputStream stream=getContentResolver().openInputStream(ContentUris.withAppendedId(collection,c.getLong(idIdx)));if(stream!=null)return stream;}}}}catch(Exception e){append("HISTÓRICO: MediaStore não abriu "+name);}finally{if(c!=null)c.close();}}
        File f=new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs"),name);if(f.isFile())return new FileInputStream(f);throw new FileNotFoundException(name);
    }
    private void deleteHistoryFile(String name){
        Uri target=historyFileUris.get(name);
        try{
            if(target!=null){boolean deleted=false;try{deleted=DocumentsContract.deleteDocument(getContentResolver(),target);}catch(Exception ignored){}if(!deleted){int n=getContentResolver().delete(target,null,null);deleted=n>0;}if(!deleted)throw new IOException("O provedor não confirmou a exclusão");}
            else{File f=new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs"),name);if(!f.isFile()||!f.delete())throw new IOException("Arquivo não removido");}
            toast("Sessão apagada: "+name);loadHistorySessions();
        }catch(Exception e){toast("Não foi possível apagar o CSV: "+e.getClass().getSimpleName());}
    }
    private void loadHistorySessions(){
        if(historyScreen==null)return; LinearLayout list=(LinearLayout)historyScreen.findViewWithTag("historyList"); if(list==null)return; list.removeAllViews(); historySessionNames.clear(); ArrayList<String> names=listPersistentHistoryFiles(); historySessionNames.addAll(names);
        if(names.isEmpty()){if(perfSessionCount!=null)setPerfText(perfSessionCount,"SESSÕES","0");TextView empty=tv("NENHUMA SESSÃO PERSISTENTE ENCONTRADA\n\nOs arquivos são procurados em Download/VirtusELM/logs. Faça uma puxada e finalize o teste para gerar um registro.",11);empty.setTextColor(Color.rgb(145,181,210));empty.setGravity(Gravity.CENTER);empty.setPadding(dp(12),dp(30),dp(12),dp(30));list.addView(empty);return;}
        TextView countLabel=tv("ARQUIVOS ENCONTRADOS: "+names.size()+" • exibindo até 500",9);countLabel.setTextColor(Color.rgb(0,194,255));countLabel.setPadding(dp(8),dp(8),dp(8),dp(8));list.addView(countLabel);
        int shown=0;for(String name:names){if(shown++>=500)break;LinearLayout item=card(Color.rgb(4,28,55));item.setPadding(dp(10),dp(8),dp(10),dp(8));TextView a=tv(name,11);a.setTextColor(Color.rgb(242,248,255));a.setTypeface(null,android.graphics.Typeface.BOLD);TextView b=tv("CSV persistente • toque para abrir resumo",9);b.setTextColor(Color.rgb(145,181,210));item.addView(a);item.addView(b);bindClick(item,()->showHistoryFile(name));list.addView(item,new LinearLayout.LayoutParams(-1,dp(66)));}
        if(perfSessionCount!=null)setPerfText(perfSessionCount,"SESSÕES",String.valueOf(names.size()));
    }
    private static class BestPull { long ts=0; String file="",vin="",fuel="",source=""; double z60=-1,z100=-1,power=-1,torque=-1,boost=-1,rpm=-1,speed=-1,pedal=-1,pedalE=-1,pedalF=-1,throttle=-1,load=-1,map=-1,baro=-1,coolant=-1,intake=-1,oilTemp=-1,fuelPct=-1,voltage=-1,quality=-1,duration=-1; int shifts=-1,samples=-1; }
    private int historyCol(String[] header,String key){if(header==null)return -1;for(int i=0;i<header.length;i++)if(key.equalsIgnoreCase(header[i].trim()))return i;return -1;}
    private String historyField(String[] fields,String[] header,String key){int i=historyCol(header,key);return i>=0&&i<fields.length?fields[i].trim():"";}
    private double historyNumber(String[] fields,String[] header,String key){int i=historyCol(header,key);return parseHistoryDouble(fields,i);}
    private ArrayList<BestPull> readBestPulls(){
        ArrayList<BestPull> pulls=new ArrayList<>(); HashSet<String> seen=new HashSet<>();
        for(String name:listPersistentHistoryFiles()){
            try(BufferedReader br=new BufferedReader(new InputStreamReader(openPersistentHistoryInput(name),StandardCharsets.UTF_8))){String line;String[] header=null;double observedSpeed=-1,observedRpm=-1,observedBoost=-1,observedPedal=-1;while((line=br.readLine())!=null){if(line.startsWith("tipo;")){header=line.split(";",-1);continue;}if(header==null)continue;String[] f=line.split(";",-1);if(f.length<2)continue;double rowSpeed=historyNumber(f,header,"speed_kmh"),rowRpm=historyNumber(f,header,"rpm"),rowBoost=historyNumber(f,header,"boost_max_bar"),rowPedal=historyNumber(f,header,"pedal_d_pct");if(rowSpeed>observedSpeed)observedSpeed=rowSpeed;if(rowRpm>observedRpm)observedRpm=rowRpm;if(rowBoost<0)rowBoost=historyNumber(f,header,"boost_bar");if(rowBoost>observedBoost)observedBoost=rowBoost;if(rowPedal>observedPedal)observedPedal=rowPedal;if(!line.startsWith("PERFORMANCE_TEST;"))continue;
                BestPull p=new BestPull();p.file=name;try{p.ts=Long.parseLong(historyField(f,header,"timestamp_ms"));}catch(Exception ignored){} p.vin=historyField(f,header,"vin");String ethanol=historyField(f,header,"ethanol_pct");p.fuel=!ethanol.isEmpty()?ethanol+"% etanol":"não informado";p.power=historyNumber(f,header,"power_est_cv");p.torque=historyNumber(f,header,"torque_est_nm");p.z60=historyNumber(f,header,"zero60_s");p.z100=historyNumber(f,header,"zero100_s");p.quality=historyNumber(f,header,"quality_pct");p.duration=historyNumber(f,header,"pull_duration_s");try{p.shifts=(int)historyNumber(f,header,"gear_shifts");}catch(Exception ignored){}p.pedal=historyNumber(f,header,"pedal_d_pct");p.pedalE=historyNumber(f,header,"pedal_e_pct");p.pedalF=historyNumber(f,header,"pedal_f_pct");p.source=historyField(f,header,"speed_source");p.map=historyNumber(f,header,"map_kpa");p.baro=historyNumber(f,header,"baro_kpa");p.boost=historyNumber(f,header,"boost_max_bar");if(p.boost<0)p.boost=historyNumber(f,header,"boost_bar");p.throttle=historyNumber(f,header,"throttle_pct");p.load=historyNumber(f,header,"load_pct");p.coolant=historyNumber(f,header,"coolant_c");p.intake=historyNumber(f,header,"intake_c");p.oilTemp=historyNumber(f,header,"oil_temp_c");p.fuelPct=historyNumber(f,header,"fuel_pct");p.voltage=historyNumber(f,header,"voltage_v");p.rpm=historyNumber(f,header,"rpm");p.speed=historyNumber(f,header,"speed_kmh");if(observedSpeed>p.speed)p.speed=observedSpeed;if(observedRpm>p.rpm)p.rpm=observedRpm;if(observedBoost>p.boost)p.boost=observedBoost;if(observedPedal>p.pedal)p.pedal=observedPedal;p.samples=(int)historyNumber(f,header,"samples");
                String key=String.format(Locale.US,"%d|%.2f|%.2f|%.0f|%.0f|%s",p.ts/60000L,p.z60,p.z100,p.power,p.rpm,p.vin);if(seen.add(key))pulls.add(p);
            }}catch(Exception ignored){}
        }
        Collections.sort(pulls,(a,b)->{boolean av=a.z100>0,bv=b.z100>0;if(av&&bv)return Double.compare(a.z100,b.z100);if(av!=bv)return av?-1:1;if(a.z60>0&&b.z60>0)return Double.compare(a.z60,b.z60);if(a.z60>0)return -1;if(b.z60>0)return 1;return Long.compare(b.ts,a.ts);});return pulls;
    }
    private TextView tableCell(String text,boolean header){TextView v=tv(text,header?9:8.5f);v.setTextColor(header?Color.rgb(0,220,255):Color.rgb(238,247,255));if(header)v.setTypeface(null,android.graphics.Typeface.BOLD);v.setGravity(Gravity.CENTER_VERTICAL);v.setPadding(dp(7),dp(8),dp(7),dp(8));v.setMinWidth(dp(header?84:84));v.setBackground(cardBg(header?Color.rgb(7,54,82):Color.rgb(4,28,55),8,Color.rgb(30,100,145)));return v;}
    private void showBestPullsDialog(){
        ArrayList<BestPull> all=readBestPulls();if(all.isEmpty()){new AlertDialog.Builder(this).setTitle("3 MELHORES PUXADAS").setMessage("Ainda não encontrei registros PERFORMANCE_TEST nos CSVs arquivados. Faça uma puxada e finalize o teste; a nova versão salvará um arquivo próprio para cada puxada.").setPositiveButton("OK",null).show();return;}
        int count=Math.min(3,all.size());LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);TextView info=tv("Ordenação: menor 0–100; quando indisponível, menor 0–60. Deslize horizontalmente para ver todas as colunas.",9);info.setTextColor(Color.rgb(145,181,210));info.setPadding(dp(4),dp(4),dp(4),dp(8));outer.addView(info);
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setFillViewport(false);LinearLayout table=new LinearLayout(this);table.setOrientation(LinearLayout.VERTICAL);
        String[] headers={"#","DATA/HORA","0–60 s","0–100 s","POTÊNCIA cv","TORQUE Nm","BOOST máx. bar","RPM máx.","VEL. máx. km/h","PEDAL D %","PEDAL E %","PEDAL F %","THROTTLE %","CARGA %","MAP kPa","BARO kPa","LÍQUIDO °C","ADMISSÃO °C","ÓLEO °C","COMB. %","TENSÃO V","QUAL. %","DURAÇÃO s","TROCAS","ETANOL","AMOSTRAS","FONTE","VIN","ARQUIVO"};LinearLayout hr=row();for(String h:headers)hr.addView(tableCell(h,true));table.addView(hr);
        for(int i=0;i<count;i++){BestPull p=all.get(i);String dt=p.ts>0?new SimpleDateFormat("dd/MM HH:mm:ss",Locale.getDefault()).format(new Date(p.ts)):"—";String[] vals={String.valueOf(i+1),dt,fmtHistory(p.z60,"",2),fmtHistory(p.z100,"",2),fmtHistory(p.power,"",0),fmtHistory(p.torque,"",0),fmtHistory(p.boost,"",2),fmtHistory(p.rpm,"",0),fmtHistory(p.speed,"",0),fmtHistory(p.pedal,"",0),fmtHistory(p.pedalE,"",0),fmtHistory(p.pedalF,"",0),fmtHistory(p.throttle,"",0),fmtHistory(p.load,"",0),fmtHistory(p.map,"",1),fmtHistory(p.baro,"",1),fmtHistory(p.coolant,"",0),fmtHistory(p.intake,"",0),fmtHistory(p.oilTemp,"",0),fmtHistory(p.fuelPct,"",0),fmtHistory(p.voltage,"",2),fmtHistory(p.quality,"",0),fmtHistory(p.duration,"",2),(p.shifts>=0?String.valueOf(p.shifts):"—"),p.fuel,p.samples>=0?String.valueOf(p.samples):"—",p.source,p.vin.isEmpty()?"—":p.vin,p.file};LinearLayout rr=row();for(String v:vals)rr.addView(tableCell(v,false));table.addView(rr);}
        hsv.addView(table,new HorizontalScrollView.LayoutParams(-2,-2));outer.addView(hsv,new LinearLayout.LayoutParams(-1,-2));TextView footer=tv("Registros encontrados: "+all.size()+" • exibindo "+count+" melhores. Os campos sem dados no CSV aparecem como —.",8.5f);footer.setTextColor(Color.rgb(145,181,210));footer.setPadding(dp(4),dp(8),dp(4),0);outer.addView(footer);
        ScrollView sv=new ScrollView(this);sv.addView(outer,new ScrollView.LayoutParams(-1,-2));new AlertDialog.Builder(this).setTitle("🏆 3 MELHORES PUXADAS").setView(sv).setPositiveButton("FECHAR",null).show();
    }
    private static class HistorySummary{
        int telemetrySamples=0, performanceTests=0, sampleCount=-1;
        long firstTs=-1,lastTs=-1;
        double maxSpeed=-1,maxRpm=-1,maxBoost=-1,maxThrottle=-1,maxAcceleration=-1;
        double zero60=-1,zero100=-1,power=-1,torque=-1,quality=-1,pullDuration=-1,pedalMax=-1,boostMax=-1,maxSpeedRecorded=-1,maxRpmRecorded=-1; int gearShifts=0;
        String vin="", speedSource="", fuel="";
    }
    private double parseHistoryDouble(String[] f,int idx){
        if(idx<0||idx>=f.length||f[idx]==null||f[idx].trim().isEmpty())return -1;
        try{return Double.parseDouble(f[idx].trim());}catch(Exception e){return -1;}
    }
    private HistorySummary readHistorySummary(BufferedReader br) throws IOException{
        HistorySummary h=new HistorySummary();String line;double prevSpeed=-1;long prevTs=-1;String[] header=null;
        while((line=br.readLine())!=null){if(line.startsWith("tipo;")){header=line.split(";",-1);continue;}if(header==null)continue;String[] f=line.split(";",-1);if(f.length<2)continue;
            String type=historyField(f,header,"tipo");long ts=-1;try{ts=Long.parseLong(historyField(f,header,"timestamp_ms"));}catch(Exception ignored){}if(ts>0){if(h.firstTs<0)h.firstTs=ts;h.lastTs=ts;}
            double rpm=historyNumber(f,header,"rpm"),speed=historyNumber(f,header,"speed_kmh"),gps=historyNumber(f,header,"gps_speed_kmh"),boost=historyNumber(f,header,"boost_max_bar"),throttle=historyNumber(f,header,"throttle_pct"),pedal=historyNumber(f,header,"pedal_d_pct");if(boost<0)boost=historyNumber(f,header,"boost_bar");String source=historyField(f,header,"speed_source");double preferred=("GPS".equalsIgnoreCase(source)&&gps>=0)?gps:(speed>=0?speed:gps);
            if(preferred>=0&&preferred>h.maxSpeed)h.maxSpeed=preferred;if(rpm>h.maxRpm)h.maxRpm=rpm;if(boost>h.maxBoost)h.maxBoost=boost;if(throttle>h.maxThrottle)h.maxThrottle=throttle;if(pedal>h.pedalMax)h.pedalMax=pedal;if(!source.isEmpty())h.speedSource=source;
            if(ts>0&&prevTs>0&&ts>prevTs&&preferred>=0&&prevSpeed>=0){double dt=(ts-prevTs)/1000.0;if(dt>0&&dt<=2.0){double acc=((preferred-prevSpeed)/3.6)/dt;if(acc>h.maxAcceleration)h.maxAcceleration=acc;}}if(preferred>=0){prevSpeed=preferred;prevTs=ts;}
            String vin=historyField(f,header,"vin");if(!vin.isEmpty())h.vin=vin;double pd=historyNumber(f,header,"pull_duration_s");if(pd>=0)h.pullDuration=pd;
            if("PERFORMANCE_TEST".equalsIgnoreCase(type)){h.performanceTests++;double p=historyNumber(f,header,"power_est_cv"),tq=historyNumber(f,header,"torque_est_nm"),z60=historyNumber(f,header,"zero60_s"),z100=historyNumber(f,header,"zero100_s"),q=historyNumber(f,header,"quality_pct");if(p>=0)h.power=p;if(tq>=0)h.torque=tq;if(z60>=0)h.zero60=z60;if(z100>=0)h.zero100=z100;if(q>=0)h.quality=q;double shifts=historyNumber(f,header,"gear_shifts");if(shifts>=0)h.gearShifts=(int)shifts;double samples=historyNumber(f,header,"samples");if(samples>=0)h.sampleCount=(int)samples;}
            else if("TELEMETRIA".equalsIgnoreCase(type))h.telemetrySamples++;
        }return h;
    }
    private String fmtHistory(double v,String unit,int decimals){
        if(v<0)return "—"; return String.format(Locale.US,"%."+decimals+"f %s",v,unit);
    }
    private void showHistoryFile(String name){
        try{
            BufferedReader br=new BufferedReader(new InputStreamReader(openPersistentHistoryInput(name),StandardCharsets.UTF_8));
            HistorySummary h=readHistorySummary(br); br.close();
            double duration=h.firstTs>0&&h.lastTs>h.firstTs?(h.lastTs-h.firstTs)/1000.0:-1;
            StringBuilder msg=new StringBuilder();
            msg.append("RESUMO DA SESSÃO\n\n");
            msg.append("VELOCIDADE MÁXIMA: ").append(fmtHistory(h.maxSpeed,"km/h",0)).append("\n");
            msg.append("BOOST MÁXIMO: ").append(fmtHistory(h.maxBoost,"bar",2)).append("\n");
            msg.append("ACELERAÇÃO MÁXIMA: ").append(h.maxAcceleration>=0?String.format(Locale.US,"%.2f m/s²",h.maxAcceleration):"—").append("\n");
            msg.append("RPM MÁXIMO: ").append(fmtHistory(h.maxRpm,"rpm",0)).append("\n");
            msg.append("PEDAL MÁXIMO: ").append(fmtHistory(h.pedalMax>=0?h.pedalMax:h.maxThrottle,"%",0)).append("\n");
            msg.append("TEMPO TOTAL: ").append(duration>=0?String.format(Locale.US,"%.1f s",duration):"—").append("\n");
            if(h.performanceTests>0){
                msg.append("\nPERFORMANCE\n");
                msg.append("0–60 km/h: ").append(fmtHistory(h.zero60,"s",2)).append("\n");
                msg.append("0–100 km/h: ").append(fmtHistory(h.zero100,"s",2)).append("\n");
                msg.append("DURAÇÃO DA PUXADA: ").append(fmtHistory(h.pullDuration,"s",2)).append("\n");
                msg.append("TROCAS DE MARCHA: ").append(h.gearShifts).append(" (estimadas)\n");
                msg.append("POTÊNCIA ESTIMADA: ").append(fmtHistory(h.power,"cv",0)).append("\n");
                msg.append("TORQUE ESTIMADO: ").append(fmtHistory(h.torque,"Nm",0)).append("\n");
                msg.append("QUALIDADE DA AQUISIÇÃO: ").append(fmtHistory(h.quality,"%",0)).append("\n");
            }
            if(!h.speedSource.isEmpty())msg.append("\nFONTE DA VELOCIDADE: ").append(h.speedSource);
            if(!h.vin.isEmpty())msg.append("\nVIN: ").append(h.vin);
            msg.append("\n\nREGISTRO: ").append(h.telemetrySamples).append(" amostras");
            if(h.performanceTests>0)msg.append(" • ").append(h.performanceTests).append(" teste(s) de performance");
            LinearLayout detail=new LinearLayout(this);detail.setOrientation(LinearLayout.VERTICAL);detail.setPadding(dp(18),dp(8),dp(18),dp(8));
            TextView detailText=tv(msg.toString(),12);detailText.setTextColor(Color.rgb(24,39,56));detailText.setLinkTextColor(Color.rgb(0,76,130));detailText.setLineSpacing(dp(2),1.0f);detailText.setMovementMethod(new ScrollingMovementMethod());detailText.setMaxHeight(dp(420));detail.addView(detailText,new LinearLayout.LayoutParams(-1,-2));
            LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setGravity(Gravity.CENTER);actions.setPadding(0,dp(12),0,dp(2));
            Button ok=btn("OK");Button del=btn("APAGAR");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(46),1);bp.setMargins(dp(6),0,dp(6),0);actions.addView(ok,bp);LinearLayout.LayoutParams dpb=new LinearLayout.LayoutParams(0,dp(46),1);dpb.setMargins(dp(6),0,dp(6),0);actions.addView(del,dpb);detail.addView(actions);
            AlertDialog detailDialog=new AlertDialog.Builder(this).setTitle("SESSÃO • "+name.replace("VirtusELM_Performance_","").replace(".csv","")).setView(detail).create();
            ok.setOnClickListener(v->detailDialog.dismiss());
            del.setOnClickListener(v->{AlertDialog confirm=new AlertDialog.Builder(this).setTitle("APAGAR SESSÃO?").setMessage("Deseja realmente apagar este arquivo CSV?\n\n"+name+"\n\nEssa ação não pode ser desfeita.").setNegativeButton("CANCELAR",(d,w)->{d.dismiss();detailDialog.dismiss();loadHistorySessions();}).setPositiveButton("APAGAR",(d,w)->{d.dismiss();detailDialog.dismiss();deleteHistoryFile(name);}).create();confirm.setOnCancelListener(d->{detailDialog.dismiss();loadHistorySessions();});confirm.show();});
            detailDialog.show();
        }catch(Exception e){toast("Não foi possível ler a sessão: "+e.getClass().getSimpleName());}
    }

    private void showScreen(int screen){
        currentScreen=screen;
        updateNavSelection(screen);
        if(homeScreen!=null)homeScreen.setVisibility(screen==0?View.VISIBLE:View.GONE);
        if(dataScreen!=null)dataScreen.setVisibility(screen==1?View.VISIBLE:View.GONE);
        if(diagnosticScreen!=null)diagnosticScreen.setVisibility(screen==2?View.VISIBLE:View.GONE);
        if(canScreen!=null)canScreen.setVisibility(screen==3?View.VISIBLE:View.GONE);
        if(configScreen!=null)configScreen.setVisibility(screen==4?View.VISIBLE:View.GONE);
        if(graphScreen!=null)graphScreen.setVisibility(screen==5?View.VISIBLE:View.GONE);
        if(performanceScreen!=null)performanceScreen.setVisibility(screen==6?View.VISIBLE:View.GONE);
        if(historyScreen!=null)historyScreen.setVisibility(screen==7?View.VISIBLE:View.GONE);
        if(dtcLibraryScreen!=null)dtcLibraryScreen.setVisibility(screen==8?View.VISIBLE:View.GONE);
        if(screen==1){
            if(!dataTabButtons.isEmpty()){setSelectedButton(dataTabButtons.get(0),!dataLogsTab);setSelectedButton(dataTabButtons.get(1),false);setSelectedButton(dataTabButtons.get(2),dataLogsTab);}
            if(dataTelemetryContent!=null)dataTelemetryContent.setVisibility(dataLogsTab?View.GONE:View.VISIBLE);
            if(dataLogsContent!=null)dataLogsContent.setVisibility(dataLogsTab?View.VISIBLE:View.GONE);
            if(log!=null&&log.getText().length()==0){synchronized(logLock){log.setText(technical.toString());}}
            if(logScroll!=null)logScroll.post(()->logScroll.fullScroll(View.FOCUS_DOWN)); updateRecordingUi();
        }
    }
    private void showHomeScreen(){showScreen(0);}
    private void showDataScreen(){historicalGraphMode=false;showScreen(1);}
    private void showDiagnosticScreen(){showScreen(2);}
    private void showCanScreen(){showScreen(3);}
    private void showConfigScreen(){showScreen(4);}
    private void showGraphScreen(){
        historicalGraphMode=false; combinedRpmValues.clear();combinedSpeedValues.clear();combinedPedalValues.clear();combinedBoostValues.clear();combinedTimeValues.clear();
        if(graphHeaderTitle!=null)graphHeaderTitle.setText("GRÁFICO COMBINADO • DADOS AO VIVO");
        if(graphHistoryStatus!=null){graphHistoryStatus.setText("DADOS EM TEMPO REAL • não representa uma puxada arquivada");graphHistoryStatus.setTextColor(Color.rgb(55,150,255));}
        showScreen(5);
    }
    private void showPerformanceTestGraph(){showScreen(5);loadLastPerformanceGraph();}
    private void showPerformanceScreen(){ historicalGraphMode=false; combinedRpmValues.clear();combinedSpeedValues.clear();combinedPedalValues.clear();combinedBoostValues.clear();combinedTimeValues.clear(); showScreen(6); startGpsTracking(); if(performanceScreen!=null){ ScrollView sv=(ScrollView)performanceScreen.getChildAt(0); if(sv!=null)sv.post(()->sv.scrollTo(0,0)); } loadHistorySessions(); }
    private void showHistoryScreen(){showScreen(7); loadHistorySessions();}
    private void showDtcLibraryScreen(){showScreen(8); renderDtcLibraryList();}

    private LinearLayout diagSection, canSection, logSection, configSection, recordSection;
    private GradientDrawable cardBg(int color,float radius,int stroke){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); g.setStroke(dp(1),stroke); return g; }
    private LinearLayout card(int color){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setBackground(cardBg(color,22,Color.rgb(20,95,150))); return l; }
    private ImageView icon(int res,int tint){ ImageView v=new ImageView(this); v.setImageResource(res); v.setColorFilter(tint); v.setScaleType(ImageView.ScaleType.CENTER_INSIDE); return v; }
    private TextView metric(String label,String value,int fg,int accent){ TextView t=tv("",10); t.setTextColor(fg); t.setGravity(Gravity.CENTER); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setSingleLine(false); t.setIncludeFontPadding(false); t.setPadding(dp(2),dp(5),dp(2),dp(5)); t.setBackground(cardBg(Color.rgb(5,34,64),16,accent)); setMetricText(t,label,value,""); return t; }
    private void setMetricText(TextView t,String label,String value,String unit){ if(t==null)return; String v=value==null?"—":value; String u=unit==null?"":unit; android.text.SpannableStringBuilder b=new android.text.SpannableStringBuilder(); int a=b.length(); b.append(label); b.setSpan(new android.text.style.AbsoluteSizeSpan(dp(9)),a,b.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); b.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(150,190,220)),a,b.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); b.append("\n"); int c=b.length(); b.append(v); b.setSpan(new android.text.style.AbsoluteSizeSpan(dp(18)),c,b.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); b.append("\n"); int d=b.length(); b.append(u); b.setSpan(new android.text.style.AbsoluteSizeSpan(dp(9)),d,b.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); t.setText(b); }
    private void addHalfView(LinearLayout r,TextView t){ LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(84),1); lp.setMargins(dp(3),dp(3),dp(3),dp(3)); r.addView(t,lp); }
    private void addModule(LinearLayout r,int iconRes,String title,String sub,int accent,final Runnable action){
        LinearLayout c=card(Color.rgb(4,28,55)); c.setPadding(dp(7),dp(6),dp(7),dp(6)); c.setBackground(pressableBg(Color.rgb(4,28,55),Color.rgb(8,58,92),accent,18));
        LinearLayout inner=new LinearLayout(this); inner.setOrientation(LinearLayout.HORIZONTAL); inner.setGravity(Gravity.CENTER_VERTICAL);
        ImageView ic=icon(iconRes,accent); ic.setScaleType(ImageView.ScaleType.CENTER_INSIDE); inner.addView(ic,new LinearLayout.LayoutParams(dp(46),dp(86)));
        LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setGravity(Gravity.CENTER_VERTICAL); texts.setPadding(dp(5),0,dp(2),0);
        TextView a=tv(title,10.5f); a.setTextColor(Color.WHITE); a.setTypeface(null,android.graphics.Typeface.BOLD); a.setSingleLine(true); a.setEllipsize(TextUtils.TruncateAt.END); a.setGravity(Gravity.CENTER_VERTICAL);
        if(Build.VERSION.SDK_INT>=26){ a.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP); }
        TextView b=tv(sub,8.2f); b.setTextColor(Color.rgb(165,195,220)); b.setSingleLine(true); b.setEllipsize(TextUtils.TruncateAt.END); b.setGravity(Gravity.CENTER_VERTICAL);
        if(Build.VERSION.SDK_INT>=26){ b.setAutoSizeTextTypeUniformWithConfiguration(7,9,1,android.util.TypedValue.COMPLEX_UNIT_SP); }
        texts.addView(a,new LinearLayout.LayoutParams(-1,dp(34))); texts.addView(b,new LinearLayout.LayoutParams(-1,dp(30)));
        inner.addView(texts,new LinearLayout.LayoutParams(0,dp(78),1));
        TextView arrow=tv("›",23); arrow.setTextColor(accent); arrow.setGravity(Gravity.CENTER); arrow.setIncludeFontPadding(false); inner.addView(arrow,new LinearLayout.LayoutParams(dp(16),dp(70)));
        c.addView(inner); bindClick(c,action); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(110),1); lp.setMargins(dp(4),dp(4),dp(4),dp(4)); r.addView(c,lp);
    }
    private void addNav(LinearLayout nav,int iconRes,String label,int accent,final Runnable action){
        LinearLayout item=new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        ImageView i=icon(iconRes,accent);
        TextView n=tv(label,11);
        n.setTextColor(accent);
        n.setGravity(Gravity.CENTER);
        item.addView(i,new LinearLayout.LayoutParams(-1,dp(52)));
        item.addView(n,new LinearLayout.LayoutParams(-1,dp(30)));
        item.setPadding(dp(3),dp(2),dp(3),dp(2));
        item.setBackground(pressableBg(Color.TRANSPARENT,Color.rgb(8,52,88),Color.TRANSPARENT,16));
        bindClick(item,action);
        navItems.add(item);
        navIcons.add(i);
        navLabels.add(n);
        nav.addView(item,new LinearLayout.LayoutParams(0,-1,1));
    }
    private void updateNavSelection(int screen){
        int selected=-1;
        if(screen>=0&&screen<=4) selected=screen;
        else if(screen==5) selected=1;
        else if(screen==6) selected=0;
        for(int i=0;i<navItems.size();i++){
            boolean active=i==selected;
            int color=active?NAV_ACTIVE:NAV_INACTIVE;
            navIcons.get(i).setColorFilter(color);
            navLabels.get(i).setTextColor(color);
        }
    }
    private void scrollToSection(LinearLayout root,View v){ if(v==null)return; v.post(()->{ ScrollView sv=(ScrollView)root.getParent(); if(sv!=null)sv.smoothScrollTo(0,Math.max(0,v.getTop()-16)); }); }

    private TextView healthChip(String text,int fg,int bg){ TextView t=tv(text,11); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setTextColor(fg); t.setGravity(Gravity.CENTER); t.setPadding(dp(6),dp(5),dp(6),dp(5)); t.setSingleLine(false); t.setMaxLines(2); if(Build.VERSION.SDK_INT>=26){ t.setAutoSizeTextTypeUniformWithConfiguration(9,11,1,android.util.TypedValue.COMPLEX_UNIT_SP); } android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(bg); g.setCornerRadius(dp(30)); g.setStroke(dp(1),fg); t.setBackground(g); return t; }
    private void setHealth(String mode,String detail){ ui(()->{ if(healthChip==null)return; String text; int fg,bg; if("GREEN".equals(mode)){ text="● SISTEMA OK"; fg=Color.rgb(0,190,120); bg=Color.rgb(7,52,48); } else if("SIM".equals(mode)){ text="● SIMULAÇÃO"; fg=Color.rgb(0,210,255); bg=Color.rgb(7,38,58); } else if("YELLOW".equals(mode)){ text="● ATENÇÃO"; fg=Color.rgb(255,184,45); bg=Color.rgb(61,45,9); } else { text="● OFFLINE"; fg=Color.rgb(255,88,88); bg=Color.rgb(61,16,24); } healthChip.setText(text); healthChip.setTextColor(fg); android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(bg); g.setCornerRadius(dp(30)); g.setStroke(dp(1),fg); healthChip.setBackground(g); }); }
    private void addHalfText(LinearLayout r, TextView t){ LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(2),0,dp(2),0); r.addView(t,lp); }
    private void resetSession(){ simulationMode=false; simulationStartMs=0; simulationIndex=0; simulationSamples.clear(); monitoring=false; operationRunning=false; markers.clear(); rawCount=frameCount=rxBytes=0; ids.clear(); noDataCycles=0; recoveringSession=false; closeSocket(); }
    private boolean hasBluetoothPermission(){
        if(Build.VERSION.SDK_INT<31) return true;
        try { return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED; }
        catch(Throwable e){ return false; }
    }
    private void clearSimulationResidueForRealVehicle(){
        lastVin="—"; lastRpm=0; lastSpeed=-1; lastLoad=-1; lastCoolant=-1; lastIntake=-1; lastOilTemp=-1; lastFuel=-1; lastVolt=-1; lastThrottle=-1; lastPedalD=-1; lastPedalE=-1; lastPedalF=-1; lastMap=-1; lastBaro=-1; lastBoost=-1; maxBoost=-1; lastOilLevel="—"; ecuResponding=false; lastDtcCodes.clear(); selectedDtcCodes.clear(); dtcSelectionMode=false;
        combinedRpmValues.clear(); combinedSpeedValues.clear(); combinedThrottleValues.clear(); combinedPedalValues.clear(); combinedBoostValues.clear();
        ui(()->{ if(vagExplorerResult!=null)vagExplorerResult.setText("Aguardando exploração real. Nenhum dado de simulação será mantido após a conexão."); if(diagnosticResult!=null)diagnosticResult.setText("Nenhum teste executado nesta conexão."); if(result!=null)result.setText("RESULTADO: —"); if(resultHome!=null)resultHome.setText("RESULTADO: —"); if(dtcStatusView!=null)dtcStatusView.setText("STATUS: AGUARDANDO LEITURA"); if(dtcCodesView!=null)dtcCodesView.setText("CÓDIGOS: nenhum DTC lido nesta sessão"); if(dtcRawView!=null)dtcRawView.setText("RAW: —"); if(combinedGraphView!=null)combinedGraphView.clear(); });
    }

    private void applyConnectStyle(boolean isConnected){ ui(()->{ if(connectButton==null)return; GradientDrawable g=new GradientDrawable(); g.setCornerRadius(dp(24)); if(isConnected){ g.setColor(simulationMode?Color.rgb(18,48,64):Color.rgb(48,12,22)); g.setStroke(dp(2),simulationMode?Color.rgb(0,210,255):Color.rgb(255,82,82)); connectButton.setText(simulationMode?"◉  SAIR DA SIMULAÇÃO":"⛓  DESCONECTAR"); connectButton.setTextColor(Color.WHITE); } else { g.setColor(Color.rgb(7,38,70)); g.setStroke(dp(1),Color.rgb(25,125,195)); connectButton.setText("CONECTAR ELM"); connectButton.setTextColor(Color.rgb(235,248,255)); } connectButton.setBackground(g); }); }

    private void toggleConnection(){
        try{
            if(connectAttempt || operationRunning){ setStatus("Conexão em andamento — aguarde a conclusão"); return; }
            if(connected){ if(monitoring){toast("Finalize a captura antes de desconectar");return;} if(recordingActive){toast("Finalize a gravação antes de desconectar");return;} disconnect(); }
            else connect();
        }catch(Throwable t){
            append("ERRO NO BOTÃO DE CONEXÃO: "+t.getClass().getSimpleName()+" — "+String.valueOf(t.getMessage()));
            setStatus("Falha de conexão — aplicativo mantido aberto");
            ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});
        }
    }
    private void disconnect(){
        epcEvidenceSavedThisSession=false; lastEpcEvidenceFile="";
        try{io.execute(()->{
            autoConnectActive=false; autoConnectAttempts=0;
            operationRunning=true; intentionalDisconnect=true; monitoring=false; stopRequested=true; connected=false; simulationMode=false;
            try{closeSocket();}catch(Throwable ignored){} closePerformanceHistory(); noDataCycles=0;
            setHealth("RED","DESCONECTADO"); setStatus("Bluetooth desconectado");
            ui(()->{if(connectButton!=null){connectButton.setEnabled(true);} applyConnectStyle(false);if(dashConn!=null){dashConn.setText("● ELM: DESCONECTADO");dashConn.setTextColor(Color.rgb(150,35,35));}});
            append("ELM desconectado pelo usuário."); operationRunning=false;
        });}catch(Throwable t){operationRunning=false;append("ERRO AO DESCONECTAR: "+t.getClass().getSimpleName());ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});}
    }
    // ===== V12.0 FIX 01 — SIMULAÇÃO IMEDIATA + ATÉ 3 TENTATIVAS DE ELM =====
    private void startAutomaticConnectionSequence(){
        autoConnectActive=isAutoConnectEnabled();
        autoConnectAttempts=0;
        if(isAutoSimulationEnabled()) io.execute(()->startSimulationMode("inicialização automática — aguardando tentativa de conexão com o ELM"));
        if(autoConnectActive) dashboardExec.schedule(this::automaticConnectionAttempt,700,TimeUnit.MILLISECONDS);
    }

    private void automaticConnectionAttempt(){
        if(!autoConnectActive || intentionalDisconnect || (connected && !simulationMode)) return;
        if(autoConnectAttempts>=3){
            autoConnectActive=false;
            setStatus("3 tentativas concluídas — permanecendo em modo simulação");
            append("=== AUTO-CONEXÃO FINALIZADA ===");
            append("Nenhum ELM conectado após 3 tentativas. Modo simulação permanece ativo.");
            return;
        }
        autoConnectAttempts++;
        final int tentativa=autoConnectAttempts;
        append("AUTO-CONEXÃO: tentativa "+tentativa+"/3");
        connectAttempt=true;
        ui(()->{ if(connectButton!=null) connectButton.setEnabled(false); setStatus("Tentativa automática "+tentativa+"/3 — procurando ELM..."); });
        io.execute(()->{
            connectWorker();
            if(autoConnectActive && !connected){
                if(isAutoSimulationEnabled()) startSimulationMode("tentativa automática "+tentativa+" sem ELM — simulação preservada");
                if(autoConnectAttempts>=3){
                    autoConnectActive=false;
                    setStatus("3 tentativas concluídas — permanecendo em modo simulação");
                    append("=== AUTO-CONEXÃO FINALIZADA ===");
                    append("Nenhum ELM conectado após 3 tentativas. Modo simulação permanece ativo.");
                }else{
                    dashboardExec.schedule(this::automaticConnectionAttempt,2200,TimeUnit.MILLISECONDS);
                }
            }else if(connected && !simulationMode){
                autoConnectActive=false;
                append("AUTO-CONEXÃO: ELM conectado — modo veículo assumido.");
            }
        });
    }

    private void connect(){
        try{
            if(connectAttempt||operationRunning){setStatus("Conexão já em andamento — aguarde");return;}
            epcEvidenceSavedThisSession=false; lastEpcEvidenceFile="";
            connectAttempt=true;
            ui(()->{if(connectButton!=null)connectButton.setEnabled(false);});
            if(Build.VERSION.SDK_INT>=31&&!hasBluetoothPermission()){
                connectAttempt=false;
                ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});
                setStatus("Permissão 'Dispositivos por perto' necessária");
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},20); return;
            }
            if(bt==null){ io.execute(()->startSimulationMode("Bluetooth indisponível neste aparelho")); connectAttempt=false; ui(()->{if(connectButton!=null)connectButton.setEnabled(true);}); return; }
            boolean enabled; try{enabled=bt.isEnabled();}catch(Throwable e){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});setStatus("Permissão Bluetooth não concedida");return;}
            if(!enabled){ io.execute(()->startSimulationMode("Bluetooth desligado — nenhum ELM pode ser localizado")); connectAttempt=false; ui(()->{if(connectButton!=null)connectButton.setEnabled(true);}); return; }
            try{io.execute(()->connectWorker());}catch(Throwable t){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});append("ERRO AO AGENDAR CONEXÃO: "+t.getClass().getSimpleName());}
        }catch(Throwable t){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});append("ERRO AO INICIAR CONEXÃO: "+t.getClass().getSimpleName()+" — "+String.valueOf(t.getMessage()));setStatus("Falha ao iniciar conexão — aplicativo mantido aberto");}
    }
    private void connectWorker(){
        if(operationRunning||monitoring){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);setStatus("Operação em andamento — finalize antes de reconectar");});return;}
        epcEvidenceSavedThisSession=false; lastEpcEvidenceFile="";
        operationRunning=true;intentionalDisconnect=false;connected=false;
        try{
            closeSocket(); if(bt==null)throw new IOException("BluetoothAdapter indisponível");
            if(Build.VERSION.SDK_INT>=31&&!hasBluetoothPermission())throw new SecurityException("BLUETOOTH_CONNECT não concedida");
            boolean enabled=true; try{enabled=bt.isEnabled();}catch(Throwable ignored){}
            if(!enabled){
                append("Bluetooth desligado — tentativa automática mantida em modo simulação.");
                startSimulationMode("Bluetooth desligado");
                return;
            }
            BluetoothDevice dev=null; Set<BluetoothDevice> bonded=bt.getBondedDevices();
            if(bonded!=null)for(BluetoothDevice d:bonded){String n=null;try{n=d.getName();}catch(Throwable ignored){}if(n!=null){String u=n.toUpperCase(Locale.US);if(u.contains("OBD")||u.contains("ELM")||u.contains("V-LINK")||u.contains("OBDLINK")){dev=d;break;}}}
            if(dev==null){
                append("ELM não encontrado entre os dispositivos Bluetooth pareados.");
                startSimulationMode("nenhum ELM327 compatível encontrado entre os dispositivos pareados");
                return;
            }
            append("ELM encontrado: "+safeDeviceName(dev));
            socket=dev.createRfcommSocketToServiceRecord(SPP);socket.connect();in=socket.getInputStream();out=socket.getOutputStream();connected=true;simulationMode=false;autoConnectActive=false; clearSimulationResidueForRealVehicle();
            setStatus("Bluetooth conectado — inicializando ELM");setHealth("YELLOW","ELM CONECTADO");
            ui(()->{applyConnectStyle(true);if(dashConn!=null){dashConn.setText("● ELM: CONECTADO");dashConn.setTextColor(BLUE);}});
            send("ATZ",2500);send("ATE0",1000);send("ATL0",1000);send("ATS1",1000);send("ATH1",1000);send("ATAT1",1000);String dp=send("ATDP",1800);lastProtocol=dp;send("ATSP0",2500);append("Inicialização concluída."); if(isPerformanceHistoryEnabled()) openPerformanceHistory();
            maxBoost=-1;lastBaro=-1;lastBoost=-1;lastOilTemp=-1;lastOilLevel="—";recordingMaxBoost=-999;noDataCycles=0;recoveringSession=false;setHealth("YELLOW","AGUARDANDO OBD");ui(()->updateDashboard());
        }catch(SecurityException e){connected=false;append("ERRO CONEXÃO/PERMISSÃO: "+String.valueOf(e.getMessage()));setStatus("Permissão Bluetooth não concedida — aplicativo mantido aberto");closeSocket();}
        catch(IOException e){connected=false;append("ERRO CONEXÃO: "+String.valueOf(e.getMessage()));setStatus("Falha de comunicação — ELM não conectado");closeSocket();}
        catch(Throwable t){connected=false;append("ERRO CONEXÃO: "+t.getClass().getSimpleName()+" — "+String.valueOf(t.getMessage()));setStatus("Falha inesperada — aplicativo mantido aberto");closeSocket();}
        finally{operationRunning=false;connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true); if(!connected){applyConnectStyle(false); if(dashConn!=null){dashConn.setText("● ELM: DESCONECTADO");dashConn.setTextColor(Color.rgb(150,35,35));}} else if(simulationMode){applyConnectStyle(true); if(dashConn!=null){dashConn.setText("● MODO SIMULAÇÃO");dashConn.setTextColor(SIM_CYAN);}}});}
    }
    private String safeDeviceName(BluetoothDevice d){try{String n=d.getName();return n==null?"OBDII":n;}catch(Throwable t){return "OBDII";}}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==20){
            boolean ok=false;
            for(int i=0;i<permissions.length&&i<grantResults.length;i++)if(Manifest.permission.BLUETOOTH_CONNECT.equals(permissions[i])){ok=grantResults[i]==PackageManager.PERMISSION_GRANTED;break;}
            if(ok){setStatus("Permissão concedida — conectando ao ELM");connect();}
            else{setStatus("Permissão Bluetooth não concedida");ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});}
        } else if(requestCode==REQ_GPS_LOCATION){
            boolean ok=false; for(int i=0;i<permissions.length&&i<grantResults.length;i++) if((Manifest.permission.ACCESS_FINE_LOCATION.equals(permissions[i])||Manifest.permission.ACCESS_COARSE_LOCATION.equals(permissions[i])) && grantResults[i]==PackageManager.PERMISSION_GRANTED){ok=true;break;}
            if(ok){ startGpsTracking(); toast("GPS habilitado para o Performance"); } else toast("Permissão de localização necessária para usar a velocidade GPS");
        }
    }

    private void dashboardSnapshot(){
        if(monitoring||operationRunning) return;
        if(simulationMode){ simulationSnapshot(); return; }
        if(out==null||in==null) return;
        try{
            String rpm=send("010C",900); String speed=send("010D",900); String load=send("0104",900); String coolant=send("0105",900); String intake=send("010F",900); String oil=send("015C",900); String fuel=send("012F",900); String volt=send("0142",900); String thr=send("0111",900); String map=send("010B",900); String baro=send("0133",900); String vin=send("0902",1500);
            boolean gotObd = rpm.matches("(?s).*41\\s*0C.*") || fuel.matches("(?s).*41\\s*2F.*") || map.matches("(?s).*41\\s*0B.*");
            if(gotObd){
                noDataCycles=0; ecuResponding=true;
                lastRpm=parseObdNumeric(rpm, "010C"); lastSpeed=parseObdNumeric(speed,"010D"); lastLoad=parseLoad(load); lastCoolant=parseCoolant(coolant); lastIntake=parseIntakeTemp(intake); lastOilTemp=parseOilTemp(oil); lastFuel=parseObdNumeric(fuel,"012F"); lastVolt=parseVoltage(volt); lastThrottle=parseThrottle(thr); lastPedalD=parsePercentPid(send("0149",700),"0149"); lastMap=parseMap(map); lastBaro=parseBaro(baro); lastBoost=calculateBoost(lastMap,lastBaro); if(lastBoost>=0 && lastBoost>maxBoost) maxBoost=lastBoost;
                String pv=parseVin(vin); if(!pv.isEmpty()) lastVin=pv;
                setHealth("GREEN","OBD ATIVO");
            } else {
                noDataCycles++; ecuResponding=false;
                setHealth("YELLOW", "ELM CONECTADO • SEM DADOS");
                append("WATCHDOG OBD: ciclo sem resposta ("+noDataCycles+").");
                if(noDataCycles==2 && !recoveringSession){ recoverObdSession(); }
                else if(noDataCycles>=4 && !recoveringSession){ append("WATCHDOG OBD: sem recuperação após 4 ciclos; reconexão automática será iniciada."); intentionalDisconnect=false; closeSocket(); setHealth("RED","RECONEXÃO AUTOMÁTICA"); scheduleReconnect(); }
            }
            if(gotObd && isPerformanceHistoryEnabled()) writePerformanceHistorySample();
            ui(()->updateDashboard());
        }catch(Exception e){ ecuResponding=false; setHealth("YELLOW","ELM CONECTADO • ERRO RX"); append("WATCHDOG OBD: erro de leitura — "+e.getClass().getSimpleName()); }
    }
    private void recoverObdSession(){
        recoveringSession=true;
        io.execute(()->{ try{ append("WATCHDOG OBD: recuperando sessão no mesmo socket."); send("AT AR",900); send("ATSP0",1200); send("ATAT1",700); append("WATCHDOG OBD: sessão OBD reinicializada."); }catch(Exception e){ append("WATCHDOG OBD: falha na recuperação — "+e.getMessage()); } finally { recoveringSession=false; } });
    }
    private double parseObdNumeric(String r,String pid){ try{String u=r.toUpperCase(Locale.US).replaceAll("[^0-9A-F ]"," ").replaceAll("\\s+"," ").trim(); Matcher m=Pattern.compile("41\\s*"+pid.substring(2)+"\\s*([0-9A-F]{2})(?:\\s*([0-9A-F]{2}))?").matcher(u); if(!m.find())return -1; int a=Integer.parseInt(m.group(1),16); int b=m.group(2)==null?0:Integer.parseInt(m.group(2),16); if(pid.equals("010C"))return (a*256+b)/4.0; if(pid.equals("012F"))return a*100.0/255.0; return a;}catch(Exception e){return -1;} }
    private double parseVoltage(String r){ try{Matcher m=Pattern.compile("41\\s*42\\s*([0-9A-F]{2})\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return (Integer.parseInt(m.group(1),16)*256+Integer.parseInt(m.group(2),16))/1000.0; }catch(Exception ignored){} return -1;}
    private double parseLoad(String r){ return parseObdNumeric(r,"0104")*100.0/255.0; }
    private double parseCoolant(String r){ double v=parseObdNumeric(r,"0105"); return v<0?-1:v-40; }
    // PID 010F = Intake Air Temperature: A - 40 °C. Não reutilizar o parser de 0105 semanticamente.
    private double parseIntakeTemp(String r){ double v=parseObdNumeric(r,"010F"); return v<0?-1:v-40; }

    private double parseOilTemp(String r){ double v=parseObdNumeric(r,"015C"); return v<0?-1:v-40; }
    private double oilColorTemp(double t){ return t; }
    private double oilTextColor(double t){ return t; }
    private void updateDataTelemetry(){ if(dataLiveTelemetry==null||!isRealtimeDataEnabled()){ if(dataLiveTelemetry!=null) dataLiveTelemetry.setText("DADOS EM TEMPO REAL DESATIVADOS"); return; } double speedPrimary=getPreferredSpeedKmh(); String rpm=String.format(Locale.US,"RPM          %6.0f     VELOCIDADE   %6.0f km/h\nCARGA        %6.0f %%     THROTTLE     %6.0f %%\nMAP          %6.0f kPa   BARO         %6.0f kPa\nBOOST        %6.2f bar   BOOST MÁX.   %6.2f bar\nLÍQUIDO      %6.0f °C    ADMISSÃO     %6.0f °C\nÓLEO         %6.0f °C    TENSÃO       %6.2f V\nCOMBUSTÍVEL  %6.0f %%",lastRpm,speedPrimary,lastLoad,lastThrottle,lastMap,lastBaro,lastBoost,maxBoost,lastCoolant,lastIntake,lastOilTemp,lastVolt,lastFuel); dataLiveTelemetry.setText(rpm); }

    private void updateOilUi(){ if(dashOilTemp==null||dashOilLevel==null)return; if(lastOilTemp<0){dashOilTemp.setText("🛢️ — °C");dashOilTemp.setTextColor(Color.rgb(145,181,210));} else {dashOilTemp.setText(String.format(Locale.US,"🛢️ %.0f °C",lastOilTemp)); int c=lastOilTemp<70?Color.rgb(70,170,255):lastOilTemp<120?Color.rgb(242,248,255):lastOilTemp<130?Color.rgb(255,180,60):Color.rgb(255,70,70);dashOilTemp.setTextColor(c);} dashOilLevel.setText("NÍVEL "+lastOilLevel); }
    private double parseThrottle(String r){ try{Matcher m=Pattern.compile("41\\s*11\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return Integer.parseInt(m.group(1),16)*100.0/255.0;}catch(Exception ignored){} return -1;}
    private double parseMap(String r){ try{Matcher m=Pattern.compile("41\\s*0B\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return Integer.parseInt(m.group(1),16);}catch(Exception ignored){} return -1;}
    private double parseBaro(String r){ try{Matcher m=Pattern.compile("41\\s*33\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return Integer.parseInt(m.group(1),16);}catch(Exception ignored){} return -1;}
    private double calculateBoost(double mapKpa,double baroKpa){ if(mapKpa<0||baroKpa<0) return -1; return (mapKpa-baroKpa)/100.0; }
    private int getPerformanceEthanolPct(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getInt(PREF_PERF_ETHANOL,-1); }
    private String getPerformanceEthanolLabel(){ int p=getPerformanceEthanolPct(); return p>=0?String.format(Locale.US,"%d%% etanol (informado manualmente)",p):"não informado"; }
    private void showEthanolDialog(){
        final EditText input=new EditText(this); input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); input.setSingleLine(true); input.setText(getPerformanceEthanolPct()>=0?String.valueOf(getPerformanceEthanolPct()):""); input.setHint("0 a 100"); input.setSelectAllOnFocus(true);
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(20),dp(4),dp(20),0); box.addView(input,new LinearLayout.LayoutParams(-1,dp(52)));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("ETANOL NO TESTE").setMessage("Informe o percentual de etanol indicado pelo veículo. Esse valor é apenas identificação do combustível do teste; não é inferido pela ECU.").setView(box).setNegativeButton("CANCELAR",null).setNeutralButton("LIMPAR",null).setPositiveButton("SALVAR",null).create();
        dialog.setOnShowListener(x->{
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().remove(PREF_PERF_ETHANOL).apply(); if(perfFuel!=null)perfFuel.setText("COMBUSTÍVEL DO TESTE: "+getPerformanceEthanolLabel()); toast("Teor de etanol removido"); dialog.dismiss(); });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{ try{int p=Integer.parseInt(input.getText().toString().trim()); if(p<0||p>100)throw new NumberFormatException(); getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putInt(PREF_PERF_ETHANOL,p).apply(); if(perfFuel!=null)perfFuel.setText("COMBUSTÍVEL DO TESTE: "+getPerformanceEthanolLabel()); toast("Etanol do teste: "+p+"%"); dialog.dismiss();}catch(Exception e){input.setError("Informe um valor entre 0 e 100");}});
        });
        dialog.show();
    }

    private boolean hasLocationPermission(){ return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED; }
    private boolean hasFineLocationPermission(){ return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED; }
    private boolean isGpsSpeedValid(){ long ageMs=gpsLastElapsedNs>0?Math.max(0,(SystemClock.elapsedRealtimeNanos()-gpsLastElapsedNs)/1000000L):Long.MAX_VALUE; return gpsHasFix && lastGpsSpeed>=0 && ageMs<=1200 && gpsAccuracyM<=25f; }
    private double getPreferredSpeedKmh(){ return simulationMode?lastSpeed:(isGpsSpeedValid()?lastGpsSpeed:-1); }
    private void startGpsTracking(){
        if(!hasLocationPermission()){ if(Build.VERSION.SDK_INT>=23) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_GPS_LOCATION); return; }
        try{
            if(locationManager==null) locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
            if(locationManager==null)return;
            if(gpsListener==null) gpsListener=new LocationListener(){ @Override public void onLocationChanged(Location location){ if(location==null)return; if(Build.VERSION.SDK_INT>=26 && location.hasSpeed()){ lastGpsSpeed=Math.max(0,location.getSpeed()*3.6); gpsAccuracyM=location.hasAccuracy()?location.getAccuracy():Float.MAX_VALUE; gpsLastElapsedNs=location.getElapsedRealtimeNanos(); gpsHasFix=true; } } @Override public void onStatusChanged(String provider,int status,Bundle extras){} @Override public void onProviderEnabled(String provider){} @Override public void onProviderDisabled(String provider){} };
            if(hasFineLocationPermission() && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,200L,0f,gpsListener,Looper.getMainLooper());
            if(locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,500L,0f,gpsListener,Looper.getMainLooper());
        }catch(SecurityException e){ append("GPS: permissão não concedida."); }catch(Exception e){ append("GPS: falha ao iniciar — "+e.getClass().getSimpleName()); }
    }
    private void stopGpsTracking(){ try{ if(locationManager!=null && gpsListener!=null) locationManager.removeUpdates(gpsListener); }catch(Exception ignored){} }
    private long crossingNs(double prevSpeed,long prevNs,double curSpeed,long curNs,double target){ if(prevNs<=0||curNs<=prevNs||curSpeed<target||prevSpeed>=target)return -1; if(curSpeed==prevSpeed)return curNs; double f=(target-prevSpeed)/(curSpeed-prevSpeed); f=Math.max(0,Math.min(1,f)); return prevNs+(long)((curNs-prevNs)*f); }

    private void startPerformanceTest(){
        if(performanceRunning){toast("Teste já está em andamento");return;}
        if(!connected||in==null||out==null){toast("Conecte o ELM antes do teste");return;}
        startGpsTracking();
        if(!isGpsSpeedValid()){toast("GPS ainda sem velocidade válida. Aguarde o fix e tente novamente."); ui(()->perfStatus.setText("AGUARDANDO GPS • VELOCIDADE PRINCIPAL = GPS")); return;}
        synchronized(activePerfGraphSamples){activePerfGraphSamples.clear();}
        performanceRunning=true; performanceStop=false; ui(()->{perfStatus.setText("ARMADO • GPS • PARTIDA PRÓXIMA DE 0 km/h"); perfStatus.setTextColor(Color.rgb(255,190,0));});
        io.execute(()->{
            long t0=0,t60=0,t100=0; boolean startedFromStop=false; double prevSpeed=-1,prevRpm=-1; long prevGpsNs=0,firstMovingNs=0,lastSampleNs=0; double bestEnginePower=0,bestEngineTorque=0;
            ArrayList<Double> powerSamples=new ArrayList<>(), torqueSamples=new ArrayList<>();
            double[] speedWin=new double[5]; long[] timeWin=new long[5]; int speedWinCount=0;
            double maxB=0,maxR=0,maxS=0; int samples=0,validDt=0,gearShifts=0; double maxDt=0; final GearShiftEstimator shiftEstimator=new GearShiftEstimator();
            final double[] gridNs=new double[29]; Arrays.fill(gridNs,-1);
            final double massKg=1250.0, crr=0.012, cdA=0.62, rho=1.225, g=9.80665, drivetrainEff=0.88; long lastProcessedGpsNs=0;
            final double stockPowerCv=128.0, stock0100s=10.1;
            try{
                while(performanceRunning && !performanceStop && connected && samples<900){
                    long now=System.nanoTime();
                    double canSpeed=parseObdNumeric(send("010D",220),"010D"); double rpm=parseObdNumeric(send("010C",220),"010C");
                    if(samples%3==0){double pedalRaw=parsePercentPid(send("0149",220),"0149"); if(pedalRaw>=0)lastPedalD=pedalRaw; else {double throttleRaw=parseThrottle(send("0111",220)); if(throttleRaw>=0)lastThrottle=throttleRaw;}}
                    double speed=getGpsSpeedForPerformance();
                    if(rpm>maxR)maxR=rpm; if(speed>maxS)maxS=speed; lastSampleNs=now;
                    double map=parseMap(send("010B",220)); double baro=parseBaro(send("0133",220)); double boost=calculateBoost(map,baro); if(boost>maxB)maxB=boost;
                    gearShifts=shiftEstimator.update(rpm,speed,now);
                    long gpsNs=gpsLastElapsedNs;
                    if(t0>0){ double elapsed=Math.max(0,(now-t0)/1e9); double pedal=getPerformancePedalPct(); synchronized(activePerfGraphSamples){ if(activePerfGraphSamples.isEmpty()) activePerfGraphSamples.add(new PerfGraphSample(0,rpm,0,pedal,boost)); if(activePerfGraphSamples.size()<1200) activePerfGraphSamples.add(new PerfGraphSample(elapsed,rpm,speed,pedal,boost)); } }
                    if(speed>=0 && gpsNs>0 && gpsNs!=lastProcessedGpsNs){
                        lastProcessedGpsNs=gpsNs;
                        if(t0==0 && speed<=2) startedFromStop=true;
                        if(prevGpsNs>0){
                            double dt=(gpsNs-prevGpsNs)/1e9;
                            if(dt>0.03&&dt<2.0){
                                validDt++; if(dt>maxDt)maxDt=dt;
                                if(t0==0 && startedFromStop && speed>prevSpeed && speed>=1){ long c=crossingNs(prevSpeed,prevGpsNs,speed,gpsNs,1); if(c>0){t0=c;firstMovingNs=c;} }
                                if(t0>0){
                                    if(speed>prevSpeed){
                                        for(int target=10;target<=280;target+=10){ int idx=target/10-1; if(gridNs[idx]<0){ long c=crossingNs(prevSpeed,prevGpsNs,speed,gpsNs,target); if(c>0)gridNs[idx]=c; } }
                                        if(t60==0){ long c=crossingNs(prevSpeed,prevGpsNs,speed,gpsNs,60); if(c>0)t60=c; }
                                        if(t100==0){ long c=crossingNs(prevSpeed,prevGpsNs,speed,gpsNs,100); if(c>0)t100=c; }
                                    }
                                    // Potência por dinâmica longitudinal: usa regressão linear em uma janela GPS de 5 pontos
                                    // em vez de derivar dois pontos consecutivos. Isso reduz fortemente picos artificiais do GPS.
                                    if(speedWinCount<5){ speedWin[speedWinCount]=speed; timeWin[speedWinCount]=gpsNs; speedWinCount++; }
                                    else { for(int wi=0;wi<4;wi++){ speedWin[wi]=speedWin[wi+1]; timeWin[wi]=timeWin[wi+1]; } speedWin[4]=speed; timeWin[4]=gpsNs; }
                                    if(speedWinCount>=5){
                                        double sumT=0,sumV=0,sumTT=0,sumTV=0;
                                        for(int wi=0;wi<5;wi++){ double tw=(timeWin[wi]-timeWin[0])/1e9; double vw=speedWin[wi]/3.6; sumT+=tw; sumV+=vw; sumTT+=tw*tw; sumTV+=tw*vw; }
                                        double den=5.0*sumTT-sumT*sumT; double a=den>1e-9?(5.0*sumTV-sumT*sumV)/den:0;
                                        double v=speed/3.6;
                                        if(a>0.0 && a<4.5 && v>5.0){
                                            double force=massKg*a + massKg*g*crr + 0.5*rho*cdA*v*v;
                                            double wheelW=force*v; double engineW=wheelW/drivetrainEff; double engineCv=engineW/735.49875;
                                            if(engineCv>0 && engineCv<220) powerSamples.add(engineCv);
                                            if(rpm>1200 && rpm<7000 && engineW>0){ double tq=engineW*60.0/(2*Math.PI*rpm); if(tq>0 && tq<320) torqueSamples.add(tq); }
                                        }
                                    }
                                }
                            }
                        }
                        prevSpeed=speed; prevRpm=rpm; prevGpsNs=gpsNs;
                    }
                    prevRpm=rpm; samples++; Thread.sleep(70);
                }
            }catch(Exception e){append("PERFORMANCE: erro no teste — "+e.getClass().getSimpleName());}
            // Consolidação robusta: percentil 90 da curva filtrada + referência de 0–100 do Virtus original.
            // A referência serve como regularização, não como limite: evita que um único pico de GPS vire "dinamômetro da Disney".
            if(!powerSamples.isEmpty()){ Collections.sort(powerSamples); bestEnginePower=powerSamples.get((int)Math.round((powerSamples.size()-1)*0.90)); }
            if(!torqueSamples.isEmpty()){ Collections.sort(torqueSamples); bestEngineTorque=torqueSamples.get((int)Math.round((torqueSamples.size()-1)*0.90)); }
            double timeRefPower=0; if(t100>t0 && t0>0){ double sec=(t100-t0)/1e9; if(sec>6 && sec<20) timeRefPower=stockPowerCv*(stock0100s/sec); }
            if(bestEnginePower>0 && timeRefPower>0) bestEnginePower=0.80*bestEnginePower+0.20*timeRefPower;
            performanceRunning=false; final long f0=t0,f60=t60,f100=t100; final double fp=bestEnginePower, ft=bestEngineTorque, fb=maxB, fMaxR=maxR, fMaxS=maxS; final int fSamples=samples,fValidDt=validDt,fShifts=gearShifts; final double fMaxDt=maxDt;
            lastPerf0060=(f60>f0&&f0>0)?(f60-f0)/1e9:-1; lastPerf0100=(f100>f0&&f0>0)?(f100-f0)/1e9:-1; lastPerfPower=fp; lastPerfTorque=ft; lastPerfMaxRpm=maxR; lastPerfMaxSpeed=maxS; lastPerfMaxBoost=fb; lastPerfPullDuration=(f100>f0)?(f100-f0)/1e9:-1; lastPerfDuration=(firstMovingNs>0&&lastSampleNs>firstMovingNs)?(lastSampleNs-firstMovingNs)/1e9:-1; lastPerfGearShifts=fShifts;
            StringBuilder gridText=new StringBuilder(); for(int target=10;target<=280;target+=10){ int idx=target/10-1; if(gridNs[idx]>0&&f0>0){ if(gridText.length()>0)gridText.append('|'); gridText.append(target).append('=').append(String.format(Locale.US,"%.3f",(gridNs[idx]-f0)/1e9)); } } lastPerfSpeedGrid=gridText.toString();
            synchronized(lastPerfGraphSamples){lastPerfGraphSamples.clear(); synchronized(activePerfGraphSamples){lastPerfGraphSamples.addAll(activePerfGraphSamples);} }
            int quality=0; if(f0>0&&startedFromStop)quality+=25; if(f60>f0)quality+=25; if(f100>f0)quality+=25; if(fSamples>=20)quality+=15; if(fValidDt>=10&&fMaxDt<=0.20)quality+=10; lastPerfQuality=quality; final int fQuality=quality; persistPerformancePull(fSamples,new ArrayList<>(lastPerfGraphSamples)); if(isPerformanceHistoryEnabled()) writePerformanceEvent();
            ui(()->{ setPerfText(perf0060,"0–60 km/h",lastPerf0060>0?String.format(Locale.US,"%.2f s",lastPerf0060):"não concluído"); setPerfText(perf0100,"0–100 km/h",lastPerf0100>0?String.format(Locale.US,"%.2f s",lastPerf0100):"não concluído"); if(fp>0){setPerfText(perfPower,"POTÊNCIA ESTIMADA",String.format(Locale.US,"%.0f cv",fp)); setPerfText(perfTorque,"TORQUE ESTIMADO",String.format(Locale.US,"%.0f Nm",ft));} else {setPerfText(perfPower,"POTÊNCIA ESTIMADA","dados insuficientes"); setPerfText(perfTorque,"TORQUE ESTIMADO","dados insuficientes");} setPerfText(perfBoost,"BOOST MÁX.",fb>0?String.format(Locale.US,"%.2f bar",fb):"— bar"); setPerfText(perfQuality,"QUALIDADE AQUISIÇÃO",fQuality+" %"); setPerfText(perfMaxRpm,"RPM MÁX.",fMaxR>0?String.format(Locale.US,"%.0f rpm",fMaxR):"— rpm"); setPerfText(perfMaxSpeed,"VELOCIDADE MÁX. GPS",fMaxS>0?String.format(Locale.US,"%.0f km/h",fMaxS):"— km/h"); setPerfText(perfDuration,"DURAÇÃO",lastPerfPullDuration>0?String.format(Locale.US,"%.2f s",lastPerfPullDuration):"— s"); perfConfidence.setText("GPS COMO FONTE PRINCIPAL • CAN PRESERVADA • 0–280 km/h em memória • TROCAS ESTIMADAS: "+fShifts+" • QUALIDADE: "+fQuality+"% • amostras "+fSamples+" • inclinação da via: NÃO MEDIDA • VIN: "+(lastVin==null||lastVin.isEmpty()?"não identificado":lastVin)); perfStatus.setText("TESTE FINALIZADO • 0–60 / 0–100 + CURVA 0–280 PRESERVADOS"); perfStatus.setTextColor(Color.rgb(0,220,180)); perfFuel.setText("COMBUSTÍVEL DO TESTE: "+getPerformanceEthanolLabel()); if(currentScreen==5&&historicalGraphMode)loadLastPerformanceGraph(); });
        });
    }
    private double getRawPerformancePedalPct(){ return lastPedalD>=0?lastPedalD:lastThrottle; }
    private double getPerformancePedalPct(){
        double raw=getRawPerformancePedalPct(); if(raw<0)return -1;
        android.content.SharedPreferences prefs=getSharedPreferences(PREFS_UI,MODE_PRIVATE);
        double lo=prefs.getFloat(PREF_PEDAL_CAL_MIN,-1f), hi=prefs.getFloat(PREF_PEDAL_CAL_MAX,-1f);
        if(lo>=0 && hi>lo+10) return Math.max(0,Math.min(100,(raw-lo)*100.0/(hi-lo)));
        return Math.max(0,Math.min(100,raw));
    }
    private void showPedalCalibrationDialog(){
        if(performanceRunning){toast("Finalize o teste antes de calibrar");return;}
        final android.content.SharedPreferences prefs=getSharedPreferences(PREFS_UI,MODE_PRIVATE);
        final String[] choices={"Registrar pedal solto como 0%","Registrar pedal totalmente pressionado como 100%","Cancelar calibração salva"};
        new AlertDialog.Builder(this).setTitle("CALIBRAÇÃO DO PEDAL").setMessage("Veículo parado, freio de estacionamento acionado e ninguém dirigindo. Use o pedal solto para 0%; depois, com o veículo imobilizado e em condição segura, registre o fim de curso para 100%. A calibração só altera a escala exibida; não envia comandos ao veículo.\n\nLeitura bruta atual: "+(getRawPerformancePedalPct()>=0?String.format(Locale.US,"%.1f%%",getRawPerformancePedalPct()):"indisponível")+"\nCalibração: "+(prefs.getFloat(PREF_PEDAL_CAL_MIN,-1f)>=0?"ativa":"não configurada"))
            .setItems(choices,(d,which)->{double raw=getRawPerformancePedalPct(); if(which==0){if(raw<0){toast("Sem leitura válida do pedal; calibração não alterada");return;}prefs.edit().putFloat(PREF_PEDAL_CAL_MIN,(float)raw).apply();toast(String.format(Locale.US,"Zero registrado em %.1f%% bruto",raw));}
                else if(which==1){double lo=prefs.getFloat(PREF_PEDAL_CAL_MIN,-1f);if(raw<0||lo<0||raw<=lo+10){toast("Registre primeiro o pedal solto; leitura máxima precisa superar o zero em pelo menos 10 pontos");return;}prefs.edit().putFloat(PREF_PEDAL_CAL_MAX,(float)raw).apply();toast(String.format(Locale.US,"Fim de curso registrado em %.1f%% bruto",raw));}
                else{prefs.edit().remove(PREF_PEDAL_CAL_MIN).remove(PREF_PEDAL_CAL_MAX).apply();toast("Calibração removida; escala bruta restaurada");} if(combinedGraphView!=null&&!historicalGraphMode)updateGraph();}).setNegativeButton("FECHAR",null).show();
    }
    private void loadLastPerformanceGraph(){
        historicalGraphMode=true; if(graphHeaderTitle!=null)graphHeaderTitle.setText("GRÁFICOS DO TESTE • HISTÓRICO DA PUXADA"); combinedRpmValues.clear();combinedSpeedValues.clear();combinedPedalValues.clear();combinedBoostValues.clear();combinedTimeValues.clear();
        ArrayList<PerfGraphSample> samples; synchronized(lastPerfGraphSamples){samples=new ArrayList<>(lastPerfGraphSamples);}
        if(performanceRunning){if(graphHistoryStatus!=null){graphHistoryStatus.setText("TESTE EM ANDAMENTO • finalize a puxada para visualizar o histórico novo");graphHistoryStatus.setTextColor(Color.rgb(255,190,0));}if(combinedGraphView!=null)combinedGraphView.invalidate();return;}
        String source="memória desta sessão";
        if(samples.isEmpty()){
            // Após reiniciar o aplicativo, reconstruir o gráfico do CSV persistente mais recente.
            ArrayList<String> files=listPersistentHistoryFiles();
            for(String name:files){ if(!name.startsWith("VirtusELM_Pull_")||!name.toLowerCase(Locale.US).endsWith(".csv"))continue;
                try(BufferedReader br=new BufferedReader(new InputStreamReader(openPersistentHistoryInput(name),StandardCharsets.UTF_8))){String line;String[] header=null;while((line=br.readLine())!=null){if(line.startsWith("tipo;")){header=line.split(";",-1);continue;}if(header==null||!line.startsWith("PERFORMANCE_SAMPLE;"))continue;String[] f=line.split(";",-1);double t=historyNumber(f,header,"elapsed_s"),r=historyNumber(f,header,"rpm"),v=historyNumber(f,header,"speed_kmh"),ped=historyNumber(f,header,"throttle_pct"),b=historyNumber(f,header,"boost_bar");if(t>=0&&samples.size()<1200)samples.add(new PerfGraphSample(t,r,v,ped,b));} }
                catch(Exception e){append("GRÁFICO HISTÓRICO: falha ao ler "+name+" — "+e.getClass().getSimpleName());}
                if(!samples.isEmpty()){source=name;break;}
            }
            synchronized(lastPerfGraphSamples){lastPerfGraphSamples.clear();lastPerfGraphSamples.addAll(samples);}
        }
        if(samples.isEmpty()){
            if(graphHistoryStatus!=null){graphHistoryStatus.setText("SEM GRÁFICO DE TESTE • execute e finalize uma puxada para registrar as amostras");graphHistoryStatus.setTextColor(Color.rgb(255,190,0));}
            if(combinedGraphView!=null)combinedGraphView.invalidate(); return;
        }
        for(PerfGraphSample s:samples){combinedTimeValues.add((float)s.t);combinedRpmValues.add((float)s.rpm);combinedSpeedValues.add(s.speed<0?Float.NaN:(float)s.speed);combinedPedalValues.add(s.pedal<0?Float.NaN:(float)s.pedal);combinedBoostValues.add(s.boost<0?Float.NaN:(float)s.boost);}
        if(graphHistoryStatus!=null){PerfGraphSample last=samples.get(samples.size()-1);graphHistoryStatus.setText("PUXADA REGISTRADA • "+samples.size()+" amostras • "+String.format(Locale.US,"%.2f s",last.t)+" • "+source);graphHistoryStatus.setTextColor(Color.rgb(0,220,180));}
        if(combinedGraphView!=null)combinedGraphView.invalidate();
    }
    private double getGpsSpeedForPerformance(){ return isGpsSpeedValid()?lastGpsSpeed:-1; }
    private void stopPerformanceTest(){ if(!performanceRunning){toast("Nenhum teste em andamento");return;} performanceStop=true; ui(()->{perfStatus.setText("FINALIZANDO TESTE…");perfStatus.setTextColor(Color.rgb(255,190,0));}); }

    private void setSelectedButton(Button b,boolean active){
        if(b==null)return; int normal=active?Color.rgb(7,72,112):Color.rgb(7,38,70); int stroke=active?Color.rgb(0,220,255):Color.rgb(25,125,195); int text=active?Color.rgb(255,255,255):Color.rgb(235,248,255);
        GradientDrawable g=new GradientDrawable(); g.setColor(normal); g.setCornerRadius(dp(24)); g.setStroke(dp(active?2:1),stroke); b.setBackground(g); b.setTextColor(text);
    }
    private void updateGraphButtonSelection(){ for(Button b:graphButtons){String label=b.getText().toString(); setSelectedButton(b,label.equals(graphMetric));} }
    private void updateGraphScaleInfo(){ if(graphScreen==null||graphView==null)return; TextView r=(TextView)graphScreen.findViewWithTag("graphRange"); if(r!=null)r.setText("ESCALA FIXA: "+graphView.range()); }

    private void updateGraph(){ if(historicalGraphMode)return; double speedPrimary=getPreferredSpeedKmh(); if(graphView!=null){ float v=-1; if("RPM".equals(graphMetric))v=(float)lastRpm; else if("BOOST".equals(graphMetric))v=(float)displayPressureBar(lastBoost); else if("THROTTLE".equals(graphMetric))v=(float)getPerformancePedalPct(); else if("VELOCIDADE".equals(graphMetric))v=(float)displaySpeed(speedPrimary); if(v>=0)graphView.add(v); } if(combinedGraphView!=null && !simulationMode){ combinedGraphView.add((float)lastRpm,(float)displaySpeed(speedPrimary),(float)getPerformancePedalPct(),(float)displayPressureBar(lastBoost)); } updateGraphScaleInfo(); }
    private void updateDashboard(){ if(!connected) setHealth("RED","DESCONECTADO"); else if(simulationMode) setHealth("SIM","MODO SIMULAÇÃO"); else if(monitoring) setHealth("YELLOW","CAN CAPTURANDO • OBD PAUSADO"); else if(ecuResponding) setHealth("GREEN","OBD ATIVO"); else setHealth("YELLOW","ELM CONECTADO • SEM DADOS"); boolean ownVehicle = PROFILE_VIN.equalsIgnoreCase(lastVin == null ? "" : lastVin.trim()); String vehicleLabel = ownVehicle ? "Volkswagen Virtus 1.0 TSI • Stage 2" : (lastVin == null || lastVin.isEmpty() || "—".equals(lastVin) ? "VEÍCULO NÃO IDENTIFICADO" : "VEÍCULO IDENTIFICADO"); dashVin.setText("VIN: "+(lastVin==null||lastVin.isEmpty()?"—":lastVin)+"\n"+vehicleLabel); TextView profile=(TextView)dashVin.getRootView().findViewWithTag("vehicleProfile"); if(profile!=null) profile.setText(ownVehicle ? "VIRTUS 1.0 TSI • STAGE 2" : ""); String ig=simulationMode?("SIMULAÇÃO • DADOS HISTÓRICOS"):ecuResponding?(lastRpm>0?"IG: ON • RUN":"IG: ON • ECU") : "IG: —"; dashIgnition.setText(ig); dashRpm.setText(lastRpm>=0?String.format(Locale.US,"%.0f rpm",lastRpm):"— rpm"); double speedPrimary=getPreferredSpeedKmh(); setMetricText(dashSpeed,"VELOCIDADE",speedPrimary>=0?String.format(Locale.US,"%.0f",displaySpeed(speedPrimary)):"—",speedUnitLabel()); setMetricText(dashBoost,"BOOST",lastMap>=0&&lastBaro>=0?String.format(Locale.US,"%.2f",displayPressureBar(lastBoost)):"—",pressureUnitLabel()); if(dashBoost!=null){ dashBoost.append("\nMAX "+(maxBoost>=0?String.format(Locale.US,"%.2f",displayPressureBar(maxBoost)):"—")+" "+pressureUnitLabel()); } setMetricText(dashLoad,"CARGA MOTOR",lastLoad>=0?String.format(Locale.US,"%.0f",lastLoad):"—","%"); setMetricText(dashFuel,"COMBUSTÍVEL",lastFuel>=0?String.format(Locale.US,"%.0f",lastFuel):"—","%"); setMetricText(dashVolt,"TENSÃO",lastVolt>=0?String.format(Locale.US,"%.2f",lastVolt):"—","V"); setMetricText(dashMap,"MAP",lastMap>=0?String.format(Locale.US,"%.0f",getPressureUnit().equals("kPa")?lastMap:displayPressureBar(lastMap/100.0)):"—",pressureUnitLabel()); setMetricText(dashBaro,"BARO",lastBaro>=0?String.format(Locale.US,"%.0f",getPressureUnit().equals("kPa")?lastBaro:displayPressureBar(lastBaro/100.0)):"—",pressureUnitLabel()); setMetricText(dashThrottle,"THROTTLE",lastThrottle>=0?String.format(Locale.US,"%.0f",lastThrottle):"—","%"); dashCoolant.setText(lastCoolant>=0?String.format(Locale.US,"TEMP. LÍQUIDO\n%.0f °C",lastCoolant):"TEMP. LÍQUIDO\n— °C"); dashIntake.setText(lastIntake>=0?String.format(Locale.US,"TEMP. ADMISSÃO\n%.0f °C",lastIntake):"TEMP. ADMISSÃO\n— °C"); if(isRealtimeDataEnabled()){ updateDataTelemetry(); updateOilUi(); rpmBar.setRpm(lastRpm); updateGraph(); } dashCan.setText(simulationMode?"MODO\nSIMULAÇÃO\nCAN OFF":String.format(Locale.US,"PROTOCOLO\nCAN 11/500\n%s",monitoring?"LIVE":"PRONTO")); if(dashConn!=null&&simulationMode){dashConn.setText("● MODO SIMULAÇÃO");dashConn.setTextColor(SIM_CYAN);} }
    private void startDashboardPolling(){
        dashboardExec.scheduleAtFixedRate(()->{
            if(connected&&!monitoring&&!operationRunning){
                // Toda leitura Bluetooth passa pelo executor único de I/O.
                // Isso elimina concorrência entre dashboard, gravação, diagnóstico e CAN Monitor.
                io.execute(()->{
                    if(!connected||monitoring||operationRunning)return;
                    if(recordingActive) recordingSnapshot();
                    else { recordingTick++; if(recordingTick%3==0) dashboardSnapshot(); else ui(()->updateDashboard()); }
                });
            }else{
                ui(()->{ if(!connected){ applyConnectStyle(false); if(dashConn!=null){dashConn.setText("● ELM: DESCONECTADO"); dashConn.setTextColor(Color.rgb(150,35,35));} setHealth("RED","DESCONECTADO"); } updateDashboard(); });
            }
        },0,1,TimeUnit.SECONDS);
    }

    private void startRecording(){
        if(recordingActive){ toast("Gravação já está ativa"); return; }
        if(!connected){ toast("Conecte o ELM antes de gravar"); return; }
        try{
            File dir=new File(getFilesDir(),"recordings"); if(!dir.exists()&&!dir.mkdirs()) throw new IOException("Não foi possível criar a pasta de gravações");
            String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
            recordingFile=new File(dir,"VirtusELM_"+stamp+".csv");
            recordingWriter=new BufferedWriter(new FileWriter(recordingFile,false));
            recordingWriter.write("timestamp_ms;hora;rpm;speed_kmh;gps_speed_kmh;speed_source;map_kpa;baro_kpa;boost_bar;boost_max_bar;throttle_pct;load_pct;coolant_c;intake_c;oil_temp_c;oil_level;fuel_pct;voltage_v;vin\n"); recordingWriter.flush();
            recordingStartMs=System.currentTimeMillis(); recordingSamples=0; recordingMaxBoost=-999; recordingActive=true; recordingTick=0;
            append("=== INÍCIO DA GRAVAÇÃO DE TELEMETRIA ==="); append("CSV: "+recordingFile.getAbsolutePath());
            startRecordingKeepAlive(); setStatus("GRAVANDO TELEMETRIA • MAP/BARO/BOOST/RPM"); setHealth("GREEN","GRAVAÇÃO ATIVA"); updateRecordingUi();
        }catch(Exception e){ append("ERRO AO INICIAR GRAVAÇÃO: "+e.getMessage()); closeRecordingWriter(); toast("Não foi possível iniciar a gravação"); }
    }
    private void stopRecording(){
        if(!recordingActive){ toast("Nenhuma gravação ativa"); return; }
        recordingActive=false; closeRecordingWriter(); stopRecordingKeepAlive();
        append("=== FIM DA GRAVAÇÃO DE TELEMETRIA ==="); append("AMOSTRAS: "+recordingSamples+" | BOOST MÁX.: "+(recordingMaxBoost>-900?String.format(Locale.US,"%.2f bar",recordingMaxBoost):"não disponível"));
        setStatus(connected?"Gravação finalizada — dados preservados":"Gravação finalizada — ELM desconectado"); updateRecordingUi(); showRecordingSummary();
    }
    private void closeRecordingWriter(){ try{if(recordingWriter!=null){recordingWriter.flush();recordingWriter.close();}}catch(Exception ignored){} recordingWriter=null; }
    private void recordingSnapshot(){
        if(!recordingActive||monitoring||(!simulationMode&&(out==null||in==null))) return;
        try{
            String rpm=send("010C",700); String map=send("010B",700); String baro=send("0133",700);
            lastRpm=parseObdNumeric(rpm,"010C"); lastMap=parseMap(map); lastBaro=parseBaro(baro); lastBoost=calculateBoost(lastMap,lastBaro);
            if(lastBoost>=0){ if(lastBoost>recordingMaxBoost) recordingMaxBoost=lastBoost; if(lastBoost>maxBoost) maxBoost=lastBoost; }
            // Dados secundários a cada 3 segundos para manter alta frequência no conjunto MAP/BARO/BOOST/RPM.
            if(recordingSamples%3==0){
                lastSpeed=parseObdNumeric(send("010D",700),"010D"); lastThrottle=parseThrottle(send("0111",700)); lastPedalD=parsePercentPid(send("0149",700),"0149"); lastLoad=parseLoad(send("0104",700)); lastCoolant=parseCoolant(send("0105",700)); lastIntake=parseIntakeTemp(send("010F",700)); lastOilTemp=parseOilTemp(send("015C",700)); lastFuel=parseObdNumeric(send("012F",700),"012F"); lastVolt=parseVoltage(send("0142",700));
                String pv=parseVin(send("0902",1200)); if(!pv.isEmpty()) lastVin=pv;
            }
            ecuResponding=true; noDataCycles=0;
            String now=new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date());
            if(recordingWriter!=null){ recordingWriter.write(System.currentTimeMillis()+";"+now+";"+fmt(lastRpm)+";"+fmt(lastSpeed)+";"+fmt(lastGpsSpeed)+";"+(isGpsSpeedValid()?"GPS":"CAN")+";"+fmt(lastMap)+";"+fmt(lastBaro)+";"+fmt(lastBoost)+";"+fmt(recordingMaxBoost)+";"+fmt(lastThrottle)+";"+fmt(lastLoad)+";"+fmt(lastCoolant)+";"+fmt(lastIntake)+";"+fmt(lastOilTemp)+";"+lastOilLevel+";"+fmt(lastFuel)+";"+fmt(lastVolt)+";"+(lastVin==null?"":lastVin)+"\n"); recordingWriter.flush(); }
            recordingSamples++;
            ui(()->{updateDashboard();updateRecordingUi();});
        }catch(Exception e){ append("GRAVAÇÃO: erro de amostragem — "+e.getClass().getSimpleName()); }
    }
    private String fmt(double v){ return v<0?"":String.format(Locale.US,"%.3f",v); }
    private void updateRecordingUi(){ ui(()->{
        if(dataScreen==null)return;
        View rootView=dataScreen;
        TextView f=rootView.findViewWithTag("recordFile");
        if(f!=null){
            if(recordingActive){
                String file=recordingFile==null?"—":recordingFile.getName();
                f.setText("GRAVANDO • "+recordingSamples+" amostras • "+file);
            }else if(recordingFile!=null){
                f.setText("FINALIZADA • "+recordingSamples+" amostras • "+recordingFile.getName());
            }else{
                f.setText("STATUS: aguardando gravação");
            }
        }
    }); }
    private void showRecordingSummary(){ String file=recordingFile==null?"—":recordingFile.getName(); String max=recordingMaxBoost>-900?String.format(Locale.US,"%.2f bar",recordingMaxBoost):"não registrado"; String estado=recordingSamples>0?"GRAVAÇÃO VÁLIDA — amostras preservadas":"GRAVAÇÃO SEM AMOSTRAS — verificar ciclo de captura"; showResult("GRAVAÇÃO DE TELEMETRIA\n\nSTATUS: "+estado+"\nAMOSTRAS: "+recordingSamples+"\nBOOST MÁX.: "+max+"\nARQUIVO: "+file+"\n\nMAP, BARO, BOOST e RPM são registrados no CSV."); }
    private void copyCsv(){ if(recordingFile==null||!recordingFile.exists()){toast("Nenhuma gravação disponível");return;} try{StringBuilder b=new StringBuilder(); BufferedReader r=new BufferedReader(new FileReader(recordingFile)); String line; while((line=r.readLine())!=null)b.append(line).append('\n'); r.close(); ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("VIRTUS ELM CSV",b.toString())); toast("CSV copiado para a área de transferência");}catch(Exception e){toast("Erro ao copiar CSV");} }
    private void startRecordingKeepAlive(){
        // Em MODO SIMULAÇÃO não existe dispositivo Bluetooth conectado.
        // O serviço foreground do tipo connectedDevice pode ser rejeitado pelo Android
        // e derrubar o processo. A gravação simulada não precisa desse serviço.
        if(simulationMode) return;
        try{ Intent i=new Intent(this,RecordingKeepAliveService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); }catch(Exception e){ append("AVISO: serviço de gravação não iniciado — "+e.getClass().getSimpleName()); }
    }
    private void stopRecordingKeepAlive(){ try{ stopService(new Intent(this,RecordingKeepAliveService.class)); }catch(Exception ignored){} }

    // ===== V12 — SIMULAÇÃO INTEGRADA PRESERVADA =====
    private void startSimulationMode(String reason){
        simulationSamples.clear(); simulationIndex=0; simulationStartMs=System.currentTimeMillis();
        loadSimulationHistory();
        if(simulationSamples.isEmpty()){
            simulationSource="perfil interno baseado em telemetria histórica";
            buildFallbackSimulation();
        }
        simulationMode=true; connected=true; ecuResponding=true; lastVin=PROFILE_VIN; noDataCycles=0; maxBoost=-1; if(isPerformanceHistoryEnabled()) openPerformanceHistory();
        setHealth("SIM","MODO SIMULAÇÃO");
        setStatus("ELM não disponível — modo simulação ativo");
        ui(()->{ applyConnectStyle(true); if(dashConn!=null){dashConn.setText("● MODO SIMULAÇÃO");dashConn.setTextColor(SIM_CYAN);} updateDashboard(); });
        append("=== MODO SIMULAÇÃO ATIVADO ===");
        append("Motivo: "+reason);
        append("Fonte: "+simulationSource);
        append("Nenhum comando foi enviado ao veículo. CAN permanece bloqueado no modo simulação.");
        simulationSnapshot();
    }
    private void loadSimulationHistory(){
        if(Build.VERSION.SDK_INT<29) return;
        Cursor c=null; try{
            String[] proj={MediaStore.Downloads._ID,MediaStore.Downloads.DISPLAY_NAME,MediaStore.Downloads.RELATIVE_PATH,MediaStore.Downloads.DATE_ADDED};
            c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,proj,null,null,MediaStore.Downloads.DATE_ADDED+" DESC");
            Uri chosen=null; String chosenName=null;
            if(c!=null){ while(c.moveToNext()){
                String path=c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.RELATIVE_PATH)); String name=c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME));
                if(path!=null&&path.contains("Download/VirtusELM/logs/")&&name!=null&&name.toLowerCase(Locale.US).endsWith(".csv")){ long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID)); chosen=ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,id); chosenName=name; break; }
            }}
            if(chosen==null) return;
            InputStream is=getContentResolver().openInputStream(chosen); if(is==null)return;
            BufferedReader br=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8)); String line; boolean header=true;
            while((line=br.readLine())!=null){ if(header){header=false;continue;} String[] p=line.split(";",-1); if(p.length<18)continue; try{
                    boolean newHistory=p.length>=27;
                    double rpm=num(p,3), speed=newHistory?num(p,5):num(p,4), map=newHistory?num(p,7):num(p,5), baro=newHistory?num(p,8):num(p,6), boost=newHistory?num(p,9):num(p,7), thr=newHistory?num(p,11):num(p,9), load=newHistory?num(p,12):num(p,10), cool=newHistory?num(p,13):num(p,11), intake=newHistory?num(p,14):num(p,12), fuel=newHistory?num(p,17):num(p,14), volt=newHistory?num(p,18):num(p,15), oil=newHistory?num(p,15):num(p,13);
                    if(rpm<0||speed<0||map<0||baro<0)continue; if(boost<0)boost=(map-baro)/100.0;
                    simulationSamples.add(new SimSample(rpm,speed,map,baro,thr<0?10:thr,load<0?15:load,cool<0?87:cool,intake<0?35:intake,fuel<0?55:fuel,volt<0?13.4:volt,oil<0?100:oil));
                    while(simulationSamples.size()>180)simulationSamples.remove(0);
                }catch(Exception ignored){} }
            br.close(); if(!simulationSamples.isEmpty()) simulationSource="último histórico persistente: "+chosenName;
        }catch(Exception e){ append("SIMULAÇÃO: não foi possível ler histórico público — usando perfil interno."); }
        finally{try{if(c!=null)c.close();}catch(Exception ignored){}}
    }
    private double num(String[] p,int i){ if(i<0||i>=p.length||p[i]==null||p[i].trim().isEmpty())return -1; return Double.parseDouble(p[i].trim().replace(',','.')); }
    private void buildFallbackSimulation(){
        simulationSamples.clear();
        double[] speeds={0,0,10,25,35,46,57,64,68,68,66,57,44,32,16,0};
        double[] rpms={890,1000,1814,2288,1720,1615,1490,1323,1792,1775,1750,1470,1550,1250,960,890};
        double[] maps={30,36,129,151,80,37,69,80,29,32,41,27,28,27,35,30};
        for(int i=0;i<speeds.length;i++){ double baro=92; double boost=Math.max(0,(maps[i]-baro)/100.0); double thr=speeds[i]>5?Math.min(88,12+speeds[i]*1.1):14; double load=Math.min(45,8+thr*0.65); simulationSamples.add(new SimSample(rpms[i],speeds[i],maps[i],baro,thr,load,87,35,55,13.4,100)); }
    }
    private SimSample currentSimulationSample(){ if(simulationSamples.isEmpty())buildFallbackSimulation(); long elapsed=(System.currentTimeMillis()-simulationStartMs)/250L; int idx=(int)(elapsed%simulationSamples.size()); simulationIndex=idx; return simulationSamples.get(idx); }
    private void simulationSnapshot(){
        if(!simulationMode)return; SimSample s=currentSimulationSample(); lastRpm=s.rpm; lastSpeed=s.speed; lastMap=s.map; lastBaro=s.baro; lastBoost=(s.map-s.baro)/100.0; if(lastBoost>maxBoost)maxBoost=lastBoost; lastThrottle=s.throttle; lastLoad=s.load; lastCoolant=s.coolant; lastIntake=s.intake; lastFuel=s.fuel; lastVolt=s.volt; lastOilTemp=s.oil; lastOilLevel="SIMULADO"; ecuResponding=true;
        if(isPerformanceHistoryEnabled()&&historyWriter!=null)writePerformanceHistorySample();
        ui(()->updateDashboard());
    }
    private String simulateResponse(String cmd){
        String u=cmd==null?"":cmd.replaceAll("\\s+","").toUpperCase(Locale.US); SimSample s=currentSimulationSample();
        if(u.startsWith("ATSH ")||u.equals("ATCFC1")||u.equals("ATCAF1")||u.equals("ATZ")||u.equals("ATE0")||u.equals("ATL0")||u.equals("ATS0")||u.equals("ATS1")||u.equals("ATH0")||u.equals("ATH1")||u.equals("ATAT1")||u.equals("ATAT0")||u.equals("ATSP0")||u.equals("ATSP6")||u.equals("ATD1")||u.equals("ATAL"))return "OK";
        if(u.equals("ATI"))return "ELM327 v1.5 SIMULATION";
        if(u.equals("ATDP")||u.equals("ATDPN"))return "ISO 15765-4 (CAN 11/500)";
        if(u.equals("ATCRA"))return "OK";
        if(u.equals("0100"))return "41 00 BE 3E B8 13";
        if(u.equals("0120"))return "41 20 80 00 00 01";
        if(u.equals("0140"))return "41 40 7A 28 00 01";
        if(u.equals("0160"))return "41 60 00 00 00 00";
        if(u.equals("010C")){int v=(int)Math.max(0,s.rpm*4);return String.format(Locale.US,"41 0C %02X %02X",(v>>8)&255,v&255);}
        if(u.equals("010D"))return String.format(Locale.US,"41 0D %02X",Math.max(0,Math.min(255,(int)s.speed)));
        if(u.equals("0104"))return String.format(Locale.US,"41 04 %02X",Math.max(0,Math.min(255,(int)(s.load*255/100))));
        if(u.equals("0105"))return String.format(Locale.US,"41 05 %02X",Math.max(0,Math.min(255,(int)(s.coolant+40))));
        if(u.equals("010F"))return String.format(Locale.US,"41 0F %02X",Math.max(0,Math.min(255,(int)(s.intake+40))));
        if(u.equals("010B"))return String.format(Locale.US,"41 0B %02X",Math.max(0,Math.min(255,(int)s.map)));
        if(u.equals("0133"))return String.format(Locale.US,"41 33 %02X",Math.max(0,Math.min(255,(int)s.baro)));
        if(u.equals("0111"))return String.format(Locale.US,"41 11 %02X",Math.max(0,Math.min(255,(int)(s.throttle*255/100))));
        if(u.equals("0149"))return String.format(Locale.US,"41 49 %02X",Math.max(0,Math.min(255,(int)(s.throttle*255/100))));
        if(u.equals("014A"))return String.format(Locale.US,"41 4A %02X",Math.max(0,Math.min(255,(int)(s.throttle*255/100))));
        if(u.equals("014B"))return String.format(Locale.US,"41 4B %02X",Math.max(0,Math.min(255,(int)(s.throttle*255/100))));
        if(u.equals("0145")||u.equals("0147")||u.equals("0148")||u.equals("014C"))return String.format(Locale.US,"41 %s %02X",u.substring(2),Math.max(0,Math.min(255,(int)(s.throttle*255/100))));
        if(u.equals("012F"))return String.format(Locale.US,"41 2F %02X",Math.max(0,Math.min(255,(int)(s.fuel*255/100))));
        if(u.equals("0142")){int v=(int)(s.volt*1000);return String.format(Locale.US,"41 42 %02X %02X",(v>>8)&255,v&255);}
        if(u.equals("015C"))return String.format(Locale.US,"41 5C %02X",Math.max(0,Math.min(255,(int)(s.oil+40))));
        if(u.equals("0902"))return "49 02 01 00 00 00 00 39 42 57 44 48 36 42 5A 33 52 50 30 30 32 32 30 31";
        if(u.equals("22F190"))return "62 F1 90 39 42 57 44 48 36 42 5A 33 52 50 30 30 32 32 30 31";
        if(u.equals("03")){ if(simulatedDtcCodes.isEmpty()) return "43 00 00 00 00 00 00"; StringBuilder d=new StringBuilder("43 "); int n=0; for(String code:simulatedDtcCodes){ String hx=encodeDtc(code); if(hx.length()==4){d.append(hx.substring(0,2)).append(" ").append(hx.substring(2)).append(" "); n++;} if(n>=3)break;} while(n<3){d.append("00 00 ");n++;} return d.toString().trim(); }
        if(u.equals("04")){ simulatedDtcCodes.clear(); return "44"; }
        if(u.equals("07"))return "47 00";
        if(u.equals("0A"))return "4A 00";
        if(u.equals("0101"))return "41 01 00 00 00 00";
        if(u.equals("0102"))return "41 02 00 00";
        if(u.equals("0200")||u.equals("0201"))return "42 00 00 00 00";
        return "NO DATA";
    }

    private String send(String cmd,long timeout){
        if(simulationMode){ return simulateResponse(cmd); }
        if(out==null||in==null){append("ERRO: ELM não conectado para "+cmd);return "";}
        try{out.write((cmd+"\r").getBytes(StandardCharsets.US_ASCII));out.flush(); append(">> "+cmd); return readUntilPrompt(timeout);}catch(Exception e){append("ERRO TX/RX: "+e); if(!intentionalDisconnect && !monitoring) safeUnexpectedDisconnect(e); return "";}
    }
    private String readUntilPrompt(long timeout){ long end=System.currentTimeMillis()+timeout; ByteArrayOutputStream b=new ByteArrayOutputStream(); try{while(System.currentTimeMillis()<end){if(in.available()>0){int x=in.read(); if(x<0)break; b.write(x); if(x=='>')break;} else Thread.sleep(4);}}catch(Exception e){append("ERRO LEITURA: "+e);} String raw=new String(b.toByteArray(),StandardCharsets.US_ASCII); String n=normalize(raw); if(!n.isEmpty())append("<< "+n); return n; }
    private String normalize(String s){ return s.replace("\u0000","").replace("\r","\n").replace("\n\n","\n").replaceAll("\n+","\n").trim(); }
    private void runOp(String name, Runnable op){ if(operationRunning){setStatus("Já existe uma operação em andamento");return;} io.execute(()->{operationRunning=true; try{ if(!simulationMode&&(out==null||in==null)) throw new IOException("ELM não conectado"); append("=== "+name+(simulationMode?" • SIMULAÇÃO":"")+" ==="); op.run(); append("=== FIM: "+name+" ==="); }catch(Exception e){append("ERRO "+name+": "+e);setStatus("Erro na operação — aplicativo mantido aberto");}finally{operationRunning=false;}}); }
    private void showResult(String s){ui(()->{ String text="RESULTADO:\n"+(s==null||s.trim().isEmpty()?"Nenhum dado retornado.":s); if(result!=null) result.setText(text); if(resultHome!=null) resultHome.setText(text); if(diagnosticResult!=null) diagnosticResult.setText(text); if(diagnosticScroll!=null) diagnosticScroll.post(()->diagnosticScroll.fullScroll(View.FOCUS_DOWN)); if(logScroll!=null && currentScreen==1) logScroll.post(()->logScroll.fullScroll(View.FOCUS_DOWN)); });}

    private String firstPayload(String resp){ String[] ls=resp.split("\\n"); for(String l:ls){String u=l.trim().toUpperCase(Locale.US); if(u.matches("^(7E[0-9A-F]|[0-9A-F]{3,8})\\s+41\\s+.*")||u.matches("^41\\s+.*")||u.matches("^43\\s+.*")||u.matches("^47\\s+.*")||u.matches("^49\\s+.*")) return u;} return resp.trim(); }
    private void queryPid(String pid,String label){ String r=send(pid,1500); String[] lines=r.split("\\n"); StringBuilder outv=new StringBuilder(); for(String l:lines){String t=l.trim(); if(t.isEmpty())continue; if(t.matches("(?i).*(41|43|47|49)\\s+.*")){outv.append(t).append("\\n");}} if(outv.length()>0) append(label+": "+outv.toString().trim()); else append(label+": sem resposta estruturada"); }

    private void quickDiagnostic(){ runOp("DIAGNÓSTICO RÁPIDO — SOMENTE LEITURA",()->{String p=send("0100",1800); StringBuilder r=new StringBuilder(); r.append("0100 / PIDs 01–20:\n").append(p).append("\n"); queryPid("010C","RPM"); queryPid("010D","VELOCIDADE"); queryPid("0105","TEMPERATURA ARREFECIMENTO"); String d=send("03",1800); append("DTC: "+d); r.append("DTC:\n").append(d); showResult(r.toString());}); }
    private void automaticDiagnostic(){ runOp("DIAGNÓSTICO COMPLETO — SOMENTE LEITURA",()->{StringBuilder r=new StringBuilder(); String[] pids={"0100","0120","0140","0160","0104","0105","010B","010C","010D","010F","015C","0111","011F","012F","0133","0142","03","07","0A","0902","0101"}; for(String p:pids){String x=send(p,p.equals("0902")?2500:1600); append(p+": "+x); r.append(p).append(" -> ").append(x).append("\n");} r.append("\nG266/NÍVEL DO ÓLEO: leitura VAG não padronizada via OBD-II; nenhum valor é inventado.\n"); showResult(r.toString());}); }
    private void vehicleData(){ runOp("LER DADOS DO VEÍCULO",()->{StringBuilder r=new StringBuilder(); String[] pids={"0100","0120","0140","0160","0104","0105","010B","010C","010D","010F","015C","0111","011F","012F","0133","0142"}; for(String p:pids){String x=send(p,1600); append(p+": "+x); r.append(p).append(" -> ").append(x).append("\n");} showResult(r.toString());}); }
    private void readDtc(){ runOp("LER CÓDIGOS DE FALHA — DTC",()->{ String r=send("03",2000); ArrayList<String> codes=parseDtcCodes(r); StringBuilder outv=new StringBuilder(); outv.append(simulationMode?"SIMULAÇÃO — ":"REAL — ").append("MODE 03\nRAW: ").append(r).append("\n\n"); if(codes.isEmpty()){ outv.append(formatDtcSummary(r,"43","MODE 03")); } else { outv.append("CÓDIGOS ENCONTRADOS: ").append(codes.size()).append("\n"); for(String c:codes)outv.append("• ").append(c).append("\n"); } updateDtcPanel(codes,r); append("DTC: "+(codes.isEmpty()?"nenhum código decodificado":codes.toString())); showResult(outv.toString()); }); }
    private void updateDtcPanel(final ArrayList<String> codes,final String raw){ ui(()->{ if(dtcStatusView==null)return; lastDtcCodes.clear(); lastDtcCodes.addAll(codes); selectedDtcCodes.retainAll(lastDtcCodes); String mode=simulationMode?"SIMULAÇÃO":"VEÍCULO / ELM"; dtcStatusView.setText("STATUS: "+mode+" • "+(codes.isEmpty()?"NENHUMA FALHA DECODIFICADA":codes.size()+" FALHA(S) ENCONTRADA(S)")); dtcStatusView.setTextColor(codes.isEmpty()?Color.rgb(255,190,0):Color.rgb(255,120,80)); dtcCodesView.setText(codes.isEmpty()?"CÓDIGOS: nenhum DTC decodificado":(dtcSelectionMode?"MARQUE OS DTCs PARA SELECIONAR:":"CÓDIGOS RECONHECIDOS:")); renderDtcList(codes); dtcRawView.setText("RAW: "+(raw==null||raw.isEmpty()?"—":raw)); }); }
    private void renderDtcList(final ArrayList<String> codes){ if(dtcListContainer==null)return; dtcListContainer.removeAllViews(); if(codes==null||codes.isEmpty()){ TextView empty=tv("Nenhum DTC",11); empty.setTextColor(NAV_INACTIVE); dtcListContainer.addView(empty); return; } for(final String code:codes){ if(dtcSelectionMode){ CheckBox cb=new CheckBox(this); cb.setText(code); cb.setTextColor(NAV_INACTIVE); cb.setTextSize(12); cb.setSingleLine(true); cb.setChecked(selectedDtcCodes.contains(code)); cb.setButtonTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{Color.rgb(0,200,255),Color.rgb(170,200,225)})); cb.setOnCheckedChangeListener((v,checked)->{if(checked)selectedDtcCodes.add(code);else selectedDtcCodes.remove(code); updateDtcSelectionButton();}); dtcListContainer.addView(cb,new LinearLayout.LayoutParams(-1,dp(40))); } else { TextView item=tv("• "+code,12); item.setTextColor(NAV_INACTIVE); item.setTypeface(null,android.graphics.Typeface.BOLD); item.setPadding(dp(8),dp(5),dp(8),dp(5)); bindClick(item,()->showDtcDetails(code)); dtcListContainer.addView(item,new LinearLayout.LayoutParams(-1,dp(38))); } } }
    private void updateDtcSelectionButton(){ if(selectDtcButton==null)return; selectDtcButton.setText(dtcSelectionMode?(selectedDtcCodes.isEmpty()?"CANCELAR SELEÇÃO":"APAGAR SELECIONADAS") : "SELECIONAR DTCs"); }
    private void toggleDtcSelectionMode(){ if(lastDtcCodes.isEmpty()){toast("Nenhum DTC disponível para selecionar");return;} if(!dtcSelectionMode){dtcSelectionMode=true;selectedDtcCodes.clear();renderDtcList(new ArrayList<>(lastDtcCodes));updateDtcSelectionButton();toast("Selecione um ou mais DTCs");}else if(selectedDtcCodes.isEmpty()){dtcSelectionMode=false;renderDtcList(new ArrayList<>(lastDtcCodes));updateDtcSelectionButton();toast("Seleção cancelada");}else{clearSelectedDtc();} }
    private void showDtcDetails(String code){ String desc=dtcDescription(code); new AlertDialog.Builder(this).setTitle(code).setMessage(desc).setPositiveButton("OK",null).show(); }
    private String dtcDescription(String code){ String d=dtcLibraryDescriptions.get(code==null?"":code.toUpperCase(Locale.US)); return d==null?"Código reconhecido; descrição detalhada não disponível na biblioteca DTC atual.":d; }
    private void initializeDtcLibrary(){ io.execute(()->{ try{ loadBundledDtcLibrary(); loadExternalDtcLibrary(); ui(()->updateDtcLibraryStatus()); }catch(Exception e){ ui(()->updateDtcLibraryStatus()); } }); }
    private boolean loadBundledDtcLibrary(){ try{ InputStream is=getAssets().open("dtc_vag.json"); String json=readAll(is); is.close(); parseDtcLibrary(json); return !dtcLibraryDescriptions.isEmpty(); }catch(Exception e){ return false; } }
    private void loadExternalDtcLibrary(){ try{ String json=null; if(Build.VERSION.SDK_INT>=29){ Cursor c=null; try{ String[] pr={MediaStore.Downloads._ID,MediaStore.Downloads.DISPLAY_NAME,MediaStore.Downloads.RELATIVE_PATH}; c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,pr,"relative_path=? AND display_name=?",new String[]{"VirtusELM/library/","dtc_vag.json"},MediaStore.Downloads.DATE_ADDED+" DESC"); if(c!=null&&c.moveToFirst()){ long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID)); Uri u=ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,id); InputStream is=getContentResolver().openInputStream(u); json=readAll(is); is.close(); } }finally{if(c!=null)c.close();} } else { File f=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/library/dtc_vag.json"); if(f.exists())json=readAll(new FileInputStream(f)); } if(json!=null&&!json.trim().isEmpty()){ JSONObject r=new JSONObject(json); String externalVersion=r.optString("version","0.0.0"); if(versionCompare(externalVersion,dtcLibraryVersion)>=0)parseDtcLibrary(json); } }catch(Exception ignored){} }
    private int versionCompare(String a,String b){ try{String[] x=a.split("\\."),y=b.split("\\."); for(int i=0;i<3;i++){int xi=i<x.length?Integer.parseInt(x[i].replaceAll("\\D.*","")):0;int yi=i<y.length?Integer.parseInt(y[i].replaceAll("\\D.*","")):0;if(xi!=yi)return xi>yi?1:-1;}return 0;}catch(Exception e){return a.equals(b)?0:-1;} }
    private void parseDtcLibrary(String json) throws Exception{ JSONObject root=new JSONObject(json); String ver=root.optString("version","1.0.0"); JSONArray arr=root.optJSONArray("dtcs"); if(arr==null)return; LinkedHashMap<String,String> parsed=new LinkedHashMap<>(); LinkedHashMap<String,JSONObject> records=new LinkedHashMap<>(); for(int i=0;i<arr.length();i++){ JSONObject o=arr.optJSONObject(i); if(o==null)continue; String code=o.optString("code","").trim().toUpperCase(Locale.US); String desc=o.optString("description","").trim(); if(!code.isEmpty()&&!desc.isEmpty()){parsed.put(code,desc); records.put(code,new JSONObject(o.toString()));} } if(!parsed.isEmpty()){ synchronized(dtcLibraryDescriptions){dtcLibraryDescriptions.clear();dtcLibraryDescriptions.putAll(parsed);dtcLibraryRecords.clear();dtcLibraryRecords.putAll(records);dtcLibraryVersion=ver;} ui(()->{updateDtcLibraryStatus(); if(dtcLibraryScreen!=null&&dtcLibraryScreen.getVisibility()==View.VISIBLE)renderDtcLibraryList();}); } }
    private String readAll(InputStream is) throws IOException{ BufferedReader br=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8)); StringBuilder b=new StringBuilder(); String line; while((line=br.readLine())!=null)b.append(line).append('\n'); br.close(); return b.toString(); }
    private void updateDtcLibraryStatus(){ String t="Biblioteca local: v"+dtcLibraryVersion+" • "+dtcLibraryDescriptions.size()+" códigos carregados"; if(dtcLibraryStatusView!=null)dtcLibraryStatusView.setText(t); if(dtcConfigStatusView!=null)dtcConfigStatusView.setText(t); }
    private void updateDtcLibraryFromNetwork(){ if(operationRunning){toast("Aguarde a operação atual terminar");return;} operationRunning=true; toast("Verificando atualização da biblioteca DTC..."); io.execute(()->{ HttpURLConnection conn=null; try{ URL u=new URL(DTC_LIBRARY_MANIFEST_URL); conn=(HttpURLConnection)u.openConnection(); conn.setConnectTimeout(10000); conn.setReadTimeout(15000); conn.setRequestMethod("GET"); conn.setRequestProperty("User-Agent","VirtusELM-V12"); int code=conn.getResponseCode(); if(code!=200)throw new IOException("Manifest HTTP "+code); String manifest=readAll(conn.getInputStream()); JSONObject m=new JSONObject(manifest); String remoteVersion=m.optString("version",""); String libraryUrl=m.optString("library_url",""); String expectedSha=m.optString("sha256","").toLowerCase(Locale.US); if(remoteVersion.isEmpty()||libraryUrl.isEmpty()||expectedSha.length()!=64)throw new IOException("Manifesto inválido"); if(remoteVersion.equals(dtcLibraryVersion)){ ui(()->{operationRunning=false;updateDtcLibraryStatus();toast("Biblioteca DTC já está atualizada (v"+remoteVersion+")");}); return; } URL lu=new URL(libraryUrl); HttpURLConnection lc=(HttpURLConnection)lu.openConnection(); try{ lc.setConnectTimeout(10000); lc.setReadTimeout(20000); lc.setRequestMethod("GET"); lc.setRequestProperty("User-Agent","VirtusELM-V12"); int lcode=lc.getResponseCode(); if(lcode!=200)throw new IOException("Biblioteca HTTP "+lcode); byte[] data=readBytes(lc.getInputStream()); String actual=sha256(data); if(!expectedSha.equals(actual))throw new IOException("SHA-256 inválido"); String json=new String(data,StandardCharsets.UTF_8); JSONObject root=new JSONObject(json); if(!remoteVersion.equals(root.optString("version","")))throw new IOException("Versão da biblioteca divergente"); saveDtcLibrary(json); parseDtcLibrary(json); }finally{lc.disconnect();} ui(()->{operationRunning=false;updateDtcLibraryStatus();toast("Biblioteca DTC atualizada para v"+remoteVersion);}); }catch(Exception e){ ui(()->{operationRunning=false;toast("Atualização DTC não concluída: "+e.getMessage());}); }finally{if(conn!=null)conn.disconnect();} }); }
    private byte[] readBytes(InputStream is) throws IOException{ ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n; while((n=is.read(buf))!=-1)b.write(buf,0,n); is.close(); return b.toByteArray(); }
    private String sha256(byte[] data) throws Exception{ MessageDigest md=MessageDigest.getInstance("SHA-256"); byte[] h=md.digest(data); StringBuilder s=new StringBuilder(); for(byte x:h)s.append(String.format(Locale.US,"%02x",x)); return s.toString(); }
    private void saveDtcLibrary(String json) throws Exception{ if(Build.VERSION.SDK_INT>=29){ ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,"dtc_vag.json"); v.put(MediaStore.Downloads.MIME_TYPE,"application/json"); v.put(MediaStore.Downloads.RELATIVE_PATH,"VirtusELM/library/"); v.put(MediaStore.Downloads.IS_PENDING,1); Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(u==null)throw new IOException("Não foi possível criar a biblioteca"); try{OutputStream os=getContentResolver().openOutputStream(u,"w"); os.write(json.getBytes(StandardCharsets.UTF_8)); os.close(); ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(u,done,null,null);}catch(Exception e){getContentResolver().delete(u,null,null);throw e;} } else { File f=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/library/dtc_vag.json"); File parent=f.getParentFile(); if(!parent.exists()&&!parent.mkdirs())throw new IOException("Não foi possível criar a pasta da biblioteca"); File tmp=new File(parent,"dtc_vag.json.tmp"); FileOutputStream os=new FileOutputStream(tmp,false); os.write(json.getBytes(StandardCharsets.UTF_8)); os.close(); if(f.exists()&&!f.delete())throw new IOException("Não foi possível substituir a biblioteca"); if(!tmp.renameTo(f))throw new IOException("Não foi possível finalizar a biblioteca"); } }
    private void clearAllDtc(){
        if(simulationMode){
            simulatedDtcCodes.clear(); lastDtcCodes.clear(); selectedDtcCodes.clear(); dtcSelectionMode=false;
            updateDtcPanel(new ArrayList<>(),"43 00 00 00 00 00 00");
            toast("SIMULAÇÃO: todos os DTCs foram removidos");
            append("DTC: limpeza total simulada — nenhum comando enviado ao veículo.");
            return;
        }
        if(!epcEvidenceSavedThisSession){
            new AlertDialog.Builder(this)
                .setTitle("PRESERVE AS EVIDÊNCIAS PRIMEIRO")
                .setMessage("Nenhum comando de limpeza foi enviado. Antes de apagar DTCs, execute INVESTIGAR EPC para ler os modos 03/07/0A, status OBD, VIN, freeze frame e respostas UDS/ISO-TP, e salvar o relatório em Download/VirtusELM/logs. A ausência de códigos decodificados não comprova ausência de falhas.")
                .setNegativeButton("CANCELAR",null)
                .setPositiveButton("INVESTIGAR EPC",(d,w)->investigateEpc())
                .show();
            return;
        }
        new AlertDialog.Builder(this)
            .setTitle("APAGAR TODOS OS DTCs?")
            .setMessage("Evidência desta sessão salva: "+(lastEpcEvidenceFile.isEmpty()?"sim":lastEpcEvidenceFile)+"\n\nO comando OBD-II Mode 04 solicita à ECU a limpeza de todos os códigos de falha; não apaga um DTC individual e pode zerar monitores de readiness. Só prossiga se o relatório e os RAWs foram preservados e você aceita essas consequências.")
            .setNegativeButton("CANCELAR",null)
            .setPositiveButton("APAGAR TODOS",(d,w)->runOp("LIMPAR TODOS OS DTCs — MODE 04",()->{
                if(!epcEvidenceSavedThisSession){
                    toast("Limpeza bloqueada: salve as evidências novamente");
                    append("MODE 04 BLOQUEADO: evidência EPC não está marcada como salva nesta sessão.");
                    return;
                }
                String evidenceFile=lastEpcEvidenceFile;
                epcEvidenceSavedThisSession=false; lastEpcEvidenceFile="";
                String r=send("04",2500); append("MODE 04: "+r);
                toast("Comando de limpeza enviado. Leia os DTCs novamente para confirmar.");
                showResult("LIMPEZA TOTAL DTC\nEvidência preservada: "+(evidenceFile.isEmpty()?"registro desta sessão":evidenceFile)+"\n\nRAW:\n"+r+"\n\nLeia os DTCs novamente para confirmar o resultado.");
            })).show();
    }

    private void clearSelectedDtc(){ ArrayList<String> selected=new ArrayList<>(selectedDtcCodes); if(simulationMode){for(String c:selected)simulatedDtcCodes.remove(c);lastDtcCodes.removeAll(selected);selectedDtcCodes.clear();dtcSelectionMode=false;updateDtcPanel(new ArrayList<>(lastDtcCodes),"43 — SIMULAÇÃO");toast(selected.size()+" DTC(s) removido(s) da simulação");append("DTC: remoção seletiva simulada: "+selected);return;} toast("LIMPEZA INDIVIDUAL: não suportada pelo OBD-II padrão. Nenhum comando foi enviado."); append("DTC: seleção individual solicitada para "+selected+" — sem transmissão; Mode 04 só limpa todos."); }
    private ArrayList<String> parseDtcCodes(String raw){
        ArrayList<String> codes=new ArrayList<>(); if(raw==null)return codes; String u=raw.toUpperCase(Locale.US).replaceAll("[^0-9A-F]+"," ").trim(); if(u.isEmpty())return codes; String[] tok=u.split("\\s+"); int svc=-1; for(int i=0;i<tok.length;i++){ if("43".equals(tok[i])){svc=i;break;} } if(svc<0||svc+1>=tok.length)return codes; for(int i=svc+1;i+1<tok.length;i+=2){ String a=tok[i],b=tok[i+1]; if("00".equals(a)&&"00".equals(b))break; if(a.length()!=2||b.length()!=2)break; try{ codes.add(decodeDtcBytePair(a,b)); }catch(Exception ignored){break;} } return codes; }
    private ArrayList<String> parseDtcCodesForResponse(String raw, String positiveSid){
        ArrayList<String> codes=new ArrayList<>();
        if(raw==null||positiveSid==null)return codes;
        String u=raw.toUpperCase(Locale.US).replaceAll("[^0-9A-F]+"," ").trim();
        if(u.isEmpty())return codes;
        String[] tok=u.split("\\s+"); int sid=-1;
        for(int i=0;i<tok.length;i++)if(positiveSid.equals(tok[i])){sid=i;break;}
        if(sid<0)return codes;
        for(int i=sid+1;i+1<tok.length;i+=2){
            String a=tok[i],b=tok[i+1];
            if(a.length()!=2||b.length()!=2)break;
            if("00".equals(a)&&"00".equals(b))break;
            try{codes.add(decodeDtcBytePair(a,b));}catch(Exception ignored){break;}
        }
        return codes;
    }
    private String formatDtcSummary(String raw, String positiveSid, String status){
        ArrayList<String> codes=parseDtcCodesForResponse(raw,positiveSid);
        if(!codes.isEmpty())return status+" ("+codes.size()+"): "+android.text.TextUtils.join(", ",codes);
        String u=raw==null?"":raw.toUpperCase(Locale.US).replaceAll("\\s+"," ").trim();
        if(u.contains("NO DATA")||u.contains("UNABLE TO CONNECT")||u.contains("ERROR"))return status+": ECU/serviço não respondeu de forma utilizável; RAW preservado.";
        if(u.contains("7F "))return status+": resposta negativa da ECU; não interpretar como ausência de falhas.";
        if(u.contains(positiveSid))return status+": resposta positiva sem DTC decodificável; conferir RAW/terminação ISO-TP.";
        return status+": nenhum DTC decodificável nesta resposta; isso não confirma ausência de falhas.";
    }
    private String decodeDtcBytePair(String a,String b){ int x=Integer.parseInt(a,16),y=Integer.parseInt(b,16); char system; switch((x>>6)&3){case 0:system='P';break;case 1:system='C';break;case 2:system='B';break;default:system='U';break;} int d2=(x>>4)&3; int d3=x&15; int d4=(y>>4)&15; int d5=y&15; return String.format(Locale.US,"%c%d%X%X%X",system,d2,d3,d4,d5); }
    private String encodeDtc(String code){ try{ if(code==null||code.length()!=5)return ""; char s=Character.toUpperCase(code.charAt(0)); int prefix=s=='P'?0:s=='C'?1:s=='B'?2:3; int v=Integer.parseInt(code.substring(1),16); int x=(prefix<<6)|((v>>8)&0x3F); int y=v&0xFF; return String.format(Locale.US,"%02X%02X",x,y); }catch(Exception e){return "";} }
    private void vagFocusedScan(){ runOp("VAG SCAN UDS 1.0 — EVIDÊNCIA 7E8 / 7E9",()->{
        final boolean realTransport = connected && !simulationMode && out != null && in != null;
        StringBuilder r=new StringBuilder();
        r.append("VAG SCAN UDS 1.0\n\n");
        r.append("OBJETIVO: testar somente leitura UDS 0x22/F190 nos endpoints de resposta CAN já observados.\n");
        r.append("BASE DE EVIDÊNCIA: CAN 11-bit / 500 kbps; respostas 7E8 e 7E9 observadas anteriormente.\n");
        r.append("TRANSPORTE: ").append(realTransport?"ELM REAL":"SIMULAÇÃO").append("\n\n");

        String proto=send("ATDP",1500);
        r.append("ATDP: ").append(proto).append("\n");
        if(realTransport){
            send("ATSP6",1200);
            send("ATE0",800); send("ATL0",800); send("ATS1",800); send("ATH1",800); send("ATCAF1",800); send("ATCFC1",800);
        }

        String functional=probeUdsVinHeader("7DF");
        String e7e0=probeUdsVinHeader("7E0");
        String e7e1=probeUdsVinHeader("7E1");
        r.append("ENDPOINT 7DF (FUNCIONAL): ").append(formatProbeResult(functional)).append("\n");
        r.append("ENDPOINT 7E0 → resposta esperada 7E8: ").append(formatProbeResult(e7e0)).append("\n");
        r.append("ENDPOINT 7E1 → resposta esperada 7E9: ").append(formatProbeResult(e7e1)).append("\n\n");

        String vin7df=parseUdsDidAscii(functional,"62","F190");
        String vin7e0=parseUdsDidAscii(e7e0,"62","F190");
        String vin7e1=parseUdsDidAscii(e7e1,"62","F190");
        r.append("VIN 7DF: ").append(vin7df.isEmpty()?"não identificado":vin7df).append("\n");
        r.append("VIN 7E0/7E8: ").append(vin7e0.isEmpty()?"não identificado":vin7e0).append("\n");
        r.append("VIN 7E1/7E9: ").append(vin7e1.isEmpty()?"não identificado":vin7e1).append("\n\n");

        r.append("INTERPRETAÇÃO\n");
        r.append("• Resposta positiva 62 F1 90 = endpoint aceitou a leitura VIN UDS.\n");
        r.append("• Ausência de resposta NÃO identifica o módulo como inexistente.\n");
        r.append("• Nenhum nome de módulo VAG é atribuído sem evidência específica.\n");
        r.append("• Nenhuma escrita, coding, adaptation, Security Access ou atuação foi executada.\n\n");
        r.append("RAW 7DF:\n").append(functional).append("\n\n");
        r.append("RAW 7E0 / VIN:\n").append(e7e0).append("\n\n");
        r.append("RAW 7E1 / VIN:\n").append(e7e1).append("\n\n");
        r.append("UDS DTC POR MÁSCARAS DE STATUS — RESPOSTAS ISO-TP REMONTADAS\n");
        send("ATSTFF",700);
        int[] masks={0x01,0x02,0x04,0x08,0x20,0x80};
        String[] maskNames={"TEST FAILED","FAILED THIS CYCLE","PENDING","CONFIRMED","FAILED SINCE CLEAR","WARNING INDICATOR"};
        for(int endpoint=0;endpoint<2;endpoint++){
            String req=endpoint==0?"7E0":"7E1", resp=endpoint==0?"7E8":"7E9";
            r.append("\nENDPOINT ").append(req).append(" → ").append(resp).append("\n");
            for(int mi=0;mi<masks.length;mi++)r.append(maskNames[mi]).append(" / ").append(String.format(Locale.US,"%02X",masks[mi])).append("\n").append(readUdsDtcStatusMask(req,resp,masks[mi])).append("\n");
        }

        // Retorna o ELM a um estado OBD funcional sem manter um header físico fixo.
        try{ send("ATSH 7DF",1000); send("ATSP0",1200); }catch(Exception ignored){}
        String text=r.toString();
        append(text.replace('\n',' '));
        ui(()->{if(vagExplorerResult!=null)vagExplorerResult.setText(text);});
        showResult(text);
    }); }

    private String probeUdsVinHeader(String header){
        try{
            send("ATSH "+header,1000);
            return send("22F190",3500);
        }catch(Exception e){ return "ERRO: "+e.getClass().getSimpleName(); }
    }
    private String probeUdsDtcHeader(String header){
        try{
            send("ATSH "+header,1000);
            return send("1902FF",3500);
        }catch(Exception e){ return "ERRO: "+e.getClass().getSimpleName(); }
    }
    private static final class IsoTpPayload {
        byte[] payload = new byte[0];
        int expectedLength = -1;
        boolean started = false;
        boolean complete = false;
        boolean bufferFull = false;
        boolean sequenceError = false;
        String note = "";
    }

    // Reassemble ISO-TP frames printed by ELM clones when the adapter does not
    // deliver a single normalized UDS payload. Only frames for the expected ECU are used.
    private IsoTpPayload reassembleIsoTp(String raw, String expectedCanId) {
        IsoTpPayload result = new IsoTpPayload();
        if (raw == null) { result.note = "sem RAW"; return result; }
        result.bufferFull = raw.toUpperCase(Locale.US).contains("BUFFER FULL");
        ByteArrayOutputStream payload = new ByteArrayOutputStream();
        int nextSequence = 1;
        String[] lines = raw.toUpperCase(Locale.US).split("\\r?\\n");
        for (String line : lines) {
            String clean = line.replaceAll("[^0-9A-F ]", " ").trim().replaceAll("\\s+", " ");
            if (clean.isEmpty()) continue;
            String[] t = clean.split(" ");
            int idAt = -1;
            for (int i=0; i<t.length; i++) {
                if (t[i].equals(expectedCanId)) { idAt=i; break; }
            }
            if (idAt >= 0 && idAt + 1 < t.length) {
                int[] b = new int[t.length-idAt-1]; int n=0;
                for (int i=idAt+1; i<t.length; i++) {
                    if (t[i].length()!=2) { n=0; break; }
                    try { b[n++]=Integer.parseInt(t[i],16); } catch(Exception e) { n=0; break; }
                }
                if (n==0) continue;
                int pci=b[0], type=(pci>>4)&0xF;
                if (type==0) { // Single Frame
                    int len=pci&0xF;
                    payload.reset();
                    int take=Math.min(len,n-1);
                    for(int i=0;i<take;i++)payload.write(b[i+1]);
                    result.started=true; result.expectedLength=len;
                    result.complete=take==len; nextSequence=1;
                } else if (type==1 && n>=2) { // First Frame
                    payload.reset();
                    result.expectedLength=((pci&0xF)<<8)|b[1];
                    for(int i=2;i<n;i++)payload.write(b[i]);
                    result.started=true; result.complete=payload.size()>=result.expectedLength; nextSequence=1;
                } else if (type==2 && result.started && !result.complete) { // Consecutive Frame
                    int seq=pci&0xF;
                    if(seq!=nextSequence) { result.sequenceError=true; result.note="sequência ISO-TP interrompida (esperado " + nextSequence + ", recebido " + seq + ")"; }
                    nextSequence=(seq+1)&0xF;
                    for(int i=1;i<n;i++)payload.write(b[i]);
                    if(result.expectedLength>=0 && payload.size()>=result.expectedLength) result.complete=true;
                }
            } else {
                // Some ELMs return the already-reassembled payload without a CAN ID.
                String[] a=clean.split(" ");
                if(a.length>=2 && (a[0].equals("59") || a[0].equals("7F"))) {
                    ByteArrayOutputStream direct=new ByteArrayOutputStream();
                    for(String v:a){ if(v.length()!=2)break; try{direct.write(Integer.parseInt(v,16));}catch(Exception e){break;} }
                    if(direct.size()>0){ payload.reset(); try{payload.write(direct.toByteArray());}catch(Exception ignored){} result.started=true; result.expectedLength=payload.size(); result.complete=true; }
                }
            }
        }
        byte[] assembled=payload.toByteArray();
        if(result.expectedLength>=0 && assembled.length>result.expectedLength) assembled=java.util.Arrays.copyOf(assembled,result.expectedLength);
        result.payload=assembled;
        if(result.sequenceError || result.bufferFull) result.complete=false;
        if(result.expectedLength<0) result.note=result.note.isEmpty()?"nenhum quadro ISO-TP reconhecido":result.note;
        else if(!result.complete) result.note=(result.note.isEmpty()?"resposta ISO-TP incompleta":result.note)+"; recebidos "+result.payload.length+"/"+result.expectedLength+" bytes"+(result.bufferFull?"; ELM reportou BUFFER FULL":"");
        return result;
    }

    private static final class UdsDtcRecord {
        String dtc; int status;
        UdsDtcRecord(String d,int s){dtc=d;status=s;}
    }

    private ArrayList<UdsDtcRecord> parseUdsDtcRecords(byte[] p) {
        ArrayList<UdsDtcRecord> outv=new ArrayList<>();
        if(p==null||p.length<3||(p[0]&255)!=0x59||(p[1]&255)!=0x02)return outv;
        // 59 02 = reportDTCByStatusMask positive response; byte 2 is statusAvailabilityMask.
        // Each DTCAndStatusRecord is exactly 3 DTC bytes followed by 1 status byte.
        for(int i=3;i+3<p.length;i+=4){
            int a=p[i]&255,b=p[i+1]&255,c=p[i+2]&255,st=p[i+3]&255;
            outv.add(new UdsDtcRecord(String.format(Locale.US,"%02X %02X %02X",a,b,c),st));
        }
        return outv;
    }

    private String udsStatusFlags(int status){
        ArrayList<String> f=new ArrayList<>();
        if((status&0x01)!=0)f.add("falha detectada");
        if((status&0x02)!=0)f.add("falhou neste ciclo");
        if((status&0x04)!=0)f.add("pendente");
        if((status&0x08)!=0)f.add("confirmada");
        if((status&0x10)!=0)f.add("teste não concluído desde a limpeza");
        if((status&0x20)!=0)f.add("falhou desde a limpeza");
        if((status&0x40)!=0)f.add("teste não concluído neste ciclo");
        if((status&0x80)!=0)f.add("solicita luz de avaria");
        return f.isEmpty()?"sem bits de status ativos":android.text.TextUtils.join(", ",f);
    }

    private String describeUdsNrc(String raw, String expectedService){
        if(raw==null)return "";
        String u=raw.toUpperCase(Locale.US).replaceAll("[^0-9A-F]+"," ").trim();
        String[] t=u.isEmpty()?new String[0]:u.split("\\s+");
        for(int i=0;i+2<t.length;i++){
            if("7F".equals(t[i]) && expectedService.equals(t[i+1])){
                String n=t[i+2]; String meaning;
                switch(n){
                    case "11": meaning="serviço não suportado"; break;
                    case "12": meaning="subfunção não suportada"; break;
                    case "13": meaning="comprimento/formato de mensagem inválido"; break;
                    case "22": meaning="condições de operação não atendidas"; break;
                    case "31": meaning="request out of range (pedido fora da faixa suportada)"; break;
                    case "33": meaning="acesso de segurança negado"; break;
                    case "78": meaning="resposta pendente; a ECU ainda está processando"; break;
                    default: meaning="NRC não mapeado pela biblioteca local"; break;
                }
                return "NRC 0x"+n+": "+meaning+". A rejeição não prova ausência de DTCs nem identifica sozinha o módulo.";
            }
        }
        return "";
    }

    private String readUdsDtcStatusMask(String requestHeader, String responseCanId, int mask){
        try{
            send("ATSH "+requestHeader,800);
            String raw=send(String.format(Locale.US,"1902%02X",mask),3500);
            IsoTpPayload iso=reassembleIsoTp(raw,responseCanId);
            StringBuilder b=new StringBuilder();
            b.append("REQUEST 1902").append(String.format(Locale.US,"%02X",mask)).append(" | ECU ").append(responseCanId).append("\n");
            b.append("RAW:\n").append(raw==null?"":raw).append("\n");
            if(iso.payload.length>=3 && (iso.payload[0]&255)==0x59 && (iso.payload[1]&255)==0x02){
                b.append("ISO-TP: ").append(iso.complete?"completo":"INCOMPLETO");
                if(iso.expectedLength>=0)b.append(" ( ").append(iso.payload.length).append("/").append(iso.expectedLength).append(" bytes)");
                if(!iso.note.isEmpty())b.append(" — ").append(iso.note);
                b.append("\nSTATUS AVAILABILITY MASK: ").append(String.format(Locale.US,"%02X",iso.payload[2]&255)).append("\n");
                ArrayList<UdsDtcRecord> records=parseUdsDtcRecords(iso.payload);
                if(records.isEmpty())b.append(iso.complete?"DTCs para esta máscara: nenhum registro retornado.\n":"Nenhum registro completo pode ser confirmado porque a resposta está incompleta.\n");
                else{
                    b.append("REGISTROS UDS: ").append(records.size()).append(iso.complete?"":" (parciais; resposta incompleta)").append("\n");
                    for(UdsDtcRecord d:records)b.append("• DTC ").append(d.dtc).append(" | STATUS ").append(String.format(Locale.US,"%02X",d.status)).append(" | ").append(udsStatusFlags(d.status)).append("\n");
                }
                if(!iso.complete)b.append("CONCLUSÃO: não tratar esta resposta como lista completa de falhas.\n");
            }else{
                b.append("ISO-TP: ").append(iso.note.isEmpty()?"sem resposta positiva 59 02":iso.note).append("\n");
                String nrc=describeUdsNrc(raw,"19");
                if(!nrc.isEmpty())b.append(nrc).append("\n");
                else if(raw!=null&&raw.toUpperCase(Locale.US).contains("7F 19"))b.append("A ECU rejeitou a solicitação UDS; isso não significa ausência de falhas.\n");
                else b.append("Sem decodificação UDS válida; RAW preservado.\n");
            }
            return b.toString();
        }catch(Exception e){return "REQUEST 1902"+String.format(Locale.US,"%02X",mask)+" | ERRO: "+e.getClass().getSimpleName();}
    }

    private String formatUdsDtcResult(String raw){
        if(raw==null||raw.trim().isEmpty()) return "sem resposta";
        String u=raw.toUpperCase(Locale.US);
        if(u.contains("59 02")) return "POSITIVA 59 02 (DTC UDS retornado)";
        if(u.contains("7F 19")) return "RESPOSTA NEGATIVA UDS: "+raw.trim();
        return "sem resposta positiva: "+raw.trim();
    }
    private String formatProbeResult(String raw){
        if(raw==null||raw.trim().isEmpty()) return "sem resposta";
        if(hasUdsPositiveResponse(raw,"62","F190")) return "POSITIVA 62 F190";
        String u=raw.toUpperCase(Locale.US);
        if(u.contains("7F 22")) return "RESPOSTA NEGATIVA UDS: "+raw.trim();
        return "sem resposta positiva: "+raw.trim();
    }

    private void vagDiagnosticExplorer(){ runOp("VAG DIAGNOSTIC EXPLORER 2.2 — SOMENTE LEITURA",()->{
        // VAG Explorer 2.2: primeira etapa UDS somente leitura, sem endereço VAG arbitrário.
        // 0x22 F190 é uma leitura de DID VIN; a resposta só é considerada evidência se o veículo responder.
        final boolean realTransport = connected && !simulationMode && out != null && in != null;
        String proto=send("ATDP",1500), dpn=send("ATDPN",1200),
               p100=send("0100",1800), p101=send("0101",1800),
               dtc=send("03",1800), vin=send("0902",2500);
        String udsVin;
        if(realTransport){
            // A leitura UDS precisa usar o endpoint físico já validado no teste de campo.
            // O teste confirmou 7E0 → 7E8 para 0x22/F190; não usar 7DF aqui.
            try{ send("ATSH 7E0",1000); udsVin=send("22F190",3500); }finally{ try{send("ATSH 7DF",1000);}catch(Exception ignored){} }
        }else udsVin=send("22F190",3000);
        String rpm=send("010C",1500), speed=send("010D",1500),
               thr=send("0111",1500), volt=send("0142",1500);

        boolean obdEvidence = hasObdPositiveResponse(p100) || hasObdPositiveResponse(p101)
                || hasObdPositiveResponse(dtc) || hasObdPositiveResponse(vin)
                || hasObdPositiveResponse(rpm) || hasObdPositiveResponse(speed)
                || hasObdPositiveResponse(thr) || hasObdPositiveResponse(volt);
        boolean udsVinPositive = hasUdsPositiveResponse(udsVin,"62","F190");
        String udsVinText = parseUdsDidAscii(udsVin,"62","F190");

        StringBuilder r=new StringBuilder();
        r.append("VAG DIAGNOSTIC EXPLORER 2.2\n\n");
        if(simulationMode) r.append("MODO: SIMULAÇÃO — dados não são evidência do veículo\n");
        else if(realTransport) r.append("MODO: VEÍCULO / ELM REAL\n");
        else r.append("MODO: SEM ELM REAL\n");
        r.append("TRANSPORTE REAL: ").append(realTransport?"SIM":"NÃO").append("\n");
        r.append("EVIDÊNCIA OBD: ").append(obdEvidence?"RESPOSTA POSITIVA":"NÃO IDENTIFICADA").append("\n");
        r.append("PROTOCOLO: ").append(proto).append("\n");
        r.append("PROTOCOLO NUM.: ").append(dpn).append("\n\n");

        r.append("VAG / UDS — LEITURA VALIDADA NESTA ETAPA\n");
        r.append("SERVIÇO: 0x22 • DID F190 (VIN)\n");
        r.append("RESPOSTA UDS: ").append(udsVinPositive?"POSITIVA (0x62 F190)":"NÃO IDENTIFICADA").append("\n");
        r.append("VIN UDS: ").append(udsVinText.isEmpty()?"não identificado":udsVinText).append("\n");


        r.append("CAN IDs / ENDEREÇOS DE RESPOSTA OBSERVADOS\n");
        ArrayList<String> idsFound=parseCanIds(
                p100+"\n"+p101+"\n"+dtc+"\n"+vin+"\n"+udsVin+"\n"+rpm+"\n"+speed+"\n"+thr+"\n"+volt);
        if(idsFound.isEmpty()){
            r.append("• Nenhum CAN ID identificável no retorno textual\n");
        }else{
            for(String id:idsFound)
                r.append("• CAN ").append(id).append(" — resposta observada").append(realTransport?" (REAL)":" (SIMULAÇÃO)").append("\n");
        }

        r.append("\nMÓDULOS VAG — EVIDÊNCIA ATUAL\n");
        r.append("01 ENGINE / OBD — ").append(hasObdPositiveResponse(p100)?"resposta OBD observada":"sem resposta positiva observada").append("\n");
        r.append("UDS VIN / DID F190 — ").append(udsVinPositive?"resposta positiva observada":"sem resposta positiva observada").append("\n");
        r.append("03 ABS — NÃO IDENTIFICADO nesta etapa (nenhuma resposta específica observada)\n");
        r.append("17 INSTRUMENTS — NÃO IDENTIFICADO nesta etapa (nenhuma resposta específica observada)\n");
        r.append("19 CAN GATEWAY — NÃO IDENTIFICADO nesta etapa (nenhuma resposta específica observada)\n");
        r.append("DESCOBERTA: nenhum endereço físico específico de módulo VAG foi inventado ou transmitido.\n");

        r.append("\nDADOS OBSERVADOS\n");
        r.append("0100 PIDs: ").append(p100).append("\n");
        r.append("0101 STATUS: ").append(p101).append("\n");
        r.append("RPM 010C: ").append(rpm).append("\n");
        r.append("VELOCIDADE 010D: ").append(speed).append("\n");
        r.append("THROTTLE 0111: ").append(thr).append("\n");
        r.append("TENSÃO 0142: ").append(volt).append("\n\n");
        r.append("DTC MODE 03:\n").append(dtc).append("\n\n");
        r.append("VIN OBD 0902:\n").append(vin).append("\n\n");
        r.append("VIN UDS 22 F1 90:\n").append(udsVin).append("\n\n");
        r.append("SOMENTE LEITURA — serviço UDS 0x22 usado apenas para leitura do DID F190. Nenhum coding, adaptation, Security Access, limpeza DTC ou escrita de módulo foi executado.");

        String text=r.toString();
        append(text.replace('\n',' '));
        ui(()->{if(vagExplorerResult!=null)vagExplorerResult.setText(text);});
        showResult(text);
    }); }

    private boolean hasObdPositiveResponse(String raw){
        if(raw==null||raw.trim().isEmpty()) return false;
        return Pattern.compile("(?i)(?:^|\\s)(?:41|43|47|49)(?:\\s|$)").matcher(raw).find();
    }

    private ArrayList<String> parseCanIds(String raw){
        ArrayList<String> out=new ArrayList<>();
        if(raw==null) return out;
        Matcher m=Pattern.compile("(?i)\\b([0-9A-F]{3})\\b\\s+(?:[0-9A-F]{2}\\s+)?(?:41|43|47|49|62|6E|7F)\\b").matcher(raw);
        while(m.find()){
            String id=m.group(1).toUpperCase(Locale.US);
            if(!out.contains(id)) out.add(id);
        }
        // Importante: IDs 7E8/7E9 nunca são inventados no modo simulação.
        return out;
    }
    private boolean hasUdsPositiveResponse(String raw,String service,String did){
        if(raw==null||raw.trim().isEmpty()) return false;
        String u=raw.toUpperCase(Locale.US).replaceAll("\\s+", " ");
        return u.matches(".*\\b62\\s+F1\\s+90\\b.*") || u.contains(service+" "+did);
    }
    private String parseUdsDidAscii(String raw,String service,String did){
        if(raw==null||raw.trim().isEmpty()) return "";
        String u=raw.toUpperCase(Locale.US).replaceAll("[^0-9A-F]", " ").trim();
        String[] tok=u.isEmpty()?new String[0]:u.split("\\s+");
        for(int i=0;i+3<tok.length;i++){
            if(service.equals(tok[i]) && "F1".equals(tok[i+1]) && did.endsWith(tok[i+2])){
                StringBuilder outv=new StringBuilder();
                for(int j=i+3;j<tok.length;j++){ if(tok[j].length()!=2) continue; try{int b=Integer.parseInt(tok[j],16); if(b>=32&&b<=126) outv.append((char)b);}catch(Exception ignored){} }
                return outv.toString().trim();
            }
            if("62".equals(tok[i]) && "F1".equals(tok[i+1]) && "90".equals(tok[i+2])){
                StringBuilder outv=new StringBuilder();
                for(int j=i+3;j<tok.length;j++){ try{int b=Integer.parseInt(tok[j],16); if(b>=32&&b<=126) outv.append((char)b);}catch(Exception ignored){} }
                String v=outv.toString().trim(); if(!v.isEmpty()) return v;
            }
        }
        return "";
    }
    private void readVin(){ runOp("LER VIN — SE DISPONÍVEL",()->{String r=send("0902",3000); String vin=parseVin(r); append("VIN: "+(vin.isEmpty()?"não identificado no parser; RAW preservado":vin)); showResult("VIN: "+(vin.isEmpty()?"não identificado":vin)+"\nRAW:\n"+r);}); }
    private String parseVin(String r){
        if(r==null||r.isEmpty()) return "";
        String[] lines=r.toUpperCase(Locale.US).replace('\r','\n').split("\n");
        StringBuilder vinHex=new StringBuilder(); boolean found=false;
        for(String rawLine:lines){
            String line=rawLine.trim(); if(line.isEmpty()) continue;
            ArrayList<String> tok=new ArrayList<>(); Matcher m=Pattern.compile("[0-9A-F]{2}").matcher(line);
            while(m.find()) tok.add(m.group());
            if(tok.size()<3) continue;
            int svc=-1;
            for(int i=0;i+2<tok.size();i++) if(tok.get(i).equals("49")&&tok.get(i+1).equals("02")&&tok.get(i+2).equals("01")){svc=i;break;}
            if(svc>=0){ found=true; for(int j=svc+3;j<tok.size();j++) vinHex.append(tok.get(j)); continue; }
            if(found){
                // Multi-frame ISO-TP continuation: 7E8 21 ... / 7E8 22 ...
                // Ignore the CAN header and PCI byte; keep only payload bytes.
                int pci=-1;
                for(int i=0;i<tok.size();i++){ if(tok.get(i).equals("21")||tok.get(i).equals("22")||tok.get(i).equals("23")||tok.get(i).equals("24")){pci=i;break;} }
                if(pci>=0){ for(int j=pci+1;j<tok.size();j++) vinHex.append(tok.get(j)); }
            }
        }
        StringBuilder vin=new StringBuilder();
        for(int i=0;i+1<vinHex.length()&&vin.length()<17;i+=2){
            try{int v=Integer.parseInt(vinHex.substring(i,i+2),16); if(v>=32&&v<=126) vin.append((char)v);}catch(Exception ignored){}
        }
        String out=vin.toString().trim();
        return out.length()==17?out:"";
    }
    private String saveEpcEvidenceReport(String fileName, String report) throws IOException {
        byte[] data=report.getBytes(StandardCharsets.UTF_8);
        if(Build.VERSION.SDK_INT>=29){
            ContentValues v=new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME,fileName);
            v.put(MediaStore.Downloads.MIME_TYPE,"text/plain");
            v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/VirtusELM/logs/");
            v.put(MediaStore.Downloads.IS_PENDING,1);
            Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
            if(u==null)throw new IOException("MediaStore não criou o arquivo de evidência");
            try(OutputStream os=getContentResolver().openOutputStream(u,"w")){
                if(os==null)throw new IOException("Não foi possível abrir o arquivo de evidência");
                os.write(data); os.flush();
            }catch(Exception e){getContentResolver().delete(u,null,null);if(e instanceof IOException)throw (IOException)e;throw new IOException("Falha ao gravar evidência",e);}
            ContentValues done=new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING,0);
            int updated=getContentResolver().update(u,done,null,null);
            if(updated<=0)throw new IOException("Arquivo gravado, mas não foi possível finalizar a publicação");
        }else{
            File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs");
            if(!dir.exists()&&!dir.mkdirs())throw new IOException("Não foi possível criar Download/VirtusELM/logs");
            File f=new File(dir,fileName);
            try(FileOutputStream os=new FileOutputStream(f,false)){os.write(data);os.flush();}
        }
        return fileName;
    }

    private void investigateEpc(){ runOp("INVESTIGAÇÃO EPC — PACOTE DE EVIDÊNCIAS SOMENTE LEITURA",()->{
        final boolean realTransport = connected && !simulationMode && out != null && in != null;
        String stamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US).format(new Date());
        StringBuilder r=new StringBuilder();
        r.append("VIRTUS ELM V12 — INVESTIGAÇÃO EPC\n");
        r.append("DATA/HORA: ").append(stamp).append("\n");
        r.append("ORIGEM: ").append(realTransport?"VEÍCULO REAL / ELM327":"SIMULAÇÃO OU TRANSPORTE NÃO CONFIRMADO").append("\n");
        r.append("MODO: SOMENTE LEITURA — NÃO APAGA FALHAS\n\n");
        if(!realTransport){
            r.append("ATENÇÃO: não há transporte ELM real confirmado. Os resultados abaixo não devem ser tratados como evidência do veículo.\n\n");
        }
        String proto=send("ATDP",1200); r.append("PROTOCOLO ATDP: ").append(proto).append("\n\n");
        String[] cmds={"03","07","0A","0101","0902","020200","020C00","020D00","020500","020B00","021100","020400","020F00","0142","0146"};
        String[] labels={"DTC CONFIRMADOS / MODE 03","DTC PENDENTES / MODE 07","DTC PERMANENTES / MODE 0A","STATUS OBD / MIL E READINESS","VIN OBD-II","FREEZE FRAME: DTC CAUSADOR / 020200","FREEZE FRAME: RPM / 020C00","FREEZE FRAME: VELOCIDADE / 020D00","FREEZE FRAME: TEMP. ARREFECIMENTO / 020500","FREEZE FRAME: MAP / 020B00","FREEZE FRAME: BORBOLETA / 021100","FREEZE FRAME: CARGA / 020400","FREEZE FRAME: TEMP. ADMISSÃO / 020F00","TENSÃO MÓDULO / 0142","TEMP. AR AMBIENTE / 0146"};
        int positiveObdResponses=0;
        for(int i=0;i<cmds.length;i++){
            String value;
            try{ value=send(cmds[i],cmds[i].equals("0902")?2500:1800); }
            catch(Exception e){ value="ERRO DE LEITURA: "+e.getClass().getSimpleName(); }
            r.append(labels[i]).append("\nCOMANDO: ").append(cmds[i]).append("\nRAW: ").append(value==null?"(null)":value).append("\n");
            if(hasObdPositiveResponse(value) || hasUdsPositiveResponse(value,"62","F190") || (value!=null && value.toUpperCase(Locale.US).contains("59 02"))) positiveObdResponses++;
            if(i==0) r.append("INTERPRETAÇÃO: ").append(formatDtcSummary(value,"43","DTC CONFIRMADOS")).append("\n");
            else if(i==1) r.append("INTERPRETAÇÃO: ").append(formatDtcSummary(value,"47","DTC PENDENTES")).append("\n");
            else if(i==2) r.append("INTERPRETAÇÃO: ").append(formatDtcSummary(value,"4A","DTC PERMANENTES")).append("\n");
            r.append("\n");
            append("EPC PACKET | "+labels[i]+" | "+cmds[i]+" | "+(value==null?"(null)":value).replace('\n',' '));
        }
        if(realTransport){
            try{
                send("ATSP6",1000); send("ATE0",700); send("ATL0",700); send("ATS1",700); send("ATH1",700); send("ATCAF1",700); send("ATCFC1",700); send("ATSTFF",700);
                r.append("VAG UDS — LEITURA DTC POR MÁSCARAS DE STATUS; DTCs UDS preservados em hexadecimal\n");
                r.append("MÉTODO: ISO-TP é remontado e a resposta só é considerada completa quando o tamanho anunciado é recebido. Consultas separadas reduzem o risco de BUFFER FULL.\n");
                int[] masks={0x01,0x02,0x04,0x08,0x20,0x80};
                String[] names={"TEST FAILED","FAILED THIS CYCLE","PENDING","CONFIRMED","FAILED SINCE CLEAR","WARNING INDICATOR"};
                for(int endpoint=0;endpoint<2;endpoint++){
                    String req=endpoint==0?"7E0":"7E1", resp=endpoint==0?"7E8":"7E9";
                    r.append("\nENDPOINT ").append(req).append(" → ").append(resp).append(" (identidade do módulo não presumida)\n");
                    for(int mi=0;mi<masks.length;mi++){
                        String detail=readUdsDtcStatusMask(req,resp,masks[mi]);
                        r.append("STATUS FILTER ").append(names[mi]).append(" / ").append(String.format(Locale.US,"%02X",masks[mi])).append("\n").append(detail).append("\n");
                        append("EPC UDS "+req+" MASK "+String.format(Locale.US,"%02X",masks[mi])+" | "+detail.replace('\n',' '));
                    }
                }
            }catch(Exception e){ r.append("VAG UDS: erro durante leitura: ").append(e.getClass().getSimpleName()).append("\n\n"); }
            finally{ try{send("ATSH 7DF",800);send("ATSP0",1000);send("ATH0",700);send("ATS0",700);send("ATST32",700);}catch(Exception ignored){} }
        } else {
            r.append("VAG UDS: ignorado porque não há conexão real confirmada.\n\n");
        }
        r.append("QUALIDADE DA CAPTURA\n");
        r.append("Respostas positivas OBD identificadas: ").append(positiveObdResponses).append("\n");
        r.append("Critério de evidência: conexão ELM real e ao menos uma resposta positiva OBD reconhecida. Uma conexão aberta, isoladamente, não comprova comunicação válida com o veículo.\n\n");
        r.append("COMO INTERPRETAR\n");
        r.append("• OBD-II Mode 03/07/0A é avaliado separadamente; respostas positivas sem código decodificável não são tratadas como ausência de falhas.\n");
        r.append("• UDS 59 02 é interpretado como registros de 3 bytes de DTC + 1 byte de status; os DTCs UDS são mantidos em hexadecimal e não convertidos artificialmente para códigos Pxxxx.\n");
        r.append("• Cada máscara UDS é consultada separadamente; respostas ISO-TP incompletas ou com BUFFER FULL são marcadas e não são consideradas listas completas.\n");
        r.append("• Resposta sem código decodificável não equivale a ‘sem falhas’: pode ser ausência de suporte, timeout, resposta negativa ou fragmentação ISO-TP.\n");
        r.append("• Compare DTC confirmado, pendente e permanente; diferenças entre modos são relevantes.\n");
        r.append("• Freeze frame pode não existir; resposta vazia/NO DATA não prova que o sistema esteja sem falha.\n");
        r.append("• Resposta negativa UDS ou ausência de resposta não identifica, por si só, o módulo nem a causa.\n");
        r.append("• Guarde este relatório antes de limpar qualquer código. Não use APAGAR TODOS antes de registrar as evidências.\n");
        r.append("• EPC recorrente, perda de potência ou funcionamento irregular requer diagnóstico automotivo; se houver perda de potência, pare em local seguro.\n");
        String report=r.toString();
        String evidenceName="VirtusELM_EPC_Evidence_"+new java.text.SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(new Date())+".txt";
        try{
            report += "\nARQUIVO DE EVIDÊNCIA: Download/VirtusELM/logs/"+evidenceName+"\n";
            boolean eligibleForClear=realTransport && positiveObdResponses>0;
            report += "STATUS DE PRESERVAÇÃO: "+(eligibleForClear?"relatório salvo com transporte ELM real e resposta positiva OBD reconhecida; a limpeza ainda exige confirmação explícita.":"relatório salvo, mas não há evidência suficiente de comunicação positiva real com o veículo; NÃO autoriza limpeza de DTCs.")+"\n";
            saveEpcEvidenceReport(evidenceName,report);
            epcEvidenceSavedThisSession=eligibleForClear;
            lastEpcEvidenceFile=eligibleForClear?evidenceName:"";
            append("EVIDÊNCIA EPC SALVA: Download/VirtusELM/logs/"+evidenceName+(eligibleForClear?" • elegível para confirmação de limpeza":" • evidência positiva insuficiente; limpeza bloqueada"));
        }catch(Exception saveError){
            epcEvidenceSavedThisSession=false;
            lastEpcEvidenceFile="";
            report += "\nFALHA AO SALVAR EVIDÊNCIA: "+saveError.getClass().getSimpleName()+" — "+String.valueOf(saveError.getMessage())+"\n";
            append("ERRO: relatório EPC não foi salvo em arquivo: "+saveError.getClass().getSimpleName()+" — "+String.valueOf(saveError.getMessage()));
            toast("Atenção: relatório EPC não foi salvo em arquivo");
        }
        append("===== INÍCIO RELATÓRIO EPC =====");
        for(String line:report.split("\n")) if(!line.trim().isEmpty()) append(line);
        append("===== FIM RELATÓRIO EPC =====");
        showResult(report);
    }); }

    private void dtcFreeze(){ runOp("DTC + FREEZE FRAME — SOMENTE LEITURA",()->{String a=send("03",2000); String b=send("0200",2000); String c=send("0201",2000); append("MODE 03: "+a); append("FREEZE FRAME 0200: "+b); append("FREEZE FRAME 0201: "+c); showResult("MODE 03:\n"+a+"\n\n0200:\n"+b+"\n\n0201:\n"+c);}); }
    private void obdStatus(){ runOp("STATUS OBD / READINESS",()->{StringBuilder r=new StringBuilder(); for(String p:new String[]{"0101","0102","0106","0107","0110"}){String x=send(p,1600);append(p+": "+x);r.append(p).append(" -> ").append(x).append("\n");}showResult(r.toString());}); }
    private void o2Test(){ runOp("TESTAR MONITORAMENTO DA SONDA",()->{StringBuilder r=new StringBuilder();for(String p:new String[]{"05","06","07","0A"}){String x=send(p,1800);append(p+": "+x);r.append(p).append(" -> ").append(x).append("\n");}showResult(r.toString());}); }
    private void ignitionOffTest(){ runOp("TESTE COM IGNIÇÃO DESLIGADA",()->{String a=send("ATI",1500);String b=send("ATDP",1500);String c=send("0100",2200);boolean ecu=c.matches("(?s).*(41\\s+00|41 00).*");String conclusion=ecu?"ELM respondeu e houve resposta OBD/CAN com a condição testada.":"ELM respondeu, mas nenhuma resposta CAN/ECU foi identificada para 0100. Isso não significa que não existam outros módulos.";append("CONCLUSÃO: "+conclusion);showResult(a+"\n"+b+"\n0100:\n"+c+"\n\n"+conclusion);}); }
    private void bodyStudy(){ runOp("ESTUDO DE MÓDULOS — SOMENTE LEITURA",()->{String a=send("ATDP",1600);String b=send("0100",2200);append("PROTOCOLO: "+a);append("0100: "+b);showResult("PROTOCOLO:\n"+a+"\n\n0100:\n"+b+"\n\nNenhum comando de atuação, segurança, coding ou lock/unlock foi transmitido.");}); }

    private volatile boolean monitorRejected = false;
    private long monitorStartedAt = 0;

    // ===== V11.6.10 — CAN LAB / INVESTIGATOR 2.1 =====
    // Baseado em implementações abertas de monitoramento ELM327:
    // ATCAF0 para CAN raw, ATAL para mensagens longas, ATD1 para DLC,
    // ATMA para Monitor All e ATCRA como teste passivo de filtro por CAN ID.
    // Nenhuma rotina desta versão transmite frames CAN arbitrários.
    private void startMonitor(){
        if(operationRunning||monitoring){setStatus(operationRunning?"Finalize a operação atual antes de capturar":"Captura já ativa");return;}
        if(!connected){setStatus("Conecte o ELM primeiro");return;}
        if(simulationMode){setStatus("CAN indisponível no modo simulação");toast("CAN exige ELM327 real");return;}

        operationRunning=true;
        monitoring=true;
        stopRequested=false;
        monitorRejected=false;
        monitorStartedAt=System.currentTimeMillis();
        rawCount=frameCount=rxBytes=0; ids.clear(); idCounts.clear(); markers.clear();
        setHealth("YELLOW","CAN LAB • OBD PAUSADO");
        setStatus("CAN LAB: preparando captura passiva");

        io.execute(()->{
            try{
                append("=== V11.6.10 — CAN LAB / INVESTIGATOR 2.1 ===");
                append("Objetivo: descobrir por que o ELM responde aos PIDs, mas não permanece em monitoramento CAN.");
                append("SOMENTE LEITURA — nenhum frame CAN arbitrário é transmitido.");

                canDiagUi("ELM: conectado\nPROTOCOLO: consultando...\nCMD: ATDP / ATDPN\nRX: —\nESTADO: CAN LAB inicial");
                String dp=send("ATDP",1500);
                String dpn=send("ATDPN",1200);
                String proto=dp.toUpperCase(Locale.US);
                append("ATDP -> "+dp);
                append("ATDPN -> "+dpn);

                String protoCmd;
                if(proto.contains("29/500")||proto.contains("29")){
                    protoCmd="ATSP7";
                    append("Protocolo detectado: CAN 29/500 — fixando protocolo 7.");
                }else{
                    protoCmd="ATSP6";
                    append("Protocolo detectado: CAN 11/500 — fixando protocolo 6.");
                }
                String sp=send(protoCmd,1200); append(protoCmd+" -> "+sp);
                canDiagUi("ELM: conectado\nPROTOCOLO: "+(proto.contains("29")?"CAN 29/500":"CAN 11/500")+"\nCMD: "+protoCmd+"\nRX: "+safeDiag(sp)+"\nESTADO: preparando CAN raw");

                // Sequência inspirada em implementações abertas de sniffer ELM327.
                // Mantemos headers/espaços/DLC visíveis para facilitar a investigação.
                String[] setup={"ATE0","ATH1","ATS1","ATL0","ATAL","ATD1","ATCAF0","ATAT0"};
                for(String cmd:setup){
                    String r=send(cmd,900);
                    append(cmd+" -> "+r);
                    if(cmd.equals("ATCAF0") && !isOk(r)){
                        append("AVISO: ATCAF0 não confirmado pelo ELM; tentando ATCAF1 para compatibilidade.");
                        String rf=send("ATCAF1",900);
                        append("ATCAF1 -> "+rf);
                    }
                }
                drainInput(180);

                // ===== V11.6.10 — TESTE FINAL: ATMR 07 =====
                // IMPORTANTE: ATMR/MR não recebe um CAN ID completo de 11 bits.
                // No CAN 11-bit ele filtra os bits 8..10 do ID (3 bits). Para o ID 7E8,
                // esses bits são 111b = 7h. Portanto o teste correto é ATMR 07,
                // não ATMR 7E8. Este teste é deliberadamente amplo (IDs 700..7FF)
                // e serve para verificar se o ELM consegue monitorar por MR.
                String mr=send("ATMR 07",1200);
                append("ATMR 07 -> "+mr);
                if(!isOk(mr) && mr.toUpperCase(Locale.US).contains("?")) append("AVISO: ELM rejeitou ATMR 07.");
                drainInput(180);

                canDiagUi("ELM: conectado\nPROTOCOLO: "+(proto.contains("29")?"CAN 29/500":"CAN 11/500")+"\nCMD: ATMR 07\nRX: aguardando...\nESTADO: Monitor Receiver por 10 s");
                append("TESTE FINAL — ATMR 07 / janela 10 s");
                append(">> ATMR 07");
                final long mrStartedAt=System.currentTimeMillis();
                monitorStartedAt=mrStartedAt;
                monitorRejected=false;
                main.postDelayed(()->{
                    if(monitoring && monitorStartedAt==mrStartedAt && !stopRequested){
                        stopRequested=true;
                        append("JANELA ATMR: 10 s atingidos — enviando interrupção CR ao ELM.");
                        try{ if(out!=null){ out.write('\r'); out.flush(); } }catch(Exception e){ append("ERRO AO INTERROMPER ATMR: "+e); }
                    }
                },10000);
                monitorLoop();

                if(frameCount>0){
                    append("=== TESTE FINAL: FRAMES CAN RECEBIDOS COM ATMR 07 ===");
                    canDiagUi("ELM: conectado\nPROTOCOLO: "+(proto.contains("29")?"CAN 29/500":"CAN 11/500")+"\nCMD: ATMR 07\nRX: frames recebidos\nESTADO: ATMR ativo — CAN RAW recebido");
                    setStatus("CAN LAB — ATMR 07 funcionou: "+frameCount+" frames");
                }else if(monitorRejected){
                    append("=== TESTE FINAL: ATMR REJEITADO IMEDIATAMENTE ===");
                    append("O ELM retornou prompt antes de permanecer em Monitor Receiver.");
                    canDiagUi("ELM: conectado\nPROTOCOLO: "+(proto.contains("29")?"CAN 29/500":"CAN 11/500")+"\nCMD: ATMR 07\nRX: >\nESTADO: ATMR rejeitado imediatamente");
                    setStatus("CAN LAB — ATMR 07 rejeitado");
                }else{
                    append("=== TESTE FINAL: ATMR 07 SEM FRAMES NA JANELA DE 10 s ===");
                    append("O ELM permaneceu em Monitor Receiver, mas não entregou frames nesta janela.");
                    canDiagUi("ELM: conectado\nPROTOCOLO: "+(proto.contains("29")?"CAN 29/500":"CAN 11/500")+"\nCMD: ATMR 07\nRX: sem frames\nESTADO: 10 s concluídos — nenhum RAW");
                    setStatus("CAN LAB — ATMR 07 ativo, porém sem frames");
                }
                // Restaura o filtro de recepção antes de devolver o ELM ao OBD normal.
                try{ String resetCra=send("ATCRA",1200); append("ATCRA (reset) -> "+resetCra); }catch(Exception e){ append("AVISO: falha ao resetar ATCRA: "+e); }
            }catch(Exception e){
                append("ERRO CAN LAB: "+e);
                setStatus("CAN LAB interrompido — dados preservados");
                monitoring=false;
                operationRunning=false;
                if(!intentionalDisconnect){
                    connected=false;
                    closeSocket();
                    setHealth("RED","RECONEXÃO AUTOMÁTICA");
                    scheduleReconnect();
                }
            }finally{
                monitoring=false;
                operationRunning=false;
            }
        });
    }

    private boolean preparePassiveTest(String label,String diagLabel) throws IOException{
        if(stopRequested) return false;
        monitoring=true;
        monitorRejected=false;
        monitorStartedAt=System.currentTimeMillis();
        drainInput(120);
        canDiagUi("ELM: conectado\nPROTOCOLO: ativo\n"+diagLabel+"\nRX: aguardando...\nESTADO: captura passiva");
        append(">> "+label);
        out.write((label+"\r").getBytes(StandardCharsets.US_ASCII));
        out.flush();
        setStatus("CAN LAB — "+diagLabel+" • OBD pausado");
        return true;
    }

    private boolean isOk(String s){
        if(s==null)return false;
        String u=s.toUpperCase(Locale.US);
        return u.contains("OK");
    }
    private String safeDiag(String s){return s==null||s.trim().isEmpty()?"—":s.replace("\n"," / ").replace("\r"," ").trim();}

    private void drainInput(long quietMs){
        if(in==null)return;
        long end=System.currentTimeMillis()+quietMs;
        int drained=0;
        try{
            while(System.currentTimeMillis()<end){
                if(in.available()>0){
                    int x=in.read();
                    if(x<0)break;
                    drained++;
                    end=System.currentTimeMillis()+40;
                }else Thread.sleep(4);
            }
        }catch(Exception e){ append("AVISO: falha ao drenar buffer antes do Monitor All: "+e.getClass().getSimpleName()); }
        if(drained>0) append("Buffer ELM drenado antes da captura: "+drained+" bytes.");
    }

    private boolean monitorLoop() throws IOException {
        ByteArrayOutputStream line=new ByteArrayOutputStream();
        ByteArrayOutputStream binary=new ByteArrayOutputStream();
        byte[] buf=new byte[1024]; long lastUi=0;
        while(monitoring){
            int n=in.read(buf);
            if(n<0) throw new IOException("socket fechado durante Monitor All");
            if(n==0) continue;
            rxBytes+=n;
            for(int i=0;i<n;i++){
                int x=buf[i]&0xFF;
                // ELM returns the prompt as a single '>' character; detect it immediately
                // so FINALIZAR CAPTURA does not depend on a trailing CR/LF.
                if(x=='>'){
                    if(line.size()>0) flushMonitorLine(line);
                    if(binary.size()>0) flushMonitorBinary(binary);
                    processMonitorRaw(">");
                    if(stopRequested) break;
                    continue;
                }
                if(x=='\r'||x=='\n'){
                    flushMonitorBinary(binary);
                    flushMonitorLine(line);
                } else if(x>=32&&x<=126){
                    if(binary.size()>0) flushMonitorBinary(binary);
                    line.write(x);
                    if(line.size()>2048) flushMonitorLine(line);
                } else {
                    if(line.size()>0) flushMonitorLine(line);
                    binary.write(x);
                    if(binary.size()>=256) flushMonitorBinary(binary);
                }
            }
            if(System.currentTimeMillis()-lastUi>200){ lastUi=System.currentTimeMillis(); updateStats(); }
        }
        if(line.size()>0) flushMonitorLine(line);
        if(binary.size()>0) flushMonitorBinary(binary);
        return !monitorRejected && stopRequested;
    }
    private void flushMonitorLine(ByteArrayOutputStream line){ if(line.size()==0)return; String s=new String(line.toByteArray(),StandardCharsets.US_ASCII).trim();line.reset();if(s.isEmpty())return;processMonitorRaw(s); }
    private void flushMonitorBinary(ByteArrayOutputStream binary){
        if(binary.size()==0)return;
        byte[] b=binary.toByteArray(); binary.reset();
        StringBuilder h=new StringBuilder();
        for(byte v:b){ if(h.length()>0) h.append(' '); h.append(String.format(Locale.US,"%02X",v&0xFF)); }
        rawCount++;
        synchronized(logLock){ technical.append("[MONITOR HEX] ").append(h).append('\n'); }
        if(rawCount<=8||rawCount%50==0) append("RAW HEX #"+rawCount+": "+h);
    }
    private void processMonitorRaw(String s){
        String u=s.toUpperCase(Locale.US).trim();
        // ELM control responses are not CAN frames and must never inflate the CAN counters.
        if(u.equals("OK")||u.equals(">")||u.equals("STOPPED")||u.contains("SEARCHING")||u.contains("NO DATA")){
            append("ELM CONTROL (fora da captura CAN): "+u);
            if(u.equals(">") && stopRequested){ canDiagUi("ELM: conectado\nPROTOCOLO: ativo\nCMD: monitor passivo\nRX: >\nESTADO: prompt recebido — captura finalizada"); monitoring=false; append("<< > — ELM retornou ao prompt; captura encerrada corretamente."); append("=== FIM DA CAPTURA CAN PASSIVA ==="); append("RAW RECEBIDOS: "+rawCount+" | FRAMES DECODIFICADOS: "+frameCount+" | IDS: "+ids.size()+" | BYTES: "+rxBytes); setStatus("Captura finalizada — retomando OBD"); setHealth("YELLOW","RETOMANDO OBD"); updateStats(); return; }
            if(u.equals(">") && !stopRequested && System.currentTimeMillis()-monitorStartedAt<2500){
                monitorRejected=true;
                canDiagUi("ELM: conectado\nPROTOCOLO: ativo\nCMD: monitor passivo\nRX: >\nESTADO: teste rejeitado — tentando próxima estratégia");
                append("PROMPT IMEDIATO: estratégia de monitoramento não permaneceu ativa.");
                monitoring=false;
                return;
            }
            return;
        }
        rawCount++;
        canDiagUi("ELM: conectado\nPROTOCOLO: ativo\nCMD: AT MA\nRX: "+s.replace("\n"," / ")+"\nESTADO: dados recebidos");
        synchronized(logLock){technical.append("[MONITOR RAW] ").append(s).append('\n');}
        if(u.contains("BUFFER FULL")){append("!! ELM REPORTOU BUFFER FULL — RAW preservado.");updateStats();return;}
        ParsedCan pc=parseCan(s);
        if(pc.ok){frameCount++; ids.add(pc.id); synchronized(canDataLock){idCounts.put(pc.id,idCounts.getOrDefault(pc.id,0L)+1L); recentCanFrames.addLast(pc.id+"  ["+pc.data+"]"); while(recentCanFrames.size()>80)recentCanFrames.removeFirst();} if(frameCount<=8||frameCount%50==0)append("CAN "+pc.id+" DLC="+pc.dlc+" DATA="+pc.data);}
        else if(rawCount<=8||rawCount%100==0){append("RAW não classificado #"+rawCount+": "+s);}
        updateStats();
    }
    static class ParsedCan {boolean ok;String id="",data="";int dlc;}
    private ParsedCan parseCan(String s){
        ParsedCan p=new ParsedCan();
        String clean=s.replaceAll("[^0-9A-Fa-f ]"," ").trim().replaceAll("\\s+"," ");
        if(clean.isEmpty())return p;
        String[] a=clean.split(" ");
        // Clone ELMs may emit compact Monitor All lines such as 7E803412FCD.
        if(a.length==1){
            String z=a[0].toUpperCase(Locale.US);
            Matcher cm=Pattern.compile("^([0-9A-F]{3}|[0-9A-F]{8})([0-8])([0-9A-F]{2,16})$").matcher(z);
            if(cm.matches()){
                int d=Integer.parseInt(cm.group(2),16); String data=cm.group(3);
                if(data.length()==d*2){p.ok=true;p.id=cm.group(1);p.dlc=d;StringBuilder db=new StringBuilder();for(int i=0;i<data.length();i+=2){if(db.length()>0)db.append(' ');db.append(data.substring(i,i+2));}p.data=db.toString();return p;}
            }
            return p;
        }
        // Common ELM CAN monitor forms: header followed by DLC and data.
        for(int i=1;i<a.length;i++){try{int d=Integer.parseInt(a[i],16);if(d>=0&&d<=8&&a.length>=i+1+d){String id=String.join(" ",Arrays.copyOfRange(a,0,i)); if(id.length()>=2&&id.length()<=12){p.ok=true;p.id=id;p.dlc=d;StringBuilder db=new StringBuilder();for(int j=i+1;j<a.length;j++){if(db.length()>0)db.append(' ');db.append(a[j]);}p.data=db.toString();return p;}}}catch(Exception ignored){}}
        return p;
    }
    private void canDiagUi(String text){ ui(()->{ if(canDiag!=null) canDiag.setText(text); }); }
    private void updateStats(){long now=System.currentTimeMillis();if(now-lastStatsUi<250)return;lastStatsUi=now;ui(()->{stats.setText("RAW: "+rawCount+" • FRAMES: "+frameCount+" • IDs: "+ids.size()+" • BYTES: "+rxBytes); updateCanTable();});}
    private void updateCanTable(){
        if(canTable==null)return;
        String filter=canFilterInput==null?"":canFilterInput.getText().toString().trim().toUpperCase(Locale.US);
        ArrayList<Map.Entry<String,Long>> top;
        synchronized(canDataLock){top=new ArrayList<>(idCounts.entrySet());}
        top.sort((a,b)->Long.compare(b.getValue(),a.getValue()));
        StringBuilder out=new StringBuilder(); int shown=0;
        if(top.isEmpty()) out.append("AGUARDANDO FRAMES CAN…");
        else { out.append(String.format(Locale.US,"%-6s %8s %8s\n","ID","FRAMES","PERCENT")); out.append("--------------------------------\n"); long total=Math.max(1,frameCount);
            for(Map.Entry<String,Long> e:top){String id=e.getKey(); if(!filter.isEmpty()&&!id.toUpperCase(Locale.US).contains(filter))continue; double pct=e.getValue()*100.0/total; out.append(String.format(Locale.US,"%-6s %8d %7.1f%%\n",id,e.getValue(),pct)); if(++shown>=12)break;}
            if(shown==0)out.append("Nenhum ID corresponde ao filtro.\n"); }
        synchronized(canDataLock){if(!recentCanFrames.isEmpty()){out.append("\nÚLTIMOS FRAMES:\n"); Iterator<String> it=recentCanFrames.descendingIterator(); int n=0; while(it.hasNext()&&n<4){String line=it.next(); if(filter.isEmpty()||line.toUpperCase(Locale.US).contains(filter)){out.append(line).append('\n');n++;}}}}
        canTable.setText(out.toString()); if(canFilterHint!=null)canFilterHint.setText(top.size()+" IDs • "+frameCount+" frames • atualização automática");
    }
    private void clearCanCapture(){if(monitoring||operationRunning){toast("Finalize a captura CAN antes de limpar");return;} synchronized(canDataLock){idCounts.clear();ids.clear();recentCanFrames.clear();markers.clear();} rawCount=frameCount=rxBytes=0; updateStats(); append("CAN INVESTIGATOR 2.0: captura limpa — conexão preservada.");}
    private void copyCanSummary(){String text; synchronized(canDataLock){StringBuilder b=new StringBuilder("VIRTUS ELM — CAN INVESTIGATOR 2.0\n"); b.append("RAW=").append(rawCount).append(" | FRAMES=").append(frameCount).append(" | IDS=").append(ids.size()).append(" | BYTES=").append(rxBytes).append("\n"); ArrayList<Map.Entry<String,Long>> top=new ArrayList<>(idCounts.entrySet()); top.sort((a,c)->Long.compare(c.getValue(),a.getValue())); int lim=Math.min(20,top.size()); for(int i=0;i<lim;i++)b.append(top.get(i).getKey()).append(" = ").append(top.get(i).getValue()).append(" frames\n"); text=b.toString();} ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("CAN INVESTIGATOR 2.0",text)); toast("RESUMO CAN COPIADO");}
    private void mark(String type){
        if(!monitoring){append("MARCADOR ignorado: captura não está ativa");return;}
        Marker m; synchronized(canDataLock){m=new Marker(type,rawCount,frameCount,rxBytes,idCounts);} markers.add(m);
        append("*** MARCADOR "+type+" | RAW="+m.raw+" | FRAMES="+m.frames+" | BYTES="+m.bytes+" | IDS="+m.idsAt.size()+" | "+sdf.format(new Date(m.when))+" ***");
    }
    private void stopMonitor(){
        if(!monitoring){ toast("Nenhuma captura CAN ativa"); return; }
        stopRequested=true; stopDeadline=System.currentTimeMillis()+8000;
        try{ if(out!=null){ out.write('\r'); out.flush(); append(">> [INTERRUPÇÃO] 1 caractere enviado ao ELM"); } }catch(Exception e){ append("ERRO AO ENVIAR INTERRUPÇÃO: "+e); }
        setStatus("Finalizando captura CAN…");
        main.postDelayed(()->{
            if(monitoring && System.currentTimeMillis()>=stopDeadline){
                monitoring=false; operationRunning=false;
                append("TIMEOUT: ELM não retornou o prompt. A conexão será reiniciada automaticamente; log e marcadores serão preservados.");
                intentionalDisconnect=false; closeSocket();
                append("=== FIM DA CAPTURA CAN PASSIVA — TIMEOUT ===");
                setStatus("Captura finalizada — reconectando ELM"); setHealth("RED","RECONEXÃO AUTOMÁTICA");
                scheduleReconnect(); updateStats();
            }
        },8100);
    }
    private void analyze(){
        if(markers.isEmpty()){append("=== ANÁLISE DIFERENCIAL DE EVENTOS ===");append("Nenhum marcador registrado.");return;}
        append("=== ANÁLISE DIFERENCIAL DE EVENTOS ===");
        for(int i=0;i<markers.size();i++){
            Marker m=markers.get(i); append("EVENTO "+(i+1)+": "+m.type+" | RAW="+m.raw+" | FRAMES="+m.frames+" | BYTES="+m.bytes+" | IDS="+m.idsAt.size()+" | "+sdf.format(new Date(m.when)));
            if(i>0){
                Marker prev=markers.get(i-1);
                LinkedHashMap<String,Long> delta=new LinkedHashMap<>();
                for(Map.Entry<String,Long> e:m.idsAt.entrySet()){long before=prev.idsAt.getOrDefault(e.getKey(),0L);long d=e.getValue()-before;if(d>0)delta.put(e.getKey(),d);}
                ArrayList<Map.Entry<String,Long>> top=new ArrayList<>(delta.entrySet()); top.sort((a,b)->Long.compare(b.getValue(),a.getValue()));
                if(top.isEmpty()) append("  DIFERENCIAL: nenhum ID CAN novo entre os marcadores.");
                else {StringBuilder z=new StringBuilder("  IDS ATIVOS NO INTERVALO: ");int lim=Math.min(12,top.size());for(int j=0;j<lim;j++){if(j>0)z.append(", ");z.append(top.get(j).getKey()).append("(").append(top.get(j).getValue()).append("x)");}append(z.toString());}
            }
        }
        append("A análise identifica candidatos por mudança de tráfego entre marcadores; ela NÃO envia quadros CAN nem tenta acionar funções do veículo.");
        showResult("Marcadores: "+markers.size()+"\nRAW: "+rawCount+"\nFrames: "+frameCount+"\nIDs: "+ids.size()+"\nVeja no LOG os IDs que mudaram entre cada evento.");
    }

    private void copyLog(){String text; synchronized(logLock){text=technical.toString();} if(text.isEmpty()){toast("Log vazio");return;} ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("VIRTUS ELM V11.6.12 — LOG",text));toast("LOG COPIADO");}
    private void clearLog(){ if(monitoring||operationRunning){toast("Finalize a operação antes de limpar o log");return;} synchronized(logLock){technical.setLength(0);} log.setText(""); if(result!=null)result.setText("RESULTADO: —"); if(resultHome!=null)resultHome.setText("RESULTADO: —"); rawCount=frameCount=rxBytes=0;ids.clear();markers.clear();stats.setText("RAW: 0 • FRAMES: 0 • IDs: 0 • BYTES: 0");append("[00] LOG LIMPO — V11.4 • conexão Bluetooth preservada"); if(logScroll!=null)logScroll.post(()->logScroll.fullScroll(View.FOCUS_DOWN)); setStatus(connected?"Conectado — log limpo":"Bluetooth não conectado"); }
    private void toast(String s){ui(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
    private void setStatus(String s){ui(()->{ if(status!=null) status.setText("Status: "+s); });}
    private void ui(Runnable r){main.post(r);}
    private void append(String s){ if(!isTechLogEnabled()) return; String line="["+sdf.format(new Date())+"] "+s; synchronized(logLock){technical.append(line).append('\n');} ui(()->{if(log!=null){log.append(line+"\n"); if(logScroll!=null)logScroll.post(()->logScroll.fullScroll(View.FOCUS_DOWN));}});}
    private void safeUnexpectedDisconnect(Exception cause){ if(intentionalDisconnect) return; boolean wasConnected=connected || socket!=null; connected=false; try{closeSocket();}catch(Exception ignored){} if(wasConnected){ append("CONEXÃO PERDIDA — preservando log e tentando reconexão automática."); setStatus("Conexão perdida — reconectando automaticamente"); scheduleReconnect(); } }
    private void scheduleReconnect(){ if(reconnecting||intentionalDisconnect||bt==null) return; reconnecting=true; dashboardExec.schedule(()->{ reconnecting=false; if(!intentionalDisconnect && !connected && !monitoring && !operationRunning) io.execute(()->connectWorker()); },1500,TimeUnit.MILLISECONDS); }
    private void closeSocket(){ connected=false; try{if(in!=null)in.close();}catch(Exception ignored){}try{if(out!=null)out.close();}catch(Exception ignored){}try{if(socket!=null)socket.close();}catch(Exception ignored){}in=null;out=null;socket=null;}
    @Override protected void onResume(){ super.onResume(); applyKeepScreenPreference(); }

    private boolean isKeepScreenOnEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_KEEP_SCREEN,true); }
    private boolean isRealtimeDataEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_REALTIME_DATA,true); }
    private boolean isTechLogEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_TECH_LOG,false); }
    private boolean isPerformanceHistoryEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_PERF_HISTORY,true); }
    private boolean isAutoSimulationEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_AUTO_SIM,true); }
    private boolean isAutoConnectEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_AUTO_CONNECT,true); }
    private String getPressureUnit(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getString(PREF_PRESSURE_UNIT,"bar"); }
    private String getSpeedUnit(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getString(PREF_SPEED_UNIT,"km/h"); }
    private double displaySpeed(double kmh){ return "mph".equals(getSpeedUnit()) ? kmh*0.621371 : kmh; }
    private String speedUnitLabel(){ return getSpeedUnit(); }
    private double displayPressureBar(double bar){ return "kPa".equals(getPressureUnit()) ? bar*100.0 : bar; }
    private String pressureUnitLabel(){ return getPressureUnit(); }
    // ===== V12.0-FIX10.3 — BASE HISTÓRICA EMBARCADA =====
    // Copia os três testes fornecidos pelo usuário para Download/VirtusELM/logs/
    // somente quando o arquivo correspondente ainda não existir. Isso torna a
    // base histórica disponível imediatamente após a instalação/atualização.
    private void seedBundledPerformanceHistory(){
        final String[] files={
            "VirtusELM_Performance_20261006_142242.csv",
            "VirtusELM_Performance_20261007_164420.csv",
            "VirtusELM_Performance_20261007_165229.csv"
        };
        for(String name:files){
            try{
                if(Build.VERSION.SDK_INT>=29){
                    if(publicDownloadCsvExists(name)) continue;
                    String assetPath="history_seed/"+name;
                    ContentValues v=new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME,name);
                    v.put(MediaStore.Downloads.MIME_TYPE,"text/csv");
                    v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/VirtusELM/logs/");
                    v.put(MediaStore.Downloads.IS_PENDING,1);
                    Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                    if(u==null) continue;
                    try(InputStream inA=getAssets().open(assetPath); OutputStream outA=getContentResolver().openOutputStream(u,"w")){
                        if(outA==null) throw new IOException("output nulo");
                        byte[] buf=new byte[8192]; int n; while((n=inA.read(buf))!=-1) outA.write(buf,0,n);
                    }
                    ContentValues done=new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING,0); getContentResolver().update(u,done,null,null);
                }else{
                    File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs");
                    if(!dir.exists()&&!dir.mkdirs()) continue;
                    File dst=new File(dir,name); if(dst.exists()) continue;
                    try(InputStream inA=getAssets().open("history_seed/"+name); OutputStream outA=new FileOutputStream(dst)){
                        byte[] buf=new byte[8192]; int n; while((n=inA.read(buf))!=-1) outA.write(buf,0,n);
                    }
                }
            }catch(Exception ignored){}
        }
        ui(()->{ if(historyScreen!=null) loadHistorySessions(); });
    }
    private boolean publicDownloadCsvExists(String name){
        Cursor c=null;
        try{
            String[] pr={MediaStore.Downloads._ID,MediaStore.Downloads.DISPLAY_NAME,MediaStore.Downloads.RELATIVE_PATH};
            c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,pr,MediaStore.Downloads.DISPLAY_NAME+"=?",new String[]{name},null);
            if(c!=null) while(c.moveToNext()){
                String path=c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.RELATIVE_PATH));
                if(path!=null && path.contains("Download/VirtusELM/logs/")) return true;
            }
        }catch(Exception ignored){} finally{ if(c!=null)c.close(); }
        return false;
    }

    private void openPerformanceHistory(){
        if(historyWriter!=null||!isPerformanceHistoryEnabled())return;
        try{
            String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
            String name="VirtusELM_Performance_"+stamp+".csv";
            OutputStream os=null;
            if(Build.VERSION.SDK_INT>=29){
                ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,name); v.put(MediaStore.Downloads.MIME_TYPE,"text/csv"); v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/VirtusELM/logs/"); v.put(MediaStore.Downloads.IS_PENDING,1);
                historyUri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(historyUri==null)throw new IOException("Não foi possível criar o arquivo público de histórico"); os=getContentResolver().openOutputStream(historyUri,"w");
            }else{
                File base=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs"); if(!base.exists()&&!base.mkdirs())throw new IOException("Não foi possível criar Download/VirtusELM/logs"); historyLegacyFile=new File(base,name); os=new FileOutputStream(historyLegacyFile,false);
            }
            historyWriter=new BufferedWriter(new OutputStreamWriter(os,StandardCharsets.UTF_8)); historySamples=0;
            historyWriter.write("tipo;timestamp_ms;hora;rpm;speed_kmh;gps_speed_kmh;speed_source;map_kpa;baro_kpa;boost_bar;boost_max_bar;throttle_pct;load_pct;coolant_c;intake_c;oil_temp_c;oil_level;fuel_pct;voltage_v;vin;ethanol_pct;power_est_cv;torque_est_nm;zero60_s;zero100_s;quality_pct;pull_duration_s;gear_shifts;pedal_d_pct;pedal_e_pct;pedal_f_pct\n"); historyWriter.flush();
            append("HISTÓRICO DE PERFORMANCE: arquivo persistente iniciado em Download/VirtusELM/logs/");
        }catch(Exception e){ historyWriter=null; historyUri=null; append("AVISO: histórico de performance não pôde ser iniciado — "+e.getClass().getSimpleName()); }
    }
    private void closePerformanceHistory(){
        try{if(historyWriter!=null){historyWriter.flush();historyWriter.close();}}catch(Exception ignored){} historyWriter=null;
        if(Build.VERSION.SDK_INT>=29&&historyUri!=null){ try{ContentValues v=new ContentValues();v.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(historyUri,v,null,null);}catch(Exception ignored){} }
        historyUri=null; historyLegacyFile=null;
    }
    private void writePerformanceHistorySample(){
        if(historyWriter==null)return; try{String now=new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date()); int ethanol=getPerformanceEthanolPct(); historyWriter.write("TELEMETRIA;"+System.currentTimeMillis()+";"+now+";"+fmt(lastRpm)+";"+fmt(lastSpeed)+";"+fmt(lastGpsSpeed)+";"+(isGpsSpeedValid()?"GPS":"CAN")+";"+fmt(lastMap)+";"+fmt(lastBaro)+";"+fmt(lastBoost)+";"+fmt(maxBoost)+";"+fmt(lastThrottle)+";"+fmt(lastLoad)+";"+fmt(lastCoolant)+";"+fmt(lastIntake)+";"+fmt(lastOilTemp)+";"+lastOilLevel+";"+fmt(lastFuel)+";"+fmt(lastVolt)+";"+(lastVin==null?"":lastVin)+";"+(ethanol>=0?ethanol:"")+";;;;;;\n"); historyWriter.flush(); historySamples++;}catch(Exception e){append("HISTÓRICO: erro de gravação — "+e.getClass().getSimpleName());}
    }
    private void persistPerformancePull(int samples,ArrayList<PerfGraphSample> graphSamples){
        long ts=System.currentTimeMillis();String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(new Date(ts));String name="VirtusELM_Pull_"+stamp+".csv";
        String header="tipo;timestamp_ms;hora;rpm;speed_kmh;gps_speed_kmh;speed_source;map_kpa;baro_kpa;boost_bar;boost_max_bar;throttle_pct;load_pct;coolant_c;intake_c;oil_temp_c;oil_level;fuel_pct;voltage_v;vin;ethanol_pct;power_est_cv;torque_est_nm;zero60_s;zero100_s;quality_pct;pull_duration_s;gear_shifts;pedal_d_pct;pedal_e_pct;pedal_f_pct;speed_grid;samples;elapsed_s\n";
        String now=new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date(ts));int ethanol=getPerformanceEthanolPct();String row="PERFORMANCE_TEST;"+ts+";"+now+";"+fmt(lastPerfMaxRpm>=0?lastPerfMaxRpm:lastRpm)+";"+fmt(lastPerfMaxSpeed>=0?lastPerfMaxSpeed:lastSpeed)+";"+fmt(lastGpsSpeed)+";"+(isGpsSpeedValid()?"GPS":"CAN")+";"+fmt(lastMap)+";"+fmt(lastBaro)+";"+fmt(lastBoost)+";"+fmt(lastPerfMaxBoost>=0?lastPerfMaxBoost:maxBoost)+";"+fmt(lastThrottle)+";"+fmt(lastLoad)+";"+fmt(lastCoolant)+";"+fmt(lastIntake)+";"+fmt(lastOilTemp)+";"+lastOilLevel+";"+fmt(lastFuel)+";"+fmt(lastVolt)+";"+(lastVin==null?"":lastVin)+";"+(ethanol>=0?ethanol:"")+";"+fmt(lastPerfPower)+";"+fmt(lastPerfTorque)+";"+fmt(lastPerf0060)+";"+fmt(lastPerf0100)+";"+fmt(lastPerfQuality)+";"+fmt(lastPerfPullDuration)+";"+lastPerfGearShifts+";"+fmt(lastPedalD)+";"+fmt(lastPedalE)+";"+fmt(lastPedalF)+";"+lastPerfSpeedGrid+";"+samples+";\n";
        try{
            if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,"text/csv");v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/VirtusELM/logs/");v.put(MediaStore.Downloads.IS_PENDING,1);Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new IOException("não foi possível criar arquivo de puxada");try(OutputStream os=getContentResolver().openOutputStream(u,"w")){if(os==null)throw new IOException("saída nula");StringBuilder csv=new StringBuilder(header).append(row); for(PerfGraphSample gs:graphSamples){csv.append("PERFORMANCE_SAMPLE;").append(ts).append(";").append(now).append(";").append(fmt(gs.rpm)).append(";").append(fmt(gs.speed)).append(";;GPS;").append(fmt(lastMap)).append(";").append(fmt(lastBaro)).append(";").append(fmt(gs.boost)).append(";").append(fmt(lastPerfMaxBoost)).append(";").append(fmt(gs.pedal)).append(";" ).append(fmt(lastLoad)).append(";").append(fmt(lastCoolant)).append(";").append(fmt(lastIntake)).append(";").append(fmt(lastOilTemp)).append(";").append(lastOilLevel).append(";").append(fmt(lastFuel)).append(";").append(fmt(lastVolt)).append(";").append(lastVin==null?"":lastVin).append(";").append(ethanol>=0?ethanol:"").append(";").append(fmt(lastPerfPower)).append(";").append(fmt(lastPerfTorque)).append(";").append(fmt(lastPerf0060)).append(";").append(fmt(lastPerf0100)).append(";").append(fmt(lastPerfQuality)).append(";").append(fmt(lastPerfPullDuration)).append(";").append(lastPerfGearShifts).append(";").append(fmt(lastPedalD)).append(";").append(fmt(lastPedalE)).append(";").append(fmt(lastPedalF)).append(";").append(lastPerfSpeedGrid).append(";").append(samples).append(";").append(String.format(Locale.US,"%.3f",gs.t)).append("\n");} os.write(csv.toString().getBytes(StandardCharsets.UTF_8));}ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(u,done,null,null);
            }else{File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs");if(!dir.exists()&&!dir.mkdirs())throw new IOException("pasta não disponível");try(Writer w=new OutputStreamWriter(new FileOutputStream(new File(dir,name)),StandardCharsets.UTF_8)){w.write(header);w.write(row); for(PerfGraphSample gs:graphSamples){w.write("PERFORMANCE_SAMPLE;"+ts+";"+now+";"+fmt(gs.rpm)+";"+fmt(gs.speed)+";;GPS;"+fmt(lastMap)+";"+fmt(lastBaro)+";"+fmt(gs.boost)+";"+fmt(lastPerfMaxBoost)+";"+fmt(gs.pedal)+";"+fmt(lastLoad)+";"+fmt(lastCoolant)+";"+fmt(lastIntake)+";"+fmt(lastOilTemp)+";"+lastOilLevel+";"+fmt(lastFuel)+";"+fmt(lastVolt)+";"+(lastVin==null?"":lastVin)+";"+(ethanol>=0?ethanol:"")+";"+fmt(lastPerfPower)+";"+fmt(lastPerfTorque)+";"+fmt(lastPerf0060)+";"+fmt(lastPerf0100)+";"+fmt(lastPerfQuality)+";"+fmt(lastPerfPullDuration)+";"+lastPerfGearShifts+";"+fmt(lastPedalD)+";"+fmt(lastPedalE)+";"+fmt(lastPedalF)+";"+lastPerfSpeedGrid+";"+samples+";"+String.format(Locale.US,"%.3f",gs.t)+"\n");}}}
            append("PUXADA ARQUIVADA: "+name+" • "+samples+" amostras");ui(()->{if(historyScreen!=null)loadHistorySessions();});
        }catch(Exception e){append("ERRO AO ARQUIVAR PUXADA: "+e.getClass().getSimpleName());ui(()->toast("Não foi possível arquivar a puxada: "+e.getClass().getSimpleName()));}
    }
    private void writePerformanceEvent(){
        if(historyWriter==null)return; try{String now=new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date()); int ethanol=getPerformanceEthanolPct(); historyWriter.write("PERFORMANCE_TEST;"+System.currentTimeMillis()+";"+now+";"+fmt(lastPerfMaxRpm>=0?lastPerfMaxRpm:lastRpm)+";"+fmt(lastPerfMaxSpeed>=0?lastPerfMaxSpeed:lastSpeed)+";"+fmt(lastGpsSpeed)+";"+(isGpsSpeedValid()?"GPS":"CAN")+";"+fmt(lastMap)+";"+fmt(lastBaro)+";"+fmt(lastBoost)+";"+fmt(lastPerfMaxBoost>=0?lastPerfMaxBoost:maxBoost)+";"+fmt(lastThrottle)+";"+fmt(lastLoad)+";"+fmt(lastCoolant)+";"+fmt(lastIntake)+";"+fmt(lastOilTemp)+";"+lastOilLevel+";"+fmt(lastFuel)+";"+fmt(lastVolt)+";"+(lastVin==null?"":lastVin)+";"+(ethanol>=0?ethanol:"")+";"+fmt(lastPerfPower)+";"+fmt(lastPerfTorque)+";"+fmt(lastPerf0060)+";"+fmt(lastPerf0100)+";"+fmt(lastPerfQuality)+";"+fmt(lastPerfPullDuration)+";"+lastPerfGearShifts+";"+fmt(lastPedalD)+";"+fmt(lastPedalE)+";"+fmt(lastPedalF)+";"+lastPerfSpeedGrid+"\n"); historyWriter.flush();}catch(Exception e){append("HISTÓRICO: erro ao registrar teste de performance — "+e.getClass().getSimpleName());}
    }
    private boolean isHapticEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_HAPTIC,true); }
    private void applyKeepScreenPreference(){ if(isKeepScreenOnEnabled()) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); }

    @Override protected void onDestroy(){intentionalDisconnect=true;monitoring=false;stopRequested=true;if(recordingActive){recordingActive=false;closeRecordingWriter();stopRecordingKeepAlive();}closePerformanceHistory();stopGpsTracking();closeSocket();io.shutdownNow();dashboardExec.shutdownNow();super.onDestroy();}
}
