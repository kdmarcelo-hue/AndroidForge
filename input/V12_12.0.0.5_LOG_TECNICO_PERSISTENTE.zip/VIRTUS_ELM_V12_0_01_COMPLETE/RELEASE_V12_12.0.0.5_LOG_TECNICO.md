# V12 12.0.0.5 — LOG técnico persistente

## Implementado
- LOG técnico detalhado ativado por padrão nas preferências.
- Cada operação executada por `runOp` cria um arquivo TXT independente.
- O TXT registra versão/build, VIN disponível, modo de transporte, protocolo, nome da operação, horário de início/fim e status.
- `send()` registra requisições TX, respostas RX, respostas vazias e erros de comunicação.
- `append()` registra eventos no arquivo da investigação mesmo quando a tela de log técnico não está aberta.
- `showResult()` persiste o resultado integral apresentado pela operação.
- Configurações ganhou a ação **EXPORTAR LOGS TÉCNICOS (.ZIP)**, que reúne os TXT e solicita ao Android onde salvar/compartilhar.
- Restaurar configurações padrão mantém o LOG técnico ativado.
- Versão paralela: applicationId `v12.marcelo.virtuselm.v12_0_0_5`, versionCode `15`, versionName `12.0.0.5`.

## Armazenamento
Os TXT são gravados no diretório privado externo do aplicativo (`Android/data/<applicationId>/files/diagnosticos`). A exportação cria um ZIP por meio do seletor de documentos do Android, sem exigir permissão ampla de armazenamento.

## Limites conhecidos
- O registro automático cobre as operações executadas pelo fluxo `runOp` e os comandos enviados pelo método `send()`. Eventos de telemetria contínua que não passem por `runOp` não são convertidos em arquivos de investigação.
- Não foi possível executar build Android neste ambiente: o projeto contém apenas `gradle-wrapper.properties`, sem `gradlew` e sem `gradle-wrapper.jar`; Gradle não está instalado.
- A validação final depende do GitHub Actions e do teste físico com ELM327.
