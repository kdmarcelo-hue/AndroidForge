V12 12.0.0.4 — CORREÇÃO DE ARQUIVOS TEMPORÁRIOS LOG

- Ignora arquivos temporários .pending-*, .pending_*, .pending, .tmp e .part durante a deduplicação.
- Aplicado às três origens de listagem: SAF, MediaStore e diretório legado.
- Arquivos temporários não são abertos, hasheados, contados nem excluídos.
- CSVs definitivos continuam sujeitos à comparação SHA-256 e à confirmação explícita já existente.
- Nenhum arquivo do usuário é removido automaticamente.

Identidade Android: applicationId v12.marcelo.virtuselm.v12_0_0_4; versionCode 14; versionName 12.0.0.4.
Build Android não executado neste ambiente.
