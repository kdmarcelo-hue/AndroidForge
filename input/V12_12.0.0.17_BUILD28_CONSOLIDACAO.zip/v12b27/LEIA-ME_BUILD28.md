# V12 12.0.0.17 — BUILD28

Pacote de código-fonte para envio ao repositório GitHub `AndroidForge`, pasta `input/`.

## Identificação
- Versão: 12.0.0.17
- BUILD: 28
- versionCode: 28
- applicationId: v12.marcelo.virtuselm.v12_0_17
- Nome exibido: V12

## Instalação paralela
O `applicationId` desta BUILD é exclusivo e diferente da BUILD27. O Android deve permitir manter as duas instalações lado a lado. Não desinstale a BUILD27 para instalar esta versão.

## Envio
1. Envie este ZIP para `input/` na branch `main`.
2. Faça commit.
3. Aguarde `V12 Automatic Build` terminar com sucesso.
4. Baixe o artefato `V12-V12_12.0.0.17_BUILD28_CONSOLIDACAO-debug` na execução correspondente.
5. Confira o APK gerado antes de instalar.

## Escopo desta BUILD
- Gráfico: linha instantânea BOOST amarela; envelope de pico translúcido; valor numérico alinhado à altura do pico; sem texto `PICO:`.
- Performance: instrumentos coloridos; ponteiro instantâneo; centro do BOOST exibe máximo da sessão.
- Descoberta: varredura complementar CAN 29-bit e tentativa independente do DID 2A26 no endereço candidato 710/77A.
- Instalação paralela por applicationId exclusivo.

## Limitações conhecidas
A BUILD ainda não conclui identificação de todos os módulos VW nem parser integral de DTC. A arquitetura Bluetooth ainda não foi refatorada para que o serviço seja proprietário do socket/fila. Essas tarefas permanecem explicitamente pendentes na auditoria e matriz de testes incluídas no ZIP. Não considerar compilação como validação no veículo.
