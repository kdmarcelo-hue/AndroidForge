# BUILD28 — Matriz de validação obrigatória

| ID | Teste | Critério de aceite | Estado antes do teste no veículo |
|---|---|---|---|
| B28-01 | Instalação paralela | BUILD27 e BUILD28 aparecem separadamente como V12 | Implementado no identificador; testar no Android |
| B28-02 | Inicialização | BUILD28 abre sem crash e mostra 12.0.0.17 | Pendente de APK |
| B28-03 | Gráfico sem dados | BOOST/RPM permanecem nas posições e cores definidas; sem texto PICO | Revisão estática |
| B28-04 | BOOST ao vivo | Linha amarela acompanha amostras válidas | Pendente no veículo |
| B28-05 | Envelope de pico | Traço acumulado translúcido fica abaixo/atrás da linha instantânea | Revisão estática |
| B28-06 | Valor na escala | Valor numérico do pico fica alinhado à linha horizontal, sem rótulo | Revisão estática |
| B28-07 | Histórico | Pico é recalculado para a puxada selecionada | Pendente em teste de histórico |
| B28-08 | Performance RPM | Escala ciano e zona vermelha; ponteiro acompanha RPM | Pendente no veículo |
| B28-09 | Performance BOOST | Ponteiro acompanha pressão instantânea; centro mostra máximo da sessão | Revisão estática; pendente no veículo |
| B28-10 | Performance velocidade | Escala azul/ciano; ponteiro acompanha velocidade | Pendente no veículo |
| B28-11 | Reinício de sessão | Pico anterior não contamina nova puxada | Código reinicia variáveis; validar no veículo |
| B28-12 | Descoberta CAN 11 bits | Correlacionar TX/RX e guardar RAW | Pendente no veículo |
| B28-13 | Descoberta CAN 29 bits | Executar duas famílias complementares mesmo com 11-bit respondendo | Implementado; varredura pode levar vários minutos |
| B28-14 | Gateway DID 2A26 | Registrar resposta RAW e aceitar apenas bitmap validado | Tentativa independente implementada; validar no veículo |
| B28-15 | Identidade de módulos | Não inferir nome de módulo apenas pelo endereço | Regra preservada |
| B28-16 | DTC por módulo | Preservar RAW; não declarar parser completo | Parser completo permanece pendente |
| B28-17 | Bluetooth | Navegar entre telas sem perder sessão | Arquitetura definitiva permanece pendente |
| B28-18 | Regressão | Diagnóstico, histórico, gravação, CUSTOM e navegação continuam funcionando | Exige testes funcionais |

## Avisos
- A varredura 29-bit executa até 512 probes adicionais. Com o timeout configurado, pode levar alguns minutos. Não iniciar durante condução; veículo parado e em condição segura.
- Não executar comandos de escrita, codificação, adaptação, Security Access ou limpeza de DTC durante a engenharia reversa.
- Build concluído não significa validação no veículo.
