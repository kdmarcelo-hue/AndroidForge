# V12 12.0.0.14 — BUILD 25 (candidato de validação)

## Identificação
- `versionName`: `12.0.0.14` (mantido)
- `versionCode`: `25` (incrementado somente o código interno da build)
- `applicationId`: `v12.marcelo.virtuselm.v12_0_14` (mantido para preservar instalação paralela)

## Implementado nesta BUILD

### 1. Painel único de diagnóstico
- A tela de diagnóstico deixa de criar quadros separados para DTC, VAG Explorer e resultado geral.
- Status, lista de DTC, RAW e resultado de investigação passam a compartilhar um único painel.
- As rotinas legadas do VAG Explorer apontam para a mesma área de resultado.
- A seleção de consultas permanece separada do painel de resultados.

### 2. Pico de boost no gráfico combinado
- A linha de pico é desenhada depois das curvas, garantindo prioridade visual em primeiro plano.
- A referência passou a usar amarelo vivo, com contorno escuro para contraste.
- O rótulo passa a ser `PICO BOOST: X,XX bar`.
- O valor continua condicionado a uma amostra válida; ausência de MAP/BARO não cria pico artificial.
- A regra existente de atualização por maior amostra válida e reinício por nova puxada foi preservada.

### 3. Identificação de build
- `versionName` e `applicationId` preservados.
- `versionCode` alterado de 24 para 25.
- Nome dos artefatos do GitHub Actions atualizado para `12.0.0.14-BUILD25`.

## Testes executados neste ambiente
- Suíte Python: **46 aprovados**.
- Testes cobrem regressões estáticas do painel único, desenho da linha de pico, versionamento e regras de descoberta já presentes no código.
- Integridade do ZIP final verificada separadamente.

## Não executado / não declarar como concluído
- Compilação Android/Gradle: não executada neste ambiente (não há Gradle instalado, Gradle Wrapper executável nem Android SDK disponível).
- Teste de instalação no Android: pendente do APK produzido pelo GitHub Actions.
- Teste físico com ELM327/Virtus: pendente.
- Diagnóstico UDS: esta entrega consolida a apresentação em painel único, mas não prova que a descoberta de todas as ECUs nem a leitura de DTC por status esteja completa no veículo. A varredura multiprotocolo permanece sujeita a validação física e correlação de RAW/ISO-TP.
- Desconexão Bluetooth ao mudar para Performance: causa ainda não isolada. O código atual mantém o socket em `MainActivity` e não encerra a conexão apenas por troca de tela; é necessário capturar o log do evento para distinguir queda física, timeout/erro RX, watchdog ou recriação da Activity.
- Android Auto: não foi incluído `CarAppService` nesta BUILD. O projeto atual não possui serviço automotivo nem arquitetura OBD desacoplada da Activity. Para cumprir a exigência de uma única sessão ELM compartilhada, é necessário primeiro extrair o proprietário do socket/leitor para um serviço ou componente de sessão de processo, e então conectar as interfaces móvel e automotiva ao mesmo fluxo. Adicionar um segundo cliente Bluetooth ou um serviço Android Auto sem esse refactor violaria o requisito do usuário e poderia disputar o ELM. A categoria/compatibilidade e aprovação do Android Auto também precisam ser validadas.

## Segurança preservada
- Nenhum comando de coding, adaptação, Security Access, escrita de DID ou limpeza de DTC foi acrescentado.
- Silêncio, timeout, NRC ou ISO-TP incompleto não devem ser interpretados como ECU inexistente ou ausência de falhas.
- A BUILD é candidata de validação, não uma versão declarada como funcional em veículo.
