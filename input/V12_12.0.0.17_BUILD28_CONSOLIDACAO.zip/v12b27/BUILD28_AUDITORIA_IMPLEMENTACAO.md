# V12 12.0.0.17 — BUILD28

Base técnica: código-fonte completo da V12 12.0.0.16 / BUILD27.

## Versionamento e instalação paralela
- `versionName`: `12.0.0.17`
- `versionCode`: `28`
- `applicationId`: `v12.marcelo.virtuselm.v12_0_17`
- Nome exibido no Android: `V12`
- O novo applicationId cria uma instalação separada da linha anterior, desde que o APK anterior permaneça instalado. Dados privados e preferências não são compartilhados entre os dois pacotes.

## Gráfico combinado
- Removido o texto `PICO:` do cabeçalho lateral.
- Cabeçalho lateral preservado: `BOOST` amarelo e `RPM` verde.
- Valor numérico do maior BOOST válido é desenhado junto à escala direita, na altura horizontal correspondente ao pico, sem rótulo textual.
- Adicionada curva envelope do maior BOOST acumulado, em amarelo/dourado translúcido e mais escuro.
- Curva instantânea de BOOST continua em amarelo vivo e é desenhada por cima das demais séries.
- Amostras inválidas continuam sendo lacunas; não são convertidas em zero.

## Instrumentos Performance
- RPM: escala ciano/azul com faixa de alerta vermelha na região superior.
- BOOST: escala amarela/dourada.
- Velocidade: escala azul/ciano.
- Ponteiro dos três instrumentos indica a leitura instantânea.
- Centro do instrumento BOOST mostra o maior valor da sessão, enquanto o ponteiro continua seguindo a pressão atual.
- A escala do BOOST permanece em 0–3 bar.
- O código existente reinicia `maxBoost` e `performanceGraphBoostPeak` ao iniciar uma nova puxada; a atualização visual usa esses valores.

## Descoberta VAG — ampliação de investigação
- A varredura CAN 29-bit agora é complementar e executada mesmo quando existem endpoints 11-bit confirmados.
- São mantidas as duas famílias candidatas já existentes: `17FC00xx → 17FE00xx` e `18DAxxF1 → 18DAF1xx`.
- A consulta do Gateway candidato `710/77A`, DID `2A26`, agora é tentada independentemente de resposta anterior ao TesterPresent.
- Operações permanecem somente leitura; nenhum comando de coding, adaptação, Security Access ou limpeza de DTC foi adicionado.

## Limitações deliberadamente não declaradas como concluídas
- Varredura de endereços não equivale a identificação completa de módulos.
- O DID `2A26` continua dependente de confirmação do formato/bitmap no veículo; endereço e formato são hipóteses de investigação.
- Identificação de centrais por referência de peça, hardware e software ainda não está completa.
- DTCs UDS ainda precisam de parser integrado para código, status, contadores e dados adicionais por módulo. Nesta BUILD, o RAW é preservado.
- O serviço `ObdConnectionService` ainda não é proprietário do socket Bluetooth; a arquitetura de sessão/fila única independente da Activity continua pendente.
- Não houve teste físico no Virtus nesta entrega.

## Validação desta preparação
- Revisão estática das alterações realizada.
- `applicationId`, `versionCode` e `versionName` conferidos no `app/build.gradle`.
- Compilação Android não executada neste ambiente por ausência de Android SDK/Gradle instalado e de `gradle-wrapper.jar`; a validação final de compilação depende do workflow GitHub Actions.
