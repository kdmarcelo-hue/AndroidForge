package com.marcelo.virtuselm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/** Keeps the V12 process alive while the user temporarily backgrounds the app.
 * The Bluetooth transport is shared by MainActivity; explicit user disconnect stops this service.
 * This service does not issue diagnostic commands or compete for the ELM socket.
 */
public final class ObdConnectionService extends Service {
    public static final String ACTION_START = "com.marcelo.virtuselm.action.OBD_KEEPALIVE_START";
    private static final String CHANNEL_ID = "v12_obd_connection";
    private static final int NOTIFICATION_ID = 1206;

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(new NotificationChannel(
                    CHANNEL_ID, "V12 — Conexão OBD", NotificationManager.IMPORTANCE_LOW));
        }
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        builder.setContentTitle("V12 — conexão OBD ativa")
                .setContentText("Mantendo a sessão Bluetooth enquanto o aplicativo está em segundo plano")
                .setSmallIcon(R.drawable.ic_app_logo)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE);
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, builder.build(),
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE);
        } else startForeground(NOTIFICATION_ID, builder.build());
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "STOP".equals(intent.getAction())) {
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Do not stop: removing the task from Recents is not an explicit OBD disconnect.
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() { super.onDestroy(); stopForeground(true); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
