from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
JAVA = (ROOT / 'app/src/main/java/com/marcelo/virtuselm/MainActivity.java').read_text(encoding='utf-8')
SERVICE = (ROOT / 'app/src/main/java/com/marcelo/virtuselm/ObdConnectionService.java').read_text(encoding='utf-8')
MANIFEST = (ROOT / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')

def test_transport_references_survive_activity_recreation():
    assert 'private static volatile BluetoothSocket socket' in JAVA
    assert 'private static volatile InputStream in' in JAVA
    assert 'private static volatile OutputStream out' in JAVA
    assert 'closeSocket();io.shutdownNow()' not in JAVA

def test_foreground_connected_device_service_declared_and_started():
    assert 'ObdConnectionService' in MANIFEST
    assert 'android:foregroundServiceType="connectedDevice"' in MANIFEST
    assert 'startForegroundService(i)' in JAVA
    assert 'FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE' in SERVICE

def test_service_does_not_create_second_bluetooth_connection():
    assert 'BluetoothSocket' not in SERVICE
    assert 'createRfcommSocket' not in SERVICE

def test_29bit_scan_is_fallback_after_11bit_discovery():
    start = JAVA.index('// 29-bit candidate ranges are a fallback')
    end = JAVA.index('report.append("TOTAL DE PROBES")', start)
    section = JAVA[start:end]
    assert 'if(responders.isEmpty() && !stopRequested)' in section
    assert 'FALLBACK CAN 29-bit OMITIDO' in section
