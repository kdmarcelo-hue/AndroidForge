from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
JAVA=(ROOT/'app/src/main/java/com/marcelo/virtuselm/MainActivity.java').read_text(encoding='utf-8')

def test_peak_line_is_foreground_and_labeled():
    start=JAVA.index('private class CombinedGraphView')
    end=JAVA.index('private static class RpmSegmentBar',start)
    graph=JAVA[start:end]
    assert graph.index('drawSeries(c,combinedRpmValues') < graph.index('c.drawLine(left,peakY,right,peakY,peakPaint)')
    assert 'PICO BOOST: %.2f bar' in graph
    assert 'Color.rgb(255,214,0)' in graph

def test_peak_updates_only_from_valid_live_boost_and_resets_for_new_pull():
    assert 'if(!Float.isNaN(gb)&&!Float.isInfinite(gb)&&gb>=0&&gb>performanceGraphBoostPeak)' in JAVA
    assert 'performanceGraphBoostPeak=-1;' in JAVA
