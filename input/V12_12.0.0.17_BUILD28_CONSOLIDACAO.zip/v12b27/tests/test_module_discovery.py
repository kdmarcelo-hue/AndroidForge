from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
JAVA=(ROOT/'app/src/main/java/com/marcelo/virtuselm/MainActivity.java').read_text(encoding='utf-8')

def test_scan_requires_real_elm_and_rejects_simulation():
    method=JAVA.split('private void scanVehicleModules()',1)[1].split('private String buildModuleReport',1)[0]
    assert 'simulationMode || !connected || out == null || in == null' in method
    assert 'VARREDURA NÃO EXECUTADA' in method
    assert 'Nenhum comando foi enviado ao veículo' in method

def test_scan_checks_physical_obd_request_range_and_vin():
    assert 'for(int id=0x7E0; id<=0x7E7' in JAVA
    assert 'send("22F190",1500)' in JAVA

def test_negative_response_and_pending_are_not_absence_of_module_or_dtc():
    assert 'private String describeUdsNrc(String raw, String expectedService)' in JAVA
    assert 'resposta pendente; a ECU ainda está processando' in JAVA
    assert 'RESPOSTA_UDS_NEGATIVA_DID_F190' in JAVA
    assert 'Silêncio, NRC, timeout, cabeçalho ausente ou ISO-TP incompleto' in JAVA

def test_vag_scan_does_not_use_simulated_evidence():
    method=JAVA.split('private void vagFocusedScan()',1)[1].split('private String probeUdsVinHeader',1)[0]
    assert 'Nenhuma consulta foi transmitida' in method
    assert 'Nenhuma consulta foi transmitida' in method

def test_performance_buttons_allow_two_lines_without_clipping():
    method=JAVA.split('Button start=btn("🏁  INICIAR 0–60 / 0–100 / 0–280")',1)[1].split('TextView note=',1)[0]
    assert 'setSingleLine(false)' in method
    assert 'setMaxLines(2)' in method
    assert 'setIncludeFontPadding(true)' in method
    assert 'dp(72)' in method
    assert 'setClipChildren(false)' in method
