# V12 12.0.0.15 — BUILD 26 (candidato de validação)

## Identificação
- versionName: 12.0.0.15
- versionCode: 26
- applicationId preservado: v12.marcelo.virtuselm.v12_0_14 (atualização sobre BUILD25)
- Base: fonte V12 12.0.0.14 BUILD25 fornecida no contexto desta conversa.

## Alterações desta evolução

### 1. Persistência da sessão Bluetooth
- Socket, InputStream e OutputStream passaram a referências estáticas compartilhadas no processo, permitindo que uma nova instância da Activity reutilize o transporte existente.
- Criado ObdConnectionService, serviço Android de primeiro plano do tipo connectedDevice.
- O serviço é iniciado após conexão Bluetooth estabelecida e encerrado quando closeSocket é executado, inclusive desconexão explícita e perda tratada pelo fluxo de reconexão.
- Removido o fechamento incondicional do socket em onDestroy da Activity. A navegação/recriação da Activity não deve, por si só, encerrar o transporte.
- O serviço publica notificação persistente enquanto a sessão está mantida.
- O serviço não abre uma segunda conexão nem transmite comandos diagnósticos; evita concorrência pelo ELM.

### 2. Descoberta VAG mais eficiente
- Mantida a descoberta CAN 11-bit já existente (janela VAG 0x700–0x774 e endpoints OBD 0x7E0–0x7E7).
- A família de endereços CAN 29-bit (512 candidatos) passou a ser fallback quando nenhum endpoint 11-bit é confirmado, evitando centenas de consultas especulativas e vários minutos de varredura em veículos que já responderam em 11-bit.
- O relatório informa explicitamente quando o fallback 29-bit foi omitido.
- Respostas continuam sendo atribuídas somente quando o CAN ID de resposta corresponde ao endpoint esperado.
- Silêncio, timeout e NRC continuam sem serem interpretados como prova de módulo inexistente.

## Limitações e validações pendentes
- O serviço de primeiro plano mantém o processo e o socket enquanto o Android mantiver o serviço ativo; não garante sobrevivência a encerramento forçado pelo usuário, falha física do Bluetooth, perda de energia ou políticas do fabricante.
- Esta BUILD mantém o transporte conectado em segundo plano, mas não implementa aquisição contínua de telemetria quando a Activity não está ativa. A coleta em segundo plano exigirá mover o loop de aquisição e a fila de comandos para o serviço, com política explícita de frequência.
- A descoberta continua baseada em famílias de endereços documentadas/candidatas e não prova cobertura integral da topologia VAG. O Gateway DID 2A26 permanece experimental e depende de endereçamento/serviço suportados pela ECU.
- Não foram adicionados comandos de escrita, coding, adaptation, Security Access ou limpeza de DTC.
- Necessário validar no Virtus: alternância entre telas, ida ao segundo plano, retorno, reconexão após queda real, varredura 11-bit e comportamento do fallback 29-bit.
- Compilação Android e instalação física ainda dependem do GitHub Actions e teste no aparelho; não declarar APK funcional antes desses resultados.
