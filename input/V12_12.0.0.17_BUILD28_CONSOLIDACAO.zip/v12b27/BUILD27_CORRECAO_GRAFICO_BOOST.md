# BUILD27 — Correção do gráfico de Boost

Base: V12 12.0.0.15 BUILD26.

## Alterações
- A curva amarela de BOOST agora é desenhada depois das curvas de velocidade, pedal e RPM, ficando visualmente em primeiro plano.
- O pico máximo válido de BOOST é exibido na lateral direita do gráfico, abaixo do título BOOST, no formato `PICO: 1.23 bar`.
- O pico do histórico é recalculado a partir das amostras carregadas, evitando reaproveitar o máximo de uma puxada anterior.
- A linha horizontal de referência do pico permanece destacada em amarelo.
- Amostras inválidas de MAP/BARO continuam como lacunas; não são convertidas artificialmente em zero.
- Versão alterada para 12.0.0.16 / versionCode 27. O applicationId foi preservado para permitir atualização sobre a instalação atual.

## Arquivo alterado
- `app/src/main/java/com/marcelo/virtuselm/MainActivity.java`
- `app/build.gradle`

## Validação
- Revisão estática do fluxo de desenho e cálculo do pico realizada.
- A compilação Android ainda precisa ser executada pelo GitHub Actions após o upload deste ZIP.
