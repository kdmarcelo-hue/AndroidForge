# REV12 FIX10.7 — PEDAL + PERFORMANCE POWER MODEL

VersionCode: 165  
VersionName: 12.0-FIX10.7

## Implementado
- Teste de acelerador em Configurações > Desenvolvimento.
- Leitura somente dos PIDs 0x49/0x4A/0x4B (Accelerator Pedal Position D/E/F).
- Comparação com throttle 0x11 e posições 0x45/0x47/0x48/0x4C.
- Exibição de resposta RAW e percentual para validação no veículo.
- Gráfico combinado passa a usar pedal quando houver leitura válida; throttle permanece como fallback e disponível no teste de desenvolvimento.
- GPS permanece como fonte principal de velocidade do teste.
- Duração exibida na Performance corresponde à puxada 0→100 km/h quando 0–100 é concluído.
- Detecção estimada de trocas de marcha por queda abrupta de RPM com velocidade não decrescente.
- Potência estimada passa a usar dinâmica longitudinal: força inercial + resistência de rolamento + arrasto aerodinâmico, corrigida por eficiência de transmissão configurada internamente (0,85), para estimativa de potência no motor.
- Torque estimado é derivado da potência estimada e RPM no ponto correspondente.
- Histórico CSV recebe duração da puxada, quantidade de trocas estimadas e leituras de pedal D/E/F sem alterar as colunas históricas anteriores.
- Resumo do histórico passa a mostrar duração da puxada e trocas estimadas.

## Preservado
- CAN/OBD somente leitura.
- GPS 0–280 km/h.
- 0–60 e 0–100.
- Boost/MAP/BARO/RPM.
- Histórico persistente e seeds.
- VAG Explorer, DTC e simulação.

## Observação de validação
A detecção de marcha é inferência baseada no comportamento de RPM e velocidade; não é leitura direta da marcha pela CAN. A potência/torque continuam sendo estimativas calculadas a partir dos dados adquiridos.
