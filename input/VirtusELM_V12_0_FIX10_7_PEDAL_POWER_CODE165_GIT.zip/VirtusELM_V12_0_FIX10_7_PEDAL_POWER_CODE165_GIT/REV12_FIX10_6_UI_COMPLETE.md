# V12.0-FIX10.6 — UI TELEMETRIA / GRAVAÇÃO / LOGS / HISTÓRICO — CODE 164

## Base
V12.0-FIX10.5 / Code 163.

## Implementações consolidadas
- Telemetria ao vivo mantém somente os valores brutos, sem os quatro cards redundantes Motor / Pressão / Temperatura / Elétrico-Combustível.
- Painel **GRAVAÇÃO DE TELEMETRIA** contém título centralizado, descrição, status/arquivo e os três comandos **INICIAR / FINALIZAR / RESUMO** em uma única linha, com largura equivalente.
- Não existe botão **COPIAR CSV** na tela principal; os arquivos continuam preservados.
- Não existe métrica **BOOST MÁX.** duplicada dentro do painel de gravação. O indicador de performance permanece na tela Performance.
- **LOG TÉCNICO** fica somente na aba **LOGS**, com atualização em tempo real e comandos de copiar/limpar disponíveis ali.
- Abas **TELEMETRIA / GRÁFICOS / LOGS** preservadas.
- Gráfico combinado preservado com dados reais, quatro escalas independentes e GPS 0–280 km/h.
- GPS continua sendo a fonte principal de velocidade na Performance, com CAN preservada para auditoria/CSV.
- Histórico lê os CSVs persistentes e apresenta primeiro um resumo orientado a dados: velocidade máxima, boost máximo, aceleração máxima estimada, RPM máximo, throttle máximo, duração, 0–60, 0–100, potência, torque, qualidade e fonte de velocidade/VIN quando disponíveis.
- Os três CSVs históricos embarcados da FIX10.3 permanecem preservados em `assets/history_seed/`.
- DTC, VAG Explorer, CAN, gravação CSV, simulação, configurações e demais funções anteriores permanecem preservados.

## Auditoria desta revisão
- Removida a função auxiliar não utilizada `dataGroup()`, que poderia reintroduzir visualmente os antigos cards caso fosse reutilizada.
- O layout da Telemetria não cria mais nenhum dos quatro cards.
- O painel de gravação concentra os três comandos solicitados e não apresenta ação redundante de cópia.
- Histórico continua calculando métricas diretamente do CSV, sem inventar valores físicos.

## Versão
- versionCode: 164
- versionName: 12.0-FIX10.6
