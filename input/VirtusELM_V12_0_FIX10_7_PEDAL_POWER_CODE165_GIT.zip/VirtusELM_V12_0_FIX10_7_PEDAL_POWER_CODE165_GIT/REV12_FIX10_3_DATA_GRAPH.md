# V12.0-FIX10.3 — DADOS DO GRÁFICO + BASE HISTÓRICA

## Correção principal
- Corrigido o bloqueio em `updateGraph()`: o método retornava imediatamente quando o `GraphView` legado não estava instanciado.
- O `CombinedGraphView` agora recebe os dados em tempo real independentemente da existência do gráfico legado.
- Mantidos os quatro eixos independentes do FIX10.2:
  - Velocidade 0–200 km/h — azul
  - Throttle 0–100% — branco
  - Boost 0–3,0 bar — amarelo
  - RPM 0–8.000 rpm — verde
- Nenhuma escala física ou valor é inventado; valores inválidos continuam sendo ignorados pelo gráfico.

## Base histórica embarcada
Os três CSVs fornecidos pelo usuário são incorporados em `assets/history_seed/` e copiados automaticamente para `Download/VirtusELM/logs/` somente se ainda não existirem:
- VirtusELM_Performance_20261006_142242.csv
- VirtusELM_Performance_20261007_164420.csv
- VirtusELM_Performance_20261007_165229.csv

Assim, a próxima instalação/atualização já terá os três testes disponíveis no Histórico de Sessões e preservados para o comparativo futuro.

## Versão
- versionCode: 161
- versionName: 12.0-FIX10.3
