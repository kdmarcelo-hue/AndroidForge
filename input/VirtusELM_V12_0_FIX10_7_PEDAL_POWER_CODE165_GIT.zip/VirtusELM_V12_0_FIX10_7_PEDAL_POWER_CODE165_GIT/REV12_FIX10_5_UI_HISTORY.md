# V12.0-FIX10.5 — UI TELEMETRIA / LOGS / HISTÓRICO

- Base: V12.0-FIX10.4 / code 162.

Nota: a FIX10.5 foi auditada e a FIX10.6 consolida a UI efetiva após validação no aparelho.
- versionCode: 163 (historical baseline).
- versionName: 12.0-FIX10.5.
- Removidos os quatro cards redundantes da aba Telemetria.
- Removido BOOST MÁX. duplicado do painel de gravação.
- Botões de gravação reorganizados dentro do painel: INICIAR / FINALIZAR / RESUMO.
- COPIAR CSV removido da tela principal; o arquivo continua sendo salvo.
- Títulos do painel de gravação e do log técnico centralizados.
- LOG TÉCNICO permanece disponível na aba LOGS, fora da tela principal de telemetria.
- Histórico de sessões passa a apresentar resumo interpretado do CSV: velocidade máxima, boost máximo, aceleração máxima estimada, RPM máximo, throttle máximo, duração, 0–60, 0–100, potência/torque estimados e qualidade quando disponíveis.
- Mantidos CSV, GPS, CAN, performance, DTC, VAG Explorer e demais funções existentes.
