# V12.0-FIX10.16 — Histórico SAF e exclusão de sessão

- VersionCode 175.
- Adiciona seleção da pasta `Download/VirtusELM/logs` via Storage Access Framework e persiste a permissão concedida pelo usuário.
- O histórico lista CSVs pelo diretório escolhido, além do MediaStore e fallback legado; prioriza a URI SAF para arquivos antigos e protegidos pelo armazenamento restrito.
- `ATUALIZAR ARQUIVOS` reconstrói a lista e testa a abertura dos CSVs indexados, mostrando contagem listada/acessível.
- A janela de sessão tem botões `OK` e `APAGAR` lado a lado, centralizados. A exclusão exige confirmação; `CANCELAR` fecha as duas janelas e retorna à lista.
- A gravação continua usando `Download/VirtusELM/logs/` via MediaStore no Android 10+, que cria/reutiliza o diretório público ao inserir os CSVs. A seleção SAF permite acessar CSVs antigos que não aparecem na consulta MediaStore da instalação atual.
- Não foi possível compilar localmente neste ambiente por ausência de Android SDK/Gradle; o ZIP precisa passar pelo workflow Build Android para confirmar compilação e gerar APK.
