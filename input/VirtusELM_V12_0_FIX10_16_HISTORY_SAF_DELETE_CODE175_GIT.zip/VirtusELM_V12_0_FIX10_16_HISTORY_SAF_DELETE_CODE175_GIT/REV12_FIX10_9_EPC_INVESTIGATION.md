# VIRTUS ELM V12.0-FIX10.9-EPC — versionCode 168

## Objetivo
Adicionar um fluxo de captura de evidências para investigar ocorrência recorrente de EPC, mantendo a aplicação estritamente em leitura.

## Alterações
- Nova seção `EPC • CAPTURA DE EVIDÊNCIAS` na tela Diagnóstico.
- Botão `INVESTIGAR EPC` reúne timestamp, estado do transporte, protocolo, DTC confirmado (Mode 03), pendente (Mode 07), permanente (Mode 0A), status OBD/readiness, VIN, consultas de freeze-frame e leituras ambientais selecionadas.
- Se houver ELM real conectado, consulta DTC UDS nos endpoints previamente observados 7E0/7E8 e 7E1/7E9, sem atribuir identidade de módulo sem evidência.
- Preserva comandos e respostas RAW no relatório e no log técnico da sessão.
- Inclui interpretação cautelosa para `NO DATA`, respostas negativas e ausência de resposta; não declara ausência de falha só porque uma leitura não retornou dados.
- Não transmite comando de limpeza, coding, adaptation, Security Access ou atuação.
- Corrige o freeze-frame legado para consultar campos com índice de quadro `00` (ex.: `020C00`) e registra o DTC causador com `020200`.

## Validação obrigatória
- Compilar Debug via GitHub Actions.
- Testar em simulação: o relatório deve marcar claramente que não é evidência real.
- Testar com ELM no veículo estacionado: comparar Modes 03/07/0A e preservar RAW.
- Não limpar DTCs antes de exportar/registrar o relatório.
