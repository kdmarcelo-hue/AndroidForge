# VIRTUS ELM V12.0-FIX10.10-UI — versionCode 169

## Auditoria visual
- Tela auditada: Performance, conforme captura de tablet enviada em 20/10/2026.
- Corrigido o botão de iniciar ensaio: rótulo em duas linhas, altura explícita de 62 dp e padding vertical maior para evitar recorte com densidade/fonte do tablet.
- Botão de finalizar recebe altura explícita igual e rótulo mais claro.
- Botões de gráficos e histórico padronizados para altura mínima de 54 dp e padding vertical seguro.
- Mantidos os cartões, métricas, cores, ordem e navegação existentes.
- Mantido o fluxo de investigação EPC da FIX10.9; nenhuma função de diagnóstico foi removida.

## Verificação
- Conferir compilação Debug no GitHub Actions antes de instalar.
- Testar a tela Performance em tablet e celular, com escala de fonte padrão e ampliada.
- Confirmar que os dois botões de ensaio aparecem completos, com texto centralizado e sem sobreposição.
