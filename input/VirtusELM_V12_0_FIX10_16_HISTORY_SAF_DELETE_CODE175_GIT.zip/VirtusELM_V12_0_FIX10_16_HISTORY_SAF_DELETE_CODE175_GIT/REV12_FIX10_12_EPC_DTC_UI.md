# FIX10.12 — Código 171

- Performance: linha dos botões passa a ter altura explícita de 54dp, botões 48dp, texto em uma linha e espaçamento controlado. Isso evita que o botão seguinte sobreponha/corte a borda inferior em tablets.
- Investigação EPC: interpreta separadamente respostas positivas OBD 43, 47 e 4A para DTC confirmados, pendentes e permanentes.
- Mantém os dados RAW no relatório e distingue resposta negativa/timeout/sem DTC decodificável de confirmação de ausência de falhas.
- Mantém consulta VAG/UDS existente e política somente leitura.
- Compilação e teste no tablet ainda necessários.
