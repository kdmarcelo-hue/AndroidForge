# FIX10.14 — Código 173
- Corrige a descoberta de CSVs em Download/VirtusELM/logs.
- Usa MediaStore.Files para enumerar os arquivos de forma mais ampla no Android 10+.
- Normaliza separadores, caixa e barra final de RELATIVE_PATH.
- Usa o mesmo mecanismo MediaStore.Files para abrir cada CSV, com fallback para File quando permitido.
- Exibe a contagem real de arquivos encontrados e aumenta o limite visual para 500.
- Preserva ranking das 3 melhores puxadas, layout e demais módulos.
- Build e teste de campo ainda precisam ser confirmados via GitHub Actions e tablet.
