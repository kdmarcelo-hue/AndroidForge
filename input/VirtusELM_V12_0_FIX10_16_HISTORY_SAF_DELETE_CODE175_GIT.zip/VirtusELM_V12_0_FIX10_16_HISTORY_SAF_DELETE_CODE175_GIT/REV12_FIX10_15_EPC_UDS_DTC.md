# FIX10.15 — Código 174 — Investigação EPC / UDS DTC

- Mantém a base FIX10.14 (histórico, melhores puxadas, UI e demais módulos).
- Corrige interpretação da resposta UDS `59 02`: cada registro é tratado como DTC de 3 bytes + status de 1 byte; não se converte esse formato diretamente para Pxxxx.
- Reúne quadros ISO-TP por endpoint, verifica tamanho anunciado e sequência de quadros, e marca resposta incompleta/BUFFER FULL.
- Investiga separadamente máscaras UDS de status `01`, `02`, `04`, `08`, `20` e `80` para reduzir respostas excessivamente grandes.
- Preserva RAW de cada consulta, registra status hexadecimal e descreve os bits de estado.
- Mantém somente leitura: nenhum comando de limpeza, coding, adaptação, Security Access ou atuação foi acrescentado.
- Requer validação no GitHub Actions e teste real com o carro parado.
