# FIX10.11 UI — Código 170
- Corrige os botões Iniciar/Finalizar da tela Performance em tablets.
- Desativa explicitamente o autosize herdado do helper de botões.
- Usa duas linhas deliberadas, fonte fixa, font padding habilitado, padding vertical de 10dp e altura de 76dp.
- Desativa clipping de filhos no contêiner de ações.
- Mantém a lógica de captura, gráficos, histórico, diagnóstico e demais telas.
- Compilação ainda precisa ser confirmada pelo GitHub Actions.
