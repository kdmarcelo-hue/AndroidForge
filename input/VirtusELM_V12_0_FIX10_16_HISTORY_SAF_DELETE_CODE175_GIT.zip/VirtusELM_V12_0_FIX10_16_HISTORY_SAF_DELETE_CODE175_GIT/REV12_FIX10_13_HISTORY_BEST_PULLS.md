# FIX10.13 — Histórico persistente e melhores puxadas (Código 172)

- O botão ATUALIZAR refaz a descoberta dos CSVs em MediaStore e em `Download/VirtusELM/logs/`; a listagem não depende de cache da tela.
- A tela abre resumos também de arquivos antigos e de Android anterior ao scoped storage, quando o acesso ao arquivo é permitido.
- Cada teste finalizado gera um CSV próprio `VirtusELM_Pull_*.csv` em `Download/VirtusELM/logs`, mesmo que a gravação contínua de telemetria esteja desativada.
- O arquivo individual guarda uma linha de teste com os valores disponíveis no fechamento: 0–60, 0–100, potência, torque, boost máximo, RPM e velocidade máximos, qualidade, duração, trocas, pedal, dados de motor, combustível, VIN, fonte, curva de cruzamentos e amostras.
- O botão `3 MELHORES PUXADAS` apresenta tabela rolável horizontalmente, ordenada pelo menor 0–100; quando não há 0–100 válido, usa 0–60. Exibe as três melhores com todos os campos arquivados relevantes.
- O leitor usa os nomes das colunas CSV, não posições fixas, para aceitar tanto os arquivos atuais como os históricos de esquemas antigos.
- A tabela inclui data/hora, tempos, potência/torque, boost, RPM, velocidade, três posições de pedal, throttle, carga, MAP, baro, temperaturas, combustível, tensão, qualidade, duração, trocas, etanol, amostras, fonte, VIN e arquivo.
- Deduplicação aproximada por minuto + métricas evita listar duas vezes a mesma puxada que está no CSV contínuo e no arquivo individual, sem eliminar facilmente puxadas iguais feitas em momentos diferentes.
- Nenhum arquivo antigo é apagado ou sobrescrito.
- Compilação e validação no dispositivo ainda dependem do GitHub Actions e teste instalado.
