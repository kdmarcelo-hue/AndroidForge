# Preparação V12 12.0.0.11

Base 12.0.0.10 auditada, biblioteca offline 1.2.0, manifesto SHA-256 e especificação técnica. **Não é ainda um APK 12.0.0.11 pronto para scan completo**: descoberta Gateway/ECUs e leitura real dos módulos 08 e 13 ainda precisam ser implementadas e validadas.
