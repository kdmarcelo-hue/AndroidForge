# REGRA PERMANENTE — ELM327 E DIAGNÓSTICO V12

O adaptador ELM327 Bluetooth utilizado no projeto já demonstrou leitura de dados e execução de alterações em outros aplicativos. Não atribuir falhas do V12 ao adaptador por hipótese. Investigar primeiro o software: comandos TX/RX, headers e IDs CAN, protocolo, fila serial, ISO-TP, UDS, NRC, timeout, parser e interpretação. Só registrar limitação do hardware com evidência específica, reproduzível e documentada.

Referência: `docs/12.0.0.11_DIAGNOSTICO_VAG_IMPLEMENTATION_SPEC.md`.
