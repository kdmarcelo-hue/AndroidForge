# V11.3 — Óleo + Cabeçalho

## Alterações
- Versão Android: 11.3 / versionCode 113.
- Cabeçalho fixo preservado.
- V do VIRTUS volta ao azul elétrico/ciano, sem tint branco.
- Imagem do Virtus ancorada na base do cabeçalho.
- Espaço livre abaixo da barra de RPM recebe leitura de temperatura do óleo.
- Temperatura do óleo consultada por OBD PID 01 5C (comando `015C`) e calculada como A - 40 °C quando a ECU responder.
- Cor da temperatura: azul em baixa temperatura, branca na faixa normal de interface, laranja em temperatura elevada e vermelha em temperatura crítica. Esses limites são de apresentação e devem ser validados em teste de campo antes de serem tratados como alarmes.
- Campo `NÍVEL —` foi reservado no mesmo cluster. A leitura real do nível não foi inventada: o sensor G266 é de nível/temperatura e sua informação pode ser transmitida por caminho específico do veículo; o mapeamento VAG/CAN ainda precisa ser identificado.
- CSV de gravação ganhou a coluna `oil_temp_c`.
- Nenhuma função de atuação, coding, adaptation, security access ou transmissão CAN arbitrária foi adicionada.

## Validação local
- Estrutura Java: contagem de chaves/parênteses balanceada.
- Build local não executado neste ambiente porque o projeto não contém `gradlew` e não há Gradle instalado no container. O workflow do GitHub Actions foi atualizado para gerar `VirtusELM-V11.3-debug`.
