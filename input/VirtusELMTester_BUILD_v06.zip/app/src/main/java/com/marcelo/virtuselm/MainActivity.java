package com.marcelo.virtuselm;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    BluetoothAdapter adapter;
    BluetoothSocket socket;
    InputStream in; OutputStream out;
    TextView log,status,liveData;
    Button connect,testEcu,readVehicle;
    Handler h=new Handler(Looper.getMainLooper());
    static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        log=findViewById(R.id.log); status=findViewById(R.id.status); liveData=findViewById(R.id.liveData);
        connect=findViewById(R.id.btnConnect); testEcu=findViewById(R.id.btnTestEcu); readVehicle=findViewById(R.id.btnReadVehicle);
        adapter=BluetoothAdapter.getDefaultAdapter();
        connect.setOnClickListener(v->startConnection());
        testEcu.setOnClickListener(v->testEcu());
        readVehicle.setOnClickListener(v->readVehicle());
        findViewById(R.id.btnClear).setOnClickListener(v->log.setText(""));
        testEcu.setEnabled(false); readVehicle.setEnabled(false); requestBt();
    }

    void requestBt(){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},10);
    }

    void startConnection(){
        if(adapter==null){ msg("Bluetooth não disponível."); return; }
        if(!adapter.isEnabled()){ msg("Ative o Bluetooth do celular."); return; }
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED){requestBt();return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestBt();return;}
        new Thread(()->{
            try{
                setStatus("PROCURANDO ELM..."); msg("Procurando ELM..."); BluetoothDevice elm=null;
                if(Build.VERSION.SDK_INT<31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED){
                    Set<BluetoothDevice> paired=adapter.getBondedDevices();
                    for(BluetoothDevice d:paired){ String n=d.getName(); if(n!=null && isElmName(n)){elm=d;break;} }
                }
                if(elm!=null){
                    msg("ELM encontrado entre dispositivos conhecidos: "+elm.getName()); adapter.cancelDiscovery();
                    socket=elm.createRfcommSocketToServiceRecord(SPP); socket.connect();
                } else {
                    msg("ELM não está pareado. Iniciando descoberta Bluetooth..."); final Object lock=new Object(); final BluetoothDevice[] found={null};
                    BroadcastReceiver receiver=new BroadcastReceiver(){ public void onReceive(Context c,Intent i){
                        if(BluetoothDevice.ACTION_FOUND.equals(i.getAction())){ BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                            if(d!=null){String n=d.getName(); if(n!=null&&isElmName(n)){found[0]=d;synchronized(lock){lock.notifyAll();}}}}
                    }};
                    registerReceiver(receiver,new IntentFilter(BluetoothDevice.ACTION_FOUND)); adapter.startDiscovery();
                    synchronized(lock){lock.wait(12000);} try{unregisterReceiver(receiver);}catch(Exception ignored){} adapter.cancelDiscovery(); elm=found[0];
                    if(elm==null){msg("Nenhum ELM identificado na descoberta Bluetooth.");setStatus("NÃO ENCONTRADO");return;}
                    msg("ELM encontrado: "+elm.getName()); socket=elm.createRfcommSocketToServiceRecord(SPP); socket.connect();
                }
                in=socket.getInputStream(); out=socket.getOutputStream(); msg("Bluetooth conectado.");
                send("ATZ"); Thread.sleep(1200); read(); send("ATE0"); Thread.sleep(300); read(); send("ATI"); Thread.sleep(500); read(); send("ATDP"); Thread.sleep(500); read(); send("ATSP0"); Thread.sleep(500); read();
                setStatus("CONECTADO AO ELM"); setButtons(true); msg("Inicialização concluída. Pronto para diagnóstico somente leitura.");
            }catch(Exception e){msg("Falha: "+e.getMessage());setStatus("NÃO CONECTADO");setButtons(false);close();}
        }).start();
    }

    boolean isElmName(String n){String u=n.toUpperCase(Locale.ROOT);return u.contains("ELM")||u.contains("OBD")||u.contains("V-LINK")||u.contains("OBDLINK");}

    void testEcu(){ new Thread(()->{
        try{ if(!connected()){msg("ELM não está conectado.");setStatus("NÃO CONECTADO");setButtons(false);return;} setButtons(false);setStatus("TESTANDO ECU...");
            msg("Teste OBD-II somente leitura."); String r=sendRead("0100",3500); msg("<< "+display(r));
            String n=norm(r); if(n.contains("4100")){setStatus("ECU RESPONDEU");msg("ECU/OBD-II respondeu ao PID 0100.");}
            else if(n.contains("NODATA")){setStatus("SEM RESPOSTA OBD-II");msg("O ELM respondeu, mas não houve dados do PID 0100.");}
            else {setStatus("RESPOSTA OBTIDA");msg("Houve resposta; conteúdo preservado no registro.");}
            msg("Nenhum comando de escrita/adaptação foi enviado.");
        }catch(Exception e){msg("Falha no teste da ECU: "+e.getMessage());setStatus("FALHA NO TESTE");}finally{setButtons(true);} }).start(); }

    void readVehicle(){ new Thread(()->{
        try{
            if(!connected()){msg("ELM não está conectado.");return;} setButtons(false);setStatus("LENDO VEÍCULO...");live("Lendo parâmetros OBD-II...");
            // Standardized, read-only OBD-II requests. No clear, coding, adaptation or actuator commands.
            String supported=sendRead("0100",2500); msg(">> 0100 (suporte PIDs 01-20)"); msg("<< "+display(supported));
            Set<Integer> pids=parseSupportedPids(supported,0x01);
            int[][] jobs={{0x0C,2},{0x0D,1},{0x05,1},{0x04,1},{0x0B,1},{0x0F,1},{0x11,1},{0x10,2},{0x1F,2},{0x2F,1},{0x33,1},{0x42,2}};
            StringBuilder summary=new StringBuilder();
            for(int[] j:jobs){int pid=j[0]; if(!pids.contains(pid)) continue; String cmd=String.format(Locale.ROOT,"01%02X",pid); String r=sendRead(cmd,2200); msg(">> "+cmd); msg("<< "+display(r)); String val=decode(pid,r); if(val!=null){summary.append(label(pid)).append(": ").append(val).append("\n");}}
            // Read standardized DTCs only. This does not clear anything.
            String dtc=sendRead("03",2500); msg(">> 03 (DTC leitura)"); msg("<< "+display(dtc));
            setStatus("LEITURA CONCLUÍDA"); live(summary.length()>0?summary.toString():"Nenhum parâmetro suportado foi decodificado.");
            msg("Leitura concluída. Nenhum comando de escrita/adaptação/limpeza foi enviado.");
        }catch(Exception e){msg("Falha na leitura: "+e.getMessage());setStatus("FALHA NA LEITURA");live("Falha ao ler parâmetros.");}finally{setButtons(true);} }).start(); }

    Set<Integer> parseSupportedPids(String r,int base){Set<Integer>s=new HashSet<>();String hex=norm(r);int pos=hex.indexOf("4100");if(pos<0)return s;String data=hex.substring(pos+4);if(data.length()<8)return s;long bits=Long.parseLong(data.substring(0,8),16);for(int i=0;i<32;i++)if((bits&(1L<<(31-i)))!=0)s.add(base+i);return s;}
    String decode(int pid,String r){String h=norm(r);String key=String.format(Locale.ROOT,"41%02X",pid);int p=h.indexOf(key);if(p<0)return null;String d=h.substring(p+4);try{
        switch(pid){case 0x0C:return String.format(Locale.ROOT,"%.0f rpm",Integer.parseInt(d.substring(0,4),16)/4.0);case 0x0D:return Integer.parseInt(d.substring(0,2),16)+" km/h";case 0x05:return (Integer.parseInt(d.substring(0,2),16)-40)+" °C";case 0x04:return String.format(Locale.ROOT,"%.1f %%",Integer.parseInt(d.substring(0,2),16)*100.0/255.0);case 0x0B:return Integer.parseInt(d.substring(0,2),16)+" kPa";case 0x0F:return (Integer.parseInt(d.substring(0,2),16)-40)+" °C";case 0x11:return String.format(Locale.ROOT,"%.1f %%",Integer.parseInt(d.substring(0,2),16)*100.0/255.0);case 0x10:return String.format(Locale.ROOT,"%.1f g/s",Integer.parseInt(d.substring(0,4),16)/100.0);case 0x1F:return Integer.parseInt(d.substring(0,4),16)+" s";case 0x2F:return String.format(Locale.ROOT,"%.1f %%",Integer.parseInt(d.substring(0,2),16)*100.0/255.0);case 0x33:return Integer.parseInt(d.substring(0,2),16)+" kPa";case 0x42:return String.format(Locale.ROOT,"%.3f V",Integer.parseInt(d.substring(0,4),16)/1000.0);default:return null;}
    }catch(Exception e){return null;}}
    String label(int p){switch(p){case 0x0C:return "RPM";case 0x0D:return "Velocidade";case 0x05:return "Temp. arrefecimento";case 0x04:return "Carga motor";case 0x0B:return "MAP";case 0x0F:return "Temp. admissão";case 0x11:return "Acelerador";case 0x10:return "MAF";case 0x1F:return "Tempo ligado";case 0x2F:return "Nível combustível";case 0x33:return "Pressão barométrica";case 0x42:return "Tensão módulo";default:return String.format(Locale.ROOT,"PID %02X",p);}}
    boolean connected(){return out!=null&&socket!=null&&socket.isConnected();}
    String sendRead(String x,long t)throws Exception{send(x);return readResponse(t);}
    synchronized void send(String x)throws Exception{if(out==null)throw new Exception("ELM desconectado");msg(">> "+x);out.write((x+"\r").getBytes(StandardCharsets.US_ASCII));out.flush();}
    void read()throws Exception{String b=readResponse(1600);msg("<< "+display(b));}
    String readResponse(long timeoutMs)throws Exception{long end=System.currentTimeMillis()+timeoutMs;StringBuilder b=new StringBuilder();while(System.currentTimeMillis()<end){while(in!=null&&in.available()>0){int c=in.read();if(c>=0)b.append((char)c);if(c=='>'){end=System.currentTimeMillis()+150;break;}}Thread.sleep(25);}return b.toString();}
    String norm(String s){return s.toUpperCase(Locale.ROOT).replaceAll("[\\r\\n\\s]","");}
    String display(String s){return s.length()>0?s.replace("\r","\n"):"(sem resposta)";}
    void close(){try{if(socket!=null)socket.close();}catch(Exception e){}socket=null;in=null;out=null;setButtons(false);}
    void msg(String s){h.post(()->log.append(s+"\n"));}
    void live(String s){h.post(()->liveData.setText(s));}
    void setStatus(String s){h.post(()->status.setText("Status: "+s));}
    void setButtons(boolean enabled){h.post(()->{testEcu.setEnabled(enabled);readVehicle.setEnabled(enabled);});}
    protected void onDestroy(){close();super.onDestroy();}
}
