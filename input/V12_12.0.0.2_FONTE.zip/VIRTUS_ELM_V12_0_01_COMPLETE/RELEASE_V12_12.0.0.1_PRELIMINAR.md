# V12 12.0.0.1 — pacote preliminar de correções

Base: `V12_PRO_PLUS_LAUNCHER_ICON_MENOS_30_AGORA.zip` (Marco Zero preservado fora deste pacote).

## Alterações aplicadas
- `versionName` alterado para `12.0.0.1`, `versionCode` para `11` e `applicationId` exclusivo `v12.marcelo.virtuselm.v12_0_0_1` para instalação paralela.
- Identificação visual fixa atualizada para `V12 • 12.0.0.1`.
- Calibração do pedal passa a ser armazenada por VIN e PID selecionado; alternar fonte não apaga a calibração da fonte anterior.
- Redefinir remove apenas os pontos da combinação VIN/fonte atual.
- Teste sequencial de progressão trata exceções de leitura e permite repetir o ponto sem avançar indevidamente; aumenta o timeout de leitura para 1,8 s.

## Limitações e validação pendente
- Não foi possível executar build Gradle neste ambiente: o pacote não contém `gradlew`/wrapper e não há Gradle instalado.
- Não houve teste físico com ELM327/veículo.
- A calibração antiga, armazenada sem VIN, não é migrada automaticamente; até calibrar novamente a combinação VIN/PID, o app usa a leitura bruta.
- Não foi implementada gravação de codificação, reset do aviso de revisão nem odômetro proprietário. Essas operações exigem identificação e procedimento VW confirmados; permanecem fora desta entrega.
- A resolução de MAP permanece a do PID OBD-II 010B (1 kPa por bit); casas decimais não podem ser recuperadas de uma resposta que fornece apenas byte inteiro.
- Descoberta de módulos UDS e liberação de catálogo CUSTOM ainda precisam de investigação e validação em veículo.

Este pacote é fonte alterada, não APK compilado nem homologação funcional.
