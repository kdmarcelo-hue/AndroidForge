# V12 12.0.0.2 — mudanças

## Implementado nesta entrega
- Atualização de `versionName` para `12.0.0.2`, `versionCode` para `12` e `applicationId` exclusivo `v12.marcelo.virtuselm.v12_0_0_2`, permitindo instalação paralela.
- Configurações reorganizadas: calibração, seleção de fonte e teste de progressão do pedal aparecem no início; manutenção da pasta LOG vem logo após; combustível padrão e opções secundárias ficam abaixo.
- Nova ação manual **VERIFICAR CSVs DUPLICADOS**. Compara conteúdo por SHA-256, não pelo nome, mostra os grupos e solicita confirmação antes de excluir. Em NÃO, preserva todos os arquivos e informa que os duplicados continuam.
- Removida a deduplicação destrutiva automática de logs durante a inicialização/importação. A importação de históricos embarcados agora apenas evita criar cópia quando conteúdo igual já existe.
- Varredura UDS: remove falso positivo que considerava qualquer frame ISO-TP como módulo respondente; agora exige resposta positiva `62 F1 90` ao DID VIN e registra a resposta RAW no log técnico.

## Limites deliberados de segurança
- A resposta ao DID F190 comprova somente que houve resposta positiva a essa leitura; não identifica sozinha fabricante, nome ou capacidade de codificação do módulo.
- Catálogo CUSTOM continua condicionado à identificação e validação de compatibilidade. Não foram habilitadas gravações genéricas.
- Odômetro real e reset do aviso de revisão permanecem não habilitados: o projeto não contém evidência validada de DID/serviço e módulo específico do Virtus 2024 para essas operações. Não foi inventado PID nem enviada gravação.
- Calibração e progressão exigem validação física no carro; o código não pode comprovar comportamento do pedal sem ELM/veículo.

## Verificação
- Conferidos os arquivos Gradle e as alterações no código-fonte.
- Build Android não executado neste ambiente: o projeto não inclui Gradle Wrapper e não há instalação Gradle/SDK Android disponível.
- Não afirmar APK compilado nem validação física com esta entrega.
