# V12.0-FIX09.1 — Performance + VAG Scan UDS

## Correção visual
- Cabeçalho PERFORMANCE mantém o ícone de bandeira e remove apenas o subtítulo.
- Cards de performance permanecem compactos, com resultado destacado e unidade menor.
- Quadro de combustível permanece visível no fluxo da tela.

## Evolução funcional VAG
- Mantida leitura UDS `0x22 / F190 (VIN)`.
- Novo `VAG SCAN UDS` focado em endpoints CAN 7DF, 7E0 e 7E1.
- 7E0/7E1 são testados porque seus pares de resposta 7E8/7E9 já foram observados no veículo durante a investigação anterior.
- O resultado diferencia resposta positiva `62 F1 90`, resposta negativa UDS e ausência de resposta.
- O aplicativo não atribui nomes de módulos sem evidência.
- Nenhuma função de escrita, coding, adaptation, Security Access ou atuação foi adicionada.
- Após o teste, o ELM retorna para header funcional 7DF e seleção automática de protocolo.

## Base externa consultada
- UDS 0x22 é serviço de leitura de dados; F190 é o DID padronizado de VIN.
- Ferramentas VAG como VCDS fazem descoberta/Auto-Scan de controladores, mas a lista de módulos depende do veículo; por isso esta versão mantém descoberta baseada em evidência em vez de declarar uma lista fixa como detectada.
