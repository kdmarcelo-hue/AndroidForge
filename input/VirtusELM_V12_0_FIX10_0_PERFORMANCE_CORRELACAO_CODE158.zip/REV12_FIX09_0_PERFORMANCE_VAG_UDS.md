# V12.0 FIX09.0 — Performance UX + VAG UDS VIN Read

## Performance
- Cabeçalho PERFORMANCE retorna ao tamanho normal.
- Cards de métricas reduzidos de 98 dp para 88 dp.
- Títulos permanecem no topo.
- Resultado numérico recebe destaque maior e fica abaixo do título, com espaço visual entre os elementos.
- Unidades permanecem menores e discretas.
- Nenhuma lógica de cálculo, ELM, CAN ou histórico foi alterada.

## VAG Diagnostic Explorer 2.2
- Mantida a separação entre veículo/ELM real, simulação e ausência de ELM.
- Adicionada primeira leitura UDS somente leitura: serviço `0x22`, DID `F190` (VIN).
- A resposta só é considerada evidência quando houver retorno positivo `0x62 F1 90`.
- CAN IDs continuam sendo exibidos somente quando aparecem no retorno textual observado; o parser agora também reconhece respostas UDS `62`, `6E` e `7F`.
- Nenhum endereço físico específico de módulo VAG foi inventado ou transmitido.
- ABS 03, Instruments 17 e Gateway 19 continuam como NÃO IDENTIFICADOS até existir resposta específica observada.
- Nenhum coding, adaptation, Security Access, atuação ou escrita foi adicionado.

## Simulação
- O modo de simulação inclui uma resposta didática para `22F190`, permitindo validar a apresentação do fluxo UDS sem afirmar que o veículo real respondeu.

## Versão
- VersionCode: 156
- VersionName: 12.0-FIX09.0
