# V12.0-FIX10.0 — PERFORMANCE / CORRELAÇÃO

## Implementações
- Menu de diagnóstico reorganizado por função: OBD-II, VAG, DTC e testes.
- Conexão real limpa resultados residuais de simulação e reinicia evidências da sessão.
- Gráfico combinado de RPM, velocidade, throttle e boost, com cores distintas e escala normalizada para correlação visual.
- Teste de 0–60 km/h e 0–100 km/h no mesmo ensaio.
- Índice de qualidade da aquisição em percentual; não representa precisão física e não corrige inclinação da via.
- VIN permanece associado ao histórico para diferenciar veículos.
- Marcha não é inventada: permanece pendente de leitura VAG.
