package com.marcelo.virtuselm.car;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;
import androidx.car.app.CarContext;
import androidx.car.app.Screen;
import androidx.car.app.model.Action;
import androidx.car.app.model.GridItem;
import androidx.car.app.model.GridTemplate;
import androidx.car.app.model.Header;
import androidx.car.app.model.ItemList;

public class PerformanceScreen extends Screen {
    private final CarContext carContext;

    public PerformanceScreen(CarContext carContext) {
        super(carContext);
        this.carContext = carContext;
    }

    private String value(String key, String fallback) {
        SharedPreferences p = carContext.getSharedPreferences("virtus_elm_ui", Context.MODE_PRIVATE);
        return p.getString(key, fallback);
    }

    @NonNull
    @Override
    public GridTemplate onGetTemplate() {
        String power = value("auto_perf_power", "— cv");
        String torque = value("auto_perf_torque", "— Nm");
        String zero100 = value("auto_perf_0100", "— s");
        String boost = value("auto_perf_boost", "— bar");
        String fuel = value("auto_perf_fuel", "—");
        String status = value("auto_perf_status", "PRONTO");

        ItemList.Builder list = new ItemList.Builder();
        list.addItem(item("POTÊNCIA", power));
        list.addItem(item("TORQUE", torque));
        list.addItem(item("0–100 km/h", zero100));
        list.addItem(item("BOOST MÁX.", boost));
        list.addItem(item("COMBUSTÍVEL", fuel));
        list.addItem(item("STATUS", status));

        return new GridTemplate.Builder()
                .setHeader(new Header.Builder()
                        .setTitle("VIRTUS ELM • PERFORMANCE")
                        .setStartHeaderAction(Action.APP_ICON)
                        .build())
                .setSingleList(list.build())
                .build();
    }

    private GridItem item(String title, String text) {
        return new GridItem.Builder()
                .setTitle(title)
                .setText(text)
                .build();
    }
}
