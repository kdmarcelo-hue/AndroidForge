# V11.6.7 — Android Auto Performance Lab

This is a test build derived from V11.6.7. The original V11 code remains intact except for a small persistence hook that saves completed Performance results in SharedPreferences.

## What was added
- Android for Cars / Car App Library 1.7.0.
- Android Auto `CarAppService` using the official `IOT` category as the closest supported category for a connected ELM327 device.
- Template-based Performance screen using `GridTemplate`.
- The car screen reads the latest completed Performance result from SharedPreferences.
- No CAN transmit, lock/unlock, coding, adaptation or security-access commands were added.

## Important limitation
This is a functional prototype for Android Auto host testing, not a claim that Google will approve the app for public distribution. The IOT category is officially supported, but the app must still satisfy the applicable car-app quality rules.

## Next step
1. Build/install the APK on an Android phone.
2. Enable Android Auto developer settings and run it against the Desktop Head Unit (DHU) or compatible Android Auto host.
3. Verify that the VIRTUS ELM Performance app is discoverable and renders the six metrics.
4. Then connect the real ELM327 and replace the SharedPreferences bridge with a live telemetry bridge.
