# V12 FIX10.8 — métrica de potência corrigida

- Code 167 / versionName 12.0-FIX10.8.
- Potência longitudinal usa regressão linear de velocidade em janela GPS de 5 pontos.
- Rejeita acelerações físicas implausíveis (>4,5 m/s²) e amostras de potência fora do envelope de cálculo.
- Consolida potência pelo percentil 90 da curva filtrada, em vez do máximo de uma amostra.
- Torque usa a mesma curva filtrada.
- Regularização leve (20%) pela relação potência/0–100 do Virtus 200 TSI original: 128 cv e 10,1 s.
- Massa de cálculo: 1250 kg; CdA=0,62; Crr=0,012; eficiência de transmissão=0,88.
- Objetivo: reduzir picos artificiais de GPS e aproximar o resultado de uma estimativa física comparável.
- Não é dinamômetro; inclinação, vento, aderência e qualidade do GPS continuam limitantes.
