# V12 FIX10.8 — métrica de potência corrigida

**Code 167 / versionName 12.0-FIX10.8**

## Objetivo
Reduzir picos artificiais de GPS que estavam produzindo valores como 247 cv / 362 Nm em uma puxada de 0–100 km/h na faixa de 10 s.

## Método
- Velocidade GPS continua sendo a fonte principal da dinâmica.
- A aceleração não é mais calculada por apenas dois pontos consecutivos.
- É usada regressão linear sobre uma janela de 5 pontos GPS.
- Acelerações acima de 4,5 m/s² são rejeitadas como prováveis artefatos para este cálculo.
- Potência instantânea fora do envelope de cálculo também é descartada.
- A potência final usa o percentil 90 da curva filtrada, em vez do maior pico isolado.
- Torque usa a mesma curva filtrada.
- Uma regularização de 20% usa a relação de potência/0–100 do Virtus 200 TSI original como referência de plausibilidade; ela não substitui a física medida.

## Parâmetros do modelo
- Massa de cálculo: 1250 kg
- Crr: 0,012
- CdA: 0,62 m²
- Densidade do ar: 1,225 kg/m³
- Eficiência de transmissão: 0,88
- Referência original: 128 cv / 10,1 s de 0–100 km/h

## Importante
A métrica continua sendo **POTÊNCIA ESTIMADA**, não medição de dinamômetro. Inclinação, vento, aderência, massa real e qualidade/frequência do GPS influenciam o resultado.
