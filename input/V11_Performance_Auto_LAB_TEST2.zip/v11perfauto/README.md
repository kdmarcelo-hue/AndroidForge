# V11 Performance Auto LAB

Minimal Android Auto test app derived from the V11 project concept.

Goal of this build: verify that a lightweight `CarAppService` appears in Android Auto and opens a Performance monitor screen in the vehicle head unit.

Package: `com.marcelo.v11performanceauto`
Version: `1.0.0`
Category: `androidx.car.app.category.IOT`
Car App API minimum: 6

This build intentionally does NOT include ELM327/Bluetooth/CAN logic. It is only a visibility/integration test. If it appears and opens in Android Auto, the next build can add the V11 telemetry layer.

Build with:
`gradle --no-daemon clean assembleDebug`
