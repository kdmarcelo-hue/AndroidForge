package com.marcelo.v11performanceauto;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(32,32,32,32);
        TextView title = new TextView(this);
        title.setText("V11 PERFORMANCE\nAndroid Auto LAB");
        title.setTextSize(24);
        title.setTextColor(Color.rgb(13,71,161));
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView info = new TextView(this);
        info.setText("Versão de teste mínima.\nConecte ao Android Auto e procure por V11 Performance.");
        info.setTextSize(16);
        info.setGravity(Gravity.CENTER);
        root.addView(info);
        setContentView(root);
    }
}
