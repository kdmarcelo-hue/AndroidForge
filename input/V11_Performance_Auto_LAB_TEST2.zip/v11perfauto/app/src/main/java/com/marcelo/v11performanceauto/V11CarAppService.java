package com.marcelo.v11performanceauto;

import androidx.car.app.CarAppService;
import androidx.car.app.Session;
import androidx.car.app.SessionInfo;
import androidx.car.app.Screen;
import androidx.car.app.CarContext;
import androidx.car.app.model.Action;
import androidx.car.app.model.CarIcon;
import androidx.car.app.model.GridItem;
import androidx.car.app.model.Header;
import androidx.car.app.model.ItemList;
import androidx.car.app.model.GridTemplate;
import androidx.car.app.validation.HostValidator;
import androidx.core.graphics.drawable.IconCompat;

public class V11CarAppService extends CarAppService {
    @Override public HostValidator createHostValidator() {
        return HostValidator.ALLOW_ALL_HOSTS_VALIDATOR;
    }

    @Override public Session onCreateSession(SessionInfo sessionInfo) {
        return new Session() {
            @Override public Screen onCreateScreen(CarContext carContext) {
                return new PerformanceScreen(carContext);
            }
        };
    }

    static class PerformanceScreen extends Screen {
        PerformanceScreen(CarContext context) { super(context); }

        @Override public androidx.car.app.model.Template onGetTemplate() {
            ItemList.Builder list = new ItemList.Builder();
            list.addItem(metric("RPM", "—"));
            list.addItem(metric("VELOCIDADE", "— km/h"));
            list.addItem(metric("BOOST", "— bar"));
            list.addItem(metric("TENSÃO", "— V"));
            list.addItem(metric("POTÊNCIA", "— cv"));
            list.addItem(metric("TORQUE", "— Nm"));
            list.addItem(metric("STATUS", "AGUARDANDO ELM"));

            return new GridTemplate.Builder()
                    .setHeader(new Header.Builder()
                            .setTitle("V11 PERFORMANCE")
                            .setStartHeaderAction(Action.APP_ICON)
                            .build())
                    .setSingleList(list.build())
                    .build();
        }

        private GridItem metric(String title, String value) {
            return new GridItem.Builder()
                    .setTitle(title)
                    .setText(value)
                    .build();
        }
    }
}
