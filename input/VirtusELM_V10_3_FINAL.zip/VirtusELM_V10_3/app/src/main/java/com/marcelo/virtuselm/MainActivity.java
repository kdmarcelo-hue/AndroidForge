package com.marcelo.virtuselm;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.text.method.ScrollingMovementMethod;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.content.ClipData;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter bt; private BluetoothSocket socket; private InputStream in; private OutputStream out;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextView status, stats, log, result;
    private final StringBuilder technical = new StringBuilder();
    private final Object logLock = new Object();
    private volatile boolean monitoring = false;
    private volatile boolean operationRunning = false;
    private long rawCount=0, frameCount=0, rxBytes=0;
    private final LinkedHashSet<String> ids = new LinkedHashSet<>();
    private long lastStatsUi=0, lastMonitorUi=0;
    private final List<Marker> markers = new ArrayList<>();
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);
    private String lastProtocol="";

    static class Marker { String type; long raw, frames, bytes; long when; Marker(String t,long r,long f,long b){type=t;raw=r;frames=f;bytes=b;when=System.currentTimeMillis();} }

    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUi(); bt=BluetoothAdapter.getDefaultAdapter(); resetSession(); append("[00] INÍCIO DE NOVA SESSÃO — V10.3"); append("BASE COMPLETA V10 + diagnóstico OBD-II + VIN + DTC + readiness + captura CAN passiva."); append("SOMENTE LEITURA: nenhum comando de atuação, coding, adaptation, security access ou lock/unlock é transmitido."); }

    private TextView tv(String s,float size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setPadding(12,8,12,8); return t; }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    private void addFull(LinearLayout r, View v){ r.addView(v,new LinearLayout.LayoutParams(-1,-2)); }
    private LinearLayout row(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setPadding(0,0,0,0); return r; }
    private void addHalf(LinearLayout r, Button b){ r.addView(b,new LinearLayout.LayoutParams(0,-2,1)); }

    private void buildUi(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(10,10,10,10);
        TextView h=tv("VIRTUS ELM — DIAGNÓSTICO\nV10.3 — BASE COMPLETA + CAN INVESTIGATOR\nSOMENTE LEITURA",20); h.setTextColor(Color.WHITE); h.setBackgroundColor(Color.rgb(20,20,20)); addFull(root,h);
        status=tv("Status: Bluetooth não conectado",16); addFull(root,status);
        Button connect=btn("CONECTAR ELM"); connect.setOnClickListener(v->connect()); addFull(root,connect);

        TextView s1=tv("DIAGNÓSTICO OBD-II",17); s1.setTextColor(Color.DKGRAY); addFull(root,s1);
        LinearLayout r1=row(); Button quick=btn("DIAGNÓSTICO RÁPIDO — SOMENTE LEITURA"); quick.setOnClickListener(v->quickDiagnostic()); addFull(r1,quick); addFull(root,r1);
        LinearLayout r2=row(); Button data=btn("LER DADOS DO VEÍCULO"); data.setOnClickListener(v->vehicleData()); Button auto=btn("DIAGNÓSTICO COMPLETO — SOMENTE LEITURA"); auto.setOnClickListener(v->automaticDiagnostic()); addHalf(r2,data); addHalf(r2,auto); addFull(root,r2);
        LinearLayout r3=row(); Button dtc=btn("LER CÓDIGOS DE FALHA — DTC"); dtc.setOnClickListener(v->readDtc()); Button vin=btn("LER VIN — SE DISPONÍVEL"); vin.setOnClickListener(v->readVin()); addHalf(r3,dtc); addHalf(r3,vin); addFull(root,r3);
        LinearLayout r4=row(); Button statusObd=btn("STATUS OBD / READINESS"); statusObd.setOnClickListener(v->obdStatus()); Button o2=btn("TESTAR MONITORAMENTO DA SONDA"); o2.setOnClickListener(v->o2Test()); addHalf(r4,statusObd); addHalf(r4,o2); addFull(root,r4);
        LinearLayout r5=row(); Button ignition=btn("TESTE COM IGNIÇÃO DESLIGADA"); ignition.setOnClickListener(v->ignitionOffTest()); Button body=btn("ESTUDO DE MÓDULOS — SOMENTE LEITURA"); body.setOnClickListener(v->bodyStudy()); addHalf(r5,ignition); addHalf(r5,body); addFull(root,r5);
        Button dtcff=btn("DTC + FREEZE FRAME — SOMENTE LEITURA"); dtcff.setOnClickListener(v->dtcFreeze()); addFull(root,dtcff);

        TextView s2=tv("INVESTIGAÇÃO CAN PASSIVA — LOCK / UNLOCK",17); s2.setTextColor(Color.DKGRAY); addFull(root,s2);
        LinearLayout r6=row(); Button cap=btn("CAPTURAR CAN"); cap.setOnClickListener(v->startMonitor()); Button stop=btn("FINALIZAR CAPTURA"); stop.setOnClickListener(v->stopMonitor()); addHalf(r6,cap); addHalf(r6,stop); addFull(root,r6);
        LinearLayout r7=row(); Button lock=btn("MARCAR LOCK"); lock.setOnClickListener(v->mark("LOCK")); Button unlock=btn("MARCAR UNLOCK"); unlock.setOnClickListener(v->mark("UNLOCK")); addHalf(r7,lock); addHalf(r7,unlock); addFull(root,r7);
        Button analyze=btn("ANALISAR EVENTOS LOCK / UNLOCK"); analyze.setOnClickListener(v->analyze()); addFull(root,analyze);
        stats=tv("RAW: 0 • FRAMES: 0 • IDs: 0 • BYTES: 0",15); addFull(root,stats);

        LinearLayout tools=row(); Button copy=btn("COPIAR LOG"); copy.setOnClickListener(v->copyLog()); Button clear=btn("LIMPAR LOG"); clear.setOnClickListener(v->clearLog()); addHalf(tools,copy); addHalf(tools,clear); addFull(root,tools);
        result=tv("RESULTADO: —",15); result.setMovementMethod(new ScrollingMovementMethod()); addFull(root,result);
        log=tv("",12); log.setTextIsSelectable(true); log.setMovementMethod(new ScrollingMovementMethod()); ScrollView sv=new ScrollView(this); sv.addView(log); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }

    private void resetSession(){ monitoring=false; operationRunning=false; markers.clear(); rawCount=frameCount=rxBytes=0; ids.clear(); closeSocket(); }
    private boolean perms(){ if(Build.VERSION.SDK_INT>=31) return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED; return true; }
    private void connect(){ if(Build.VERSION.SDK_INT>=31&&!perms()){ requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},20); return; } if(bt==null){setStatus("Bluetooth indisponível");return;} if(!bt.isEnabled()){setStatus("Bluetooth desligado");return;} io.execute(()->connectWorker()); }
    private void connectWorker(){ if(operationRunning||monitoring){ui(()->setStatus("Operação em andamento — finalize antes de reconectar"));return;} try{ closeSocket(); BluetoothDevice dev=null; for(BluetoothDevice d:bt.getBondedDevices()){String n=d.getName(); if(n!=null){String u=n.toUpperCase(Locale.US); if(u.contains("OBD")||u.contains("ELM")||u.contains("V-LINK")||u.contains("OBDLINK")){dev=d;break;}}} if(dev==null){ui(()->setStatus("OBDII não encontrado entre dispositivos pareados"));return;} append("ELM encontrado: "+dev.getName()); socket=dev.createRfcommSocketToServiceRecord(SPP); socket.connect(); in=socket.getInputStream(); out=socket.getOutputStream(); setStatus("Bluetooth conectado — ELM pronto"); send("ATZ",2500); send("ATE0",1000); send("ATL0",1000); send("ATS1",1000); send("ATH1",1000); send("ATAT1",1000); String dp=send("ATDP",1800); lastProtocol=dp; send("ATSP0",2500); append("Inicialização concluída."); }catch(Exception e){ append("ERRO CONEXÃO: "+e); setStatus("Erro de comunicação — aplicativo mantido aberto"); closeSocket(); } }

    private String send(String cmd,long timeout){ if(out==null||in==null){append("ERRO: ELM não conectado para "+cmd);return "";} try{out.write((cmd+"\r").getBytes(StandardCharsets.US_ASCII));out.flush(); append(">> "+cmd); return readUntilPrompt(timeout);}catch(Exception e){append("ERRO TX/RX: "+e); return "";} }
    private String readUntilPrompt(long timeout){ long end=System.currentTimeMillis()+timeout; ByteArrayOutputStream b=new ByteArrayOutputStream(); try{while(System.currentTimeMillis()<end){if(in.available()>0){int x=in.read(); if(x<0)break; b.write(x); if(x=='>')break;} else Thread.sleep(4);}}catch(Exception e){append("ERRO LEITURA: "+e);} String raw=new String(b.toByteArray(),StandardCharsets.US_ASCII); String n=normalize(raw); if(!n.isEmpty())append("<< "+n); return n; }
    private String normalize(String s){ return s.replace("\u0000","").replace("\r","\n").replace("\n\n","\n").replaceAll("\n+","\n").trim(); }
    private void runOp(String name, Runnable op){ if(operationRunning){setStatus("Já existe uma operação em andamento");return;} io.execute(()->{operationRunning=true; try{ if(out==null||in==null) throw new IOException("ELM não conectado"); append("=== "+name+" ==="); op.run(); append("=== FIM: "+name+" ==="); }catch(Exception e){append("ERRO "+name+": "+e);setStatus("Erro na operação — aplicativo mantido aberto");}finally{operationRunning=false;}}); }
    private void showResult(String s){ui(()->result.setText("RESULTADO:\n"+s));}

    private String firstPayload(String resp){ String[] ls=resp.split("\\n"); for(String l:ls){String u=l.trim().toUpperCase(Locale.US); if(u.matches("^(7E[0-9A-F]|[0-9A-F]{3,8})\\s+41\\s+.*")||u.matches("^41\\s+.*")||u.matches("^43\\s+.*")||u.matches("^47\\s+.*")||u.matches("^49\\s+.*")) return u;} return resp.trim(); }
    private void queryPid(String pid,String label){ String r=send(pid,1500); String[] lines=r.split("\\n"); StringBuilder outv=new StringBuilder(); for(String l:lines){String t=l.trim(); if(t.isEmpty())continue; if(t.matches("(?i).*(41|43|47|49)\\s+.*")){outv.append(t).append("\\n");}} if(outv.length()>0) append(label+": "+outv.toString().trim()); else append(label+": sem resposta estruturada"); }

    private void quickDiagnostic(){ runOp("DIAGNÓSTICO RÁPIDO — SOMENTE LEITURA",()->{String p=send("0100",1800); StringBuilder r=new StringBuilder(); r.append("0100 / PIDs 01–20:\n").append(p).append("\n"); queryPid("010C","RPM"); queryPid("010D","VELOCIDADE"); queryPid("0105","TEMPERATURA ARREFECIMENTO"); String d=send("03",1800); append("DTC: "+d); r.append("DTC:\n").append(d); showResult(r.toString());}); }
    private void automaticDiagnostic(){ runOp("DIAGNÓSTICO COMPLETO — SOMENTE LEITURA",()->{StringBuilder r=new StringBuilder(); String[] pids={"0100","0120","0140","0160","0104","0105","010B","010C","010D","010F","0111","011F","012F","0133","0142","03","07","0A","0902","0101"}; for(String p:pids){String x=send(p,p.equals("0902")?2500:1600); append(p+": "+x); r.append(p).append(" -> ").append(x).append("\n");} showResult(r.toString());}); }
    private void vehicleData(){ runOp("LER DADOS DO VEÍCULO",()->{StringBuilder r=new StringBuilder(); String[] pids={"0100","0120","0140","0160","0104","0105","010B","010C","010D","010F","0111","011F","012F","0133","0142"}; for(String p:pids){String x=send(p,1600); append(p+": "+x); r.append(p).append(" -> ").append(x).append("\n");} showResult(r.toString());}); }
    private void readDtc(){ runOp("LER CÓDIGOS DE FALHA — DTC",()->{String r=send("03",2000); if(r.contains("43 00")||r.matches("(?s).*\\b43\\s+00\\b.*")){append("DTC: nenhum código reportado pela resposta OBD recebida.");} else append("DTC RAW: "+r); showResult(r);}); }
    private void readVin(){ runOp("LER VIN — SE DISPONÍVEL",()->{String r=send("0902",3000); String vin=parseVin(r); append("VIN: "+(vin.isEmpty()?"não identificado no parser; RAW preservado":vin)); showResult("VIN: "+(vin.isEmpty()?"não identificado":vin)+"\nRAW:\n"+r);}); }
    private String parseVin(String r){String h=r.replaceAll("[^0-9A-Fa-f]","").toUpperCase(Locale.US); int i=h.indexOf("490201"); if(i<0)return ""; String rest=h.substring(i+6); StringBuilder b=new StringBuilder(); for(int j=0;j+1<rest.length()&&b.length()<17;j+=2){int v=Integer.parseInt(rest.substring(j,j+2),16); if(v>=32&&v<=126)b.append((char)v);} String v=b.toString(); return v.length()==17?v:"";}
    private void dtcFreeze(){ runOp("DTC + FREEZE FRAME — SOMENTE LEITURA",()->{String a=send("03",2000); String b=send("0200",2000); String c=send("0201",2000); append("MODE 03: "+a); append("FREEZE FRAME 0200: "+b); append("FREEZE FRAME 0201: "+c); showResult("MODE 03:\n"+a+"\n\n0200:\n"+b+"\n\n0201:\n"+c);}); }
    private void obdStatus(){ runOp("STATUS OBD / READINESS",()->{StringBuilder r=new StringBuilder(); for(String p:new String[]{"0101","0102","0106","0107","0110"}){String x=send(p,1600);append(p+": "+x);r.append(p).append(" -> ").append(x).append("\n");}showResult(r.toString());}); }
    private void o2Test(){ runOp("TESTAR MONITORAMENTO DA SONDA",()->{StringBuilder r=new StringBuilder();for(String p:new String[]{"05","06","07","0A"}){String x=send(p,1800);append(p+": "+x);r.append(p).append(" -> ").append(x).append("\n");}showResult(r.toString());}); }
    private void ignitionOffTest(){ runOp("TESTE COM IGNIÇÃO DESLIGADA",()->{String a=send("ATI",1500);String b=send("ATDP",1500);String c=send("0100",2200);boolean ecu=c.matches("(?s).*(41\\s+00|41 00).*");String conclusion=ecu?"ELM respondeu e houve resposta OBD/CAN com a condição testada.":"ELM respondeu, mas nenhuma resposta CAN/ECU foi identificada para 0100. Isso não significa que não existam outros módulos.";append("CONCLUSÃO: "+conclusion);showResult(a+"\n"+b+"\n0100:\n"+c+"\n\n"+conclusion);}); }
    private void bodyStudy(){ runOp("ESTUDO DE MÓDULOS — SOMENTE LEITURA",()->{String a=send("ATDP",1600);String b=send("0100",2200);append("PROTOCOLO: "+a);append("0100: "+b);showResult("PROTOCOLO:\n"+a+"\n\n0100:\n"+b+"\n\nNenhum comando de atuação, segurança, coding ou lock/unlock foi transmitido.");}); }

    private volatile boolean monitorRejected = false;
    private long monitorStartedAt = 0;

    private void startMonitor(){
        if(operationRunning||monitoring){setStatus(operationRunning?"Finalize a operação atual antes de capturar":"Captura já ativa");return;}
        if(out==null||in==null){setStatus("Conecte o ELM primeiro");return;}
        io.execute(()->{
            monitoring=true; monitorRejected=false; monitorStartedAt=System.currentTimeMillis();
            rawCount=frameCount=rxBytes=0; ids.clear(); markers.clear();
            try{
                append("=== INÍCIO DA CAPTURA CAN PASSIVA ===");
                append("Preparando o ELM para Monitor All — somente leitura.");
                String dp=send("ATDP",1500);
                String proto=dp.toUpperCase(Locale.US);
                if(proto.contains("29/500")||proto.contains("29")){
                    append("Protocolo detectado: CAN 29/500 — fixando protocolo 7 para a captura.");
                    send("ATSP7",1200);
                }else{
                    append("Protocolo detectado: CAN 11/500 — fixando protocolo 6 para a captura.");
                    send("ATSP6",1200);
                }
                String init=send("0100",2200);
                if(!init.matches("(?s).*41\\s+00.*")) append("AVISO: 0100 não retornou resposta OBD; ainda assim a captura passiva será tentada.");
                send("AT AR",1000);
                send("ATE0",700);
                send("ATH1",700);
                send("ATS1",700);
                send("ATL1",700);
                send("ATCAF0",1000);
                append("AT MA será usado em Monitor All. O aplicativo não transmite mensagens CAN ao veículo.");
                out.write("AT MA\r".getBytes(StandardCharsets.US_ASCII)); out.flush(); append(">> AT MA");
                setStatus("MONITORAMENTO CAN INICIANDO — aguardando barramento");
                monitorLoop();
            }catch(Exception e){append("ERRO MONITOR: "+e);setStatus("Captura interrompida — dados preservados");}
            finally{monitoring=false;}
        });
    }
    private void monitorLoop() throws IOException { ByteArrayOutputStream line=new ByteArrayOutputStream(); long lastByte=System.currentTimeMillis(); while(monitoring){ if(in.available()>0){int x=in.read(); if(x<0)throw new IOException("socket fechado"); rxBytes++; lastByte=System.currentTimeMillis(); if(x=='\r'||x=='\n'){flushMonitorLine(line);} else {line.write(x); if(line.size()>1024){flushMonitorLine(line);}} } else { if(line.size()>0 && System.currentTimeMillis()-lastByte>80) flushMonitorLine(line); try{Thread.sleep(2);}catch(InterruptedException e){Thread.currentThread().interrupt();break;} } } if(line.size()>0)flushMonitorLine(line); }
    private void flushMonitorLine(ByteArrayOutputStream line){ if(line.size()==0)return; String s=new String(line.toByteArray(),StandardCharsets.US_ASCII).trim();line.reset();if(s.isEmpty())return;processMonitorRaw(s); }
    private void processMonitorRaw(String s){
        String u=s.toUpperCase(Locale.US).trim();
        // ELM control responses are not CAN frames and must never inflate the CAN counters.
        if(u.equals("OK")||u.equals(">")||u.equals("STOPPED")||u.contains("SEARCHING")||u.contains("NO DATA")){
            append("ELM CONTROL (fora da captura CAN): "+u);
            if(u.equals(">") && System.currentTimeMillis()-monitorStartedAt<2500){
                monitorRejected=true;
                append("ERRO: AT MA retornou o prompt imediatamente — Monitor All não permaneceu ativo.");
                setStatus("AT MA não permaneceu ativo — captura não iniciada");
                monitoring=false;
            }
            return;
        }
        rawCount++;
        synchronized(logLock){technical.append("[MONITOR RAW] ").append(s).append('\n');}
        if(u.contains("BUFFER FULL")){append("!! ELM REPORTOU BUFFER FULL — RAW preservado.");updateStats();return;}
        ParsedCan pc=parseCan(s);
        if(pc.ok){frameCount++;ids.add(pc.id);if(frameCount<=8||frameCount%50==0)append("CAN "+pc.id+" DLC="+pc.dlc+" DATA="+pc.data);}
        else if(rawCount<=8||rawCount%100==0){append("RAW não classificado #"+rawCount+": "+s);}
        updateStats();
    }
    static class ParsedCan {boolean ok;String id="",data="";int dlc;}
    private ParsedCan parseCan(String s){ParsedCan p=new ParsedCan();String clean=s.replaceAll("[^0-9A-Fa-f ]"," ").trim().replaceAll("\\s+"," ");if(clean.isEmpty())return p;String[] a=clean.split(" ");if(a.length<2)return p;
        // Common ELM CAN monitor forms: 11/29-bit header followed by DLC and data. Keep conservative.
        for(int i=1;i<a.length;i++){try{int d=Integer.parseInt(a[i],16);if(d>=0&&d<=8&&a.length>=i+1+d){String id=String.join(" ",Arrays.copyOfRange(a,0,i)); if(id.length()>=2&&id.length()<=12){p.ok=true;p.id=id;p.dlc=d;StringBuilder db=new StringBuilder();for(int j=i+1;j<a.length;j++){if(db.length()>0)db.append(' ');db.append(a[j]);}p.data=db.toString();return p;}}}catch(Exception ignored){}}
        return p;
    }
    private void updateStats(){long now=System.currentTimeMillis();if(now-lastStatsUi<250)return;lastStatsUi=now;ui(()->stats.setText("RAW: "+rawCount+" • FRAMES: "+frameCount+" • IDs: "+ids.size()+" • BYTES: "+rxBytes));}
    private void mark(String type){if(!monitoring){append("MARCADOR ignorado: captura não está ativa");return;}Marker m=new Marker(type,rawCount,frameCount,rxBytes);markers.add(m);append("*** MARCADOR "+type+" | RAW="+m.raw+" | FRAMES="+m.frames+" | BYTES="+m.bytes+" | "+sdf.format(new Date(m.when))+" ***");}
    private void stopMonitor(){if(!monitoring)return;io.execute(()->{try{ // ELM documentation: any single input character interrupts AT MA; then wait for prompt.
            out.write('\r');out.flush();append(">> [INTERRUPÇÃO] 1 caractere enviado ao ELM");long end=System.currentTimeMillis()+3000;ByteArrayOutputStream b=new ByteArrayOutputStream();while(System.currentTimeMillis()<end){if(in.available()>0){int x=in.read();if(x<0)break;b.write(x);if(x=='>')break;}else Thread.sleep(5);}String s=normalize(new String(b.toByteArray(),StandardCharsets.US_ASCII));if(!s.isEmpty())append("<< "+s); }catch(Exception e){append("ERRO AO INTERROMPER: "+e);}finally{monitoring=false;append("=== FIM DA CAPTURA CAN PASSIVA ===");append("RAW RECEBIDOS: "+rawCount+" | FRAMES DECODIFICADOS: "+frameCount+" | IDS: "+ids.size()+" | BYTES: "+rxBytes);setStatus("Captura finalizada — dados preservados");updateStats();}});}
    private void analyze(){ if(markers.isEmpty()){append("=== ANÁLISE LOCK / UNLOCK ===");append("Nenhum marcador registrado.");return;}append("=== ANÁLISE LOCK / UNLOCK ===");for(int i=0;i<markers.size();i++){Marker m=markers.get(i);append("EVENTO "+(i+1)+": "+m.type+" | RAW="+m.raw+" | FRAMES="+m.frames+" | BYTES="+m.bytes+" | "+sdf.format(new Date(m.when)));}append("A análise mantém o RAW como fonte primária; frames não classificados não são descartados.");showResult("Marcadores registrados: "+markers.size()+"\nRAW: "+rawCount+"\nFrames decodificados: "+frameCount+"\nIDs: "+ids.size());}

    private void copyLog(){String text; synchronized(logLock){text=technical.toString();} if(text.isEmpty()){toast("Log vazio");return;} ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("VIRTUS ELM V10.3 — LOG",text));toast("LOG COPIADO");}
    private void clearLog(){ if(monitoring||operationRunning){toast("Finalize a operação antes de limpar o log");return;} synchronized(logLock){technical.setLength(0);} log.setText(""); result.setText("RESULTADO: —"); rawCount=frameCount=rxBytes=0;ids.clear();markers.clear();stats.setText("RAW: 0 • FRAMES: 0 • IDs: 0 • BYTES: 0");append("[00] INÍCIO DE NOVA SESSÃO — LOG LIMPO — V10.3"); }
    private void toast(String s){ui(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
    private void setStatus(String s){ui(()->status.setText("Status: "+s));}
    private void ui(Runnable r){main.post(r);}
    private void append(String s){String line="["+sdf.format(new Date())+"] "+s; synchronized(logLock){technical.append(line).append('\n');} ui(()->{if(log!=null){log.append(line+"\n");}});}
    private void closeSocket(){try{if(in!=null)in.close();}catch(Exception ignored){}try{if(out!=null)out.close();}catch(Exception ignored){}try{if(socket!=null)socket.close();}catch(Exception ignored){}in=null;out=null;socket=null;}
    @Override protected void onDestroy(){monitoring=false;closeSocket();io.shutdownNow();super.onDestroy();}
}
