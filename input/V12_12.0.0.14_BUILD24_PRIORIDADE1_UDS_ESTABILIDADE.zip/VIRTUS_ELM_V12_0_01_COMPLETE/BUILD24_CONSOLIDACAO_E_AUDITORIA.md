# V12 12.0.0.14 — BUILD 24 CONSOLIDADO

## Identificação preservada
- `versionName`: 12.0.0.14
- `versionCode`: 24
- `applicationId`: `v12.marcelo.virtuselm.v12_0_14`
- A identificação não foi incrementada nesta consolidação, conforme solicitado.

## Consolidação do que já existia no projeto
- Tela CUSTOM com catálogo mestre VW, agrupamento por categoria, estado de compatibilidade, seleção bloqueada quando não validada, backup do estado observado, consulta/revisão do backup, descoberta de módulos, histórico e preparação/revisão de alterações.
- Tela Gráficos separada da tela Performance, com gráfico combinado de RPM, velocidade, pedal e boost, modos ao vivo e histórico.
- Linha horizontal de pico do boost e legenda numérica no gráfico combinado; o valor é mantido em memória durante a puxada e reiniciado ao iniciar nova puxada/novo processo do app.
- Indicadores de performance, incluindo boost máximo, RPM máximo, velocidade máxima, qualidade da aquisição e duração.
- Catálogo de DTC VAG e biblioteca de personalizações existente preservados.
- Backup descrito como snapshot do estado observado; não é apresentado como backup integral de coding/adaptações ECU.

## Correção de confiabilidade nesta consolidação
A rotina de descoberta não aceitava mais um `7E 00` genérico sem cabeçalho como prova de qualquer endereço sondado. Isso podia atribuir uma resposta sem correlação física ao endpoint errado. Agora:
- exige o CAN ID de resposta exato do endpoint em teste;
- exige payload UDS correlacionado ao TesterPresent: resposta positiva `7E 00` ou negativa `7F 3E NRC`;
- resposta sem cabeçalho CAN é inconclusiva e não cria módulo;
- NRC prova que houve resposta diagnóstica, mas não prova que o serviço solicitado foi aceito;
- nenhum endereço é convertido automaticamente em nome de módulo.

## Descoberta multiprotocolo presente
- CAN 11-bit: faixa VAG candidata `700–774` e faixa OBD `7E0–7E7`.
- CAN 29-bit: famílias candidatas `17FC00xx → 17FE00xx` e `18DAxxF1 → 18DAF1xx`.
- Endpoints respondentes recebem consultas somente leitura para VIN DID `F190` e DTC UDS `19 02` com máscara `2D`.
- Gateway `710/77A` é tratado como candidato; DID `2A26` só é consultado depois de resposta física correlacionada nesse endpoint.
- A lista de instalação do Gateway, quando validada, significa configuração lógica; não é prova de presença física atual.

## Limites técnicos explícitos
- As famílias CAN são sondagens candidatas, não um mapeamento garantido do Virtus específico.
- O relatório Car Scanner fornecido não contém IDs CAN físicos, RAW CAN nem a sequência de descoberta. Logo, o V12 não inventa associação entre endereços e módulos como 01-Engine, 03-ABS, 09-BCM etc.
- O bitmap DID `2A26` é aceito apenas no formato validado no parser atual; outras variantes permanecem não interpretadas, não convertidas em ausência de módulos.
- O teste físico no Virtus ainda é necessário para confirmar quais endpoints e serviços respondem com este ELM327.
- A compilação Android não foi executada neste ambiente: não há Gradle Wrapper nem Android SDK disponíveis aqui. O ZIP deve passar pelo GitHub Actions antes da instalação.
- Não foram adicionadas operações de coding, adaptação, Security Access, escrita de DIDs ou limpeza de DTC.

## Referência de regressão funcional — relatório Car Scanner de 04/11/2026
Módulos listados no relatório: 01 Engine, 02 Transmission, 03 ABS, 05 Access/Start Authorization, 08 HVAC, 09 Onboard Supply, 10 Parking Assistant, 13 ACC, 15 Airbag, 17 Instrument Cluster, 19 CAN Gateway, 44 Steering Assist, 45 Parking Assistant e 5F Information Electronics. A lista é referência de cobertura para comparação manual; não foi usada para fabricar respostas nem IDs CAN.

DTCs de motor reportados: P0300, P0301, P0363 e P0303 (pendentes). Outros registros históricos/inativos: HVAC B10F000, ACC U112300 e painel U111000. O V12 deve preservar estado, módulo de origem, RAW e freeze frame quando fornecidos pela ECU; não deve converter falha sem resposta em “sem falhas”.

## Verificações realizadas no pacote
- ZIP de origem extraído sem erro.
- Identificação de versão conferida no `app/build.gradle`.
- Alteração de correlação CAN/UDS conferida por inspeção estática.
- Catálogos JSON conferidos quanto à sintaxe.
- Integridade do ZIP final verificada após geração.
- Não declarar build Android ou teste em veículo como concluído.


## BUILD24 FIX — estabilidade do Explorador VAG e layout do Histórico

- Corrigido o caminho de desconexão no Explorador VAG: a mensagem de erro e o AlertDialog são publicados na thread principal por `ui(...)`; não há criação de diálogo na thread de I/O.
- O Explorador VAG agora apresenta status NÃO EXECUTADO, causa, orientação e preserva a tela/resultados quando o ELM está desconectado ou a aplicação está em simulação. Nenhum comando é transmitido nesse cenário.
- A varredura VAG multiprotocolo também usa a thread principal para apresentar a condição de conexão ausente.
- Botões do Histórico receberam larguras mínimas zeradas, altura de toque uniforme, texto centralizado e quebra em até duas linhas para evitar corte horizontal.
- Identificação mantida: versionName 12.0.0.14, versionCode 24, applicationId v12.marcelo.virtuselm.v12_0_14.
- Validação deste pacote: inspeção estática do fluxo, conferência de identificadores e integridade ZIP. Build Android, teste em aparelho e teste físico com ELM ainda precisam ser executados pelo GitHub Actions e no veículo.


## BUILD24 — Prioridade 1: contenção de falhas VAG/UDS (revisão seguinte)
- Leitura consolidada verifica transporte ELM real antes de enfileirar consultas avançadas VAG/UDS; sem transporte, mostra relatório e não transmite comandos.
- `runOp` captura falhas inesperadas, registra a causa, atualiza o status/resultado pela thread principal e protege a finalização da sessão.
- Plano mestre de continuidade incluído em `PLANO_MESTRE_CONTINUIDADE_V12_12.0.0.14_BUILD24.md`.
- Ainda pendentes: compilação Android, testes automatizados completos, teste com ELM desconectado e teste físico conectado ao Virtus.
