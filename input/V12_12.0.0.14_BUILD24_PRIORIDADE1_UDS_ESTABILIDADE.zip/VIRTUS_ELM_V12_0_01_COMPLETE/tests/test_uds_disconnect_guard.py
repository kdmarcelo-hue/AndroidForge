from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAVA = (ROOT / 'app/src/main/java/com/marcelo/virtuselm/MainActivity.java').read_text()


def test_advanced_uds_is_blocked_before_queue_without_real_transport():
    start = JAVA.index('private void runUnifiedDiagnostic')
    end = JAVA.index('private void addDiagSection', start)
    method = JAVA[start:end]
    guard = method.index('if (advancedUdsSelected && !realTransportAvailable)')
    queue = method.index('runOp(complete?')
    assert guard < queue
    assert 'Nenhum comando UDS/VAG foi transmitido' in method
    assert 'return;' in method[guard:queue]


def test_operation_boundary_catches_unexpected_throwables_and_finalizes():
    start = JAVA.index('private void runOp(String name, Runnable op)')
    end = JAVA.index('private void showResult', start)
    method = JAVA[start:end]
    assert 'catch(Throwable e)' in method
    assert 'finally' in method
    assert 'finishDiagnosticSession' in method
    assert 'operationRunning=false' in method
