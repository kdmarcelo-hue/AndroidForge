# V12 — Plano mestre de continuidade

**Versão mantida:** 12.0.0.14 — BUILD24 / versionCode 24  
**Regra:** preservar as correções visuais já aprovadas e incluir este documento em todos os próximos pacotes-fonte.

## Confirmado pelo usuário no aparelho
- Alinhamento dos botões do Histórico corrigido.
- Botões Escolher pasta de logs e Performance sem deslocamento vertical.
- Algarismos da tela Performance com tamanho uniforme.

## Prioridade atual — estabilidade do Explorador VAG/UDS
- Não encerrar o processo nem a tela quando o ELM estiver desconectado, em simulação, com streams inválidos, timeout, resposta negativa ou falha de transporte.
- Informar status, causa e ação recomendada dentro do app.
- Preservar logs e resultados já obtidos.
- Não transmitir consultas UDS/VAG sem transporte real confirmado.
- Não classificar silêncio, timeout ou NRC como módulo inexistente ou ausência de DTC.
- Capturar falhas inesperadas na fronteira da operação e finalizar a sessão com segurança.

## Próximas prioridades
1. Descoberta e identificação real dos módulos; distinguir candidato, resposta física, identidade e leitura de DTC.
2. Investigação DTC/EPC e preservação de RAW, status e Freeze Frame.
3. Biblioteca técnica VW/VAG, referências Ross-Tech, VCDS, OBDeleven e Carista.
4. Performance: gráfico somente na aba Gráficos, linha de pico do boost, consistência entre Performance e histórico, reset por nova puxada/sessão.
5. Histórico: CSV, nomes longos, seleção/exclusão de pendentes e resumo de puxadas.
6. CUSTOM: diagnóstico, personalização, recursos avançados, backup local e histórico; deixar explícito o que não grava/restaura ECU.

## Regras permanentes
- Nenhum coding, adaptação, Security Access, escrita ou limpeza de DTC sem autorização explícita.
- Backup local de estado observado não é backup integral de coding ECU.
- Não inventar identificação de módulos nem converter ausência de resposta em “sem falhas”.
- Não remover nem regredir correções visuais aprovadas.
- Em cada entrega, listar implementado, validado por teste automatizado, compilado e ainda dependente de teste no veículo separadamente.

## Registro desta revisão — prioridade 1
- A leitura consolidada agora verifica se qualquer opção avançada VAG/UDS foi selecionada sem transporte ELM real. Nesse caso, bloqueia a transmissão, apresenta relatório explicativo, preserva seleção e resultados e retorna sem enfileirar rotinas avançadas.
- `runOp` agora captura também falhas inesperadas (`Throwable`) na fronteira da operação, registra a causa, atualiza a interface na thread principal e finaliza a sessão em bloco protegido. Isso reduz o risco de uma exceção da rotina diagnóstica encerrar o processo.
- Limite: captura de exceções não protege contra encerramento pelo sistema operacional, falha nativa, ANR ou falta de memória; compilação e teste físico ainda são necessários.
