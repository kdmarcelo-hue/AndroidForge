# V12 0.08 — versão consolidada

- Ícone oficial azul futurista/vermelho com zona segura adaptativa, arte original preservada.
- Instalação paralela: applicationId custom008; versionCode 9.
- CUSTOM: varredura de leitura com classificação conservadora, histórico de revisões, backup/consulta de reversão e bloqueio de gravação sem procedimento validado.
- Config: teste progressivo do pedal integrado à calibração; remove botão duplicado em Desenvolvimento.
- Antes da instalação: validar build no GitHub Actions e executar teste de campo com ELM327 real.
