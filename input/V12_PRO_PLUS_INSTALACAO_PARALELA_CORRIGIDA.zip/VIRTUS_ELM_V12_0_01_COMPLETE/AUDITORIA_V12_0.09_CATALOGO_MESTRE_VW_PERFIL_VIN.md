# V12 0.09 — Catálogo mestre Volkswagen e perfis por VIN

## Entrega desta versão
- Versão Android 0.09, versionCode 10 e applicationId `v12.marcelo.virtuselm.custom009` para instalação paralela.
- Catálogo local `app/src/main/assets/vw_customization_catalog.json`, organizado por categorias, identificadores estáveis, famílias de módulos e estado de compatibilidade.
- A lista inclui itens candidatos de personalização para investigação em várias famílias Volkswagen; não afirma que todos existam ou sejam compatíveis em todos os modelos.
- Todos os itens iniciam como `UNKNOWN` / `NOT_VALIDATED`, visualmente escurecidos e bloqueados para seleção. O scan atual de DID F190 só detecta resposta de leitura e NÃO é tratado como validação de codificação.
- Backups passam a ser salvos em `files/vehicles/<VIN>/v12_vehicle_state_backup.json`; quando o VIN não está identificado, ficam isolados em `VIN_NAO_IDENTIFICADO`.

## Limites conhecidos
- Esta entrega NÃO inclui um banco proprietário do Carista/OBDeleven nem presume que exista uma lista universal de todas as codificações VW.
- O catálogo é um seed de referência. Cada item precisa de fonte técnica verificável, aplicabilidade por plataforma/módulo e procedimento de leitura/escrita validado antes de ser liberado.
- A descoberta atual usa uma varredura de leitura limitada a IDs de solicitação 11-bit comuns; não identifica universalmente todos os módulos, e não comprova suporte a escrita.
- Nenhum comando de codificação/adaptação é habilitado por esta mudança. Backup é snapshot de dados observados, não dump integral de ECU.
- Compilação Android não foi executada neste ambiente; executar GitHub Actions e validar o APK no aparelho.

## Critérios de validação recomendados
1. Compilar debug/release no workflow.
2. Instalar 0.09 ao lado da versão anterior e conferir o launcher.
3. Conferir que catálogo carrega e que itens desconhecidos aparecem escurecidos/bloqueados.
4. Executar scan somente leitura com ELM real e confirmar que a lista não muda para suportada apenas por uma resposta F190.
5. Criar snapshots com VIN conhecido e não identificado e verificar isolamento por pasta.
