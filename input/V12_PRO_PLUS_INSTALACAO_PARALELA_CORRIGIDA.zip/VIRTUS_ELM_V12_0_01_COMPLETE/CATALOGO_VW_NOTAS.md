# Catálogo de personalizações Volkswagen — notas

Itens candidatos: 158 em 14 categorias.

Este é um catálogo inicial de referência, não uma lista oficial, completa ou garantida de todas as funções VW. Cada entrada inicia UNKNOWN. O V12 deve habilitar uma operação somente após mapear módulo/serviço/identificador/valores, confirmar condições de segurança e validar leitura posterior. Fontes comerciais proprietárias não foram copiadas.
