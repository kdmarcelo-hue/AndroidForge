# V12 0.07 — CUSTOM / descoberta / backup e reversão

## Consolidado nesta revisão
- Versionamento atualizado para `versionName 0.07`, `versionCode 8` e applicationId paralelo `v12.marcelo.virtuselm.custom007`.
- Mantido o recurso do ícone oficial azul futurista com detalhes vermelhos em `drawable-nodpi/v12_official_icon.png`, usado pelo foreground do ícone adaptativo.
- CUSTOM agora oferece varredura somente leitura dos endereços de requisição 11-bit comuns `7E0`–`7E7`, tentando leitura UDS DID `F190` e registrando resposta bruta, endereço e estado de resposta.
- Os resultados são guardados localmente e incluídos no snapshot de backup.
- A revisão da seleção deixa explícito que não existe mapeamento de gravação validado no catálogo genérico; nenhuma escrita é transmitida por essa tela.
- Backup JSON agora inclui snapshot de telemetria, DTCs já conhecidos, módulos detectados e registros de transação que existam.
- A consulta do backup mostra quantos módulos e registros de operação existem e oferece verificação de restauração. Sem parâmetro com valor original, procedimento de escrita e rollback validados, a restauração é bloqueada.

## Limites técnicos explícitos
- A varredura `7E0`–`7E7` é uma tentativa de descoberta parcial, não uma enumeração universal de todos os módulos do veículo. Ausência de resposta não prova incompatibilidade.
- Uma resposta ao DID `F190` não comprova que o módulo aceite codificação/adaptação.
- O catálogo visual de funções ainda não contém identificadores/serviços de gravação verificados para o VIN e os módulos reais deste Virtus. Por isso, não existe gravação de customização habilitada nesta versão; a confirmação “GRAVAR NO MÓDULO” não pode ser honestamente acionada para opções genéricas.
- O backup de telemetria não é uma imagem completa das ECUs. O método de transação foi preparado para persistir registros futuros, mas não há transações de escrita válidas cadastradas; portanto, a reversão ECU continua indisponível até mapear e validar os parâmetros reais.
- O pacote ZIP foi verificado estruturalmente. Não foi compilado localmente: o projeto não inclui `gradlew`/`gradle-wrapper.jar` e o ambiente local não tem Gradle instalado. Compilar pelo GitHub Actions continua obrigatório antes de instalar.

## Próxima validação no veículo
1. Conectar o ELM327 real, com veículo parado e ignição conforme recomendado para diagnóstico.
2. Executar a varredura e salvar os logs RAW/respostas.
3. Identificar os módulos com endereço, identificação de hardware/software e serviço suportado.
4. Só então preencher catálogo por função com leitura, domínio de valores, pré-condições, escrita, confirmação posterior e retorno validado.
