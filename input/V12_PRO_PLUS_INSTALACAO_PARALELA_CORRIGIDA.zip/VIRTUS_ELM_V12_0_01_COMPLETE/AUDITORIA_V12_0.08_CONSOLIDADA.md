# V12 0.08 — entrega consolidada e auditoria

## Identidade e instalação
- `versionName`: 0.08; `versionCode`: 9.
- `applicationId`: `v12.marcelo.virtuselm.custom008`, diferente das versões custom003–custom007 para permitir instalação lado a lado.
- Não remover nem desinstalar a versão anterior para instalar esta. O Android trata-a como aplicativo separado.
- Ícone oficial preservado em `drawable-nodpi/v12_official_icon.png`; novo foreground com margem transparente usa a mesma arte reduzida, sem redesenho, para respeitar a zona segura do launcher adaptativo. Recursos de launcher legado gerados para mdpi–xxxhdpi.

## CUSTOM
- Mantidos os grupos funcionais, seleção e revisão.
- Mantida a varredura de leitura de endereços de diagnóstico, agora com critério mais estrito para considerar resposta positiva. Resposta não identifica por si só o módulo nem prova capacidade de escrita.
- Adicionado histórico local de revisões de personalização, com timestamp, VIN disponível, funções selecionadas e estado explícito `REVIEW_ONLY_NO_WRITE`.
- Mantidos backup e consulta/reversão; o backup registra estado observado, não dump integral de ECU. A reversão permanece bloqueada sem valor original, serviço de escrita e procedimento de retorno comprovados.
- Nenhum comando de escrita foi inventado para o catálogo genérico. O fluxo de gravação continua bloqueado até que uma função tenha mapeamento e validação específicos para o módulo/VIN. Isso é deliberado para não alegar suporte que o ELM327 não demonstrou.

## Pedal / Config
- Removido o cartão separado “DESENVOLVIMENTO / TESTE DO ACELERADOR”.
- Teste progressivo integrado à mesma seção “CALIBRAÇÃO DO PEDAL”, junto à seleção explícita da fonte e calibração 0/50/100.
- Novo teste captura manualmente cinco amostras 0/25/50/75/100 da fonte selecionada, compara com throttle PID 0111 quando disponível, registra RAW e detecta tendência não monotônica. Exige conexão real e bloqueia simulação.
- O teste é somente leitura; não envia calibração à ECU. A validação em campo continua necessária.

## Verificações efetuadas
- ZIP de origem íntegro antes da edição.
- Arquivos Java/XML revisados por substituições estruturais e verificações estáticas.
- Arte oficial original mantida sem alteração; nova versão de foreground é apenas uma cópia redimensionada sobre transparência.
- Compilação Android não executada neste ambiente (sem Gradle/Android SDK local e sem `gradlew` no pacote). Deve ser confirmada no GitHub Actions antes de instalar o APK.

## Itens que exigem teste no veículo real
1. Identificação de módulos e interpretação ISO-TP no ELM327 utilizado.
2. Respostas dos PIDs do pedal e throttle, em veículo parado e condição segura.
3. Compatibilidade de cada função CUSTOM.
4. Escrita/restauração só depois de implementar e validar serviços, identificadores, acesso, faixas de valores e retorno específicos; não há escrita universal baseada apenas no ELM327.
