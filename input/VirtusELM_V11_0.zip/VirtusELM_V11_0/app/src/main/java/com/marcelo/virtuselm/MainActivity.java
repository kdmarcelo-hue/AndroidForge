package com.marcelo.virtuselm;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.text.method.ScrollingMovementMethod;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import android.content.ClipData;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter bt; private BluetoothSocket socket; private InputStream in; private OutputStream out;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextView status, stats, log, result;
    private TextView dashConn, dashVin, dashIgnition, dashRpm, dashFuel, dashVolt, dashMap, dashBaro, dashBoost, dashBoostMax, dashThrottle, dashCan;
    private ProgressBar rpmBar, boostBar, throttleBar;
    private Button connectButton;
    private TextView healthChip;
    private int noDataCycles = 0;
    private boolean recoveringSession = false;
    private final ScheduledExecutorService dashboardExec = Executors.newSingleThreadScheduledExecutor();
    private volatile boolean dashboardPolling = false;
    private volatile boolean stopRequested = false;
    private volatile long stopDeadline = 0;
    private String lastVin = "—";
    private double lastRpm = 0, lastFuel = -1, lastVolt = -1, lastThrottle = -1, lastMap = -1, lastBaro = -1, lastBoost = -1, maxBoost = -1;
    private boolean ecuResponding = false;
    private final StringBuilder technical = new StringBuilder();
    private final Object logLock = new Object();
    private volatile boolean monitoring = false;
    private volatile boolean operationRunning = false;
    private long rawCount=0, frameCount=0, rxBytes=0;
    private final LinkedHashSet<String> ids = new LinkedHashSet<>();
    private final LinkedHashMap<String,Long> idCounts = new LinkedHashMap<>();
    private long lastStatsUi=0, lastMonitorUi=0;
    private final List<Marker> markers = new ArrayList<>();
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);
    private String lastProtocol="";
    private volatile boolean intentionalDisconnect = false;
    private volatile boolean reconnecting = false;

    static class Marker {
        String type; long raw, frames, bytes, when; Map<String,Long> idsAt;
        Marker(String t,long r,long f,long b,Map<String,Long> counts){
            type=t; raw=r; frames=f; bytes=b; when=System.currentTimeMillis(); idsAt=new LinkedHashMap<>(counts);
        }
    }

    @Override public void onCreate(Bundle b){ super.onCreate(b); buildUi(); bt=BluetoothAdapter.getDefaultAdapter(); resetSession(); append("[00] INÍCIO DE NOVA SESSÃO — V11.0"); append("BASE COMPLETA V10 + boost real por BARO + captura CAN passiva + análise diferencial de eventos."); append("SOMENTE LEITURA: nenhum comando de atuação, coding, adaptation, security access ou CAN arbitrário é transmitido."); startDashboardPolling(); }

    private static final int BLUE = Color.rgb(13, 71, 161);
    private static final int BLUE_DARK = Color.rgb(7, 45, 99);
    private static final int BLUE_LIGHT = Color.rgb(232, 240, 254);
    private static final int BLUE_BORDER = Color.rgb(144, 180, 220);
    private static final int TEXT = Color.rgb(35, 45, 55);

    private TextView tv(String s,float size){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(TEXT);
        t.setPadding(14,10,14,10); return t;
    }
    private Button btn(String s){
        Button b=new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextSize(12); b.setTextColor(Color.rgb(235,248,255));
        b.setMinHeight(46); b.setMinimumHeight(46); b.setPadding(10,5,10,5);
        android.graphics.drawable.GradientDrawable normal=new android.graphics.drawable.GradientDrawable();
        normal.setColor(Color.rgb(7,38,70)); normal.setCornerRadius(24f); normal.setStroke(1, Color.rgb(25,125,195));
        android.graphics.drawable.GradientDrawable pressed=new android.graphics.drawable.GradientDrawable();
        pressed.setColor(Color.rgb(10,70,115)); pressed.setCornerRadius(24f); pressed.setStroke(2, Color.rgb(0,200,255));
        android.graphics.drawable.StateListDrawable states=new android.graphics.drawable.StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, pressed); states.addState(new int[]{}, normal);
        b.setBackground(states); b.setStateListAnimator(null); b.setSoundEffectsEnabled(true);
        return b;
    }
    private void addFull(LinearLayout r, View v){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(6,3,6,3); r.addView(v,lp);
    }
    private LinearLayout row(){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(4,0,4,0); return r;
    }
    private void addHalf(LinearLayout r, Button b){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(3,0,3,0);
        r.addView(b,lp);
    }
    private TextView section(String title){
        TextView t=tv(title,17); t.setTextColor(Color.WHITE); t.setTypeface(null,android.graphics.Typeface.BOLD);
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable(); bg.setColor(BLUE); bg.setCornerRadius(18f); t.setBackground(bg); t.setPadding(14,12,14,12); return t;
    }
    private void buildUi(){
        final int BG = Color.rgb(3,16,34);
        final int CARD = Color.rgb(5,28,54);
        final int CARD2 = Color.rgb(7,38,70);
        final int CYAN = Color.rgb(0,190,255);
        final int CYAN2 = Color.rgb(55,160,255);
        final int WHITE = Color.rgb(240,248,255);
        final int MUTED = Color.rgb(155,184,210);

        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(BG);
        ScrollView page = new ScrollView(this);
        page.setFillViewport(true);
        page.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(12,12,12,96);
        page.addView(root,new ScrollView.LayoutParams(-1,-2));
        frame.addView(page,new FrameLayout.LayoutParams(-1,-1));

        // HERO
        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable heroBg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(4,31,66),Color.rgb(2,14,31)});
        heroBg.setCornerRadius(28f); heroBg.setStroke(1,CYAN2); hero.setBackground(heroBg);
        hero.setPadding(16,14,16,10);
        LinearLayout brand = new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL);
        TextView vLogo=tv("V",44); vLogo.setTextColor(CYAN); vLogo.setTypeface(null,android.graphics.Typeface.BOLD); vLogo.setGravity(Gravity.CENTER);
        GradientDrawable vg=new GradientDrawable(); vg.setColor(Color.TRANSPARENT); vg.setStroke(2,CYAN); vg.setCornerRadius(18); vLogo.setBackground(vg);
        brand.addView(vLogo,new LinearLayout.LayoutParams(62,62));
        LinearLayout btitles=new LinearLayout(this); btitles.setOrientation(LinearLayout.VERTICAL); btitles.setPadding(12,0,0,0);
        TextView title=tv("VIRTUS ELM",28); title.setTextColor(WHITE); title.setTypeface(null,android.graphics.Typeface.BOLD);
        TextView sub=tv("V11.0  •  DIAGNÓSTICO VAG",13); sub.setTextColor(CYAN); sub.setTypeface(null,android.graphics.Typeface.BOLD);
        btitles.addView(title); btitles.addView(sub); brand.addView(btitles,new LinearLayout.LayoutParams(0,-2,1));
        ImageView car=new ImageView(this); car.setImageResource(com.marcelo.virtuselm.R.drawable.v11_car_header); car.setScaleType(ImageView.ScaleType.CENTER_CROP);
        brand.addView(car,new LinearLayout.LayoutParams(185,78)); hero.addView(brand);
        TextView strap=tv("LEITURA  •  ANÁLISE  •  DESEMPENHO  •  CAN",11); strap.setTextColor(MUTED); strap.setPadding(4,6,4,2); hero.addView(strap);
        addFull(root,hero);

        // CONNECTION / HEALTH
        LinearLayout connCard=card(CARD); connCard.setPadding(12,10,12,10);
        LinearLayout conn=row();
        TextView btIcon=tv("◉",28); btIcon.setTextColor(CYAN); btIcon.setGravity(Gravity.CENTER); conn.addView(btIcon,new LinearLayout.LayoutParams(48,54));
        LinearLayout connTxt=new LinearLayout(this); connTxt.setOrientation(LinearLayout.VERTICAL);
        TextView e1=tv("ELM327 v1.5",17); e1.setTextColor(WHITE); e1.setTypeface(null,android.graphics.Typeface.BOLD);
        dashConn=tv("Desconectado",12); dashConn.setTextColor(MUTED); connTxt.addView(e1); connTxt.addView(dashConn); conn.addView(connTxt,new LinearLayout.LayoutParams(0,-2,1));
        healthChip=healthChip("● OFFLINE", Color.rgb(255,90,90), Color.rgb(55,16,24)); conn.addView(healthChip,new LinearLayout.LayoutParams(-2,48));
        connCard.addView(conn);
        LinearLayout cr2=row();
        connectButton=btn("DESCONECTAR ELM"); connectButton.setOnClickListener(v->toggleConnection());
        cr2.addView(connectButton,new LinearLayout.LayoutParams(0,50,1));
        TextView proto=tv("CAN 11/500",12); proto.setTextColor(CYAN); proto.setGravity(Gravity.CENTER); cr2.addView(proto,new LinearLayout.LayoutParams(105,50));
        connCard.addView(cr2,new LinearLayout.LayoutParams(-1,-2)); addFull(root,connCard);

        // LIVE ENGINE DASHBOARD
        LinearLayout live=card(CARD); live.setPadding(12,10,12,12);
        TextView liveTitle=tv("●  MOTOR EM TEMPO REAL",16); liveTitle.setTextColor(WHITE); liveTitle.setTypeface(null,android.graphics.Typeface.BOLD); live.addView(liveTitle);
        LinearLayout rpmRow=row();
        LinearLayout rpmBox=card(CARD2); rpmBox.setPadding(12,8,12,8);
        TextView rpmLabel=tv("RPM DO MOTOR",11); rpmLabel.setTextColor(CYAN); rpmBox.addView(rpmLabel);
        dashRpm=tv("— rpm",38); dashRpm.setTextColor(WHITE); dashRpm.setTypeface(null,android.graphics.Typeface.BOLD); rpmBox.addView(dashRpm);
        rpmBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); rpmBar.setMax(7000); rpmBar.setProgress(0); rpmBox.addView(rpmBar,new LinearLayout.LayoutParams(-1,16));
        rpmRow.addView(rpmBox,new LinearLayout.LayoutParams(0,-2,2));
        LinearLayout temps=card(CARD2); temps.setPadding(10,8,10,8);
        dashIgnition=tv("IG: —",12); dashIgnition.setTextColor(CYAN); temps.addView(dashIgnition);
        TextView tl=tv("TEMP. LÍQUIDO",10); tl.setTextColor(MUTED); temps.addView(tl);
        TextView tli=tv("— °C",18); tli.setTextColor(WHITE); temps.addView(tli);
        TextView ta=tv("TEMP. ADMISSÃO",10); ta.setTextColor(MUTED); temps.addView(ta);
        TextView tai=tv("— °C",18); tai.setTextColor(WHITE); temps.addView(tai);
        rpmRow.addView(temps,new LinearLayout.LayoutParams(0,-2,1)); live.addView(rpmRow);

        LinearLayout g1=row(); dashFuel=metric("COMBUSTÍVEL","— %",WHITE,CYAN); dashVolt=metric("TENSÃO","— V",WHITE,CYAN); dashMap=metric("MAP","— kPa",WHITE,CYAN); dashBaro=metric("BARO","— kPa",WHITE,CYAN); addHalfView(g1,dashFuel);addHalfView(g1,dashVolt);addHalfView(g1,dashMap);addHalfView(g1,dashBaro); live.addView(g1);
        LinearLayout g2=row(); dashBoost=metric("BOOST","— bar",WHITE,CYAN); dashBoostMax=metric("BOOST MÁX.","— bar",WHITE,CYAN); dashThrottle=metric("THROTTLE","— %",WHITE,CYAN); TextView carga=metric("CARGA MOTOR","— %",WHITE,CYAN); addHalfView(g2,dashBoost);addHalfView(g2,dashBoostMax);addHalfView(g2,dashThrottle);addHalfView(g2,carga); live.addView(g2);
        boostBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); boostBar.setMax(250); live.addView(boostBar,new LinearLayout.LayoutParams(-1,10));
        throttleBar=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); throttleBar.setMax(100); live.addView(throttleBar,new LinearLayout.LayoutParams(-1,8));
        LinearLayout vehicle=row(); dashVin=tv("VIN: —",11); dashVin.setTextColor(WHITE); vehicle.addView(dashVin,new LinearLayout.LayoutParams(0,44,2)); dashCan=tv("CAN: PRONTO • RAW 0 • FR 0 • BYTES 0",10); dashCan.setTextColor(CYAN); dashCan.setGravity(Gravity.CENTER_VERTICAL); vehicle.addView(dashCan,new LinearLayout.LayoutParams(0,44,1)); live.addView(vehicle);
        addFull(root,live);

        TextView modHead=tv("MÓDULOS",19); modHead.setTextColor(WHITE); modHead.setTypeface(null,android.graphics.Typeface.BOLD); modHead.setPadding(8,14,8,7); addFull(root,modHead);
        LinearLayout m1=row(); addModule(m1,"🔧  DIAGNÓSTICO","Códigos de falha • VIN • DTC",CYAN,()->scrollToSection(root,diagSection)); addModule(m1,"◉  SENSORES","Dados em tempo real",Color.rgb(0,220,180),()->scrollToSection(root,live)); addFull(root,m1);
        LinearLayout m2=row(); addModule(m2,"▥  GRÁFICOS","Análise e histórico",Color.rgb(150,100,255),()->showResult("GRÁFICOS\n\nBase preparada para V11.x.\nA gravação de PIDs será integrada sem alterar o polling OBD atual.")); addModule(m2,"◉  CAN INVESTIGATOR","Captura e análise CAN",Color.rgb(255,190,0),()->scrollToSection(root,canSection)); addFull(root,m2);
        LinearLayout m3=row(); addModule(m3,"▤  GRAVAÇÃO DE DADOS","Logs e exportação",Color.rgb(255,80,90),()->scrollToSection(root,logSection)); addModule(m3,"🚗  VIRTUS / VAG","Informações do veículo",CYAN2,()->vehicleData()); addFull(root,m3);

        diagSection=section("DIAGNÓSTICO OBD-II"); addFull(root,diagSection);
        LinearLayout r1=row(); Button quick=btn("DIAGNÓSTICO RÁPIDO"); quick.setOnClickListener(v->quickDiagnostic()); addFull(r1,quick); addFull(root,r1);
        LinearLayout r2=row(); Button data=btn("LER DADOS"); data.setOnClickListener(v->vehicleData()); Button auto=btn("DIAGNÓSTICO COMPLETO"); auto.setOnClickListener(v->automaticDiagnostic()); addHalf(r2,data); addHalf(r2,auto); addFull(root,r2);
        LinearLayout r3=row(); Button dtc=btn("DTC"); dtc.setOnClickListener(v->readDtc()); Button vin=btn("VIN"); vin.setOnClickListener(v->readVin()); addHalf(r3,dtc); addHalf(r3,vin); addFull(root,r3);
        LinearLayout r4=row(); Button statusObd=btn("STATUS / READINESS"); statusObd.setOnClickListener(v->obdStatus()); Button o2=btn("MONITORAMENTO SONDA"); o2.setOnClickListener(v->o2Test()); addHalf(r4,statusObd); addHalf(r4,o2); addFull(root,r4);
        LinearLayout r5=row(); Button ignition=btn("IGNIÇÃO OFF"); ignition.setOnClickListener(v->ignitionOffTest()); Button body=btn("ESTUDO DE MÓDULOS"); body.setOnClickListener(v->bodyStudy()); addHalf(r5,ignition); addHalf(r5,body); addFull(root,r5);
        Button dtcff=btn("DTC + FREEZE FRAME"); dtcff.setOnClickListener(v->dtcFreeze()); addFull(root,dtcff);

        canSection=section("CAN INVESTIGATOR • SOMENTE LEITURA"); addFull(root,canSection);
        LinearLayout canStatus=card(CARD2); canStatus.setPadding(12,10,12,10); TextView cst=tv("CAPTURA CAN",12); cst.setTextColor(CYAN); canStatus.addView(cst); stats=tv("RAW: 0 • FRAMES: 0 • IDs: 0 • BYTES: 0",18); stats.setTextColor(WHITE); stats.setTypeface(null,android.graphics.Typeface.BOLD); canStatus.addView(stats); canStatus.addView(tv("Monitor All • sem transmissão CAN arbitrária",10)); addFull(root,canStatus);
        LinearLayout r6=row(); Button cap=btn("▶  CAPTURAR CAN"); cap.setOnClickListener(v->startMonitor()); Button stop=btn("■  FINALIZAR"); stop.setOnClickListener(v->stopMonitor()); addHalf(r6,cap); addHalf(r6,stop); addFull(root,r6);
        LinearLayout r7=row(); Button lock=btn("LOCK"); lock.setOnClickListener(v->mark("LOCK")); Button unlock=btn("UNLOCK"); unlock.setOnClickListener(v->mark("UNLOCK")); addHalf(r7,lock); addHalf(r7,unlock); addFull(root,r7);
        LinearLayout r8=row(); Button ss=btn("START / STOP"); ss.setOnClickListener(v->mark("START-STOP")); Button trunk=btn("PORTA-MALAS"); trunk.setOnClickListener(v->mark("PORTA-MALAS")); addHalf(r8,ss); addHalf(r8,trunk); addFull(root,r8);
        LinearLayout r9=row(); Button farol=btn("FAROL / OUTRO"); farol.setOnClickListener(v->mark("FAROL-OUTRO")); Button analyze=btn("ANALISAR DIFERENÇAS"); analyze.setOnClickListener(v->analyze()); addHalf(r9,farol); addHalf(r9,analyze); addFull(root,r9);

        logSection=section("LOG TÉCNICO"); addFull(root,logSection);
        LinearLayout tools=row(); Button copy=btn("COPIAR LOG"); copy.setOnClickListener(v->copyLog()); Button clear=btn("LIMPAR LOG"); clear.setOnClickListener(v->clearLog()); addHalf(tools,copy); addHalf(tools,clear); addFull(root,tools);
        result=tv("RESULTADO: —",13); result.setTextColor(WHITE); result.setPadding(14,14,14,14); result.setBackground(cardBg(CARD2,22,CYAN2)); addFull(root,result);
        log=tv("",10); log.setTextColor(Color.rgb(185,210,230)); log.setTextIsSelectable(true); log.setMovementMethod(ScrollingMovementMethod.getInstance()); log.setPadding(12,12,12,12); log.setBackground(cardBg(Color.rgb(2,20,38),20,Color.rgb(25,80,120))); addFull(root,log);

        // Fixed bottom navigation
        LinearLayout nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setGravity(Gravity.CENTER); nav.setPadding(6,6,6,6); nav.setBackground(cardBg(Color.rgb(3,25,48),26,CYAN2));
        addNav(nav,"⌂\nInício",()->page.smoothScrollTo(0,0)); addNav(nav,"▥\nDados",()->scrollToSection(root,live)); addNav(nav,"⚙\nDiagnóstico",()->scrollToSection(root,diagSection)); addNav(nav,"◉\nCAN",()->scrollToSection(root,canSection)); addNav(nav,"☰\nConfig",()->toast("Configurações avançadas serão incorporadas nas próximas versões."));
        FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(-1,64,Gravity.BOTTOM); np.setMargins(8,0,8,8); frame.addView(nav,np);
        setContentView(frame);
    }

    private LinearLayout diagSection, canSection, logSection;
    private GradientDrawable cardBg(int color,float radius,int stroke){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(radius); g.setStroke(1,stroke); return g; }
    private LinearLayout card(int color){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setBackground(cardBg(color,22,Color.rgb(20,95,150))); return l; }
    private TextView metric(String label,String value,int fg,int accent){ TextView t=tv(label+"\n"+value,11); t.setTextColor(fg); t.setGravity(Gravity.CENTER); t.setPadding(4,8,4,8); t.setBackground(cardBg(Color.rgb(6,38,68),16,accent)); return t; }
    private void addHalfView(LinearLayout r,TextView t){ LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(3,3,3,3); r.addView(t,lp); }
    private void addModule(LinearLayout r,String title,String sub,int accent,final Runnable action){ LinearLayout c=card(Color.rgb(5,31,58)); c.setPadding(12,10,10,10); TextView a=tv(title,15); a.setTextColor(Color.WHITE); a.setTypeface(null,android.graphics.Typeface.BOLD); TextView b=tv(sub,10); b.setTextColor(Color.rgb(155,190,215)); c.addView(a); c.addView(b); c.setOnClickListener(v->action.run()); c.setClickable(true); c.setForeground(getResources().getDrawable(android.R.drawable.list_selector_background)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,78,1); lp.setMargins(4,4,4,4); r.addView(c,lp); }
    private void addNav(LinearLayout nav,String text,final Runnable action){ TextView n=tv(text,10); n.setTextColor(Color.rgb(180,210,235)); n.setGravity(Gravity.CENTER); n.setPadding(2,2,2,2); n.setOnClickListener(v->action.run()); nav.addView(n,new LinearLayout.LayoutParams(0,-1,1)); }
    private void scrollToSection(LinearLayout root,View v){ if(v==null)return; v.post(()->{ ScrollView sv=(ScrollView)root.getParent(); if(sv!=null)sv.smoothScrollTo(0,Math.max(0,v.getTop()-16)); }); }

    private TextView healthChip(String text,int fg,int bg){ TextView t=tv(text,11); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setTextColor(fg); t.setGravity(Gravity.CENTER); t.setPadding(14,9,14,9); android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(bg); g.setCornerRadius(30f); g.setStroke(1,fg); t.setBackground(g); return t; }
    private void setHealth(String mode,String detail){ ui(()->{ if(healthChip==null)return; String text; int fg,bg; if("GREEN".equals(mode)){ text="● OK • " + detail; fg=Color.rgb(27,94,32); bg=Color.rgb(232,245,233); } else if("YELLOW".equals(mode)){ text="● ATENÇÃO • " + detail; fg=Color.rgb(245,124,0); bg=Color.rgb(255,243,224); } else { text="● OFFLINE • " + detail; fg=Color.rgb(183,28,28); bg=Color.rgb(255,235,238); } healthChip.setText(text); healthChip.setTextColor(fg); android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(bg); g.setCornerRadius(30f); g.setStroke(1,fg); healthChip.setBackground(g); }); }
    private void addHalfText(LinearLayout r, TextView t){ LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(2,0,2,0); r.addView(t,lp); }
    private void resetSession(){ monitoring=false; operationRunning=false; markers.clear(); rawCount=frameCount=rxBytes=0; ids.clear(); noDataCycles=0; recoveringSession=false; closeSocket(); }
    private boolean perms(){ if(Build.VERSION.SDK_INT>=31) return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)==PackageManager.PERMISSION_GRANTED; return true; }
    private void toggleConnection(){ if(socket!=null && socket.isConnected()){ if(monitoring){ toast("Finalize a captura antes de desconectar"); return; } disconnect(); } else connect(); }
    private void disconnect(){ io.execute(()->{ operationRunning=true; intentionalDisconnect=true; monitoring=false; stopRequested=true; closeSocket(); noDataCycles=0; setHealth("RED","DESCONECTADO"); setStatus("Bluetooth desconectado"); ui(()->{connectButton.setText("CONECTAR ELM"); dashConn.setText("● ELM: DESCONECTADO"); dashConn.setTextColor(Color.rgb(150,35,35));}); append("ELM desconectado pelo usuário."); operationRunning=false; }); }
    private void connect(){ if(Build.VERSION.SDK_INT>=31&&!perms()){ requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},20); return; } if(bt==null){setStatus("Bluetooth indisponível");return;} if(!bt.isEnabled()){setStatus("Bluetooth desligado");return;} io.execute(()->connectWorker()); }
    private void connectWorker(){ if(operationRunning||monitoring){ui(()->setStatus("Operação em andamento — finalize antes de reconectar"));return;} operationRunning=true; intentionalDisconnect=false; try{ if(socket!=null && socket.isConnected()) return; closeSocket(); BluetoothDevice dev=null; for(BluetoothDevice d:bt.getBondedDevices()){String n=d.getName(); if(n!=null){String u=n.toUpperCase(Locale.US); if(u.contains("OBD")||u.contains("ELM")||u.contains("V-LINK")||u.contains("OBDLINK")){dev=d;break;}}} if(dev==null){ui(()->setStatus("OBDII não encontrado entre dispositivos pareados"));return;} append("ELM encontrado: "+dev.getName()); socket=dev.createRfcommSocketToServiceRecord(SPP); socket.connect(); in=socket.getInputStream(); out=socket.getOutputStream(); setStatus("Bluetooth conectado — ELM pronto"); setHealth("YELLOW","ELM CONECTADO"); ui(()->{connectButton.setText("DESCONECTAR ELM"); dashConn.setText("● ELM: CONECTADO"); dashConn.setTextColor(BLUE);}); send("ATZ",2500); send("ATE0",1000); send("ATL0",1000); send("ATS1",1000); send("ATH1",1000); send("ATAT1",1000); String dp=send("ATDP",1800); lastProtocol=dp; send("ATSP0",2500); append("Inicialização concluída."); maxBoost=-1; lastBaro=-1; lastBoost=-1; noDataCycles=0; recoveringSession=false; setHealth("YELLOW","AGUARDANDO OBD"); ui(()->updateDashboard()); }catch(Exception e){ append("ERRO CONEXÃO: "+e); setStatus("Erro de comunicação — tentando reconectar"); safeUnexpectedDisconnect(e); } finally { operationRunning=false; } }

    private void dashboardSnapshot(){
        if(out==null||in==null||monitoring||operationRunning) return;
        try{
            String rpm=send("010C",900); String fuel=send("012F",900); String volt=send("0142",900); String thr=send("0111",900); String map=send("010B",900); String baro=send("0133",900); String vin=send("0902",1500);
            boolean gotObd = rpm.matches("(?s).*41\\s+0C.*") || fuel.matches("(?s).*41\\s+2F.*") || map.matches("(?s).*41\\s+0B.*");
            if(gotObd){
                noDataCycles=0; ecuResponding=true;
                lastRpm=parseObdNumeric(rpm, "010C"); lastFuel=parseObdNumeric(fuel,"012F"); lastVolt=parseVoltage(volt); lastThrottle=parseThrottle(thr); lastMap=parseMap(map); lastBaro=parseBaro(baro); lastBoost=calculateBoost(lastMap,lastBaro); if(lastBoost>=0 && lastBoost>maxBoost) maxBoost=lastBoost;
                String pv=parseVin(vin); if(!pv.isEmpty()) lastVin=pv;
                setHealth("GREEN","OBD ATIVO");
            } else {
                noDataCycles++; ecuResponding=false;
                setHealth("YELLOW", "ELM CONECTADO • SEM DADOS");
                append("WATCHDOG OBD: ciclo sem resposta ("+noDataCycles+").");
                if(noDataCycles==2 && !recoveringSession){ recoverObdSession(); }
                else if(noDataCycles>=4 && !recoveringSession){ append("WATCHDOG OBD: sem recuperação após 4 ciclos; reconexão automática será iniciada."); intentionalDisconnect=false; closeSocket(); setHealth("RED","RECONEXÃO AUTOMÁTICA"); scheduleReconnect(); }
            }
            ui(()->updateDashboard());
        }catch(Exception e){ ecuResponding=false; setHealth("YELLOW","ELM CONECTADO • ERRO RX"); append("WATCHDOG OBD: erro de leitura — "+e.getClass().getSimpleName()); }
    }
    private void recoverObdSession(){
        recoveringSession=true;
        io.execute(()->{ try{ append("WATCHDOG OBD: recuperando sessão no mesmo socket."); send("AT AR",900); send("ATSP0",1200); send("ATAT1",700); append("WATCHDOG OBD: sessão OBD reinicializada."); }catch(Exception e){ append("WATCHDOG OBD: falha na recuperação — "+e.getMessage()); } finally { recoveringSession=false; } });
    }
    private double parseObdNumeric(String r,String pid){ try{String u=r.toUpperCase(Locale.US).replaceAll("[^0-9A-F ]"," ").replaceAll("\\s+"," ").trim(); Matcher m=Pattern.compile("41\\s+"+pid.substring(2)+"\\s+([0-9A-F]{2})(?:\\s+([0-9A-F]{2}))?").matcher(u); if(!m.find())return -1; int a=Integer.parseInt(m.group(1),16); int b=m.group(2)==null?0:Integer.parseInt(m.group(2),16); if(pid.equals("010C"))return (a*256+b)/4.0; if(pid.equals("012F"))return a*100.0/255.0; return a;}catch(Exception e){return -1;} }
    private double parseVoltage(String r){ try{Matcher m=Pattern.compile("41\\s+42\\s+([0-9A-F]{2})\\s+([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return (Integer.parseInt(m.group(1),16)*256+Integer.parseInt(m.group(2),16))/1000.0; }catch(Exception ignored){} return -1;}
    private double parseThrottle(String r){ try{Matcher m=Pattern.compile("41\\s+11\\s+([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return Integer.parseInt(m.group(1),16)*100.0/255.0;}catch(Exception ignored){} return -1;}
    private double parseMap(String r){ try{Matcher m=Pattern.compile("41\\s+0B\\s+([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return Integer.parseInt(m.group(1),16);}catch(Exception ignored){} return -1;}
    private double parseBaro(String r){ try{Matcher m=Pattern.compile("41\\s+33\\s+([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return Integer.parseInt(m.group(1),16);}catch(Exception ignored){} return -1;}
    private double calculateBoost(double mapKpa,double baroKpa){ if(mapKpa<0||baroKpa<0) return -1; return (mapKpa-baroKpa)/100.0; }
    private void updateDashboard(){ if(socket==null||!socket.isConnected()) setHealth("RED","DESCONECTADO"); else if(monitoring) setHealth("YELLOW","CAN CAPTURANDO • OBD PAUSADO"); else if(ecuResponding) setHealth("GREEN","OBD ATIVO"); else setHealth("YELLOW","ELM CONECTADO • SEM DADOS"); dashVin.setText("VIN: "+lastVin); String ig=ecuResponding?(lastRpm>0?"IG: ON • RUN":"IG: ON • ECU") : "IG: —"; dashIgnition.setText(ig); dashRpm.setText(lastRpm>=0?String.format(Locale.US,"RPM: %.0f",lastRpm):"RPM: —"); dashFuel.setText(lastFuel>=0?String.format(Locale.US,"FUEL: %.0f%%",lastFuel):"FUEL: —"); dashVolt.setText(lastVolt>=0?String.format(Locale.US,"V: %.2f",lastVolt):"V: —"); rpmBar.setProgress((int)Math.min(7000,Math.max(0,lastRpm))); dashMap.setText(lastMap>=0?String.format(Locale.US,"MAP: %.0f kPa",lastMap):"MAP: —"); dashBaro.setText(lastBaro>=0?String.format(Locale.US,"BARO: %.0f kPa",lastBaro):"BARO: —"); dashBoost.setText(lastBoost>=0?String.format(Locale.US,"BOOST: %.2f bar",lastBoost):"BOOST: —"); dashBoostMax.setText(maxBoost>=0?String.format(Locale.US,"BOOST MÁX.: %.2f bar",maxBoost):"BOOST MÁX.: —"); dashThrottle.setText(lastThrottle>=0?String.format(Locale.US,"THR: %.0f%%",lastThrottle):"THR: —"); boostBar.setProgress((int)Math.min(250,Math.max(0,(lastBoost<0?0:lastBoost)*100))); throttleBar.setProgress((int)Math.min(100,Math.max(0,lastThrottle<0?0:lastThrottle))); dashCan.setText(String.format(Locale.US,"CAN: %s • RAW %d • FR %d • BYTES %d",monitoring?"LIVE":"PRONTO",rawCount,frameCount,rxBytes)); }
    private void startDashboardPolling(){ dashboardExec.scheduleAtFixedRate(()->{ if(socket!=null&&socket.isConnected()&&!monitoring&&!operationRunning) dashboardSnapshot(); else ui(()->{ if(socket==null||!socket.isConnected()){ connectButton.setText("CONECTAR ELM"); dashConn.setText("● ELM: DESCONECTADO"); dashConn.setTextColor(Color.rgb(150,35,35)); setHealth("RED","DESCONECTADO"); } updateDashboard(); }); },0,3,TimeUnit.SECONDS); }

    private String send(String cmd,long timeout){ if(out==null||in==null){append("ERRO: ELM não conectado para "+cmd);return "";} try{out.write((cmd+"\r").getBytes(StandardCharsets.US_ASCII));out.flush(); append(">> "+cmd); return readUntilPrompt(timeout);}catch(Exception e){append("ERRO TX/RX: "+e); if(!intentionalDisconnect && !monitoring) safeUnexpectedDisconnect(e); return "";} }
    private String readUntilPrompt(long timeout){ long end=System.currentTimeMillis()+timeout; ByteArrayOutputStream b=new ByteArrayOutputStream(); try{while(System.currentTimeMillis()<end){if(in.available()>0){int x=in.read(); if(x<0)break; b.write(x); if(x=='>')break;} else Thread.sleep(4);}}catch(Exception e){append("ERRO LEITURA: "+e);} String raw=new String(b.toByteArray(),StandardCharsets.US_ASCII); String n=normalize(raw); if(!n.isEmpty())append("<< "+n); return n; }
    private String normalize(String s){ return s.replace("\u0000","").replace("\r","\n").replace("\n\n","\n").replaceAll("\n+","\n").trim(); }
    private void runOp(String name, Runnable op){ if(operationRunning){setStatus("Já existe uma operação em andamento");return;} io.execute(()->{operationRunning=true; try{ if(out==null||in==null) throw new IOException("ELM não conectado"); append("=== "+name+" ==="); op.run(); append("=== FIM: "+name+" ==="); }catch(Exception e){append("ERRO "+name+": "+e);setStatus("Erro na operação — aplicativo mantido aberto");}finally{operationRunning=false;}}); }
    private void showResult(String s){ui(()->result.setText("RESULTADO:\n"+s));}

    private String firstPayload(String resp){ String[] ls=resp.split("\\n"); for(String l:ls){String u=l.trim().toUpperCase(Locale.US); if(u.matches("^(7E[0-9A-F]|[0-9A-F]{3,8})\\s+41\\s+.*")||u.matches("^41\\s+.*")||u.matches("^43\\s+.*")||u.matches("^47\\s+.*")||u.matches("^49\\s+.*")) return u;} return resp.trim(); }
    private void queryPid(String pid,String label){ String r=send(pid,1500); String[] lines=r.split("\\n"); StringBuilder outv=new StringBuilder(); for(String l:lines){String t=l.trim(); if(t.isEmpty())continue; if(t.matches("(?i).*(41|43|47|49)\\s+.*")){outv.append(t).append("\\n");}} if(outv.length()>0) append(label+": "+outv.toString().trim()); else append(label+": sem resposta estruturada"); }

    private void quickDiagnostic(){ runOp("DIAGNÓSTICO RÁPIDO — SOMENTE LEITURA",()->{String p=send("0100",1800); StringBuilder r=new StringBuilder(); r.append("0100 / PIDs 01–20:\n").append(p).append("\n"); queryPid("010C","RPM"); queryPid("010D","VELOCIDADE"); queryPid("0105","TEMPERATURA ARREFECIMENTO"); String d=send("03",1800); append("DTC: "+d); r.append("DTC:\n").append(d); showResult(r.toString());}); }
    private void automaticDiagnostic(){ runOp("DIAGNÓSTICO COMPLETO — SOMENTE LEITURA",()->{StringBuilder r=new StringBuilder(); String[] pids={"0100","0120","0140","0160","0104","0105","010B","010C","010D","010F","0111","011F","012F","0133","0142","03","07","0A","0902","0101"}; for(String p:pids){String x=send(p,p.equals("0902")?2500:1600); append(p+": "+x); r.append(p).append(" -> ").append(x).append("\n");} showResult(r.toString());}); }
    private void vehicleData(){ runOp("LER DADOS DO VEÍCULO",()->{StringBuilder r=new StringBuilder(); String[] pids={"0100","0120","0140","0160","0104","0105","010B","010C","010D","010F","0111","011F","012F","0133","0142"}; for(String p:pids){String x=send(p,1600); append(p+": "+x); r.append(p).append(" -> ").append(x).append("\n");} showResult(r.toString());}); }
    private void readDtc(){ runOp("LER CÓDIGOS DE FALHA — DTC",()->{String r=send("03",2000); if(r.contains("43 00")||r.matches("(?s).*\\b43\\s+00\\b.*")){append("DTC: nenhum código reportado pela resposta OBD recebida.");} else append("DTC RAW: "+r); showResult(r);}); }
    private void readVin(){ runOp("LER VIN — SE DISPONÍVEL",()->{String r=send("0902",3000); String vin=parseVin(r); append("VIN: "+(vin.isEmpty()?"não identificado no parser; RAW preservado":vin)); showResult("VIN: "+(vin.isEmpty()?"não identificado":vin)+"\nRAW:\n"+r);}); }
    private String parseVin(String r){String h=r.replaceAll("[^0-9A-Fa-f]","").toUpperCase(Locale.US); int i=h.indexOf("490201"); if(i<0)return ""; String rest=h.substring(i+6); StringBuilder b=new StringBuilder(); for(int j=0;j+1<rest.length()&&b.length()<17;j+=2){int v=Integer.parseInt(rest.substring(j,j+2),16); if(v>=32&&v<=126)b.append((char)v);} String v=b.toString(); return v.length()==17?v:"";}
    private void dtcFreeze(){ runOp("DTC + FREEZE FRAME — SOMENTE LEITURA",()->{String a=send("03",2000); String b=send("0200",2000); String c=send("0201",2000); append("MODE 03: "+a); append("FREEZE FRAME 0200: "+b); append("FREEZE FRAME 0201: "+c); showResult("MODE 03:\n"+a+"\n\n0200:\n"+b+"\n\n0201:\n"+c);}); }
    private void obdStatus(){ runOp("STATUS OBD / READINESS",()->{StringBuilder r=new StringBuilder(); for(String p:new String[]{"0101","0102","0106","0107","0110"}){String x=send(p,1600);append(p+": "+x);r.append(p).append(" -> ").append(x).append("\n");}showResult(r.toString());}); }
    private void o2Test(){ runOp("TESTAR MONITORAMENTO DA SONDA",()->{StringBuilder r=new StringBuilder();for(String p:new String[]{"05","06","07","0A"}){String x=send(p,1800);append(p+": "+x);r.append(p).append(" -> ").append(x).append("\n");}showResult(r.toString());}); }
    private void ignitionOffTest(){ runOp("TESTE COM IGNIÇÃO DESLIGADA",()->{String a=send("ATI",1500);String b=send("ATDP",1500);String c=send("0100",2200);boolean ecu=c.matches("(?s).*(41\\s+00|41 00).*");String conclusion=ecu?"ELM respondeu e houve resposta OBD/CAN com a condição testada.":"ELM respondeu, mas nenhuma resposta CAN/ECU foi identificada para 0100. Isso não significa que não existam outros módulos.";append("CONCLUSÃO: "+conclusion);showResult(a+"\n"+b+"\n0100:\n"+c+"\n\n"+conclusion);}); }
    private void bodyStudy(){ runOp("ESTUDO DE MÓDULOS — SOMENTE LEITURA",()->{String a=send("ATDP",1600);String b=send("0100",2200);append("PROTOCOLO: "+a);append("0100: "+b);showResult("PROTOCOLO:\n"+a+"\n\n0100:\n"+b+"\n\nNenhum comando de atuação, segurança, coding ou lock/unlock foi transmitido.");}); }

    private volatile boolean monitorRejected = false;
    private long monitorStartedAt = 0;

    private void startMonitor(){
        if(operationRunning||monitoring){setStatus(operationRunning?"Finalize a operação atual antes de capturar":"Captura já ativa");return;}
        if(out==null||in==null){setStatus("Conecte o ELM primeiro");return;}
        io.execute(()->{
            monitoring=true; stopRequested=false; monitorRejected=false; monitorStartedAt=System.currentTimeMillis();
            rawCount=frameCount=rxBytes=0; ids.clear(); idCounts.clear(); markers.clear();
            try{
                append("=== INÍCIO DA CAPTURA CAN PASSIVA — V11.0 ===");
                append("Preparando o ELM para Monitor All — somente leitura.");
                String dp=send("ATDP",1500);
                String proto=dp.toUpperCase(Locale.US);
                if(proto.contains("29/500")||proto.contains("29")){
                    append("Protocolo detectado: CAN 29/500 — fixando protocolo 7 para a captura.");
                    send("ATSP7",1200);
                }else{
                    append("Protocolo detectado: CAN 11/500 — fixando protocolo 6 para a captura.");
                    send("ATSP6",1200);
                }
                String init=send("0100",2200);
                if(!init.matches("(?s).*41\\s+00.*")) append("AVISO: 0100 não retornou resposta OBD; ainda assim a captura passiva será tentada.");
                send("AT AR",1000);
                send("ATE0",700);
                send("ATH1",700);
                send("ATS0",700);
                send("ATL0",700);
                append("AT MA será usado em Monitor All. O aplicativo não transmite mensagens CAN ao veículo.");
                out.write("AT MA\r".getBytes(StandardCharsets.US_ASCII)); out.flush(); append(">> AT MA");
                setHealth("YELLOW","CAN CAPTURANDO • OBD PAUSADO"); setStatus("MONITORAMENTO CAN INICIANDO — OBD pausado durante captura");
                monitorLoop();
            }catch(Exception e){append("ERRO MONITOR: "+e);setStatus("Captura interrompida — dados preservados"); if(!intentionalDisconnect) safeUnexpectedDisconnect(e);}
            finally{monitoring=false;}
        });
    }
    private void monitorLoop() throws IOException {
        ByteArrayOutputStream line=new ByteArrayOutputStream();
        ByteArrayOutputStream binary=new ByteArrayOutputStream();
        byte[] buf=new byte[1024]; long lastUi=0;
        while(monitoring){
            int n=in.read(buf);
            if(n<0) throw new IOException("socket fechado durante Monitor All");
            if(n==0) continue;
            rxBytes+=n;
            for(int i=0;i<n;i++){
                int x=buf[i]&0xFF;
                // ELM returns the prompt as a single '>' character; detect it immediately
                // so FINALIZAR CAPTURA does not depend on a trailing CR/LF.
                if(x=='>'){
                    if(line.size()>0) flushMonitorLine(line);
                    if(binary.size()>0) flushMonitorBinary(binary);
                    processMonitorRaw(">");
                    if(stopRequested) break;
                    continue;
                }
                if(x=='\r'||x=='\n'){
                    flushMonitorBinary(binary);
                    flushMonitorLine(line);
                } else if(x>=32&&x<=126){
                    if(binary.size()>0) flushMonitorBinary(binary);
                    line.write(x);
                    if(line.size()>2048) flushMonitorLine(line);
                } else {
                    if(line.size()>0) flushMonitorLine(line);
                    binary.write(x);
                    if(binary.size()>=256) flushMonitorBinary(binary);
                }
            }
            if(System.currentTimeMillis()-lastUi>200){ lastUi=System.currentTimeMillis(); updateStats(); }
        }
        if(line.size()>0) flushMonitorLine(line);
        if(binary.size()>0) flushMonitorBinary(binary);
    }
    private void flushMonitorLine(ByteArrayOutputStream line){ if(line.size()==0)return; String s=new String(line.toByteArray(),StandardCharsets.US_ASCII).trim();line.reset();if(s.isEmpty())return;processMonitorRaw(s); }
    private void flushMonitorBinary(ByteArrayOutputStream binary){
        if(binary.size()==0)return;
        byte[] b=binary.toByteArray(); binary.reset();
        StringBuilder h=new StringBuilder();
        for(byte v:b){ if(h.length()>0) h.append(' '); h.append(String.format(Locale.US,"%02X",v&0xFF)); }
        rawCount++;
        synchronized(logLock){ technical.append("[MONITOR HEX] ").append(h).append('\n'); }
        if(rawCount<=8||rawCount%50==0) append("RAW HEX #"+rawCount+": "+h);
    }
    private void processMonitorRaw(String s){
        String u=s.toUpperCase(Locale.US).trim();
        // ELM control responses are not CAN frames and must never inflate the CAN counters.
        if(u.equals("OK")||u.equals(">")||u.equals("STOPPED")||u.contains("SEARCHING")||u.contains("NO DATA")){
            append("ELM CONTROL (fora da captura CAN): "+u);
            if(u.equals(">") && stopRequested){ monitoring=false; append("<< > — ELM retornou ao prompt; captura encerrada corretamente."); append("=== FIM DA CAPTURA CAN PASSIVA ==="); append("RAW RECEBIDOS: "+rawCount+" | FRAMES DECODIFICADOS: "+frameCount+" | IDS: "+ids.size()+" | BYTES: "+rxBytes); setStatus("Captura finalizada — retomando OBD"); setHealth("YELLOW","RETOMANDO OBD"); updateStats(); return; }
            if(u.equals(">") && !stopRequested && System.currentTimeMillis()-monitorStartedAt<2500){
                monitorRejected=true;
                append("ERRO: AT MA retornou o prompt imediatamente — Monitor All não permaneceu ativo.");
                setStatus("AT MA não permaneceu ativo — captura não iniciada");
                monitoring=false;
            }
            return;
        }
        rawCount++;
        synchronized(logLock){technical.append("[MONITOR RAW] ").append(s).append('\n');}
        if(u.contains("BUFFER FULL")){append("!! ELM REPORTOU BUFFER FULL — RAW preservado.");updateStats();return;}
        ParsedCan pc=parseCan(s);
        if(pc.ok){frameCount++;ids.add(pc.id);idCounts.put(pc.id,idCounts.getOrDefault(pc.id,0L)+1L);if(frameCount<=8||frameCount%50==0)append("CAN "+pc.id+" DLC="+pc.dlc+" DATA="+pc.data);}
        else if(rawCount<=8||rawCount%100==0){append("RAW não classificado #"+rawCount+": "+s);}
        updateStats();
    }
    static class ParsedCan {boolean ok;String id="",data="";int dlc;}
    private ParsedCan parseCan(String s){ParsedCan p=new ParsedCan();String clean=s.replaceAll("[^0-9A-Fa-f ]"," ").trim().replaceAll("\\s+"," ");if(clean.isEmpty())return p;String[] a=clean.split(" ");if(a.length<2)return p;
        // Common ELM CAN monitor forms: 11/29-bit header followed by DLC and data. Keep conservative.
        for(int i=1;i<a.length;i++){try{int d=Integer.parseInt(a[i],16);if(d>=0&&d<=8&&a.length>=i+1+d){String id=String.join(" ",Arrays.copyOfRange(a,0,i)); if(id.length()>=2&&id.length()<=12){p.ok=true;p.id=id;p.dlc=d;StringBuilder db=new StringBuilder();for(int j=i+1;j<a.length;j++){if(db.length()>0)db.append(' ');db.append(a[j]);}p.data=db.toString();return p;}}}catch(Exception ignored){}}
        return p;
    }
    private void updateStats(){long now=System.currentTimeMillis();if(now-lastStatsUi<250)return;lastStatsUi=now;ui(()->stats.setText("RAW: "+rawCount+" • FRAMES: "+frameCount+" • IDs: "+ids.size()+" • BYTES: "+rxBytes));}
    private void mark(String type){
        if(!monitoring){append("MARCADOR ignorado: captura não está ativa");return;}
        Marker m=new Marker(type,rawCount,frameCount,rxBytes,idCounts); markers.add(m);
        append("*** MARCADOR "+type+" | RAW="+m.raw+" | FRAMES="+m.frames+" | BYTES="+m.bytes+" | IDS="+m.idsAt.size()+" | "+sdf.format(new Date(m.when))+" ***");
    }
    private void stopMonitor(){
        if(!monitoring){ toast("Nenhuma captura CAN ativa"); return; }
        stopRequested=true; stopDeadline=System.currentTimeMillis()+8000;
        try{ if(out!=null){ out.write('\r'); out.flush(); append(">> [INTERRUPÇÃO] 1 caractere enviado ao ELM"); } }catch(Exception e){ append("ERRO AO ENVIAR INTERRUPÇÃO: "+e); }
        setStatus("Finalizando captura CAN…");
        main.postDelayed(()->{ if(monitoring && System.currentTimeMillis()>=stopDeadline){ monitoring=false; append("TIMEOUT: ELM não retornou o prompt. A conexão será reiniciada automaticamente; log e marcadores serão preservados."); intentionalDisconnect=false; closeSocket(); append("=== FIM DA CAPTURA CAN PASSIVA — TIMEOUT ==="); setStatus("Captura finalizada — reconectando ELM"); setHealth("RED","RECONEXÃO AUTOMÁTICA"); scheduleReconnect(); updateStats(); } },8100);
    }
    private void analyze(){
        if(markers.isEmpty()){append("=== ANÁLISE DIFERENCIAL DE EVENTOS ===");append("Nenhum marcador registrado.");return;}
        append("=== ANÁLISE DIFERENCIAL DE EVENTOS ===");
        for(int i=0;i<markers.size();i++){
            Marker m=markers.get(i); append("EVENTO "+(i+1)+": "+m.type+" | RAW="+m.raw+" | FRAMES="+m.frames+" | BYTES="+m.bytes+" | IDS="+m.idsAt.size()+" | "+sdf.format(new Date(m.when)));
            if(i>0){
                Marker prev=markers.get(i-1);
                LinkedHashMap<String,Long> delta=new LinkedHashMap<>();
                for(Map.Entry<String,Long> e:m.idsAt.entrySet()){long before=prev.idsAt.getOrDefault(e.getKey(),0L);long d=e.getValue()-before;if(d>0)delta.put(e.getKey(),d);}
                ArrayList<Map.Entry<String,Long>> top=new ArrayList<>(delta.entrySet()); top.sort((a,b)->Long.compare(b.getValue(),a.getValue()));
                if(top.isEmpty()) append("  DIFERENCIAL: nenhum ID CAN novo entre os marcadores.");
                else {StringBuilder z=new StringBuilder("  IDS ATIVOS NO INTERVALO: ");int lim=Math.min(12,top.size());for(int j=0;j<lim;j++){if(j>0)z.append(", ");z.append(top.get(j).getKey()).append("(").append(top.get(j).getValue()).append("x)");}append(z.toString());}
            }
        }
        append("A análise identifica candidatos por mudança de tráfego entre marcadores; ela NÃO envia quadros CAN nem tenta acionar funções do veículo.");
        showResult("Marcadores: "+markers.size()+"\nRAW: "+rawCount+"\nFrames: "+frameCount+"\nIDs: "+ids.size()+"\nVeja no LOG os IDs que mudaram entre cada evento.");
    }

    private void copyLog(){String text; synchronized(logLock){text=technical.toString();} if(text.isEmpty()){toast("Log vazio");return;} ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("VIRTUS ELM V11.0 — LOG",text));toast("LOG COPIADO");}
    private void clearLog(){ if(monitoring||operationRunning){toast("Finalize a operação antes de limpar o log");return;} synchronized(logLock){technical.setLength(0);} log.setText(""); result.setText("RESULTADO: —"); rawCount=frameCount=rxBytes=0;ids.clear();markers.clear();stats.setText("RAW: 0 • FRAMES: 0 • IDs: 0 • BYTES: 0");append("[00] LOG LIMPO — V11.0 • conexão Bluetooth preservada"); setStatus((socket!=null&&socket.isConnected())?"Conectado — log limpo":"Bluetooth não conectado"); }
    private void toast(String s){ui(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
    private void setStatus(String s){ui(()->status.setText("Status: "+s));}
    private void ui(Runnable r){main.post(r);}
    private void append(String s){String line="["+sdf.format(new Date())+"] "+s; synchronized(logLock){technical.append(line).append('\n');} ui(()->{if(log!=null){log.append(line+"\n");}});}
    private void safeUnexpectedDisconnect(Exception cause){ if(intentionalDisconnect) return; boolean wasConnected=socket!=null; try{closeSocket();}catch(Exception ignored){} if(wasConnected){ append("CONEXÃO PERDIDA — preservando log e tentando reconexão automática."); setStatus("Conexão perdida — reconectando automaticamente"); scheduleReconnect(); } }
    private void scheduleReconnect(){ if(reconnecting||intentionalDisconnect||bt==null) return; reconnecting=true; dashboardExec.schedule(()->{ reconnecting=false; if(!intentionalDisconnect && (socket==null || !socket.isConnected()) && !monitoring && !operationRunning) io.execute(()->connectWorker()); },1500,TimeUnit.MILLISECONDS); }
    private void closeSocket(){try{if(in!=null)in.close();}catch(Exception ignored){}try{if(out!=null)out.close();}catch(Exception ignored){}try{if(socket!=null)socket.close();}catch(Exception ignored){}in=null;out=null;socket=null;}
    @Override protected void onDestroy(){intentionalDisconnect=true;monitoring=false;stopRequested=true;closeSocket();io.shutdownNow();dashboardExec.shutdownNow();super.onDestroy();}
}
