# AUDITORIA — VIRTUS ELM V11.0

## Escopo
Correção do estado de comunicação, watchdog OBD, recuperação automática e UX do estado de conexão/CAN.

## Estado visual
- Verde: OBD ativo e resposta ECU detectada.
- Amarelo: ELM conectado, mas OBD temporariamente pausado, em captura CAN ou sem resposta.
- Vermelho: ELM desconectado ou em reconexão automática.

## CAN
`AT MA` permanece somente leitura. O polling OBD não roda simultaneamente durante a captura. O encerramento aguarda `>` antes de considerar o monitor finalizado. Em timeout, a conexão é reiniciada e os dados são preservados.

## Watchdog
Após ciclos consecutivos sem resposta OBD, a V11.0 tenta `AT AR`, `ATSP0` e `ATAT1` no mesmo socket. Persistindo a ausência de resposta, inicia reconexão automática.

## Segurança
Nenhuma função de atuação, lock/unlock, coding, adaptation, security access ou transmissão de CAN arbitrário foi adicionada.
