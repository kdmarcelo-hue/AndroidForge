# VIRTUS ELM V12 — FIX10.20 / Code180

## Escopo
- Mantém a tela de gráficos ao vivo para o menu geral GRÁFICOS e a aba GRÁFICOS de DADOS.
- O botão VER GRÁFICOS DO TESTE na tela PERFORMANCE abre o modo histórico, separado da telemetria ao vivo.
- O rodapé da tela de gráficos tem dois botões de mesma largura: PERFORMANCE à esquerda e DADOS à direita.
- A tela histórica usa amostras coletadas durante a puxada, desde o início do teste até FINALIZAR; não injeta os dados ao vivo na curva histórica.
- Cada puxada arquiva linhas PERFORMANCE_SAMPLE no CSV persistente, com tempo decorrido, velocidade GPS, RPM, pedal normalizado e pressão de turbo (boost). O gráfico pode reconstruir a última puxada após reiniciar o aplicativo.
- Durante uma puxada em andamento, a tela informa que o gráfico novo só estará disponível após finalizar.
- Inclui calibração explícita do pedal: registrar leitura com pedal solto como 0% e leitura no fim de curso como 100%. Sem calibração, mantém o valor bruto e não assume que 88% seja 100%.

## Segurança e integridade dos dados
- A mudança não adiciona comandos de atuação, codificação, adaptação ou acesso de segurança ao veículo.
- O teste continua dependente de velocidade GPS válida e usa leituras OBD somente para RPM, pedal/borboleta, MAP e pressão atmosférica.
- O ponto de velocidade zero é um ponto inicial de referência para o gráfico; RPM, pedal e boost nesse ponto são leituras disponíveis, não são artificialmente zerados.
- Valores ausentes permanecem ausentes/gaps; o código não cria uma curva estimada para fingir que existiram amostras.
- A calibração é explícita, persistente no aplicativo e reversível. Não é aplicado offset automático arbitrário.

## Testes de bancada
Executar `python3 tests/bench_fix10_20.py`. O script valida os contratos de código relevantes sem ELM327 ou veículo. Ele não substitui a compilação Android, testes instrumentados, nem a validação real do GPS/ECU.

## Limitações conhecidas antes do teste real
- Não há Android SDK/Gradle disponível neste ambiente; portanto, este pacote ainda não foi compilado aqui.
- Os CSVs de puxadas anteriores à FIX10.20 contêm apenas resumo e não podem produzir retroativamente a curva que não foi gravada.
- A curva usa amostras realmente obtidas. Se GPS, PID de pedal ou MAP não responderem, o gráfico mostrará lacunas; não são inferidos valores ausentes.
- A calibração 0/100 precisa ser feita com o veículo parado e com leituras OBD válidas; conferir a resposta antes de usar a curva como medida quantitativa.
