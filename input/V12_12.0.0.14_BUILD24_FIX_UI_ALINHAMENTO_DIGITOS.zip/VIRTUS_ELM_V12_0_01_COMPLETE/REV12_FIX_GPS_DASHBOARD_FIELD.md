# V12 — Correção da velocidade GPS no painel principal

## Causa identificada
A rotina GPS existia, mas era acionada principalmente ao abrir a área Performance. Além disso, `getPreferredSpeedKmh()` priorizava sempre a velocidade simulada quando `simulationMode` estava ativo. Assim, o painel inicial não exibia a velocidade GPS real em uma sessão de simulação, mesmo com permissão concedida.

## Alterações
- Inicia o rastreamento GPS durante `onCreate` e retoma no `onResume` quando a permissão já foi concedida.
- Evita registrar o mesmo listener mais de uma vez.
- Atualiza o painel quando chega uma nova localização, sem esperar a próxima consulta OBD.
- Prioriza a velocidade GPS válida no painel; usa velocidade simulada apenas quando não há fix GPS válido e o modo simulação está ativo.
- Ajusta a janela de validade para 2,5 s, mais tolerante a atualizações GPS usuais próximas de 1 Hz, e limite de precisão horizontal de 50 m.
- Mantém a leitura OBD de velocidade (`010D`) separada da velocidade GPS (`lastGpsSpeed`).

## Permissões e limitações
O Manifest já declara `ACCESS_FINE_LOCATION` e `ACCESS_COARSE_LOCATION`. O Android ainda exige autorização em tempo de execução. Para velocidade confiável, conceder localização precisa e manter os serviços de localização ativos. Em ambiente interno, garagem ou túnel, o GPS pode não obter fix.

## Segurança
A correção não inicia teste de aceleração nem executa qualquer comando no veículo. Não realizar testes de performance em via pública. O uso do aparelho e a inspeção do aplicativo devem ocorrer com o veículo estacionado.

## Validação
A suíte Python valida a integração estática e os testes de regressão; não substitui compilação Android nem teste físico de recepção GPS.
