# V12 12.0.0.9 — consolidação de fonte (versionCode 19)

## Identificação
- `versionName`: `12.0.0.9`
- `versionCode`: `19`
- `applicationId`: mantido como `v12.marcelo.virtuselm.v12_0_0_8` para permitir atualização sobre a instalação 12.0.0.8.
- Projeto: `VirtusELM_V12_0_0_9`

## Correções e integrações nesta base
- Corrigidos os dois erros Java de escape que causaram falha de compilação no Actions: quebra de linha literal inserida como `\\n` entre instruções e caractere inválido em `append('\\\\n')`, normalizado para `append('\\n')`.
- Tela principal de diagnóstico consolidada com seleção de DTC confirmados (Mode 03), pendentes (07), permanentes (0A), readiness (01), Freeze Frame (02), VIN (09) e dados ao vivo (RPM, velocidade e temperatura).
- A seleção VAG UDS executa consultas somente-leitura nos endpoints conhecidos 7E0/7E1; o Explorador VAG detalhado chama a rotina existente de leitura VIN e DTC UDS por máscaras de status.
- A seleção Investigação EPC agora enfileira a rotina existente de coleta de evidências, incluindo consultas OBD e UDS, registro RAW e tentativa de persistência do relatório.
- As rotinas avançadas são enfileiradas no executor serial existente após a leitura OBD, evitando chamadas concorrentes ao transporte ELM.
- Mantido o `applicationId` da instalação anterior; atualizado o teste de versão que ainda esperava 12.0.0.7.
- Workflow mantém compilação Debug antes da Release.

## Validação executada neste ambiente
- `pytest -q`: 14 testes aprovados.
- Inspeção estática dos trechos Java alterados.

## Validação ainda necessária
- Não foi possível executar Gradle/Android build neste ambiente: não há `gradle`, `gradlew`, Gradle Wrapper nem Android SDK instalados na base recebida. Portanto, esta entrega não é declarada como compilada.
- Não houve teste físico com o Virtus 200 TSI 2024 nem com o ELM327 do usuário.
- Resposta UDS depende de endereçamento, protocolo, gateway, configuração e suporte real da ECU. 7E0/7E1 não representam todos os módulos do veículo.

## Escopo preexistente preservado, não certificado nesta entrega
O código-base contém ferramentas de desempenho, gráficos, aquisição OBD, histórico, exportação, biblioteca DTC, catálogo de customização, CAN Investigator, ISO-TP/UDS parcial, scan EPC e rotinas VAG. A presença no código não significa que todas estejam completas ou validadas no veículo.

## Itens que não podem ser declarados concluídos
- Auto-Scan VAG completo pelo Gateway endereço 19 e identificação de todos os módulos instalados.
- Biblioteca abrangente de DTCs VAG/SAE: o JSON embarcado contém 33 registros; não foram inventadas descrições sem fonte técnica confiável.
- Cobertura ISO-TP/UDS universal e validação de fluxo FC/STmin/BS em todos os módulos.
- Codificação, adaptações, Basic Settings, testes de atuadores e resets: não habilitados como operações genéricas; exigem identificação e validação específica por ECU, e alguns exigem autorização/ferramentas de segurança.
- Correção definitiva de todos os comportamentos de gráfico, latência, BOOST, histórico e MediaStore/SAF em dispositivo real.
- Diagnóstico do script externo `diagnose_failure.py`: o script não estava presente no arquivo-fonte recebido.

Esta é uma base consolidada para teste controlado no GitHub Actions, não uma declaração de suporte universal ou release validada em veículo.
