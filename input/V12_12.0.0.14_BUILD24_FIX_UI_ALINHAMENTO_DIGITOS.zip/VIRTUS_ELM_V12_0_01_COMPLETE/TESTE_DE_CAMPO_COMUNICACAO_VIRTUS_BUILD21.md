# V12 12.0.0.11 — pacote de teste de campo BUILD21

## Finalidade
Este pacote serve para verificar, no Virtus 200 TSI 2024, a comunicação básica do ELM327 e obter evidências reais de respostas OBD/UDS e do teste experimental de Gateway. **Não é release final nem comprova compatibilidade integral com o veículo.**

## Identificação preservada
- versionName: `12.0.0.11`
- versionCode: `21`
- applicationId: `v12.marcelo.virtuselm.v12_0_11`
- Transporte esperado: adaptador ELM327 Bluetooth; o protocolo será consultado no próprio veículo.

## Segurança
1. Estacione em local seguro, aplique o freio de estacionamento e mantenha o veículo imobilizado.
2. Faça as verificações com ignição ligada e, preferencialmente, motor desligado. Não opere menus de diagnóstico nem CAN Lab dirigindo.
3. As rotinas desta revisão são de leitura. Não execute comandos manuais no terminal ELM nem tente codificação, adaptação, Security Access ou limpeza de DTC.
4. Se houver queda de tensão, aquecimento anormal do adaptador, desconexão ou comportamento inesperado, interrompa a sessão.

## Como gerar o APK pelo GitHub Actions
1. Extraia o conteúdo do ZIP e envie **o conteúdo da pasta do projeto** para a raiz do repositório `AndroidForge`, preservando `.github`, `app`, `tests`, `build.gradle` e `settings.gradle`.
2. No GitHub, abra **Actions** e execute **Android Build** (`workflow_dispatch`) ou aguarde o workflow após o commit.
3. Só prossiga se o job **Compile debug variant** terminar com sucesso.
4. Baixe o artefato `VirtusELM-V12.0.0.11-BUILD21-debug`, extraia o APK e instale no Android.
5. O workflow também permite executar `V12 Offline ELM Replay Bench`. Esse teste offline não substitui o teste físico.

## Roteiro de teste no veículo

### A. Conexão básica
1. Pareie o ELM327 nas configurações Bluetooth do Android.
2. Abra o V12, conecte ao adaptador e confirme que o app indica conexão real (não simulação).
3. Abra a função de leitura de dados do veículo e confirme se a comunicação OBD básica permanece estável.
4. Registre o protocolo informado pelo app/ELM (`ATDP` e `ATDPN`, quando exibidos) e o texto RAW de resposta.

### B. Varredura de endereços de diagnóstico
1. Execute **IDENTIFICAR MÓDULOS DO VEÍCULO**.
2. A rotina atual consulta apenas os endereços de requisição `7E0` a `7E7`, enviando UDS `22 F190`.
3. Uma resposta positiva `62 F190` significa apenas que aquele endereço respondeu à leitura do DID VIN. Não identifica, por si só, o nome do módulo.
4. “Sem resposta positiva nesta varredura” não prova que a ECU inexiste: ela pode usar outro endereço, protocolo, gateway ou serviço.
5. Guarde o relatório completo e as linhas RAW.

### C. VAG Scan UDS
1. Execute a opção **VAG SCAN UDS** se estiver disponível na tela de diagnóstico.
2. A rotina testa o endereço funcional `7DF` e os endpoints `7E0`/`7E1`, observando respostas esperadas `7E8`/`7E9`.
3. Registre protocolo, respostas, VIN decodificado e RAW. Não generalize os resultados para todas as ECUs.

### D. Gateway Installation List — experimental
1. Execute somente se o veículo estiver parado e a conexão básica estiver estável.
2. Marque a opção **Gateway • Installation List DID 2A26 (experimental)** no diagnóstico unificado.
3. A implementação usa CAN 11-bit TX `710` / RX `77A` como hipótese experimental, protocolo CAN 11-bit/500 kbps. Isso não é universal nem foi validado previamente neste Virtus.
4. Registre o RAW e o resultado. Um bitmap válido lista nós lógicos configurados; não confirma que cada módulo esteja presente/respondendo agora.
5. Se não houver resposta, isso não confirma ausência do Gateway. Não repita continuamente a consulta.

### E. CAN Lab passivo
1. Execute somente com o carro imobilizado. A rotina pausa a operação OBD e tenta monitorar tráfego por aproximadamente 10 segundos.
2. Registra `ATDP`, `ATDPN`, prepara o ELM em modo CAN raw e testa `ATMR 07`.
3. Interprete o resultado como um teste de capacidade do adaptador/firmware para monitorar frames. `ATMR 07` é um filtro amplo de bits do identificador, não uma captura completa nem um sniffer CAN profissional.
4. Registre se o comando foi rejeitado, permaneceu ativo sem frames ou recebeu frames. Não conclua que a rede do veículo está inativa apenas porque não chegaram frames nessa janela.

## O que ainda não está neste pacote
- Árvore completa de investigação individual por ECU/subteste.
- Descoberta universal de ECUs em CAN 11-bit e 29-bit.
- Identificação completa de módulos por número de peça, hardware, software e fabricante.
- Integração de base ODX/MCD compatível e licenciada para o VIN/variantes do veículo.
- Biblioteca completa de medições, escalas, canais e DTC específicos de cada ECU.
- Captura CAN completa com filtros arbitrários, correlação de eventos e exportação PCAP.
- Adaptações/codificação e operações de escrita.

## ODX/MCD: é necessário para este teste?
Não. A primeira validação de conexão, protocolo, respostas OBD/UDS e RAW pode ser feita sem ODX/MCD. Essa base será necessária para enriquecer a interpretação específica de ECUs, serviços, DTCs, parâmetros e escalas. Use somente dados cuja origem e licença permitam integração; não inclua bases proprietárias do ODIS/ODX sem autorização.

## Evidências a trazer de volta
- Resultado do workflow Android Build (sucesso/falha e log do primeiro erro, se houver).
- Captura da tela de conexão e protocolo.
- Relatório da varredura `7E0`–`7E7`.
- Resultado do VAG Scan UDS.
- Resultado/RAW do Gateway 2A26, inclusive se falhar.
- Resultado do CAN Lab: rejeitado, sem frames ou frames recebidos.
- Modelo/revisão do ELM327, se identificável.

**Importante:** os 24 testes Python existentes passaram localmente no ambiente de preparação. Isso não valida Gradle, APK, instalação, comunicação Bluetooth nem compatibilidade física com o Virtus. O build Android precisa ser confirmado no GitHub Actions antes da instalação.
