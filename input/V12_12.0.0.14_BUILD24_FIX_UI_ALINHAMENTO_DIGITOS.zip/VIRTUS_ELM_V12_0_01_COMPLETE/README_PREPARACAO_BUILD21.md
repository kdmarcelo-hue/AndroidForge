# V12 — preparação técnica BUILD21

Base preservada: versão 12.0.0.11, versionCode 21 e applicationId existente.

## Conteúdo desta revisão
- Leitura experimental e opcional do Gateway Installation List DID 2A26.
- Parser estrito do bitmap 32 bytes, LSB-first, endereços lógicos 0–255.
- Evidência bruta e classificação conservadora de ausência de resposta.
- Correção do parser ISO-TP para resposta UDS positiva 0x62 sem CAN ID.
- Workflow de build: debug sem assinatura; release assinado condicionado aos segredos.
- Testes automatizados de regressão do bitmap, integração, ISO-TP, replay e telemetria.

## Como validar no GitHub Actions
1. Subir o conteúdo deste ZIP no repositório mantendo a estrutura.
2. Executar o workflow `Android Build`.
3. Confirmar `Compile debug variant`.
4. Para APK release assinado, configurar `V12_KEYSTORE_BASE64`, `V12_KEYSTORE_PASSWORD`, `V12_KEY_ALIAS` e `V12_KEY_PASSWORD` em Secrets.
5. Executar também `V12 Offline ELM Replay Bench`.

## Limites desta entrega
A leitura 2A26 usa TX 0x710 / RX 0x77A como hipótese técnica experimental, não como endereçamento universal. Não foi validada no veículo. O build Android e a instalação não foram executados neste ambiente. Não há escrita/coding/adaptation habilitada por esta alteração.
