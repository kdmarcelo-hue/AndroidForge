from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'app/src/main/java/com/marcelo/virtuselm/MainActivity.java'

class GpsDashboardIntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.java = SOURCE.read_text(encoding='utf-8')

    def test_gps_tracking_starts_during_app_initialization(self):
        on_create = self.java.split('@Override public void onCreate(Bundle b){', 1)[1].split('private void recordStartupFailure', 1)[0]
        self.assertIn('startGpsTracking();', on_create)

    def test_real_gps_speed_has_priority_over_simulated_speed(self):
        self.assertIn('private double getPreferredSpeedKmh(){ return isGpsSpeedValid()?lastGpsSpeed:(simulationMode?lastSpeed:-1); }', self.java)

    def test_location_callback_refreshes_dashboard(self):
        self.assertIn('gpsHasFix=true; ui(()->{if(dashSpeed!=null)updateDashboard();});', self.java)

    def test_tracking_is_not_registered_twice(self):
        self.assertIn('if(gpsTrackingActive)return;', self.java)
        self.assertIn('gpsTrackingActive=true;', self.java)

    def test_gps_fix_freshness_allows_normal_one_hz_updates(self):
        self.assertIn('ageMs<=2500 && gpsAccuracyM<=50f', self.java)

if __name__ == '__main__':
    unittest.main()
