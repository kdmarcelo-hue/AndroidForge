from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "app/src/main/java/com/marcelo/virtuselm/MainActivity.java"

class JavaCompileRegression(unittest.TestCase):
    def test_report_newline_replacement_uses_valid_java_string_literal(self):
        source = SOURCE.read_text(encoding="utf-8")
        self.assertIn('result.replace("\\\\n", " ")', source)
        self.assertNotIn("result.replace('\\\\n', ' ')", source)

if __name__ == "__main__":
    unittest.main()
