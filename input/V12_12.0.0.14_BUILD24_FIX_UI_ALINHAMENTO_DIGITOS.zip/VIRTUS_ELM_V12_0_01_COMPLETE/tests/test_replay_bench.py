#!/usr/bin/env python3
import sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"tools"/"replay_bench"))
import replay_bench as rb
FIX=ROOT/"tools"/"replay_bench"/"fixtures"
class ReplayBenchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reports={r["file"]:r for r in (rb.run_fixture(p) for p in sorted(FIX.glob("*.txt")))}
    def test_three_real_logs_are_loaded(self): self.assertEqual(len(self.reports),3)
    def test_obd_responders_are_separated(self):
        r=next(v for k,v in self.reports.items() if "DIAGN" in k)
        self.assertIn("7E8",r["responders"]); self.assertIn("7E9",r["responders"])
    def test_map_baro_and_boost_reference(self):
        r=next(v for k,v in self.reports.items() if "DIAGN" in k)
        self.assertEqual(r["pid_values"]["0B"][0]["value"],91)
        self.assertEqual(r["pid_values"]["33"][0]["value"],92)
        self.assertAlmostEqual((91-92)/100,-0.01,places=2)
    def test_pid_conversions(self):
        r=next(v for k,v in self.reports.items() if "DIAGN" in k)
        self.assertEqual(r["pid_values"]["05"][0]["value"],75)
        self.assertEqual(r["pid_values"]["0F"][0]["value"],40)
        self.assertEqual(r["pid_values"]["0C"][0]["value"],0)
        self.assertEqual(r["pid_values"]["0D"][0]["value"],0)
        self.assertAlmostEqual(r["pid_values"]["11"][0]["value"],17.65,places=2)
    def test_unsupported_pid_is_not_fabricated(self):
        r=next(v for k,v in self.reports.items() if "DIAGN" in k)
        self.assertNotIn("5C",r["pid_values"]); self.assertGreaterEqual(r["no_data_count"],1)
    def test_uds_pending_is_retained_as_pending_evidence(self):
        r=next(v for k,v in self.reports.items() if "VAG_SCAN" in k)
        self.assertGreater(r["uds_pending_count"],0); self.assertGreaterEqual(r["uds_negative_out_of_range"],1)
    def test_four_uds_dtc_records_reassemble(self):
        r=next(v for k,v in self.reports.items() if "VAG_SCAN" in k)
        d=r["uds_dtc"]["7E8"]
        self.assertEqual(d["status"],"COMPLETE"); self.assertEqual(d["mask"],0xFF)
        self.assertEqual([x["dtc"] for x in d["records"]],["00 27 DB","00 29 5F","00 29 61","00 84 2B"])
        self.assertEqual([x["status"] for x in d["records"]],[0x60,0x60,0x60,0x20])
    def test_isotp_rejects_bad_sequence(self):
        payload,status=rb.isotp_payload([bytes.fromhex("10 08 59 02 FF 00 01 02"),bytes.fromhex("22 03 04 05 06 07 08 09")])
        self.assertIsNone(payload); self.assertEqual(status,"BAD_SEQUENCE")
    def test_isotp_marks_truncated_multiframe(self):
        payload,status=rb.isotp_payload([bytes.fromhex("10 08 59 02 FF 00 01 02")])
        self.assertIsNone(payload); self.assertEqual(status,"INCOMPLETE_ISOTP")
if __name__=="__main__": unittest.main(verbosity=2)
