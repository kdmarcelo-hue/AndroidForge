import unittest

BITMAP_BYTES = 32

def decode(payload):
    if payload is None or len(payload) != 35:
        return []
    if payload[:3] != bytes((0x62, 0x2A, 0x26)):
        return []
    found = []
    for i, value in enumerate(payload[3:]):
        for bit in range(8):
            if value & (1 << bit):
                found.append(i * 8 + bit)
    return found

class GatewayInstallationListTests(unittest.TestCase):
    def test_lsb_first_node_order(self):
        bitmap = bytearray(BITMAP_BYTES)
        bitmap[0] = 0b00000101
        bitmap[1] = 0b10000000
        self.assertEqual(decode(bytes((0x62,0x2A,0x26)) + bitmap), [0,2,15])

    def test_highest_logical_node(self):
        bitmap = bytearray(BITMAP_BYTES)
        bitmap[31] = 0x80
        self.assertEqual(decode(bytes((0x62,0x2A,0x26)) + bitmap), [255])

    def test_wrong_sid_or_did_rejected(self):
        bitmap = bytes(BITMAP_BYTES)
        self.assertEqual(decode(bytes((0x59,0x2A,0x26)) + bitmap), [])
        self.assertEqual(decode(bytes((0x62,0x2A,0x27)) + bitmap), [])

    def test_truncated_or_oversized_bitmap_rejected(self):
        header = bytes((0x62,0x2A,0x26))
        self.assertEqual(decode(header + bytes(31)), [])
        self.assertEqual(decode(header + bytes(33)), [])

    def test_empty_bitmap_is_valid_empty_installation_list(self):
        self.assertEqual(decode(bytes((0x62,0x2A,0x26)) + bytes(32)), [])

if __name__ == "__main__":
    unittest.main()
