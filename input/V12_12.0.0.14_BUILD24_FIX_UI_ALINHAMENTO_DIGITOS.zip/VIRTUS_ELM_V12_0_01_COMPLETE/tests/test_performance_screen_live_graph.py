import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
JAVA=(ROOT/'app/src/main/java/com/marcelo/virtuselm/MainActivity.java').read_text(encoding='utf-8')
class PerformanceScreenLiveGraphTests(unittest.TestCase):
    def test_combined_graph_exists_only_on_graph_screen(self):
        self.assertIn('combinedGraphView=new CombinedGraphView(this)', JAVA)
        perf=JAVA.split('private LinearLayout buildPerformanceScreen',1)[1].split('private class PerformanceGaugeView',1)[0]
        self.assertNotIn('CombinedGraphView', perf)
        self.assertNotIn('TELEMETRIA DA PUXADA • AO VIVO', perf)
    def test_real_samples_are_published_to_the_shared_graph(self):
        start=JAVA.index('private void startPerformanceTest()')
        end=JAVA.index('private String buildPullComparison',start)
        block=JAVA[start:end]
        self.assertIn('if(t0>0 && samples%2==0)',block)
        for token in ('combinedTimeValues.add(gt)','combinedRpmValues.add(gr)','combinedSpeedValues.add(gs)','combinedPedalValues.add(gp)','combinedBoostValues.add(gb)','combinedGraphView.invalidate()'):
            self.assertIn(token,block)
    def test_invalid_boost_does_not_show_peak_placeholder(self):
        self.assertIn('PICO: %.2f bar',JAVA)
        self.assertNotIn('PICO: —',JAVA)
    def test_peak_and_performance_max_use_the_same_pull_window(self):
        self.assertIn('if(t0>0 && boost>=0)',JAVA)
        self.assertIn('performanceGraphBoostPeak=fb; maxBoost=fb;',JAVA)
if __name__=='__main__': unittest.main(verbosity=2)
