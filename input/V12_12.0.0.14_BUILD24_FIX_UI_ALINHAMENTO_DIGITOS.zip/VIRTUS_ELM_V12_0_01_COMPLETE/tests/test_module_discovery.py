from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
JAVA = (ROOT / 'app/src/main/java/com/marcelo/virtuselm/MainActivity.java').read_text(encoding='utf-8')

class ModuleDiscoveryTests(unittest.TestCase):
    def test_scan_requires_real_elm_and_rejects_simulation(self):
        method = JAVA.split('private void scanVehicleModules()', 1)[1].split('private String buildModuleReport', 1)[0]
        self.assertIn('simulationMode || !connected || out == null || in == null', method)
        self.assertIn('VARREDURA REAL NECESSÁRIA', method)

    def test_scan_checks_conventional_physical_request_range(self):
        self.assertIn('String[] requests = {"7E0","7E1","7E2","7E3","7E4","7E5","7E6","7E7"}', JAVA)
        self.assertIn('send("22F190", 3500)', JAVA)

    def test_negative_response_is_not_misreported_as_no_response(self):
        self.assertIn('RESPOSTA_UDS_NEGATIVA_DID_F190', JAVA)
        self.assertIn('describeUdsNrc(raw, "22")', JAVA)
        self.assertIn('ECU respondeu negativamente ao DID F190', JAVA)

    def test_response_pending_has_its_own_classification(self):
        self.assertIn('RESPOSTA_UDS_PENDENTE_DID_F190', JAVA)
        self.assertIn('NRC 0x78', JAVA)

    def test_vag_scan_cannot_generate_simulated_vehicle_evidence(self):
        method = JAVA.split('private void vagFocusedScan()', 1)[1].split('private String probeUdsVinHeader', 1)[0]
        self.assertIn('if(simulationMode || !connected || out==null || in==null)', method)
        self.assertIn('O VAG Scan não será executado em simulação', method)

    def test_performance_buttons_allow_two_lines_without_clipping(self):
        method = JAVA.split('Button start=btn("🏁  INICIAR 0–60 / 0–100 / 0–280")', 1)[1].split('TextView note=', 1)[0]
        self.assertIn('setSingleLine(false)', method)
        self.assertIn('setMaxLines(2)', method)
        self.assertIn('setIncludeFontPadding(true)', method)
        self.assertIn('dp(72)', method)
        self.assertIn('setClipChildren(false)', method)

if __name__ == '__main__':
    unittest.main(verbosity=2)
