#!/usr/bin/env python3
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAVA = (ROOT / 'app/src/main/java/com/marcelo/virtuselm/MainActivity.java').read_text(encoding='utf-8')
GRADLE = (ROOT / 'app/build.gradle').read_text(encoding='utf-8')

class LivePerformanceGraphTests(unittest.TestCase):
    def test_version_incremented_for_parallel_install(self):
        self.assertIn("applicationId 'v12.marcelo.virtuselm.v12_0_13'", GRADLE)
        self.assertRegex(GRADLE, r'versionCode\s+23\b')
        self.assertIn("versionName '12.0.0.13'", GRADLE)

    def test_new_pull_resets_historical_graph_mode(self):
        start = JAVA.index('private void startPerformanceTest()')
        section = JAVA[start:start + 1800]
        self.assertIn('historicalGraphMode=false;', section)
        self.assertIn('combinedGraphView.clear()', section)

    def test_live_samples_update_shared_obd_state(self):
        start = JAVA.index('private void startPerformanceTest()')
        section = JAVA[start:JAVA.index('private String buildPullComparison', start)]
        for token in ('lastRpm=rpm;', 'lastSpeed=canSpeed;', 'lastMap=map;', 'lastBaro=baro;', 'lastBoost=boost;'):
            self.assertIn(token, section)

    def test_dashboard_and_graph_refresh_is_not_waiting_for_gps_t0(self):
        start = JAVA.index('private void startPerformanceTest()')
        section = JAVA[start:JAVA.index('private String buildPullComparison', start)]
        self.assertRegex(section, r'if\s*\(samples%5==0\)\s*\{')
        self.assertIn('updateDashboard();', section)
        self.assertNotRegex(section, r'if\s*\(t0>0\s*&&\s*samples%5==0\)\s*\{\s*final double liveRpm')

    def test_boost_uses_map_and_baro_and_invalid_data_is_not_carried_forward(self):
        start = JAVA.index('private void startPerformanceTest()')
        section = JAVA[start:JAVA.index('private String buildPullComparison', start)]
        self.assertIn('double boost=calculateBoost(map,baro)', section)
        self.assertIn('else lastBoost=-1;', section)

if __name__ == '__main__':
    unittest.main(verbosity=2)
