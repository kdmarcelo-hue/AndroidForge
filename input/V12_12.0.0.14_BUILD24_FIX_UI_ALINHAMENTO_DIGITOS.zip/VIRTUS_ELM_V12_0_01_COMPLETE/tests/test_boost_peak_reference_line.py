import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
JAVA=(ROOT/'app/src/main/java/com/marcelo/virtuselm/MainActivity.java').read_text(encoding='utf-8')
class BoostPeakReferenceLineTests(unittest.TestCase):
    def test_horizontal_translucent_peak_line_and_corner_legend(self):
        self.assertIn('Color.argb(145,170,112,0)', JAVA)
        self.assertIn('c.drawLine(left,peakY,right,peakY,peakPaint)', JAVA)
        self.assertIn('PICO: %.2f bar', JAVA)
    def test_peak_updates_only_from_valid_live_boost_and_resets_for_new_pull(self):
        self.assertIn('if(!Float.isNaN(gb)&&!Float.isInfinite(gb)&&gb>=0&&gb>performanceGraphBoostPeak)', JAVA)
        self.assertIn('performanceGraphBoostPeak=-1;', JAVA)
if __name__=='__main__': unittest.main(verbosity=2)
