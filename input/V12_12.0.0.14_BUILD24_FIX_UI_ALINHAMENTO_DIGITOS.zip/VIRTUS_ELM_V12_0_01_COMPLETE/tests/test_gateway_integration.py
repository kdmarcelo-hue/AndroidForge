import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAVA = (ROOT / "app/src/main/java/com/marcelo/virtuselm/MainActivity.java").read_text()
MODEL = (ROOT / "app/src/main/java/com/marcelo/virtuselm/VagGatewayDiscovery.java").read_text()
WORKFLOW = (ROOT / ".github/workflows/android-build.yml").read_text()

class GatewayIntegrationTests(unittest.TestCase):
    def test_gateway_is_opt_in_in_unified_diagnostic(self):
        self.assertIn("Gateway • Installation List DID 2A26 (experimental)", JAVA)
        self.assertIn("io.execute(this::readGatewayInstallationList)", JAVA)

    def test_only_read_request_and_candidate_address_are_used(self):
        self.assertIn('send("ATSH 710"', JAVA)
        self.assertIn('send("222A26"', JAVA)
        method = JAVA[JAVA.index("private void readGatewayInstallationList"):JAVA.index("private void vagFocusedScan")]
        for forbidden in ("2E", "2F", "27", "31", "11"):
            self.assertNotIn('send("' + forbidden, method)

    def test_uds_62_is_accepted_in_direct_isotp_fallback(self):
        self.assertIn('a[0].equals("62")', JAVA)

    def test_model_requires_exact_positive_response(self):
        self.assertIn("payload.length != 3 + BITMAP_BYTES", MODEL)
        self.assertIn("payload[0] & 0xFF) != 0x62", MODEL)
        self.assertIn("payload[1] & 0xFF) != DID_HIGH", MODEL)
        self.assertIn("payload[2] & 0xFF) != DID_LOW", MODEL)

    def test_workflow_builds_debug_without_release_secrets(self):
        self.assertIn("gradle --no-daemon clean assembleDebug", WORKFLOW)
        self.assertIn("steps.signing.outputs.available == 'true'", WORKFLOW)

if __name__ == "__main__":
    unittest.main(verbosity=2)
