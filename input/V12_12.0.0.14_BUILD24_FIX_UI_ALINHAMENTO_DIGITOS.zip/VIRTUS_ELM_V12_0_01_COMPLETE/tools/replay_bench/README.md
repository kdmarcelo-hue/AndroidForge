# V12 — bancada offline de reprodução ELM/UDS

Esta bancada usa os três logs reais fornecidos em `fixtures/`. Ela não se conecta ao Bluetooth/ELM, não acessa o veículo e não envia comandos.

## Executar localmente

Requer Python 3.10+ (sem bibliotecas externas):

```bash
python -m unittest discover -s tests -p 'test_replay_bench.py' -v
python tools/replay_bench/replay_bench.py
```

O segundo comando gera `replay_report.json` com respondedores CAN separados, respostas ISO-TP, PIDs reconhecidos, contagem de `NO DATA`, NRCs pendentes/negativos e DTCs UDS remontados.

## O que os testes cobrem

- Os três arquivos de evidência são carregados.
- Respondedores `7E8` e `7E9` são mantidos separados.
- Decodificação de MAP, BARO, RPM, velocidade, temperaturas e posição do acelerador.
- PID sem resposta (`015C`) não vira medição inventada.
- Remontagem ISO-TP de resposta UDS `59 02`, incluindo o caso observado em que `7F 19 78` antecede a resposta positiva.
- Os quatro registros UDS do pedido `19 02 20` são recuperados com seus status.
- Quadros ISO-TP truncados ou com sequência inválida são rejeitados.

## Limites

Esta é uma bancada de referência Python que reproduz e decodifica os registros capturados. Ela valida os bytes e as regras de protocolo representadas nos logs; **não executa o interpretador Java/Android da aplicação em runtime** e não prova comunicação futura com o veículo. Para validar a implementação Android de ponta a ponta, a próxima etapa é ligar o mesmo conjunto de fixtures ao modo de simulação interno da aplicação e comparar a saída da tela/log com `replay_report.json`.

Nenhum comando de escrita, coding, Security Access, limpeza de DTC ou atuação é incluído.
