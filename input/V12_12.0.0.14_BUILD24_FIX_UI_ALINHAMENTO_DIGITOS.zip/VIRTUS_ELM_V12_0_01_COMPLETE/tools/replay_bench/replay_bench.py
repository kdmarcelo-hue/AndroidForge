#!/usr/bin/env python3
"""Replay real V12 ELM evidence logs offline. No Bluetooth, vehicle, or write commands."""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path
from collections import defaultdict

HEX = re.compile(r'^(7E[89A-Fa-f]|7DF)\s+((?:[0-9A-Fa-f]{2}\s*)+)$')

def parse_can_frames(text):
    frames = defaultdict(list)
    for line in text.splitlines():
        m = HEX.match(line.strip())
        if m:
            frames[m.group(1).upper()].append(bytes.fromhex(m.group(2)))
    return frames

def isotp_payload(frames):
    """Reassemble one ISO-TP payload from ordered CAN data fields."""
    if not frames:
        return None, "NO_FRAME"
    # Some ELM logs contain NRC 0x78 (single frame) followed by the
    # eventual positive ISO-TP response in the same RX block.
    if len(frames)>1 and frames[0] and (frames[0][0]>>4)==0 and len(frames[0])>=4 and frames[0][1:4][0]==0x7F and frames[0][3]==0x78:
        next_ff=next((i for i,f in enumerate(frames[1:],1) if f and (f[0]>>4)==1),None)
        if next_ff is not None: frames=frames[next_ff:]
    first=frames[0]
    if not first: return None, "EMPTY_FRAME"
    pci=first[0] >> 4
    if pci == 0:
        n=first[0] & 0x0F
        payload=first[1:1+n]
        return (payload, "COMPLETE") if len(payload)==n else (None,"TRUNCATED_SF")
    if pci != 1 or len(first)<2: return None,"UNSUPPORTED_PCI"
    total=((first[0]&0x0F)<<8)|first[1]
    payload=bytearray(first[2:])
    seq=1
    for frame in frames[1:]:
        if not frame or frame[0]>>4 != 2: continue
        if (frame[0]&0x0F) != (seq&0x0F): return None,"BAD_SEQUENCE"
        payload.extend(frame[1:])
        seq+=1
        if len(payload)>=total:
            return bytes(payload[:total]),"COMPLETE"
    return None,"INCOMPLETE_ISOTP"

def responses_by_ecu(text):
    out={}
    for ecu, frames in parse_can_frames(text).items():
        payload,status=isotp_payload(frames)
        out[ecu]={"payload":payload.hex(" ").upper() if payload else None,
                  "status":status,"frame_count":len(frames)}
    return out

def decode_obd_pid(pid, payload):
    """Return standards-based value; None means unavailable/unsupported."""
    if payload is None: return None
    b=list(payload)
    if pid==0x0B and len(b)>=1: return {"value":b[0],"unit":"kPa","label":"MAP"}
    if pid==0x33 and len(b)>=1: return {"value":b[0],"unit":"kPa","label":"BARO"}
    if pid==0x0C and len(b)>=2: return {"value":((b[0]*256)+b[1])/4,"unit":"rpm","label":"RPM"}
    if pid==0x0D and len(b)>=1: return {"value":b[0],"unit":"km/h","label":"Velocidade"}
    if pid in (0x05,0x0F) and len(b)>=1:
        return {"value":b[0]-40,"unit":"°C","label":"Temperatura do líquido" if pid==5 else "Temperatura de admissão"}
    if pid==0x11 and len(b)>=1: return {"value":round(b[0]*100/255,2),"unit":"%","label":"Acelerador"}
    if pid==0x2F and len(b)>=1: return {"value":round(b[0]*100/255,2),"unit":"%","label":"Nível de combustível"}
    if pid==0x42 and len(b)>=2: return {"value":((b[0]*256)+b[1])/1000,"unit":"V","label":"Tensão módulo"}
    return None

def parse_uds_dtc(payload):
    if not payload or len(payload)<3 or payload[0:2] != bytes([0x59,0x02]):
        return {"status":"NOT_POSITIVE_5902","records":[],"mask":None}
    mask=payload[2]
    rest=payload[3:]
    records=[]
    if len(rest)%4:
        return {"status":"MALFORMED_RECORD_LENGTH","records":[],"mask":mask}
    for i in range(0,len(rest),4):
        d=rest[i:i+3]; st=rest[i+3]
        records.append({"dtc":d.hex(" ").upper(),"status":st,
                        "failed_since_clear":bool(st&0x20),
                        "failed_this_cycle":bool(st&0x02),
                        "pending":bool(st&0x04),
                        "confirmed":bool(st&0x08),
                        "warning_indicator":bool(st&0x80)})
    return {"status":"COMPLETE","mask":mask,"records":records}

def parse_log(path):
    text=Path(path).read_text(encoding="utf-8",errors="replace")
    tx=re.findall(r'\bTX \[\d+ ms\]:\s*([^\r\n]+)',text)
    rx=re.findall(r'\bRX:\s*([^\r\n]+)',text)
    return {"file":Path(path).name,"tx":tx,"rx":rx,"text":text}

def run_fixture(path):
    item=parse_log(path); text=item["text"]
    rx_blocks=re.findall(r'\[\d{2}:\d{2}:\d{2}\.\d+\] RX:\s*(.*?)(?=\n\[\d{2}:\d{2}:\d{2}\.\d+\]|\Z)',text,re.S)
    responders=set(); response_records=[]; pid_values={}; uds_dtc={}
    for block in rx_blocks:
        for ecu,frames in parse_can_frames(block).items():
            responders.add(ecu)
            payload,status=isotp_payload(frames)
            response_records.append({"ecu":ecu,"status":status,
                                     "payload":payload.hex(" ").upper() if payload else None})
            if status!="COMPLETE" or not payload: continue
            if payload[0]==0x41 and len(payload)>=3:
                pid=payload[1]; decoded=decode_obd_pid(pid,payload[2:])
                if decoded is not None:
                    pid_values.setdefault(f"{pid:02X}",[]).append({"ecu":ecu,**decoded})
            if payload[0]==0x59:
                uds_dtc[ecu]=parse_uds_dtc(payload)
    return {"file":item["file"],"tx_count":len(item["tx"]),"rx_count":len(item["rx"]),
            "responders":sorted(responders),"responses":response_records,"pid_values":pid_values,
            "uds_dtc":uds_dtc,"uds_pending_count":text.count("7F 19 78"),
            "uds_negative_out_of_range":text.count("7F 22 31"),
            "no_data_count":len(re.findall(r'\bNO DATA\b',text))}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--fixtures",default=str(Path(__file__).parent/"fixtures"))
    ap.add_argument("--out",default=str(Path(__file__).parent/"replay_report.json"))
    args=ap.parse_args()
    files=sorted(Path(args.fixtures).glob("*.txt"))
    reports=[run_fixture(p) for p in files]
    out={"bench":"V12 offline ELM evidence replay","mode":"READ_ONLY_FIXTURES",
         "fixture_count":len(files),"reports":reports,
         "safety":"No Bluetooth/vehicle connection and no actuator, security, coding, clear-DTC or write command."}
    Path(args.out).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"Fixtures: {len(files)}")
    for r in reports:
        print(f"- {r['file']}: TX={r['tx_count']} RX={r['rx_count']} responders={','.join(r['responders']) or 'none'} pending={r['uds_pending_count']}")
    print(f"Report: {args.out}")
    return 0 if files else 2

if __name__=="__main__": raise SystemExit(main())
