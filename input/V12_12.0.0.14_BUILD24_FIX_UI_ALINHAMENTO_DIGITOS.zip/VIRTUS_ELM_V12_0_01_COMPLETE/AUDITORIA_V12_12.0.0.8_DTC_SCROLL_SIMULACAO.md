# V12 12.0.0.8 — correção de rolagem, DTC e coerência da simulação

## Base
Derivada do ZIP `V12_12.0.0.7_CORRECAO_GRAFICOS_LIVE_ATUALIZADO.zip` (SHA-256 `b10e91a35377eedadc13a75080e0204d00f533faaf2afdab22a6c7221f8f9330`).

## Evidências dos logs recebidos em 02/11/2026
- Duas leituras Mode 03 retornaram `43 01 33 00 00 00 00`, corretamente decodificadas como P0133.
- A investigação EPC retornou PID `0101` como `41 01 00 00 00 00`, informando zero DTCs apesar do P0133 confirmado em Mode 03.
- O arquivo de biblioteca embarcado já continha P0133, mas a inicialização assíncrona podia deixar a primeira consulta ao detalhe sem registro carregado; o diálogo mostrava a mensagem genérica.
- `showResult()` executava `diagnosticScroll.fullScroll(View.FOCUS_DOWN)`, causando o salto da tela de diagnóstico para o final após a leitura.

## Correções
1. Removida a rolagem automática do contêiner geral de diagnóstico ao publicar resultados. A rolagem própria da aba Logs permanece independente.
2. A resposta simulada do PID `0101` agora informa a quantidade de DTCs confirmados atualmente presentes em `simulatedDtcCodes`, mantendo MIL desligada no cenário de bancada. Para um P0133, a resposta passa a `41 01 01 00 00 00`; após remoção simulada, a contagem volta a zero.
3. A consulta de detalhe DTC tenta carregar a biblioteca embarcada quando a primeira consulta ocorre antes da conclusão da inicialização assíncrona.
4. Registro P0133 enriquecido com localização B1S1, causas possíveis, orientação e referência; a descrição não atribui automaticamente a falha ao remapeamento ou à remoção do catalisador.

## Identidade
- versionName: `12.0.0.8`
- versionCode: `18`
- applicationId: `v12.marcelo.virtuselm.v12_0_0_8`

## Verificações realizadas neste pacote
- Integridade estrutural do ZIP de origem e leitura dos nove arquivos de log.
- Conferência estática dos pontos de código alterados e da identidade Gradle.
- Validação JSON do catálogo DTC e presença de P0133.
- Não foi executado build Android neste ambiente; não há confirmação de APK compilado. O build e a validação final de instalação dependem do GitHub Actions.
