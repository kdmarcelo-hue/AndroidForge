# V12 12.0.0.12 BUILD22 — integração de diagnóstico, interface e GPS

## Descoberta de endpoints
- Varredura real somente leitura dos endereços físicos convencionais CAN 11-bit 0x7E0–0x7E7.
- Cada requisição consulta o DID UDS F190 e preserva o RAW recebido.
- Separa resposta positiva, resposta negativa UDS, NRC 0x78 (Response Pending), quadro recebido sem payload UDS reconhecido e ausência de resposta.
- O relatório mostra o par request/response esperado, sem atribuir nome de módulo com base apenas no endereço.
- A rotina bloqueia explicitamente execução em simulação.

## VAG Scan
- Bloqueia execução em simulação para impedir que respostas artificiais sejam apresentadas como evidência do veículo.
- Mantém a etapa experimental de Gateway 2A26 isolada e marcada como não universal; não assume que 0x710/0x77A seja o endereço correto para todo veículo.

## Interface
- Botões Iniciar/Finalizar da tela Performance passam a aceitar duas linhas, desativam autosize herdado, habilitam font padding e recebem altura/padding compatíveis com o texto.
- Contêiner de ações em paisagem não recorta os filhos.

## GPS
- Mantém a correção anterior: inicialização do listener no painel, atualização imediata e prioridade de velocidade GPS válida.

## Limites conhecidos
- A varredura 0x7E0–0x7E7 não é uma varredura integral de todas as redes VAG. Não cobre, por si só, endereçamento estendido 29-bit, redes secundárias, topologia de Gateway ou identificação por ODX/ASAM.
- DID F190 não é suportado por todo módulo. NRC ou silêncio não significa módulo ausente.
- A lista 2A26 ainda depende de confirmar endereço/roteamento específico do Gateway do veículo. Nenhum endereço alternativo foi inventado.
- Não foram adicionados comandos de escrita, coding, adaptation, Security Access, clear DTC ou atuação.

## Validação
- Executar a suíte Python `python -m unittest discover -s tests -p 'test_*.py' -v`.
- A suíte estática não substitui `assembleDebug`, instalação Android ou teste real com o Virtus estacionado.
