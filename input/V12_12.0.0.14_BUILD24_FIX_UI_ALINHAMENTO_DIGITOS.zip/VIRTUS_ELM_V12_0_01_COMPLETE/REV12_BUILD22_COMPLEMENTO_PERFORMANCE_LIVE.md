# V12 12.0.0.12 — Complemento BUILD22

## Alterações complementares
- Adicionado gráfico combinado diretamente à tela Performance, para acompanhar velocidade GPS, pedal, BOOST calculado por MAP−BARO e RPM durante a puxada.
- As amostras são publicadas na interface em intervalos de duas iterações, somente após o início medido da puxada. Valores indisponíveis permanecem como lacunas; não são convertidos em zero.
- O gráfico mantém até 180 amostras recentes na tela Performance.
- O indicador inferior dos instrumentos deixa de permanecer com o texto genérico “AGUARDANDO” e passa a informar “SEM DADO” quando não há uma leitura válida. A leitura numérica continua como traço, sem inventar pressão.
- Mantidas as métricas de 0–60, 0–100, duração, velocidade máxima, RPM máximo, BOOST máximo, qualidade, histórico e comparação das melhores puxadas já existentes.

## Validação executada
- `python -m unittest discover -s tests -p 'test_*.py' -v`: 39 testes aprovados.
- O teste comportamental do estimador de trocas: 4/4 casos aprovados.
- ZIP será validado após empacotamento.

## Limitações conhecidas
- Não foi executada compilação Android/Gradle neste ambiente; a compilação precisa ser confirmada pelo GitHub Actions.
- O gráfico ao vivo depende de telemetria real disponível. Sem resposta válida de MAP/BARO, BOOST aparece sem dado; o aplicativo não fabrica uma curva.
- A leitura e a comparação de desempenho devem ser realizadas em ambiente seguro e pista apropriada, nunca com o condutor operando o aplicativo durante a condução.
