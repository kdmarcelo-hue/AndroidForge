# BUILD 24 — Matriz de evidência e validação

| Área | Implementação no código | Evidência ainda necessária |
|---|---|---|
| Descoberta CAN 11-bit | Sondagem de endpoints candidatos e correlação por RX ID + resposta UDS | Respostas reais do Virtus com cabeçalhos CAN visíveis |
| Descoberta CAN 29-bit | Sondagem das famílias candidatas documentadas no código | Confirmar suporte do ELM e topologia real do veículo |
| Identidade ECU | Consulta UDS ReadDataByIdentifier F190 | Resposta 62 F1 90 válida por endpoint |
| DTC UDS | Consulta 19 02 2D; RAW preservado | Reassembly ISO-TP e interpretação de cada ECU no carro |
| Gateway | Candidato 710/77A, DID 2A26 condicional | Confirmar resposta positiva e formato de bitmap no veículo |
| CUSTOM | Catálogo, backup observado, revisão, histórico e scan | Validar navegação e ações na tela após instalação |
| Performance | Métricas e gráfico combinado fora da tela Performance | Validar telemetria ao vivo e consistência com histórico |
| Boost máximo | Cálculo MAP−BARO e pico durante a puxada | Comparar com logs reais de MAP/BARO e puxada completa |

## Critério de verdade
1. `RESPONDEU`: CAN ID RX exato + resposta UDS correlacionada ao pedido.
2. `IDENTIFICADO`: identidade lida e validada; não basta endereço.
3. `DTC LIDO`: resposta positiva UDS `59 02` completa e associada ao mesmo endpoint.
4. `SEM FALHAS`: somente quando resposta positiva válida indica lista vazia, nunca por timeout, NRC ou silêncio.
5. `LISTADO NO GATEWAY`: configuração lógica reportada pelo DID, não presença física.
