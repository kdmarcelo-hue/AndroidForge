# BUILD24 — correções de alinhamento e tipografia

Identificação preservada: V12 12.0.0.14 / versionCode 24.

## Histórico de sessões
- Desativado o alinhamento automático por linha de base nas duas fileiras de ações do histórico, evitando deslocamento vertical entre botões com rótulos de comprimentos diferentes.
- Botões de ação agora usam uma única linha, centralização vertical, altura mínima uniforme, padding simétrico e redução automática de fonte em Android 8+.
- Rótulo superior simplificado para “PASTA DE LOGS”, mantendo a ação de seleção da pasta.
- Rótulo “PERFORMANCE” permanece em uma linha com fonte ajustável.

## Tela Performance
- Corrigido o índice inicial do span numérico em `setPerfText`: o texto contém apenas uma quebra de linha entre título e valor; o offset anterior somava duas posições e deixava o primeiro caractere fora da formatação numérica.
- Agora todos os algarismos do valor recebem o mesmo tamanho e fonte monoespaçada; a unidade permanece com estilo menor.

## Validação
- Alterações de código verificadas por inspeção dos trechos modificados.
- ZIP validado estruturalmente após geração.
- Não foi executado build Android nem teste físico nesta entrega.
