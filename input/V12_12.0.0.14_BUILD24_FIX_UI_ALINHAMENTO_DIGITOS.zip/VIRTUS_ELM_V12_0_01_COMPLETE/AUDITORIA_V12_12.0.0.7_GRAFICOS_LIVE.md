# V12 12.0.0.7 — correção da telemetria ao vivo durante a puxada

## Sintoma relatado
Na versão 12.0.0.6, durante uma puxada real, os indicadores/barras e o gráfico combinado não acompanhavam os valores; a linha amarela de BOOST permanecia sem variação.

## Causa técnica identificada no código-fonte 12.0.0.6
`startPerformanceTest()` executa um loop de aquisição OBD no executor único de I/O (`io`) e consulta RPM, velocidade OBD, MAP e BARO em ciclos curtos. Enquanto esse loop ocupa o executor, o `startDashboardPolling()` continua enfileirando `dashboardSnapshot()`, mas essas leituras não conseguem ser processadas em paralelo. A atualização dos gauges e do gráfico combinado dependia de `updateDashboard()`/`updateGraph()`, que normalmente eram chamados pelo ciclo de dashboard. Assim, durante o ensaio, a aquisição avançava, mas a camada visual não recebia amostras novas em tempo real.

Além disso, o loop do ensaio guardava amostras em `activePerfGraphSamples`, porém não publicava o estado OBD compartilhado (`lastRpm`, `lastMap`, `lastBaro`, `lastBoost`) para a atualização dos gauges e do gráfico combinado. A linha amarela podia, portanto, continuar mostrando apenas a linha-base mesmo com leituras locais MAP/BARO no loop.

## Evidência adicional da versão 12.0.0.6 (capturas posteriores)
- Tela Performance mostrou RPM e velocidade como LIVE, mas pressão turbo como AGUARDANDO; portanto, MAP/BARO ainda precisam ser confirmados como leituras válidas no veículo. Não se deve fabricar BOOST quando esses PIDs não respondem.
- A tela do gráfico combinado abriu com a série amarela na linha-base e sem recuperar a puxada recém-concluída, embora o histórico de sessões apresentasse registros. Foi identificado que `showGraphScreen()` limpava os buffers e não chamava `loadLastPerformanceGraph()` após uma puxada finalizada.

## Correções aplicadas
- A cada cinco amostras do ensaio (cadência aproximada de 350 ms, sujeita à latência real do ELM), publica os valores OBD atuais no estado compartilhado.
- Chama `updateDashboard()` pela thread de UI nessa cadência, alimentando gauges, barras, telemetria e `updateGraph()` sem depender de uma nova tarefa no executor de I/O ocupado.
- Mantém o cálculo de BOOST estritamente baseado em `(MAP - BARO) / 100`; nenhum valor é estimado ou inventado para substituir MAP/BARO ausente.
- Quando MAP ou BARO não responde, invalida `lastBoost` em vez de deixar um valor antigo na tela; o gráfico usa a linha-base 0,0 já implementada, enquanto os indicadores mostram indisponibilidade.
- Ao iniciar uma nova puxada, sai do modo histórico e limpa o buffer visual combinado para iniciar uma série ao vivo nova.
- Ao abrir o gráfico depois de uma puxada concluída, recupera as amostras da sessão em memória/CSV em vez de apagar os dados e exibir apenas a linha-base. Durante uma puxada ativa, mantém o modo ao vivo; sem sessão registrada, permanece aguardando amostras reais.
- Preserva o requisito de GPS como fonte principal de velocidade no ensaio Performance; não muda o critério de início/medição da puxada.

## Versão
- `versionName`: `12.0.0.7`
- `versionCode`: `17`
- `applicationId`: `v12.marcelo.virtuselm.v12_0_0_7` (instalação paralela)

## Testes executados
- Verificação estática da nova transição de tela: puxada ativa permanece ao vivo; puxada concluída carrega histórico; ausência de amostras não gera pontos artificiais.
- Teste estático específico da publicação das amostras e atualização visual a cada cinco amostras.
- Testes existentes de replay de logs OBD/UDS e testes de estimador preservados.

## Limitações
- A tela de Performance que mostrou BOOST como AGUARDANDO indica que MAP e/ou BARO não foram considerados válidos naquela captura. O cálculo continua sendo `(MAP - BARO) / 100`; é necessário analisar os registros TX/RX dos PIDs `010B` e `0133` no log da próxima sessão para determinar se o problema é suporte do PID, ausência de resposta, timeout ou resposta malformada. A linha de BOOST não será artificialmente elevada.
- Esta auditoria é de código e testes estáticos/replay. Não foi possível executar build Android neste ambiente porque não há Android SDK/Gradle wrapper configurado.
- Não foi executado teste físico com ELM327/veículo após a alteração. A validação final depende do GitHub Actions e de teste controlado no veículo, com o condutor sem operar o tablet.
- BOOST só sobe acima de zero quando MAP medido supera BARO medido. Uma puxada sem carga suficiente ou sem resposta válida desses PIDs não comprova pressão positiva.
