# Auditoria de implementação incremental — V12 12.0.0.11 / BUILD21

## Base
- Fonte: `V12_12.0.0.11_CODE21_AJUSTES_UI_TESTE.zip`
- SHA-256 de entrada: `3b4297c4f5e8f0742b44201bb7e61090203afb25332a99da006ea7213072a2df`
- `versionName`: 12.0.0.11; `versionCode`: 21
- `applicationId`: `v12.marcelo.virtuselm.v12_0_11` (preservado)

## Alterações
1. Criada `VagGatewayDiscovery.java`: valida resposta UDS `62 2A 26` e bitmap com exatamente 32 bytes.
2. Decodificação LSB-first dos endereços lógicos 0–255.
3. Nó listado pelo Gateway é separado de presença atual da ECU (`NOT_TESTED`).
4. Nova opção opt-in no diagnóstico unificado: `Gateway • Installation List DID 2A26 (experimental)`.
5. Requisição experimental somente leitura usando CAN 11-bit candidato TX `710` / RX `77A`, com tentativa de restauração do header/protocolo em `finally`.
6. RAW preservado; ausência, NRC, bitmap inválido e ISO-TP incompleto não significam módulo inexistente.
7. Parser ISO-TP de payload sem CAN ID aceita resposta UDS positiva `62` (além de `59` e `7F`).
8. Workflow Android atualizado para BUILD21: debug não depende de segredos; release assinado é executado apenas quando os quatro segredos de assinatura existem.
9. Teste de regressão de versão atualizado para os metadados reais 12.0.0.11 / BUILD21.

## Validação
- Foram executados testes Python de bitmap, replay, ISO-TP e telemetria.
- Compilação Android: não executada; não há evidência de build nesta estação.
- Teste físico no Virtus 200 TSI 2024: não executado.
- Endereçamento 710/77A: candidato experimental, não validado neste veículo.
- Nenhuma escrita, coding, adaptation, Security Access ou limpeza de DTC foi adicionada.

## Limitações abertas
- O DID 2A26 lista nós lógicos configurados; não prova presença atual, identidade, variante de software/peça ou capacidade de escrita.
- Falta integrar ODX/MCD licenciado e compatível, identificação robusta por ECU, leitura avançada de DTC UDS individual, árvore granular de subtestes, inventário de canais de medição/adaptação e histórico unificado completo.
