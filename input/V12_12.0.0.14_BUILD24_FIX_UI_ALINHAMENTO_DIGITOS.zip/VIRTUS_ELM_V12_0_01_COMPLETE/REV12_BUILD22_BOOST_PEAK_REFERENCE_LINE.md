# V12 12.0.0.12 — referência de pico do boost no gráfico

- Adicionada linha horizontal âmbar escura e translúcida atravessando a área do gráfico.
- A legenda no canto superior direito exibe `PICO: X,XX bar`.
- O pico é atualizado em tempo real somente com amostras válidas de boost (MAP/BARO); valores ausentes não são convertidos em zero.
- O pico é reiniciado ao iniciar uma nova puxada, para representar a máxima daquela sessão.
- A curva de boost ao vivo mantém sua cor original e permanece visualmente distinta da linha de referência.

Validação estática automatizada incluída em `tests/test_boost_peak_reference_line.py`. A compilação Android e a renderização em dispositivo ainda dependem do GitHub Actions e teste no aparelho.
