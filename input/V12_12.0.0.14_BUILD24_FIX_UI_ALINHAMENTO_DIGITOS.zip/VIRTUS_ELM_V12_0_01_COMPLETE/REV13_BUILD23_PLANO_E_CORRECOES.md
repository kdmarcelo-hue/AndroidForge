# V12 12.0.0.13 — Build 23

## Implementado nesta consolidação
- Gráfico combinado removido da tela Performance; permanece na tela dedicada Gráficos.
- Linha horizontal âmbar translúcida e legenda numérica do pico mantidas no gráfico dedicado.
- Placeholder `PICO: —` removido: sem pico válido, não há linha nem texto de pico.
- Janela de cálculo do pico alinhada ao início efetivo da puxada (t0), evitando incluir leituras anteriores à partida.
- Máximo do gauge e máximo final da puxada passam a usar o mesmo máximo válido da sessão de teste.
- Pico reiniciado ao iniciar nova puxada e ao iniciar nova instância do app (estado em memória, sem persistência entre execuções).
- Mantidos recursos existentes de backup observado, catálogo CUSTOM, histórico e varredura somente leitura.
- Versão incrementada para 12.0.0.13 / versionCode 23 / applicationId v12.marcelo.virtuselm.v12_0_13 para instalação paralela.

## Limites conhecidos / validação necessária
- A varredura de módulos continua limitada aos endereços físicos convencionais 7E0–7E7 e às consultas já implementadas; não equivale à descoberta completa VAG/VCDS via topologia de Gateway.
- Backup continua sendo snapshot do estado observado e não backup integral de coding/adaptation das ECUs; reversão de escrita permanece bloqueada sem serviço e valores originais validados.
- O catálogo CUSTOM não habilita gravações genéricas. Revisões são registradas sem enviar escrita à ECU.
- Os valores de potência e torque continuam estimativas por dinâmica longitudinal, não medição de dinamômetro.
- É necessária compilação Android via GitHub Actions e validação no veículo, parado/ambiente seguro. Testes Python estáticos não substituem compilação nem teste físico.
