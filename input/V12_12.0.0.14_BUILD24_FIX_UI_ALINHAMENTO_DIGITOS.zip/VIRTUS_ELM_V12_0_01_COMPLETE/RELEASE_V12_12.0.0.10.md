# V12 12.0.0.10 — pacote de testes paralelo

## Identidade Android
- versionName: `12.0.0.10`
- versionCode: `20`
- applicationId: `v12.marcelo.virtuselm.v12_0_0_10`

O `applicationId` é exclusivo desta versão. O Android deve permitir instalar esta build ao lado da 12.0.0.9 e manter os dois aplicativos separados. Dados privados, preferências e históricos internos não são compartilhados automaticamente entre os pacotes.

## Correções incluídas nesta revisão
- Corrigido o deslocamento do início do texto numérico em `setPerfText()`, para aplicar a mesma formatação a todos os algarismos (ex.: `24`).
- O histórico do gráfico continua priorizando amostras temporais reais do CSV.
- Quando o arquivo da melhor puxada contém apenas o resumo consolidado, o gráfico passa a reconstruir uma curva estimada com duração, velocidade máxima, BOOST máximo, RPM máximo, pedal/acelerador e quantidade de trocas disponíveis. A origem é identificada como `CURVA ESTIMADA A PARTIR DO RESUMO`; os pontos intermediários não são apresentados como telemetria medida.
- Atualizados nome do projeto e nome do artefato de release.

## Limites de validação
- Este pacote foi alterado no código-fonte; não foi compilado neste ambiente por ausência do Gradle Wrapper/Android SDK.
- A instalação paralela depende de o APK ser gerado com sucesso no GitHub Actions e de assinatura compatível com a política de instalação do Android.
- A curva estimada não substitui amostras reais e não permite afirmar o instante exato das trocas de marcha.
- A aquisição ao vivo de MAP/BARO/BOOST ainda precisa ser validada no veículo e com o adaptador ELM327.
- Este pacote não declara concluídos os demais itens amplos de diagnóstico VAG/UDS, biblioteca DTC e codificação avançada discutidos no planejamento.
