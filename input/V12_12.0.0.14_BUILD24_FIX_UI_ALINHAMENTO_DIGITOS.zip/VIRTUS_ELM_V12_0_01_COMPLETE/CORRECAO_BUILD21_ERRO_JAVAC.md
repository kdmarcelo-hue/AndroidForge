# Correção do BUILD21 — erro de compilação Java

## Erro observado no GitHub Actions

`MainActivity.java:2999: error: unclosed character literal`

A chamada usava `String.replace('\\n', ' ')`, tentando representar dois caracteres dentro de um literal `char`. Em Java, um `char` representa um único caractere; essa expressão não compila.

## Correção aplicada

A chamada foi alterada para `String.replace("\\n", " ")`, usando strings para substituir a sequência literal barra invertida + `n` que o relatório monta.

## Escopo

Esta correção remove o erro de sintaxe identificado no log. Ela não comprova, por si só, compilação Android completa nem validação no veículo. O workflow deve ser executado novamente para confirmar.
