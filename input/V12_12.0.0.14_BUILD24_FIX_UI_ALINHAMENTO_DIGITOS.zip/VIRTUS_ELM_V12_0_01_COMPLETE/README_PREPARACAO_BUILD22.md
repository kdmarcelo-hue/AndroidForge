# V12 — preparação técnica BUILD22

- versionName: 12.0.0.12
- versionCode: 22
- applicationId: v12.marcelo.virtuselm.v12_0_12 (instalação paralela)
- Base funcional: pacote BUILD21 com correção GPS já integrada.
- Alterações: descoberta real de endpoints UDS, distinção de NRC 0x78/negativas/silêncio, bloqueio de VAG Scan em simulação e correção de recorte dos botões Performance.
- Segurança: somente leitura; sem coding, adaptation, Security Access, limpeza DTC ou atuação.
- Validação atual: suíte Python automatizada; compilação Android ainda depende do GitHub Actions.
