# V12 12.0.0.8 — revisão consolidada / Build Code 18

## Identidade preservada
- applicationId: `v12.marcelo.virtuselm.v12_0_0_8`
- versionName: `12.0.0.8`
- versionCode: `18`
- Não criar 12.0.0.9 e não alterar a identidade de instalação.

## Correções implementadas nesta revisão do pacote
1. **Gráfico histórico:** a tela deixa de preferir cegamente a última amostra mantida em memória. Ao abrir o histórico fora de uma puxada ativa, consulta o ranking já existente de melhores puxadas e tenta reconstruir as séries a partir do CSV da melhor puxada. Mantém fallback para CSVs antigos de puxada/performance.
2. **Eixo temporal:** normaliza o tempo da série pelo primeiro timestamp da amostra e usa a extensão temporal real para posicionar os pontos, evitando colapsar todas as amostras no primeiro pixel quando o tempo inicial não é zero.
3. **Log técnico:** remove seleção de texto do painel para não competir com o gesto de rolagem. A rolagem interna permanece sem barra visível; a atualização automática só acompanha novas mensagens quando o usuário já estava no fim do log, preservando a posição quando ele navega para cima.
4. **Números dos cartões de Performance:** aplica fonte monoespaçada somente ao campo numérico, mantendo tamanho uniforme e alinhamento previsível entre valores com diferentes quantidades de dígitos.
5. **CSV / MediaStore:** leitura persistente prioriza a coleção Downloads com filtro pelo nome e caminho relativo exatos; mantém fallback para URI SAF e armazenamento legado. Falhas de abertura/publicação são registradas e arquivos pendentes criados durante falha de inicialização são removidos quando possível.
6. **Aquisição OBD na puxada:** RPM, MAP e BARO continuam sendo consultados em cada ciclo; velocidade CAN e pedal passam a ser consultados a cada quatro ciclos. O timeout individual foi reduzido de 220 ms para 160 ms, sem consultas concorrentes no canal serial. Quando MAP/BARO falham, o log técnico passa a registrar as respostas brutas dos PIDs `010B` e `0133` a cada dez ciclos para permitir diagnóstico sem inundar o log.

## Itens preservados
- Fórmula do BOOST: `(MAP - BARO) / 100`, sem fabricar pressão quando MAP/BARO não são válidos.
- Aquisição de performance, GPS como fonte primária de velocidade do teste, estimadores, DTC, VAG, CUSTOM e demais módulos existentes.
- Os arquivos e recursos originais do pacote foram mantidos; somente `MainActivity.java` e este relatório foram alterados.

## Validação e limitações
- Verificações estáticas de identidade, presença das alterações, integridade do ZIP e balanceamento estrutural do fonte foram executadas.
- **Build Android não executado localmente:** o pacote não contém `gradlew` e o ambiente não tem Gradle/Android SDK configurados. O workflow `.github/workflows/android-build.yml` usa Gradle 8.7 e exige os quatro secrets de assinatura.
- **Não há validação física OBD/ELM neste ambiente.** O indicador BOOST continuará dependendo de respostas válidas e recentes dos PIDs MAP `010B` e BARO `0133`. Se a ECU/ELM não responder a um deles, mostrar indisponibilidade é o comportamento correto, não LIVE artificial.
- A atualização ao vivo durante puxadas mantém publicação de estado a cada cinco amostras. O loop foi otimizado para reduzir latência e priorizar RPM/MAP/BARO. A taxa real continua limitada pela latência de consulta/resposta do ELM327 e da ECU; não foi alterado o protocolo para enviar comandos concorrentes pelo mesmo canal serial.
- A rolagem do painel foi corrigida para preservar a posição do usuário. O gesto precisa ser validado no aparelho Android após a instalação.
