# Auditoria — V12 12.0.0.11 / gráfico e arquivos pendentes

## Alterações nesta revisão
- Tela de gráficos agora oferece seleção explícita entre **TEMPO REAL** e **HISTÓRICO**.
- O modo tempo real limpa a série anterior, mantém os buffers próprios da visualização e informa quando não há conexão/telemetria; não fabrica pontos offline.
- O modo histórico continua carregando a puxada persistida e preserva a identificação de curvas estimadas.
- Removida a legenda explicativa inferior que ocupava espaço vertical no gráfico.
- Histórico de sessões: ações Atualizar, Pendentes e Performance dispostas em uma única linha, com pesos iguais.
- Consulta de pendentes ampliada: além de `IS_PENDING=1`, inclui arquivos cujo nome começa com `.pending`, mesmo quando o índice MediaStore não os marca como pendentes.
- Se a consulta não localizar candidatos, o app oferece abrir o seletor da pasta para inspeção manual.

## Verificações estáticas
- `versionName`: 12.0.0.11.
- `versionCode`: 21.
- `applicationId`: v12.marcelo.virtuselm.v12_0_11.
- Confirmada presença dos novos controles e dos filtros por nome `.pending` e `IS_PENDING` no código-fonte.
- Confirmada remoção do texto de legenda antiga do gráfico.

## Limitações de validação
- Não foi executado build Android/Gradle nesta revisão; a compilação deve ser confirmada no GitHub Actions.
- A exclusão via MediaStore depende das permissões e da visibilidade dos itens no Android. Quando o MediaStore não retornar os arquivos, o aplicativo oferece abrir o seletor de pasta; a seleção/exclusão manual por SAF ainda depende da concessão de acesso e não foi validada em dispositivo nesta revisão.
- O gráfico em tempo real depende de telemetria real ou modo de simulação explicitamente ativado. Offline e sem simulação, o estado correto é aguardando dados.
