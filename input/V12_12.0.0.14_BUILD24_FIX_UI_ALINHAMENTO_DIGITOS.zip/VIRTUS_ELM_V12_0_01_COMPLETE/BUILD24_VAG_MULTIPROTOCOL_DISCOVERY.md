# V12 12.0.0.14 — BUILD 24

## Entrega desta revisão

- Substituída a varredura restrita 7E0–7E7 por descoberta multiprotocolo somente leitura.
- CAN 11-bit VAG: varredura física dos endereços de requisição 0x700–0x774, com resposta candidata request + 0x6A.
- CAN 11-bit OBD: varredura 0x7E0–0x7E7, com resposta candidata request + 8.
- CAN 29-bit VAG: família 0x17FC00xx → 0x17FE00xx.
- CAN 29-bit OBD: família 0x18DAxxF1 → 0x18DAF1xx.
- Em cada endpoint com resposta ao TesterPresent físico (3E 00), consulta separada de identidade UDS (22 F1 90) e DTC/status (19 02 2D).
- Consulta do Gateway Installation List DID 2A26 somente se o endpoint candidato 710 → 77A responder ao TesterPresent.
- RAW de identidade e DTC preservado no resultado; endpoint, identidade e leitura de DTC têm estados distintos.
- Silêncio, NRC, timeout e ISO-TP incompleto não são tratados como ausência de módulo nem como ausência de falhas.
- Nenhuma escrita, coding, adaptação, Security Access ou limpeza é executada pela nova varredura.
- Versão 12.0.0.14, versionCode 24, applicationId independente para instalação paralela.

## Limites técnicos

1. Os quatro esquemas são famílias públicas de endereçamento usadas como candidatos de varredura; não são uma tabela comprovada de endereços físicos do Virtus específico.
2. A resposta ao TesterPresent comprova resposta do endpoint no momento da varredura. O nome do módulo só deve ser atribuído depois de identidade/metadata compatível.
3. O DID 2A26 e seu formato de bitmap são experimentais no projeto. Se a ECU/Gateway responder com NRC, formato diferente ou silêncio, o resultado permanece inconclusivo.
4. A varredura multiprotocolo pode levar alguns minutos em ELM327 Bluetooth, especialmente em adaptadores clones. Interromper a operação não deve ser interpretado como varredura completa.
5. Esta entrega não foi testada fisicamente no Virtus e não houve compilação Android local: o pacote recebido não contém Gradle Wrapper e este ambiente não possui Android SDK/Gradle instalados. A compilação final precisa ser confirmada pelo GitHub Actions; a confirmação física dos módulos depende do carro conectado.
6. Os identificadores 11-bit e 29-bit foram derivados de implementações e documentação técnica pública; a implementação no ELM327 pode variar por firmware/clone. O log RAW deve ser usado para auditar respostas reais.

## Referências técnicas utilizadas

- dtcsweep (MIT), varredura read-only de famílias VAG 11-bit e 29-bit, TesterPresent, identidade UDS e DTC: https://github.com/NinjaStyle82/dtcsweep
- Ross-Tech, módulos e Gateway Installation List: https://register.ross-tech.com/vcds/tour/scm_screen.php e https://www.ross-tech.com/vcds/tour/installation-list.php
- CDA, CAN/ISO-TP, endereçamento físico e tratamento de NRC pendente: https://eclipse-opensovd.github.io/classic-diagnostic-adapter/03_architecture/03_communication/02_can_communication.html
