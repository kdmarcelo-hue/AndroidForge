# V12 12.0.0.11 — preparação de correções

Base: `V12_12.0.0.10_CODE20_INSTALACAO_PARALELA_TESTES.zip`.

## Identidade
- versionName: 12.0.0.11
- versionCode: 21
- applicationId: v12.marcelo.virtuselm.v12_0_11
- Pacote distinto da 12.0.0.10 para instalação paralela.

## Alterações aplicadas nesta preparação
- Carregamento dos indicadores de performance a partir do melhor resumo persistido ao abrir Performance, sem exigir conexão Bluetooth.
- Recuperação das amostras históricas em memória quando válidas e ordenadas; rejeição de timestamps repetidos/não crescentes na leitura dos CSVs antes do fallback estimado.
- Rolagem vertical interna e barras de rolagem para os painéis de log e resultado.
- Correção da quebra de linha do log, que era anexada como texto literal `\\n`.
- Correção do início do trecho numérico no `SpannableString` dos indicadores.
- Inclusão de gerenciador de arquivos MediaStore pendentes na pasta Download/VirtusELM/logs, com seleção múltipla, confirmação e exclusão em lote.

## Validação pendente
Este ambiente não contém Gradle Wrapper (`gradlew`/`gradle-wrapper.jar`) nem Android SDK configurado. Portanto, esta preparação não foi compilada aqui e não há alegação de APK validado. A compilação e os testes de instalação devem ser executados pela GitHub Actions antes de instalar no veículo.

A auditoria integral das frentes de diagnóstico VAG/UDS, biblioteca DTC, MAP/BARO/boost, persistência e regressão funcional ainda precisa ser concluída sobre o código e logs do veículo. Não considerar esses itens como implementados apenas por constarem na especificação geral da 12.0.0.11.
