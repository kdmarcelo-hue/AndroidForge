# V12 12.0.0.6 — Correção do gráfico BOOST

## Causa identificada no código 12.0.0.5
- `calculateBoost()` retorna -1 quando MAP ou BARO não estão disponíveis.
- `CombinedGraphView.addOne()` descarta valores negativos.
- `drawSeries()` não desenha a série quando há menos de duas amostras.
- Consequência: a legenda BOOST aparece, mas a linha amarela pode desaparecer completamente.

## Correção
- A série BOOST passa a desenhar a linha-base amarela em 0,0 bar mesmo antes de existir amostra.
- Em atualizações ao vivo, valores ausentes/inválidos alimentam a linha-base 0,0 em vez de remover a série.
- O cálculo físico de pressão positiva permanece baseado em `(MAP - BARO) / 100`; não foi inventado valor de pressão.
- Texto da tela esclarece que a linha-base não comprova leitura válida de MAP/BARO.

## Limitação técnica que permanece para o teste no veículo
Acelerar com o carro parado e sem carga pode não produzir pressão positiva mensurável; o turbo pode permanecer próximo da pressão atmosférica. Para validar o aumento real de boost, é necessário comparar MAP e BARO sob carga em condições seguras, sem o condutor operar o aplicativo.

## Versão
- versionName: 12.0.0.6
- versionCode: 16
- applicationId: v12.marcelo.virtuselm.v12_0_0_6

## Validação
- Alterações aplicadas ao código-fonte e configuração Gradle.
- Build Android não executado neste ambiente; não declarar APK compilado.
