# V12 12.0.0.11 — correção e auditoria dos gráficos

## Alterações aplicadas

1. O gráfico combinado deixa de bloquear a aquisição quando `simulationMode` está ativo. Os pontos simulados são plotados e o status informa explicitamente que são dados simulados, não telemetria real.
2. O gráfico histórico não aceita mais uma única amostra como se fosse uma curva válida. Quando há somente uma amostra, tenta recuperar a melhor puxada e reconstruir uma curva estimada a partir do resumo persistido (`duration` e `speed`), identificando a curva como estimada.
3. A compatibilidade com CSVs antigos também exige pelo menos duas amostras válidas; um arquivo incompleto não impede a tentativa de reconstrução pelo resumo.
4. A linha horizontal artificial de BOOST em 0 bar foi removida. MAP/BARO ausentes ou inválidos agora deixam uma lacuna na série, em vez de inventar pressão zero.
5. Padronizado o tamanho da tipografia dos valores numéricos dos cartões de performance para 18sp.
6. Textos de orientação do gráfico atualizados para descrever o modo combinado e distinguir simulação/estimativa.

## Verificações estáticas executadas

- `versionName`: `12.0.0.11`.
- `versionCode`: `21`.
- `applicationId`: `v12.marcelo.virtuselm.v12_0_11` (preservado).
- Verificado no código: condição de gráfico ao vivo aceita `ecuResponding || simulationMode`.
- Verificado no código: fallback de curva estimada é acionado quando a série persistida tem menos de duas amostras.
- Verificado no código: não há mais desenho de linha-base artificial para BOOST sem amostras válidas.

## Limitação de validação

Não foi possível executar build Android neste ambiente: o projeto não contém `gradle-wrapper.jar` e não há instalação local de Gradle/Android SDK disponível. Portanto, este ZIP é código-fonte corrigido e auditado estaticamente; a compilação final precisa ser confirmada pelo workflow GitHub Actions. Não declarar APK validado até o workflow concluir com sucesso.
