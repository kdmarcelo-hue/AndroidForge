package com.marcelo.virtuselm;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Read-only helpers for UDS Gateway Installation List (DID 0x2A26).
 * A set bit means a logical node is listed by the Gateway; it does not prove
 * that the ECU currently responds or identify its hardware/software variant.
 */
public final class VagGatewayDiscovery {
    private VagGatewayDiscovery() {}

    public static final int DID_HIGH = 0x2A;
    public static final int DID_LOW = 0x26;
    public static final int BITMAP_BYTES = 32;

    public static final class Node {
        public final int logicalAddress;
        public final boolean listedByGateway;
        public final String currentPresence = "NOT_TESTED";
        Node(int address) { logicalAddress = address; listedByGateway = true; }
    }

    /** Accept only a complete positive response: 62 2A 26 + exactly 32 bytes. */
    public static List<Node> decodePositiveResponse(byte[] payload) {
        if (payload == null || payload.length != 3 + BITMAP_BYTES) return Collections.emptyList();
        if ((payload[0] & 0xFF) != 0x62 || (payload[1] & 0xFF) != DID_HIGH
                || (payload[2] & 0xFF) != DID_LOW) return Collections.emptyList();
        ArrayList<Node> nodes = new ArrayList<>();
        for (int i = 0; i < BITMAP_BYTES; i++) {
            int value = payload[3 + i] & 0xFF;
            for (int bit = 0; bit < 8; bit++) {
                if ((value & (1 << bit)) != 0) nodes.add(new Node(i * 8 + bit));
            }
        }
        return Collections.unmodifiableList(nodes);
    }

    public static String classifyNoResponse() {
        return "NOT_CONFIRMED: no usable response; module absence cannot be inferred";
    }

    /** Address conversion is deliberately not provided: mapping depends on bus/topology. */
}
