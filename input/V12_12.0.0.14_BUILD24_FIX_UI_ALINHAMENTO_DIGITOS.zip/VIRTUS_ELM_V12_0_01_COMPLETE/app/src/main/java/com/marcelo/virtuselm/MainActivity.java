package com.marcelo.virtuselm;

import android.Manifest;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.ContentUris;
import android.database.Cursor;
import android.content.pm.PackageManager;
import android.os.*;
import android.text.method.ScrollingMovementMethod;
import android.view.*;
import android.widget.*;
import android.text.TextUtils;
import android.content.Intent;
import android.os.Build;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.content.ClipData;
import android.content.ContentValues;
import android.net.Uri;
import android.provider.MediaStore;
import android.provider.DocumentsContract;
import android.os.Environment;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter bt; private BluetoothSocket socket; private InputStream in; private OutputStream out;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextView status, stats, log, result, canTable, canFilterHint, canDiag;
    private LinearLayout dataScreen, homeScreen, diagnosticScreen, canScreen, customScreen, configScreen, graphScreen, performanceScreen;
    private ScrollView logScroll, diagnosticScroll;
    private FrameLayout appContainer;
    private LinearLayout mainShell;
    private LinearLayout fixedHero, fixedNav;
    private ImageView fixedBrandLogo;
    private ImageView fixedCarImage;
    private TextView fixedBrandSubtitle;
    private TextView fixedBrandVersion;
    private boolean performanceImmersive=false;
    private TextView resultHome;
    private int currentScreen=0;
    // ===== V12 — BASE CONSOLIDADA =====
    // Menu ativo preservado; V12 mantém a navegação consolidada.
    private final ArrayList<LinearLayout> navItems=new ArrayList<>();
    private final ArrayList<ImageView> navIcons=new ArrayList<>();
    private final ArrayList<TextView> navLabels=new ArrayList<>();
    private static final int SIM_CYAN=Color.rgb(0,194,255);
    private final int NAV_ACTIVE=Color.rgb(35,185,255);
    private final int NAV_INACTIVE=Color.rgb(175,205,230);
    private TextView dashConn, dashVin, dashIgnition, dashRpm, dashFuel, dashVolt, dashMap, dashBaro, dashBoost, dashBoostMax, dashThrottle, dashCan, dashSpeed, dashLoad, dashCoolant, dashIntake, dashOilTemp, dashOilLevel, dataLiveTelemetry;
    private RpmSegmentBar rpmBar;
    private Button connectButton;
    private TextView healthChip;
    private int noDataCycles = 0;
    private boolean recoveringSession = false;
    private final ScheduledExecutorService dashboardExec = Executors.newSingleThreadScheduledExecutor();
    private volatile boolean dashboardPolling = false;
    private volatile boolean stopRequested = false;
    private volatile long stopDeadline = 0;
    private String lastVin = "—";
    private static final String PROFILE_VIN = "9BWDH6BZ3RP002201";
    private double lastRpm = 0, lastFuel = -1, lastVolt = -1, lastThrottle = -1, lastPedalD = -1, lastPedalE = -1, lastPedalF = -1, lastMap = -1, lastBaro = -1, lastBoost = -1, maxBoost = -1, lastSpeed = -1, lastGpsSpeed = -1, lastLoad = -1, lastCoolant = -1, lastIntake = -1, lastOilTemp = -1;
    private LocationManager locationManager;
    private volatile long gpsLastElapsedNs = 0L;
    private volatile float gpsAccuracyM = Float.MAX_VALUE;
    private volatile boolean gpsHasFix = false;
    private volatile boolean gpsTrackingActive = false;
    private LocationListener gpsListener;
    private static final int REQ_GPS_LOCATION = 30;
    private String lastOilLevel = "—";
    private boolean ecuResponding = false;
    private final StringBuilder technical = new StringBuilder();
    private final Object logLock = new Object();
    private volatile boolean monitoring = false;
    private volatile boolean operationRunning = false;
    private long rawCount=0, frameCount=0, rxBytes=0;
    private final LinkedHashSet<String> ids = new LinkedHashSet<>();
    private final LinkedHashMap<String,Long> idCounts = new LinkedHashMap<>();
    private final Object canDataLock = new Object();
    private final ArrayDeque<String> recentCanFrames = new ArrayDeque<>();
    private EditText canFilterInput;
    private long lastStatsUi=0, lastMonitorUi=0;
    private final List<Marker> markers = new ArrayList<>();
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);
    private String lastProtocol="";
    private volatile boolean intentionalDisconnect = false;
    private volatile boolean reconnecting = false;
    private volatile boolean connected = false;
    private volatile boolean connectAttempt = false;
    // ===== V12.0 FIX 01 — CONEXÃO AUTOMÁTICA COM SIMULAÇÃO DE PARTIDA =====
    private volatile boolean autoConnectActive = false;
    private int autoConnectAttempts = 0;
    // ===== V12 — MODO SIMULAÇÃO PRESERVADO =====
    private volatile boolean simulationMode = false;
    private long simulationStartMs = 0L;
    private final ArrayList<SimSample> simulationSamples = new ArrayList<>();
    private int simulationIndex = 0;
    private String simulationSource = "perfil interno de demonstração";
    private static class SimSample {
        double rpm,speed,map,baro,throttle,load,coolant,intake,fuel,volt,oil;
        SimSample(double r,double s,double m,double b,double t,double l,double c,double i,double f,double v,double o){rpm=r;speed=s;map=m;baro=b;throttle=t;load=l;coolant=c;intake=i;fuel=f;volt=v;oil=o;}
    }
    // Estado da gravação de telemetria — permanece independente da navegação V11.4.
    private volatile boolean recordingActive = false;
    private BufferedWriter recordingWriter = null;
    private File recordingFile = null;
    private long recordingStartMs = 0L;
    private int recordingSamples = 0;
    private int recordingTick = 0;
    private double recordingMaxBoost = -999.0;
    private static final String PREFS_UI = "virtus_elm_ui";
    private static final String PREF_KEEP_SCREEN = "keep_screen_on";
    private static final String PREF_HAPTIC = "haptic_feedback";
    private static final String PREF_PERF_ETHANOL = "performance_ethanol_pct"; // legado: não usado para sobrescrever o padrão
    private static final String PREF_DEFAULT_ETHANOL = "performance_default_ethanol_pct";
    private static final String PREF_PEDAL_SOURCE = "performance_pedal_source";
    private volatile int performanceEthanolOverride = -1;
    private static final String PREF_REALTIME_DATA = "realtime_data_enabled";
    private static final String PREF_TECH_LOG = "technical_log_enabled";
    private static final String PREF_PERF_HISTORY = "performance_history_enabled";
    private static final String PREF_PEDAL_CAL_MIN = "performance_pedal_cal_min";
    private static final String PREF_PEDAL_CAL_MAX = "performance_pedal_cal_max";
    private static final String PREF_AUTO_SIM = "simulation_auto_enabled";
    private static final String PREF_AUTO_CONNECT = "auto_connect_elm";
    private static final String PREF_PRESSURE_UNIT = "pressure_unit";
    private static final String PREF_SPEED_UNIT = "speed_unit";
    private BufferedWriter historyWriter = null;
    // V12 12.0.0.5 — registro técnico persistente por investigação.
    private final Object diagnosticFileLock = new Object();
    private BufferedWriter diagnosticSessionWriter = null;
    private File diagnosticSessionFile = null;
    private byte[] pendingDiagnosticExport = null;
    private static final int REQUEST_EXPORT_DIAGNOSTIC_ZIP = 9055;
    private Uri historyUri = null;
    private File historyLegacyFile = null;
    private long historySamples = 0L;
    private double lastPerfPower = -1, lastPerfTorque = -1, lastPerf0100 = -1, lastPerf0060 = -1, lastPerfQuality = -1, lastPerfPullDuration = -1;
    private int lastPerfGearShifts = 0;
    private String lastPerfSpeedGrid = "";
    private GraphView graphView;
    private CombinedGraphView combinedGraphView;
    private String graphMetric = "BOOST";
    private final ArrayDeque<Float> combinedRpmValues=new ArrayDeque<>();
    private final ArrayDeque<Float> combinedSpeedValues=new ArrayDeque<>();
    private final ArrayDeque<Float> combinedThrottleValues=new ArrayDeque<>();
    private final ArrayDeque<Float> combinedPedalValues=new ArrayDeque<>();
    private final ArrayDeque<Float> combinedBoostValues=new ArrayDeque<>();
    private final ArrayDeque<Float> combinedTimeValues=new ArrayDeque<>();
    private volatile boolean historicalGraphMode=false;
    private volatile double performanceGraphBoostPeak=-1;
    private TextView graphHistoryStatus, graphHeaderTitle;
    private static class PerfGraphSample { final double t,rpm,speed,pedal,boost; PerfGraphSample(double t,double rpm,double speed,double pedal,double boost){this.t=t;this.rpm=rpm;this.speed=speed;this.pedal=pedal;this.boost=boost;} }

    /** Estimates upshifts from the high-rate OBD RPM stream, then confirms recovery against speed. */
    private static class GearShiftEstimator {
        private double prevRpm=-1, prevSpeed=-1, candidateRpm=-1, candidateSpeed=-1;
        private long prevNs=0, candidateNs=0, lastConfirmedNs=0;
        private int shifts=0;
        int update(double rpm, double speed, long nowNs) {
            if (rpm < 900 || speed < 0 || nowNs <= 0) { prevRpm=rpm; prevSpeed=speed; prevNs=nowNs; return shifts; }
            if (candidateNs > 0) {
                long age=nowNs-candidateNs;
                boolean speedConsistent = speed >= candidateSpeed-1.5 && speed >= prevSpeed-1.5;
                boolean rpmRecovered = rpm >= candidateRpm + Math.max(250.0, candidateRpm*0.06);
                if (age <= 2500000000L && rpmRecovered && speedConsistent && (lastConfirmedNs==0 || nowNs-lastConfirmedNs>=1200000000L)) {
                    shifts++; lastConfirmedNs=nowNs; candidateNs=0;
                } else if (age > 2500000000L || speed < candidateSpeed-3.0) {
                    candidateNs=0;
                }
            }
            if (candidateNs==0 && prevRpm>=3000 && rpm>=1000 && rpm <= prevRpm-500 && speed >= prevSpeed-1.5 && (lastConfirmedNs==0 || nowNs-lastConfirmedNs>=1200000000L)) {
                candidateRpm=rpm; candidateSpeed=speed; candidateNs=nowNs;
            }
            prevRpm=rpm; prevSpeed=speed; prevNs=nowNs;
            return shifts;
        }
    }
    private final ArrayList<PerfGraphSample> activePerfGraphSamples=new ArrayList<>();
    private final ArrayList<PerfGraphSample> lastPerfGraphSamples=new ArrayList<>();
    private TextView perfPower, perfTorque, perf0100, perf0060, perfFuel, perfBoost, perfStatus, perfConfidence, perfQuality;
    private TextView devPedalResult;
    private final ArrayList<Button> graphButtons=new ArrayList<>();
    private final ArrayList<Button> dataTabButtons=new ArrayList<>();
    private TextView dtcStatusView, dtcCodesView, dtcRawView;
    private LinearLayout dtcListContainer;
    private Button clearDtcButton, selectDtcButton;
    private boolean dataLogsTab = false;
    private LinearLayout dataTelemetryContent, dataLogsContent;
    private boolean dtcSelectionMode = false;
    private final LinkedHashSet<String> selectedDtcCodes = new LinkedHashSet<>();
    private final LinkedHashSet<String> lastDtcCodes = new LinkedHashSet<>();
    private final LinkedHashSet<String> simulatedDtcCodes = new LinkedHashSet<>(Arrays.asList("P0133"));
    // EPC/DTC evidence gate: real Mode 04 is blocked until an EPC evidence report is saved in this app session.
    private volatile boolean epcEvidenceSavedThisSession = false;
    private volatile String lastEpcEvidenceFile = "";
    private static final String DTC_LIBRARY_MANIFEST_URL = "https://raw.githubusercontent.com/kdmarcelo-hue/AndroidForge/main/library/library_info.json";
    private final LinkedHashMap<String,String> dtcLibraryDescriptions = new LinkedHashMap<>();
    private String dtcLibraryVersion = "1.0.0";
    private TextView dtcLibraryStatusView;
    private TextView dtcConfigStatusView;
    private LinearLayout dtcLibraryScreen;
    private LinearLayout dtcLibraryListContainer;
    private EditText dtcLibrarySearch;
    private final LinkedHashMap<String,JSONObject> dtcLibraryRecords = new LinkedHashMap<>();
    private TextView vagExplorerResult, diagnosticResult;
    private Button perfEthanolButton;
    private volatile boolean performanceRunning=false;
    private volatile boolean performanceStop=false;
    // ===== V12.0-FIX05 — HISTÓRICO / PERFORMANCE 2.0 =====
    private LinearLayout historyScreen;
    private static final int REQ_HISTORY_TREE = 741;
    private final LinkedHashMap<String,Uri> historyFileUris = new LinkedHashMap<>();
    private Uri historyTreeUri = null;
    private TextView perfMaxRpm, perfMaxSpeed, perfDuration, perfSessionCount;
    private PerformanceGaugeView perfRpmGauge, perfBoostGauge, perfSpeedGauge;
    private double lastPerfMaxRpm=-1, lastPerfMaxSpeed=-1, lastPerfMaxBoost=-1, lastPerfDuration=-1;
    private final ArrayList<String> historySessionNames=new ArrayList<>();

    /** Barra de RPM segmentada: 0–4k verde, 4–6k amarelo, 6–8k vermelho; segmentos inativos permanecem na mesma família de cor em baixa intensidade. */
    /** Gráfico LIVE com escala fixa por parâmetro, grade e unidade. */
    private class GraphView extends View {
        private final Paint line=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint grid=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final ArrayDeque<Float> values=new ArrayDeque<>();
        private float min=0,max=1;
        private String metric="BOOST", unit="bar";
        GraphView(Context c){
            super(c); setBackgroundColor(Color.rgb(2,20,38));
            line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(5f);
            grid.setStyle(Paint.Style.STROKE); grid.setStrokeWidth(1f);
            text.setColor(Color.rgb(165,195,220)); text.setTextSize(11f*c.getResources().getDisplayMetrics().scaledDensity);
            text.setTextAlign(Paint.Align.RIGHT);
            setWillNotDraw(false);
            configure("BOOST");
        }
        private void configure(String m){
            metric=m;
            if("RPM".equals(m)){min=0;max=8000;unit="rpm";}
            else if("BOOST".equals(m)){
                boolean kpa="kPa".equals(getPressureUnit());
                min=0; max=kpa?300:3; unit=kpa?"kPa":"bar";
            }
            else if("THROTTLE".equals(m)){min=0;max=100;unit="%";}
            else if("VELOCIDADE".equals(m)){boolean mph="mph".equals(getSpeedUnit());min=0;max=mph?174.0f:280;unit=mph?"mph":"km/h";}
            values.clear(); invalidate();
        }
        void setMetric(String m){configure(m);}
        void add(float v){if(Float.isNaN(v)||v<-999)return; values.add(v); while(values.size()>120)values.removeFirst(); invalidate();}
        String range(){return String.format(Locale.US,"0–%s %s",("RPM".equals(metric)?"8000": "BOOST".equals(metric)?(getPressureUnit().equals("kPa")?"300":"3,0"):"THROTTLE".equals(metric)?"100":(getSpeedUnit().equals("mph")?"174":"280")),unit);}
        String unit(){return unit;}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth(),h=getHeight();
            float left=dpLocal(48), top=dpLocal(10), right=w-dpLocal(8), bottom=h-dpLocal(12);
            float plotW=Math.max(1,right-left), plotH=Math.max(1,bottom-top);
            int divisions=5;
            grid.setColor(Color.rgb(25,70,105));
            for(int i=0;i<=divisions;i++){float y=top+plotH*i/divisions; c.drawLine(left,y,right,y,grid);}
            for(int i=0;i<=divisions;i++){float y=top+plotH*i/divisions; double val=max-(max-min)*i/(double)divisions; String lab=label(val); c.drawText(lab,left-dpLocal(5),y+dpLocal(4),text);}
            if(values.size()<2)return;
            line.setColor(Color.rgb(0,210,255));
            float dx=plotW/(values.size()-1f), prevY=0; int i=0;
            for(float v:values){float clamped=Math.max(min,Math.min(max,v)); float x=left+i*dx; float y=bottom-(clamped-min)/(max-min)*plotH; if(i>0)c.drawLine(left+(i-1)*dx,prevY,x,y,line); prevY=y; i++;}
        }
        private String label(double v){
            if("RPM".equals(metric)) return String.format(Locale.US,"%.0f",v);
            if("BOOST".equals(metric)) return String.format(Locale.US,"%.1f",v);
            return String.format(Locale.US,"%.0f",v);
        }
        private float dpLocal(float v){return v*getResources().getDisplayMetrics().density;}
    }

    /** Gráfico combinado com quatro eixos visuais independentes: velocidade/throttle à esquerda e boost/RPM à direita. */
    private class CombinedGraphView extends View {
        private final Paint grid=new Paint(Paint.ANTI_ALIAS_FLAG), line=new Paint(Paint.ANTI_ALIAS_FLAG), text=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int SPEED=Color.rgb(55,150,255), THROTTLE=Color.WHITE, BOOST=Color.rgb(255,190,0), RPM=Color.rgb(0,220,180);
        CombinedGraphView(Context c){ super(c); setBackgroundColor(Color.rgb(2,20,38)); grid.setStyle(Paint.Style.STROKE); grid.setStrokeWidth(1f); line.setStyle(Paint.Style.STROKE); text.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); setWillNotDraw(false); }
        private float dp(float v){return v*getResources().getDisplayMetrics().density;}
        private void axisLabel(Canvas c,String s,float x,float y,int color,Paint.Align align){ text.setTextSize(9f*getResources().getDisplayMetrics().scaledDensity); text.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); text.setTextAlign(align); text.setColor(color); c.drawText(s,x,y,text); }
        private void tick(Canvas c,String s,float x,float y,int color,Paint.Align align){ text.setTextSize(8f*getResources().getDisplayMetrics().scaledDensity); text.setTypeface(android.graphics.Typeface.DEFAULT); text.setTextAlign(align); text.setColor(color); c.drawText(s,x,y,text); }
        private void drawSeries(Canvas c,ArrayDeque<Float> vals,float min,float max,int color,float left,float top,float pw,float ph){
            if(vals.size()<2)return; line.setColor(color); line.setStrokeWidth(dp(2.2f));
            Float[] a=vals.toArray(new Float[0]); Float[] times=combinedTimeValues.toArray(new Float[0]); float dx=pw/Math.max(1,a.length-1); float minTime=times.length>0?times[0]:0f; float maxTime=times.length>0?times[times.length-1]:0f; float timeSpan=Math.max(0.001f,maxTime-minTime); float px=0,py=0; boolean have=false;
            for(int i=0;i<a.length;i++){
                float v=a[i]==null?Float.NaN:a[i]; if(Float.isNaN(v)||v<min){have=false;continue;}
                float n=Math.max(0,Math.min(1,(v-min)/(max-min))); float x=(historicalGraphMode&&times.length==a.length)?left+Math.max(0,Math.min(1,(times[i]-minTime)/timeSpan))*pw:left+i*dx; float y=top+ph-n*ph;
                if(have)c.drawLine(px,py,x,y,line); px=x; py=y; have=true;
            }
        }
        private String fmt(double v,int decimals){return decimals==0?String.format(Locale.US,"%.0f",v):String.format(Locale.US,"%.1f",v);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth(),h=getHeight();
            float left=dp(58), right=w-dp(58), top=dp(38), bottom=h-dp(28); float pw=Math.max(1,right-left), ph=Math.max(1,bottom-top);
            // Cabeçalhos dos quatro eixos — substituem a legenda antiga.
            axisLabel(c,"VELOCIDADE",dp(5),dp(13),SPEED,Paint.Align.LEFT); axisLabel(c,"PEDAL",dp(5),dp(25),THROTTLE,Paint.Align.LEFT);
            axisLabel(c,"BOOST",w-dp(5),dp(13),BOOST,Paint.Align.RIGHT); axisLabel(c,"RPM",w-dp(5),dp(25),RPM,Paint.Align.RIGHT);
            grid.setColor(Color.rgb(25,70,105));
            for(int i=0;i<=7;i++){float y=top+ph*i/7f;c.drawLine(left,y,right,y,grid);}
            for(int i=0;i<=7;i++){
                float y=top+ph*i/7f; double f=1-i/7.0;
                tick(c,fmt(280*f,0),dp(5),y+dp(3),SPEED,Paint.Align.LEFT);
                tick(c,fmt(100*f,0),dp(43),y+dp(3),THROTTLE,Paint.Align.RIGHT);
                tick(c,fmt(3*f,1),w-dp(43),y+dp(3),BOOST,Paint.Align.LEFT);
                tick(c,fmt(8000*f,0),w-dp(5),y+dp(3),RPM,Paint.Align.RIGHT);
            }
            drawSeries(c,combinedSpeedValues,0,280,SPEED,left,top,pw,ph);
            drawSeries(c,combinedPedalValues,0,100,THROTTLE,left,top,pw,ph);
            // BOOST só é desenhado quando há amostras válidas. Ausência de MAP/BARO
            // não pode ser convertida em uma linha artificial em 0 bar.
            drawSeries(c,combinedBoostValues,0,3,BOOST,left,top,pw,ph);
            // Referência horizontal do maior boost válido desta puxada: tom âmbar
            // escuro/translúcido, distinto da curva BOOST ao vivo.
            double peak=performanceGraphBoostPeak;
            if(peak>=0 && peak<=3){
                float peakY=top+ph-(float)(peak/3.0)*ph;
                Paint peakPaint=new Paint(Paint.ANTI_ALIAS_FLAG); peakPaint.setColor(Color.argb(145,170,112,0)); peakPaint.setStrokeWidth(dp(1.8f)); peakPaint.setStyle(Paint.Style.STROKE);
                c.drawLine(left,peakY,right,peakY,peakPaint);
                text.setTextSize(9f*getResources().getDisplayMetrics().scaledDensity); text.setTypeface(android.graphics.Typeface.DEFAULT_BOLD); text.setTextAlign(Paint.Align.RIGHT); text.setColor(Color.rgb(205,155,55));
                c.drawText(String.format(Locale.US,"PICO: %.2f bar",peak),right-dp(3),Math.max(top+dp(10),peakY-dp(4)),text);
            }
            drawSeries(c,combinedRpmValues,0,8000,RPM,left,top,pw,ph);
            text.setTextSize(8f*getResources().getDisplayMetrics().scaledDensity); text.setTypeface(android.graphics.Typeface.DEFAULT); text.setTextAlign(Paint.Align.CENTER); text.setColor(Color.rgb(130,165,195)); c.drawText("TEMPO (s)",w/2f,h-dp(7),text);
        }
        void add(float rpm,float speed,float pedal,float boost){
            addOne(combinedRpmValues,rpm,8000);
            addOne(combinedSpeedValues,speed<0?Float.NaN:speed,280);
            addOne(combinedPedalValues,pedal,100);
            // Sem MAP/BARO válido, manter lacuna (NaN); nunca fabricar 0 bar.
            addOne(combinedBoostValues,(Float.isNaN(boost)||Float.isInfinite(boost)||boost<0)?Float.NaN:boost,3);
            invalidate();
        }
        private void addOne(ArrayDeque<Float> q,float v,float max){
            if(Float.isNaN(v)||Float.isInfinite(v)||v<0) q.add(Float.NaN);
            else q.add(Math.min(max,v));
            while(q.size()>(historicalGraphMode?1200:180))q.removeFirst();
        }
        void clear(){combinedRpmValues.clear();combinedSpeedValues.clear();combinedThrottleValues.clear();combinedPedalValues.clear();combinedBoostValues.clear();combinedTimeValues.clear();invalidate();}
    }

    private static class RpmSegmentBar extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); private float rpm=0f;
        private final int green=Color.rgb(120,235,150), greenDim=Color.rgb(18,62,42);
        private final int yellow=Color.rgb(255,210,80), yellowDim=Color.rgb(70,58,20);
        private final int red=Color.rgb(255,82,92), redDim=Color.rgb(70,24,30);
        RpmSegmentBar(Context c){super(c); paint.setStyle(Paint.Style.FILL); setWillNotDraw(false);}
        void setRpm(double v){rpm=(float)Math.max(0,Math.min(8000,v)); invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth(),h=getHeight(); float gap=dpLocal(3); int n=32; float sw=(w-gap*(n-1))/n; float active=(rpm/8000f)*n;
            for(int i=0;i<n;i++){ float x=i*(sw+gap); float center=(i+0.5f)/n*8000f; boolean on=i<active; int color=center<4000? (on?green:greenDim) : center<6000? (on?yellow:yellowDim) : (on?red:redDim); paint.setColor(color); c.drawRoundRect(new RectF(x,1,x+sw,h-1),2,2,paint); }
        }
        private float dpLocal(float v){return v*getResources().getDisplayMetrics().density;}
    }

    /** Escala da barra de RPM: cada número fica centrado exatamente sobre uma das posições de referência da barra. */
    private static class RpmScaleView extends View {
        private final Paint text=new Paint(Paint.ANTI_ALIAS_FLAG);
        RpmScaleView(Context c){super(c); text.setColor(Color.rgb(165,195,220)); text.setTextSize(9f*c.getResources().getDisplayMetrics().scaledDensity); text.setTextAlign(Paint.Align.CENTER); text.setTypeface(android.graphics.Typeface.DEFAULT); setWillNotDraw(false);}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth(),h=getHeight(); float gap=3f*getResources().getDisplayMetrics().density; int n=32; float sw=(w-gap*(n-1))/n; float first=sw/2f; float last=(n-1)*(sw+gap)+sw/2f; Paint.FontMetrics fm=text.getFontMetrics(); float baseline=h/2f-(fm.ascent+fm.descent)/2f; for(int i=0;i<=8;i++){float x=first+(last-first)*(i/8f); c.drawText(String.valueOf(i),x,baseline,text);} }
    }

    static class Marker {
        String type; long raw, frames, bytes, when; Map<String,Long> idsAt;
        Marker(String t,long r,long f,long b,Map<String,Long> counts){
            type=t; raw=r; frames=f; bytes=b; when=System.currentTimeMillis(); idsAt=new LinkedHashMap<>(counts);
        }
    }

    /** Padrão visual único para todos os interruptores de Configurações. */
    private void styleConfigSwitch(android.widget.Switch sw) {
        if (sw == null) return;
        sw.setShowText(true);
        sw.setTextOn("ON");
        sw.setTextOff("OFF");
        sw.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 8f);
        int[][] states = new int[][] { new int[] { android.R.attr.state_checked }, new int[] {} };
        int[] thumbColors = new int[] { Color.rgb(35, 205, 120), Color.rgb(235, 65, 80) };
        int[] trackColors = new int[] { Color.rgb(25, 115, 75), Color.rgb(115, 35, 45) };
        android.content.res.ColorStateList thumb = new android.content.res.ColorStateList(states, thumbColors);
        android.content.res.ColorStateList track = new android.content.res.ColorStateList(states, trackColors);
        sw.setThumbTintList(thumb);
        sw.setTrackTintList(track);
        sw.setMinWidth(dp(66));
        sw.setPadding(dp(3), 0, dp(3), 0);
    }


    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        try {
            applyKeepScreenPreference();
            buildUi();
            initializeDtcLibrary();
            try { bt=BluetoothAdapter.getDefaultAdapter(); } catch(Exception e) { bt=null; }
            resetSession();
            startGpsTracking();
            append("[00] INÍCIO DE NOVA SESSÃO — V12.0");
            append("BASE COMPLETA V12 + simulação configurável + conexão automática + unidades configuráveis.");
            append("SOMENTE LEITURA: nenhum comando de atuação, coding, adaptation, security access ou CAN arbitrário é transmitido.");
            io.execute(()->{ try { seedBundledPerformanceHistory(); } catch(Throwable e) { recordStartupFailure("histórico", e); } });
            startDashboardPolling();
            // Comportamento original do V12: abrir sempre em simulação. Bluetooth
            // só é tentado quando o usuário toca em CONECTAR ELM.
            if(isAutoSimulationEnabled()) io.execute(()->startSimulationMode("inicialização — simulação automática ativada; Bluetooth sob solicitação do usuário"));
            else { setStatus("Simulação automática desativada — toque em Conectar para tentar o ELM"); ui(()->{ if(dashConn!=null){dashConn.setText("● SIMULAÇÃO AUTOMÁTICA OFF");dashConn.setTextColor(Color.rgb(145,181,210));} updateDashboard(); }); }
        } catch(Throwable e) {
            recordStartupFailure("onCreate", e);
            showStartupRecovery(e);
        }
    }

    private void recordStartupFailure(String stage, Throwable error) {
        try {
            File f = new File(getFilesDir(), "v12_startup_error.txt");
            try (FileOutputStream out = new FileOutputStream(f, true)) {
                String line = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())
                    + " | " + stage + " | " + error.getClass().getName() + " | " + String.valueOf(error.getMessage()) + "\n";
                out.write(line.getBytes(StandardCharsets.UTF_8));
                for (StackTraceElement el : error.getStackTrace()) out.write(("    at " + el.toString() + "\n").getBytes(StandardCharsets.UTF_8));
            }
        } catch(Throwable ignored) { }
    }

    private void showStartupRecovery(Throwable error) {
        try {
            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setGravity(Gravity.CENTER_VERTICAL);
            root.setPadding(dp(24), dp(24), dp(24), dp(24));
            root.setBackgroundColor(Color.rgb(1,10,22));
            TextView title = new TextView(this);
            title.setText("V12 • RECUPERAÇÃO DE INICIALIZAÇÃO");
            title.setTextColor(Color.rgb(0,194,255)); title.setTextSize(20); title.setGravity(Gravity.CENTER);
            root.addView(title, new LinearLayout.LayoutParams(-1,-2));
            TextView detail = new TextView(this);
            detail.setText("O aplicativo encontrou uma falha ao iniciar e registrou o diagnóstico localmente.\n\nEtapa: onCreate\nErro: " + error.getClass().getSimpleName() + "\n" + String.valueOf(error.getMessage()) + "\n\nSeus históricos e configurações não foram apagados.");
            detail.setTextColor(Color.WHITE); detail.setTextSize(15); detail.setPadding(0, dp(20), 0, dp(20));
            root.addView(detail, new LinearLayout.LayoutParams(-1,-2));
            Button retry = new Button(this); retry.setText("TENTAR ABRIR NOVAMENTE"); retry.setOnClickListener(v -> recreate());
            root.addView(retry, new LinearLayout.LayoutParams(-1,-2));
            setContentView(root);
        } catch(Throwable ignored) { }
    }

    private static final int BLUE = Color.rgb(13, 71, 161);
    private static final int BLUE_DARK = Color.rgb(7, 45, 99);
    private static final int BLUE_LIGHT = Color.rgb(232, 240, 254);
    private static final int BLUE_BORDER = Color.rgb(144, 180, 220);
    private static final int TEXT = Color.rgb(35, 45, 55);

    private int dp(float v){ return Math.round(v * getResources().getDisplayMetrics().density); }

    /** Feedback padrão para toda área realmente interativa. O toque háptico pode ser desativado em Configurações. */
    private void bindClick(View v, final Runnable action){
        v.setClickable(true);
        v.setFocusable(true);
        v.setHapticFeedbackEnabled(isHapticEnabled());
        v.setOnClickListener(view->{
            if(isHapticEnabled()) view.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            if(action!=null) action.run();
        });
    }

    private android.graphics.drawable.Drawable pressableBg(int normalColor,int pressedColor,int strokeColor,float radius){
        android.graphics.drawable.GradientDrawable normal=new android.graphics.drawable.GradientDrawable();
        normal.setColor(normalColor); normal.setCornerRadius(dp(radius)); normal.setStroke(dp(1),strokeColor);
        android.graphics.drawable.GradientDrawable pressed=new android.graphics.drawable.GradientDrawable();
        pressed.setColor(pressedColor); pressed.setCornerRadius(dp(radius)); pressed.setStroke(dp(2),Color.rgb(0,210,255));
        android.graphics.drawable.StateListDrawable states=new android.graphics.drawable.StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed},pressed);
        states.addState(new int[]{},normal);
        return states;
    }

    private TextView tv(String s,float size){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,size); t.setTextColor(TEXT);
        t.setIncludeFontPadding(true); t.setPadding(dp(8),dp(5),dp(8),dp(5)); return t;
    }
    private Button btn(String s){
        Button b=new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextSize(11); b.setTextColor(Color.rgb(235,248,255));
        b.setGravity(Gravity.CENTER); b.setSingleLine(true); b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(dp(50)); b.setMinimumHeight(dp(50)); b.setPadding(dp(5),dp(1),dp(5),dp(1)); b.setIncludeFontPadding(false); b.setHorizontallyScrolling(false);
        if(Build.VERSION.SDK_INT>=26){ b.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP); }
        android.graphics.drawable.GradientDrawable normal=new android.graphics.drawable.GradientDrawable();
        normal.setColor(Color.rgb(7,38,70)); normal.setCornerRadius(dp(24)); normal.setStroke(dp(1), Color.rgb(25,125,195));
        android.graphics.drawable.GradientDrawable pressed=new android.graphics.drawable.GradientDrawable();
        pressed.setColor(Color.rgb(10,70,115)); pressed.setCornerRadius(dp(24)); pressed.setStroke(dp(2), Color.rgb(0,200,255));
        android.graphics.drawable.StateListDrawable states=new android.graphics.drawable.StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, pressed); states.addState(new int[]{}, normal);
        b.setBackground(states); b.setStateListAnimator(null); b.setSoundEffectsEnabled(true);
        return b;
    }
    private void addFull(LinearLayout r, View v){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(dp(6),dp(3),dp(6),dp(3)); r.addView(v,lp);
    }
    private void addTight(LinearLayout r, View v){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(dp(4),dp(1),dp(4),dp(1)); r.addView(v,lp);
    }
    private LinearLayout row(){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(dp(4),0,dp(4),0); return r;
    }
    private void addHalf(LinearLayout r, Button b){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(3),0,dp(3),0);
        r.addView(b,lp);
    }
    private void addThird(LinearLayout r, Button b){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(2),0,dp(2),0);
        r.addView(b,lp);
    }
    private LinearLayout section(String title){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();
        bg.setColor(BLUE);
        bg.setCornerRadius(dp(18));
        box.setBackground(bg);
        box.setPadding(dp(14),dp(12),dp(14),dp(12));
        TextView t=tv(title,20);
        t.setTextColor(Color.WHITE);
        t.setTypeface(null,android.graphics.Typeface.BOLD);
        t.setGravity(Gravity.CENTER); t.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        box.addView(t,new LinearLayout.LayoutParams(-1,-2));
        return box;
    }
    private void refreshHeaderVersion(TextView target){
        if(target==null)return;
        String version=BuildConfig.VERSION_NAME==null?"12.0":BuildConfig.VERSION_NAME;
        // Versão curta e legível; sempre deriva do versionName/versionCode do build.
        version=version.replace("12.0-FIX10.", "FIX10.");
        version=version.replace("-PERFORMANCE-CLUSTER-CODE188", "");
        target.setText("V12 • "+version+" • BUILD "+BuildConfig.VERSION_CODE);
        target.setContentDescription("Versão instalada: "+BuildConfig.VERSION_NAME+", build "+BuildConfig.VERSION_CODE);
    }

    private void buildUi(){
        final int BG = Color.rgb(1,10,22), CARD = Color.rgb(3,25,49), CARD2 = Color.rgb(4,31,60);
        final int CYAN = Color.rgb(0,194,255), CYAN2 = Color.rgb(45,142,255), WHITE = Color.rgb(242,248,255), MUTED = Color.rgb(145,181,210);

        // Estrutura V11.4: cabeçalho fixo + área central de conteúdo + menu fixo.
        appContainer=new FrameLayout(this); appContainer.setBackgroundColor(BG);
        LinearLayout shell=new LinearLayout(this); shell.setOrientation(LinearLayout.VERTICAL); shell.setBackgroundColor(BG);

        // CABEÇALHO FIXO — identidade do aplicativo permanece na tela durante toda a navegação.
        LinearLayout hero=card(Color.rgb(2,20,43)); fixedHero=hero;
        GradientDrawable hb=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(4,38,82),Color.rgb(2,12,28)});
        hb.setCornerRadius(dp(20)); hb.setStroke(dp(1),CYAN2); hero.setBackground(hb); hero.setPadding(dp(10),dp(4),dp(10),dp(4));
        LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=icon(R.drawable.v11_logo,CYAN); fixedBrandLogo=logo; logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); brand.addView(logo,new LinearLayout.LayoutParams(dp(56),dp(56)));
        LinearLayout bt=new LinearLayout(this); bt.setOrientation(LinearLayout.VERTICAL); bt.setGravity(Gravity.CENTER_VERTICAL); bt.setPadding(dp(6),0,0,0);
        TextView title=tv("VIRTUS",10.5f); title.setTextColor(WHITE); title.setTypeface(null,android.graphics.Typeface.BOLD); title.setSingleLine(true); title.setGravity(Gravity.CENTER); title.setIncludeFontPadding(false);
        TextView sub=tv("V12  •  DIAGNÓSTICO",9.5f); fixedBrandSubtitle=sub; sub.setTextColor(CYAN); sub.setTypeface(null,android.graphics.Typeface.BOLD); sub.setSingleLine(true); sub.setGravity(Gravity.CENTER); sub.setIncludeFontPadding(false);
        TextView strap=tv("LEITURA  •  ANÁLISE  •  CAN",8.0f); strap.setTextColor(MUTED); strap.setSingleLine(true); strap.setGravity(Gravity.CENTER); strap.setIncludeFontPadding(false); strap.setPadding(0,0,0,0);
        TextView version=tv("V12 • 12.0.0.1",8.5f); fixedBrandVersion=version; version.setTextColor(Color.rgb(180,194,211)); version.setSingleLine(true); version.setGravity(Gravity.CENTER); version.setIncludeFontPadding(false);
        refreshHeaderVersion(version);
        bt.addView(title,new LinearLayout.LayoutParams(-1,dp(22))); bt.addView(sub,new LinearLayout.LayoutParams(-1,dp(22))); bt.addView(strap,new LinearLayout.LayoutParams(-1,dp(20))); bt.addView(version,new LinearLayout.LayoutParams(-1,dp(24))); bt.setTranslationY(0);
        brand.addView(bt,new LinearLayout.LayoutParams(0,dp(82),1));
        // ===== V12.0-FIX06 — TOQUE NO VIRTUS / PISCADA DO FAROL =====
        // Mantém a imagem e o enquadramento originais; apenas adiciona uma camada
        // transparente sobre os faróis para o efeito visual de luz alta.
        FrameLayout carFrame=new FrameLayout(this);
        LinearLayout.LayoutParams carLp=new LinearLayout.LayoutParams(dp(202),dp(82)); carLp.gravity=Gravity.BOTTOM; carLp.setMargins(dp(2),0,dp(1),0);
        ImageView car=new ImageView(this); fixedCarImage=car; car.setImageResource(R.drawable.v12_car_header_motion); car.setScaleType(ImageView.ScaleType.FIT_CENTER); car.setAdjustViewBounds(false); car.setTranslationY(dp(5));
        carFrame.addView(car,new FrameLayout.LayoutParams(-1,-1));
        // A arte usa alfa progressivo nas bordas e na base; o fundo do tema aparece através dela.
        HeadlightFlashView headlightFlash=new HeadlightFlashView(this);
        headlightFlash.setTranslationY(dp(5));
        carFrame.addView(headlightFlash,new FrameLayout.LayoutParams(-1,-1));
        carFrame.setContentDescription("Virtus — tocar para piscar os faróis");
        carFrame.setClickable(true);
        carFrame.setOnClickListener(v -> triggerHeadlightFlashAndSafeCacheClear(headlightFlash));
        brand.addView(carFrame,carLp); hero.addView(brand);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(96)); hp.setMargins(dp(8),dp(5),dp(8),dp(5)); shell.addView(hero,hp);

        // ÁREA CENTRAL — somente esta região troca de tela.
        FrameLayout contentHost=new FrameLayout(this); shell.addView(contentHost,new LinearLayout.LayoutParams(-1,0,1));

        homeScreen=buildHomeScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        diagnosticScreen=buildDiagnosticScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        canScreen=buildCanScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        customScreen=buildCustomScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        configScreen=buildConfigScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        dataScreen=buildDataScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        graphScreen=buildGraphScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        performanceScreen=buildPerformanceScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        historyScreen=buildHistoryScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        dtcLibraryScreen=buildDtcLibraryScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        contentHost.addView(homeScreen,screenLp()); contentHost.addView(dataScreen,screenLp()); contentHost.addView(diagnosticScreen,screenLp()); contentHost.addView(canScreen,screenLp()); contentHost.addView(customScreen,screenLp()); contentHost.addView(configScreen,screenLp()); contentHost.addView(graphScreen,screenLp()); contentHost.addView(performanceScreen,screenLp()); contentHost.addView(historyScreen,screenLp()); contentHost.addView(dtcLibraryScreen,screenLp());
        dataScreen.setVisibility(View.GONE); diagnosticScreen.setVisibility(View.GONE); canScreen.setVisibility(View.GONE); customScreen.setVisibility(View.GONE); configScreen.setVisibility(View.GONE); graphScreen.setVisibility(View.GONE); performanceScreen.setVisibility(View.GONE); historyScreen.setVisibility(View.GONE); dtcLibraryScreen.setVisibility(View.GONE);

        // MENU FIXO — navegação troca somente o conteúdo central.
        LinearLayout nav=new LinearLayout(this); fixedNav=nav; nav.setOrientation(LinearLayout.HORIZONTAL); nav.setGravity(Gravity.CENTER); nav.setPadding(dp(4),dp(5),dp(4),dp(5)); nav.setBackground(cardBg(Color.rgb(3,24,47),24,CYAN2));
        addNav(nav,R.drawable.ic_home,"Início",NAV_ACTIVE,()->showHomeScreen());
        addNav(nav,R.drawable.ic_chart,"Dados",NAV_INACTIVE,()->showDataScreen());
        addNav(nav,R.drawable.ic_engine,"Diagnóstico",NAV_INACTIVE,()->showDiagnosticScreen());
        addNav(nav,R.drawable.ic_tune,"CUSTOM",NAV_INACTIVE,()->showCustomScreen());
        addNav(nav,R.drawable.ic_settings,"Config",NAV_INACTIVE,()->showConfigScreen());
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(104)); np.setMargins(dp(5),dp(4),dp(5),dp(8)); shell.addView(nav,np);

        mainShell=shell; setContentView(shell); currentScreen=0;
    }

    private LinearLayout.LayoutParams screenLp(){ return new LinearLayout.LayoutParams(-1,-1); }

    /**
     * FIX06: efeito visual de farol alto + limpeza somente do cache temporário
     * pertencente ao próprio aplicativo. Não toca em SharedPreferences, banco,
     * arquivos persistentes, histórico CSV ou dados de configuração.
     */
    private void triggerHeadlightFlashAndSafeCacheClear(HeadlightFlashView flash){
        if(flash!=null) flash.flash();
        io.execute(() -> {
            int removed=0;
            try{ removed += clearCacheContents(getCacheDir()); }catch(Exception ignored){}
            try{ if(getExternalCacheDir()!=null) removed += clearCacheContents(getExternalCacheDir()); }catch(Exception ignored){}
            final int count=removed;
            main.post(() -> {
                if(isTechLogEnabled()){ append("FIX06: toque no Virtus — piscada de farol executada; cache temporário interno limpo: "+count+" item(ns).\n"); }
            });
        });
    }

    private int clearCacheContents(File dir){
        if(dir==null || !dir.exists() || !dir.isDirectory()) return 0;
        File[] children=dir.listFiles();
        if(children==null) return 0;
        int removed=0;
        for(File child:children){
            if(deleteRecursively(child)) removed++;
        }
        return removed;
    }

    private boolean deleteRecursively(File f){
        if(f==null || !f.exists()) return false;
        if(f.isDirectory()){
            File[] children=f.listFiles();
            if(children!=null) for(File child:children) deleteRecursively(child);
        }
        return f.delete();
    }

    /** Camada transparente sobre a imagem do Virtus; coordenadas normalizadas
     * pelos faróis da arte 313x170 usada no cabeçalho. */
    private static class HeadlightFlashView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF left=new RectF(), right=new RectF();
        private float flashAlpha=0f;
        private long start=0L;
        private boolean running=false;
        private final Runnable ticker=new Runnable(){ @Override public void run(){
            long elapsed=System.currentTimeMillis()-start;
            if(elapsed>=520){ flashAlpha=0f; running=false; invalidate(); return; }
            if(elapsed<90) flashAlpha=elapsed/90f;
            else if(elapsed<300) flashAlpha=1f;
            else flashAlpha=1f-((elapsed-300)/220f);
            invalidate(); postDelayed(this,16);
        }};
        HeadlightFlashView(Context c){ super(c); setWillNotDraw(false); setClickable(false); }
        void flash(){
            removeCallbacks(ticker); start=System.currentTimeMillis(); running=true; flashAlpha=0f; invalidate(); post(ticker);
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            if(!running && flashAlpha<=0f) return;
            float w=getWidth(), h=getHeight();
            // FIX06.3: faróis deslocados ligeiramente para baixo; brilho concentrado no centro óptico;
            // o efeito fica sobre os faróis, não sobre o capô/parabrisa.
            // Coordenadas normalizadas sobre a arte original (453x170), não sobre o frame inteiro.
            // A imagem usa FIT_CENTER; reproduzimos o mesmo retângulo para a piscada acompanhar os faróis.
            final float artRatio=453f/170f;
            float artW=w, artH=w/artRatio;
            if(artH>h){ artH=h; artW=h*artRatio; }
            float ox=(w-artW)/2f, oy=(h-artH)/2f;
            float lx=ox+artW*0.220f, rx=ox+artW*0.525f;
            float ly=oy+artH*0.585f, ry=oy+artH*0.540f;
            float lw=artW*0.070f, rw=artW*0.072f, hh=artH*0.085f;
            paint.setStyle(Paint.Style.FILL);
            // FIX06.3: brilho +20% e núcleo central mais intenso, como uma lâmpada real.
            for(int i=3;i>=1;i--){
                float a=Math.min(1f,flashAlpha*(0.20f*i));
                paint.setColor(Color.argb((int)(255*a),255,255,255));
                float padX=(3-i)*w*0.016f, padY=(3-i)*h*0.013f;
                left.set(lx-lw/2-padX,ly-hh/2-padY,lx+lw/2+padX,ly+hh/2+padY);
                right.set(rx-rw/2-padX,ry-hh/2-padY,rx+rw/2+padX,ry+hh/2+padY);
                c.drawOval(left,paint); c.drawOval(right,paint);
            }
            // Núcleo quente/branco: menor e mais concentrado no centro óptico.
            float coreAlpha=flashAlpha;
            paint.setColor(Color.argb((int)(255*coreAlpha),255,255,255));
            float cl=artW*0.030f, cr=artW*0.032f, ch=artH*0.050f;
            left.set(lx-cl/2,ly-ch/2,lx+cl/2,ly+ch/2);
            right.set(rx-cr/2,ry-ch/2,rx+cr/2,ry+ch/2);
            c.drawOval(left,paint); c.drawOval(right,paint);
        }
    }

    private LinearLayout buildHomeScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout wrap=new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.setBackgroundColor(BG);
        ScrollView page=new ScrollView(this); page.setFillViewport(true); page.setBackgroundColor(BG); page.setClipToPadding(false);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(10),dp(4),dp(10),dp(16)); page.addView(root,new ScrollView.LayoutParams(-1,-2)); wrap.addView(page,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout conn=card(CARD); conn.setPadding(dp(10),dp(8),dp(10),dp(8)); LinearLayout cr=row();
        healthChip=healthChip("● OFFLINE",Color.rgb(255,88,88),Color.rgb(61,16,24)); LinearLayout.LayoutParams healthLp=new LinearLayout.LayoutParams(0,dp(58),1.12f); healthLp.setMargins(0,0,dp(3),0); cr.addView(healthChip,healthLp);
        ImageView bti=icon(R.drawable.ic_bluetooth,CYAN); LinearLayout.LayoutParams btLp=new LinearLayout.LayoutParams(0,dp(52),0.35f); btLp.setMargins(dp(3),0,dp(3),0); cr.addView(bti,btLp);
        status=tv("Pronto",9); status.setTextColor(MUTED); status.setSingleLine(true); status.setVisibility(View.GONE);
        connectButton=btn("CONECTAR ELM"); connectButton.setTextSize(11); bindClick(connectButton,()->toggleConnection()); connectButton.setMinWidth(0); connectButton.setMinimumWidth(0); LinearLayout.LayoutParams connectLp=new LinearLayout.LayoutParams(0,dp(52),1f); connectLp.setMargins(dp(3),0,0,0); cr.addView(connectButton,connectLp); conn.addView(cr); addFull(root,conn);

        LinearLayout live=card(CARD); live.setPadding(dp(10),dp(9),dp(10),dp(10)); LinearLayout dashHead=row(); TextView dl=tv("ROTAÇÃO DO MOTOR",13); dl.setTextColor(WHITE); dl.setTypeface(null,android.graphics.Typeface.BOLD); dashHead.addView(dl,new LinearLayout.LayoutParams(0,dp(30),1));
        TextView model=tv("",10.5f); model.setSingleLine(true); if(Build.VERSION.SDK_INT>=26){ model.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP); } model.setTextColor(WHITE); model.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); model.setTag("vehicleProfile"); dashHead.addView(model,new LinearLayout.LayoutParams(dp(160),dp(30))); live.addView(dashHead);
        LinearLayout cluster=card(CARD2); cluster.setPadding(dp(10),dp(5),dp(10),dp(8));
        LinearLayout rpmTop=row(); dashRpm=tv("0 rpm",39); dashRpm.setTextColor(WHITE); dashRpm.setTypeface(null,android.graphics.Typeface.BOLD); dashRpm.setSingleLine(true); rpmTop.addView(dashRpm,new LinearLayout.LayoutParams(0,dp(72),1)); dashIgnition=tv("IG: —",8); dashIgnition.setSingleLine(true); dashIgnition.setEllipsize(android.text.TextUtils.TruncateAt.END); dashIgnition.setTextColor(CYAN); dashIgnition.setTypeface(null,android.graphics.Typeface.BOLD); dashIgnition.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); rpmTop.addView(dashIgnition,new LinearLayout.LayoutParams(dp(58),dp(72))); cluster.addView(rpmTop);
        rpmBar=new RpmSegmentBar(this); cluster.addView(rpmBar,new LinearLayout.LayoutParams(-1,dp(18))); RpmScaleView scale=new RpmScaleView(this); cluster.addView(scale,new LinearLayout.LayoutParams(-1,dp(24)));
        LinearLayout oilRow=row(); dashOilTemp=tv("🛢️ — °C",12); dashOilTemp.setTextColor(CYAN); dashOilTemp.setTypeface(null,android.graphics.Typeface.BOLD); dashOilTemp.setGravity(Gravity.CENTER_VERTICAL); dashOilLevel=tv("NÍVEL —",10); dashOilLevel.setTextColor(Color.rgb(145,181,210)); dashOilLevel.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); oilRow.addView(dashOilTemp,new LinearLayout.LayoutParams(0,dp(30),1)); oilRow.addView(dashOilLevel,new LinearLayout.LayoutParams(0,dp(30),1)); cluster.addView(oilRow);
        LinearLayout tempRow=row(); dashCoolant=tv("TEMP. LÍQUIDO\n— °C",11); dashCoolant.setTextColor(WHITE); tempRow.addView(dashCoolant,new LinearLayout.LayoutParams(0,dp(58),1)); dashIntake=tv("TEMP. ADMISSÃO\n— °C",11); dashIntake.setTextColor(WHITE); dashIntake.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); tempRow.addView(dashIntake,new LinearLayout.LayoutParams(0,dp(58),1)); cluster.addView(tempRow);
        live.addView(cluster,new LinearLayout.LayoutParams(-1,dp(205)));
        LinearLayout g1=row(); dashSpeed=metric("VELOCIDADE","— km/h",WHITE,CYAN); dashBoost=metric("BOOST","— bar",WHITE,CYAN); dashVolt=metric("TENSÃO","— V",WHITE,CYAN); dashLoad=metric("CARGA MOTOR","— %",WHITE,CYAN); addHalfView(g1,dashSpeed);addHalfView(g1,dashBoost);addHalfView(g1,dashVolt);addHalfView(g1,dashLoad); live.addView(g1);
        LinearLayout g2=row(); dashMap=metric("MAP","— kPa",WHITE,CYAN); dashBaro=metric("BARO","— kPa",WHITE,CYAN); dashThrottle=metric("THROTTLE","— %",WHITE,CYAN); dashFuel=metric("COMBUSTÍVEL","— %",WHITE,CYAN); addHalfView(g2,dashMap);addHalfView(g2,dashBaro);addHalfView(g2,dashThrottle);addHalfView(g2,dashFuel); live.addView(g2);
        LinearLayout vehicle=row(); dashVin=tv("VIN: —\nVEÍCULO NÃO IDENTIFICADO",10.5f); dashVin.setTextColor(WHITE); dashVin.setGravity(Gravity.CENTER_VERTICAL); dashVin.setBackground(cardBg(CARD2,16,CYAN2)); vehicle.addView(dashVin,new LinearLayout.LayoutParams(0,dp(62),2)); dashCan=tv("PROTOCOLO\nCAN 11/500",11); dashCan.setTextColor(WHITE); dashCan.setGravity(Gravity.CENTER); dashCan.setBackground(cardBg(CARD2,16,CYAN2)); vehicle.addView(dashCan,new LinearLayout.LayoutParams(0,dp(62),1)); live.addView(vehicle); addFull(root,live);

        LinearLayout modHeader=row(); TextView modHead=tv("MÓDULOS",22); modHead.setTextColor(WHITE); modHead.setTypeface(null,android.graphics.Typeface.BOLD); modHead.setPadding(dp(8),dp(10),dp(8),dp(2)); modHeader.addView(modHead,new LinearLayout.LayoutParams(0,dp(46),1)); TextView modHint=tv("SELECIONE UMA FUNÇÃO",10); modHint.setTextColor(CYAN); modHint.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); modHint.setPadding(dp(8),dp(10),dp(8),dp(2)); modHeader.addView(modHint,new LinearLayout.LayoutParams(dp(170),dp(46))); addFull(root,modHeader);
        LinearLayout m1=row(); addModule(m1,R.drawable.ic_engine,"DIAGNÓSTICO","Códigos de falhas (DTC)",CYAN,()->showDiagnosticScreen()); addModule(m1,R.drawable.ic_gauge,"PERFORMANCE","Potência • torque • testes",Color.rgb(0,220,180),()->showPerformanceScreen()); addFull(root,m1);
        LinearLayout m2=row(); addModule(m2,R.drawable.ic_chart,"GRÁFICOS","Análise e histórico",Color.rgb(150,100,255),()->showGraphScreen()); addModule(m2,R.drawable.ic_document,"GRAVAÇÃO DE DADOS","Logs e exportação (CSV)",Color.rgb(255,80,90),()->showDataScreen()); addFull(root,m2);
        LinearLayout m3=row(); addModule(m3,R.drawable.ic_vehicle,"INFORMAÇÕES DO VEÍCULO","Identificação por VIN",CYAN2,()->{showHomeScreen();vehicleData();}); addFull(root,m3);
        resultHome=tv("RESULTADO: —",11); resultHome.setTextColor(WHITE); resultHome.setPadding(dp(12),dp(8),dp(12),dp(8)); resultHome.setBackground(cardBg(CARD2,16,CYAN2)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(80)); rp.setMargins(dp(6),dp(3),dp(6),dp(8)); root.addView(resultHome,rp);
        return wrap;
    }

    private LinearLayout buildCustomScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(5),dp(10),dp(8)); screen.setBackgroundColor(BG);
        ScrollView sv=new ScrollView(this); sv.setFillViewport(false); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(0,0,0,dp(12)); sv.addView(root,new ScrollView.LayoutParams(-1,-2));
        LinearLayout head=card(CARD2); head.setPadding(dp(14),dp(12),dp(14),dp(12)); head.setBackground(cardBg(CARD2,18,CYAN));
        TextView title=tv("CUSTOMIZAÇÃO VW",18); title.setTextColor(WHITE); title.setTypeface(null,android.graphics.Typeface.BOLD); head.addView(title);
        TextView sub=tv("Virtus 200 TSI • funções via OBD",10); sub.setTextColor(MUTED); head.addView(sub); addFull(root,head);
        TextView notice=tv("Selecione um cluster. A lista abre nesta tela, sem janelas pop-up. Funções de gravação só serão habilitadas após validar módulo, compatibilidade e valor original.",10); notice.setTextColor(MUTED); notice.setPadding(dp(5),dp(6),dp(5),dp(10)); addFull(root,notice);
        JSONArray catalogCategories = loadCustomCatalog();
        int catalogCount = 0; for(int ci=0;ci<catalogCategories.length();ci++){JSONObject cc=catalogCategories.optJSONObject(ci);if(cc!=null)catalogCount+=cc.optJSONArray("items")!=null?cc.optJSONArray("items").length():0;}
        TextView catalogSummary=tv("CATÁLOGO MESTRE VW • "+catalogCount+" funções de referência • compatibilidade ainda não presumida",10); catalogSummary.setTextColor(MUTED); catalogSummary.setPadding(dp(5),dp(4),dp(5),dp(8)); addFull(root,catalogSummary);
        final java.util.LinkedHashSet<String> selectedCustom = new java.util.LinkedHashSet<>();
        final int[] fallbackColors={Color.rgb(50,197,244),Color.rgb(177,122,255),Color.rgb(53,214,176),Color.rgb(245,192,74),Color.rgb(255,96,120),Color.rgb(77,148,255),Color.rgb(255,75,90)};
        for(int i=0;i<catalogCategories.length();i++){
          final JSONObject category=catalogCategories.optJSONObject(i); if(category==null)continue;
          final String categoryName=category.optString("name","OUTRAS FUNÇÕES"); final String categoryId=category.optString("id","unknown");
          int accent=fallbackColors[i%fallbackColors.length]; try{accent=Color.parseColor(category.optString("color","#32C5F4"));}catch(Exception ignored){}
          final JSONArray items=category.optJSONArray("items")==null?new JSONArray():category.optJSONArray("items");
          final LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setVisibility(View.GONE);
          LinearLayout cluster=card(CARD); cluster.setOrientation(LinearLayout.VERTICAL); cluster.setPadding(dp(12),dp(9),dp(12),dp(9)); cluster.setBackground(cardBg(CARD,16,accent));
          LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
          TextView icon=tv("◆",23); icon.setTextColor(accent); icon.setGravity(Gravity.CENTER); row.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(48)));
          LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); TextView label=tv(categoryName,13); label.setTextColor(WHITE); label.setTypeface(null,android.graphics.Typeface.BOLD); texts.addView(label); TextView hint=tv(items.length()+" funções • "+category.optString("moduleFamily","módulo a identificar"),9); hint.setTextColor(MUTED); texts.addView(hint); row.addView(texts,new LinearLayout.LayoutParams(0,-2,1)); TextView chevron=tv("⌄",22); chevron.setTextColor(accent); row.addView(chevron); cluster.addView(row);
          bindClick(row,()->{boolean open=list.getVisibility()!=View.VISIBLE; list.setVisibility(open?View.VISIBLE:View.GONE); chevron.setText(open?"⌃":"⌄");});
          for(int j=0;j<items.length();j++){
            final JSONObject feature=items.optJSONObject(j); if(feature==null)continue;
            final String featureId=feature.optString("id","unknown"); final String functionName=feature.optString("title",featureId); final String statusCode=feature.optString("compatibilityStatus","UNKNOWN");
            LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setPadding(dp(10),dp(8),dp(8),dp(8));
            boolean supported="SUPPORTED_WRITE_VALIDATED".equals(statusCode); int itemBg=supported?Color.rgb(10,54,78):Color.rgb(20,31,44); item.setBackground(cardBg(itemBg,10,supported?accent:Color.rgb(57,72,87)));
            LinearLayout itemRow=new LinearLayout(this); itemRow.setOrientation(LinearLayout.HORIZONTAL); itemRow.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout itemText=new LinearLayout(this); itemText.setOrientation(LinearLayout.VERTICAL);
            TextView ft=tv(functionName,11); ft.setTextColor(supported?WHITE:Color.rgb(145,158,174)); ft.setTypeface(null,android.graphics.Typeface.BOLD); itemText.addView(ft);
            String stateLabel=supported?"COMPATIBILIDADE E ESCRITA VALIDADAS":"NÃO VALIDADA • BLOQUEADA";
            TextView state=tv(stateLabel,9); state.setTextColor(supported?accent:Color.rgb(112,126,143)); itemText.addView(state);
            TextView detail=tv("ID: "+featureId+"\nMódulo esperado: "+feature.optString("moduleFamily",category.optString("moduleFamily","não definido"))+"\nEstado: "+statusCode+"\n"+feature.optString("sourceNote","Sem fonte técnica vinculada.")+"\nA presença no catálogo não comprova suporte no veículo. A liberação exige identificação da central, evidência de compatibilidade, valor original e procedimento de escrita validado.",9); detail.setTextColor(MUTED); detail.setVisibility(View.GONE); itemText.addView(detail);
            itemRow.addView(itemText,new LinearLayout.LayoutParams(0,-2,1));
            android.widget.CheckBox select=new android.widget.CheckBox(this); select.setButtonTintList(android.content.res.ColorStateList.valueOf(supported?accent:Color.rgb(91,103,117))); select.setText(supported?"Selecionar":"Bloqueada"); select.setTextColor(supported?MUTED:Color.rgb(112,126,143)); select.setTextSize(10); select.setEnabled(supported); select.setOnCheckedChangeListener((button,checked)->{String key=featureId+" — "+functionName;if(checked)selectedCustom.add(key);else selectedCustom.remove(key);}); itemRow.addView(select); item.addView(itemRow);
            bindClick(ft,()->detail.setVisibility(detail.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
            LinearLayout.LayoutParams ilp=new LinearLayout.LayoutParams(-1,-2); ilp.setMargins(0,dp(5),0,0); list.addView(item,ilp);
          }
          cluster.addView(list); LinearLayout.LayoutParams clp=new LinearLayout.LayoutParams(-1,-2); clp.setMargins(dp(2),dp(4),dp(2),dp(5)); root.addView(cluster,clp);
        }
        TextView backupNotice=tv("BACKUP DO VEÍCULO • salva o estado observado pelo V12 e os valores disponíveis nesta sessão. Isso não equivale a uma cópia integral das codificações internas das centrais.",9); backupNotice.setTextColor(MUTED); backupNotice.setPadding(dp(6),dp(10),dp(6),dp(8)); addFull(root,backupNotice);
        android.widget.Button backupButton=new android.widget.Button(this); backupButton.setText("CRIAR BACKUP DO ESTADO ATUAL"); backupButton.setAllCaps(false); backupButton.setTextColor(WHITE); backupButton.setBackground(cardBg(Color.rgb(7,43,72),12,CYAN)); backupButton.setOnClickListener(v->createVehicleStateBackup()); LinearLayout.LayoutParams backupLp=new LinearLayout.LayoutParams(-1,dp(50)); backupLp.setMargins(dp(2),dp(4),dp(2),dp(5)); root.addView(backupButton,backupLp);
        android.widget.Button restoreButton=new android.widget.Button(this); restoreButton.setText("CONSULTAR BACKUP / REVERSÃO"); restoreButton.setAllCaps(false); restoreButton.setTextColor(WHITE); restoreButton.setBackground(cardBg(Color.rgb(34,35,65),12,Color.rgb(177,122,255))); restoreButton.setOnClickListener(v->reviewVehicleStateBackup()); LinearLayout.LayoutParams restoreLp=new LinearLayout.LayoutParams(-1,dp(50)); restoreLp.setMargins(dp(2),dp(2),dp(2),dp(8)); root.addView(restoreButton,restoreLp);
        android.widget.Button scanModules=new android.widget.Button(this); scanModules.setText("IDENTIFICAR MÓDULOS DO VEÍCULO"); scanModules.setAllCaps(false); scanModules.setTextColor(WHITE); scanModules.setBackground(cardBg(Color.rgb(8,49,78),12,CYAN)); scanModules.setOnClickListener(v->scanVehicleModules()); LinearLayout.LayoutParams scanLp=new LinearLayout.LayoutParams(-1,dp(50)); scanLp.setMargins(dp(2),dp(10),dp(2),dp(5)); root.addView(scanModules,scanLp);
        TextView scanHint=tv("A varredura é somente leitura. Módulos sem resposta não serão declarados incompatíveis; ficarão como não identificados.",9); scanHint.setTextColor(MUTED); addFull(root,scanHint);
        android.widget.Button historyCustom=new android.widget.Button(this); historyCustom.setText("HISTÓRICO DE PERSONALIZAÇÕES"); historyCustom.setAllCaps(false); historyCustom.setTextColor(WHITE); historyCustom.setBackground(cardBg(Color.rgb(34,35,65),12,Color.rgb(177,122,255))); historyCustom.setOnClickListener(v->showCustomHistory()); LinearLayout.LayoutParams historyCustomLp=new LinearLayout.LayoutParams(-1,dp(48)); historyCustomLp.setMargins(dp(2),dp(2),dp(2),dp(5)); root.addView(historyCustom,historyCustomLp);
        android.widget.Button review=new android.widget.Button(this); review.setText("REVISAR / PREPARAR ALTERAÇÃO"); review.setAllCaps(false); review.setTextColor(WHITE); review.setBackground(cardBg(Color.rgb(7,43,72),12,CYAN)); review.setOnClickListener(v->{
            if(selectedCustom.isEmpty()){android.widget.Toast.makeText(this,"Selecione ao menos uma função para revisar.",android.widget.Toast.LENGTH_SHORT).show();return;}
            StringBuilder summary=new StringBuilder("FUNÇÕES SELECIONADAS\n\n"); for(String name:selectedCustom)summary.append("• ").append(name).append("\n");
            summary.append("\nVERIFICAÇÃO TÉCNICA\nMódulos com resposta de leitura nesta sessão: ").append(countRespondingModules(lastDiscoveredModules)).append("\n");
            summary.append("Estado: revisão registrada; nenhum comando de escrita será enviado porque o catálogo ainda não contém mapeamento de gravação validado para estas funções genéricas. A confirmação CANCELAR/GRAVAR só será apresentada para uma operação real cujo serviço, identificador, valores permitidos, acesso e retorno tenham sido validados.\n");
            recordCustomReview(selectedCustom, lastDiscoveredModules.length());
            new android.app.AlertDialog.Builder(this).setTitle("REVISÃO DE CUSTOMIZAÇÃO").setMessage(summary.toString()).setNegativeButton("CANCELAR",null).setPositiveButton("VER MÓDULOS",(d,w)->showDiscoveredModules()).show();
        }); LinearLayout.LayoutParams reviewLp=new LinearLayout.LayoutParams(-1,dp(50)); reviewLp.setMargins(dp(2),dp(5),dp(2),dp(8)); root.addView(review,reviewLp);
        return screen;
    }

    private JSONArray loadCustomCatalog() {
        try (InputStream in=getAssets().open("vw_customization_catalog.json")) {
            ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buffer=new byte[8192]; int n;
            while((n=in.read(buffer))>0)out.write(buffer,0,n);
            JSONObject root=new JSONObject(new String(out.toByteArray(),StandardCharsets.UTF_8));
            return root.optJSONArray("categories")==null?new JSONArray():root.optJSONArray("categories");
        } catch(Exception e) { append("CUSTOM CATALOG: falha ao carregar catálogo local — "+e.getClass().getSimpleName()); return new JSONArray(); }
    }

    private int countRespondingModules(JSONArray modules) { int count=0; if(modules!=null) for(int i=0;i<modules.length();i++){JSONObject m=modules.optJSONObject(i);if(m!=null&&m.optBoolean("respondedToReadDidF190",false))count++;}return count; }

    private void recordCustomReview(java.util.Set<String> selected, int discoveredCount) {
        try { JSONObject t=new JSONObject(); t.put("timestamp",System.currentTimeMillis()); t.put("stage","REVIEW_ONLY_NO_WRITE"); t.put("vin",lastVin==null?"":lastVin); t.put("simulation",simulationMode); t.put("connected",connected); t.put("discoveredModuleCount",discoveredCount); JSONArray f=new JSONArray(); for(String name:selected)f.put(name); t.put("selectedFunctions",f); t.put("rollbackReady",false); t.put("result","No ECU write sent; catalog mapping not validated"); appendCustomTransaction(t); }
        catch(Exception e){append("CUSTOM HISTORY: não foi possível registrar revisão: "+e.getClass().getSimpleName());}
    }

    private void shareText(String subject, String content) {
        try { Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(Intent.EXTRA_SUBJECT,subject); i.putExtra(Intent.EXTRA_TEXT,content); startActivity(Intent.createChooser(i,"Compartilhar histórico V12")); }
        catch(Exception e){toast("Compartilhamento indisponível neste dispositivo");}
    }

    private void showCustomHistory() {
        JSONArray entries=readCustomTransactions(); StringBuilder b=new StringBuilder();
        for(int i=entries.length()-1;i>=0;i--){JSONObject t=entries.optJSONObject(i);if(t==null)continue;long ts=t.optLong("timestamp",0);String when=ts>0?new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm:ss",java.util.Locale.getDefault()).format(new java.util.Date(ts)):"data indisponível";b.append(when).append("\nEtapa: ").append(t.optString("stage","—")).append("\nVIN: ").append(t.optString("vin","—")).append("\nResultado: ").append(t.optString("result","—")).append("\nFunções: ");JSONArray f=t.optJSONArray("selectedFunctions");if(f!=null)for(int j=0;j<f.length();j++){if(j>0)b.append(", ");b.append(f.optString(j));}b.append("\n\n");}
        if(b.length()==0)b.append("Nenhuma revisão de personalização foi registrada ainda. As revisões futuras serão salvas aqui.\n\nEste histórico não afirma que uma gravação foi executada; cada entrada mostra o estágio e o resultado registrado.");
        new AlertDialog.Builder(this).setTitle("HISTÓRICO DE PERSONALIZAÇÕES").setMessage(b.toString()).setPositiveButton("OK",null).setNeutralButton("COMPARTILHAR",(d,w)->shareText("V12 — Histórico de personalizações",b.toString())).show();
    }

    private static final String VEHICLE_BACKUP_FILE = "v12_vehicle_state_backup.json";
    private static final String ECU_MODULES_PREF = "v12_custom_discovered_modules_v1";
    private File vehicleProfileDir() {
        String vin=(lastVin==null?"":lastVin.trim()).toUpperCase(Locale.US).replaceAll("[^A-Z0-9]", "");
        if(vin.isEmpty()||"—".equals(vin)||"NA".equals(vin))vin="VIN_NAO_IDENTIFICADO";
        File dir=new File(new File(getFilesDir(),"vehicles"),vin);
        if(!dir.exists())dir.mkdirs();
        return dir;
    }
    private File vehicleBackupFile() { return new File(vehicleProfileDir(), VEHICLE_BACKUP_FILE); }

    private static final String ECU_TXN_FILE = "v12_custom_transactions.json";
    private volatile JSONArray lastDiscoveredModules = new JSONArray();
    private final LinkedHashMap<String, JSONObject> pendingCustomOperations = new LinkedHashMap<>();

    /** Read-only discovery on the conventional 11-bit powertrain/diagnostic request range.
     * A positive DID, a negative UDS response, and silence are kept as distinct outcomes.
     * This is endpoint discovery only: no VAG module name is inferred from an address.
     */
    private static final class VagEndpoint {
        final String scheme, requestId, responseId, elmPrefix, elmHeader;
        String presenceRaw="";
        VagEndpoint(String scheme,String requestId,String responseId,String elmPrefix,String elmHeader){
            this.scheme=scheme;this.requestId=requestId;this.responseId=responseId;this.elmPrefix=elmPrefix;this.elmHeader=elmHeader;
        }
    }

    private boolean responseMatchesEndpoint(String raw, VagEndpoint ep) {
        if(raw==null || raw.trim().isEmpty() || ep==null || ep.responseId==null) return false;
        String u=raw.toUpperCase(Locale.US).replaceAll("[^0-9A-F]+"," ").trim().replaceAll("\\s+"," ");
        // A positive TesterPresent payload without its CAN ID cannot be attributed
        // to the endpoint currently being probed. ELM clones that suppress headers
        // therefore produce an UNVERIFIED result, never a fabricated module hit.
        String[] tokens=u.isEmpty()?new String[0]:u.split(" ");
        for(int i=0;i<tokens.length;i++) {
            if(!tokens[i].equals(ep.responseId.toUpperCase(Locale.US))) continue;
            // Require a UDS TesterPresent positive response (7E 00) or a
            // well-formed negative response to service 3E (7F 3E NRC).
            for(int j=i+1;j+2<tokens.length && j<i+9;j++) {
                if("7E".equals(tokens[j]) && "00".equals(tokens[j+1])) return true;
                if("7F".equals(tokens[j]) && "3E".equals(tokens[j+1])
                        && tokens[j+2].matches("[0-9A-F]{2}")) return true;
            }
        }
        return false;
    }

    private String activeElmCanPrefix = "";
    private void configureElmForEndpoint(VagEndpoint ep) {
        if("CAN29".equals(ep.scheme) || "OBD_CAN29".equals(ep.scheme)) {
            if(!ep.elmPrefix.equals(activeElmCanPrefix)) { send("ATCP "+ep.elmPrefix,180); activeElmCanPrefix=ep.elmPrefix; }
        }
        send("ATSH "+ep.elmHeader,180);
    }

    /**
     * Read-only multi-scheme discovery. Scans the VAG 11-bit range, standard
     * OBD 11-bit endpoints and both commonly documented 29-bit diagnostic
     * families. An address is marked responsive only after a physical
     * TesterPresent response; identity and DTC reads are separate evidence.
     */
    private void scanVehicleModules() {
        stopRequested=false;
        if (simulationMode || !connected || out == null || in == null) {
            final String message = "VARREDURA NÃO EXECUTADA\n\nMotivo: ELM327 desconectado ou modo de simulação ativo.\n\nNenhum comando foi enviado ao veículo. O V12 permanece aberto. Conecte o adaptador e tente novamente.";
            append("VAG DISCOVERY: operação bloqueada com segurança — sem conexão real.");
            showResult(message);
            ui(() -> { if (!isFinishing() && !isDestroyed()) new AlertDialog.Builder(this).setTitle("CONEXÃO NECESSÁRIA").setMessage(message).setPositiveButton("OK", null).show(); });
            return;
        }
        runOp("VARREDURA VAG MULTIPROTOCOLO • SOMENTE LEITURA", () -> {
            JSONArray found = new JSONArray();
            ArrayList<VagEndpoint> responders = new ArrayList<>();
            StringBuilder report = new StringBuilder();
            report.append("V12 VAG DISCOVERY — SOMENTE LEITURA\n");
            report.append("Método: TesterPresent 3E 00; identidade 22 F1 90; DTC UDS 19 02.\n");
            report.append("CRITÉRIO ESTRITO: somente resposta com CAN ID RX exato é atribuída ao endpoint. Resposta sem cabeçalho é inconclusiva.\n");
            report.append("TEMPO: varredura ampla pode levar vários minutos; interrompa se houver instabilidade no adaptador.\n");
            report.append("Nenhum endereço é convertido automaticamente em nome de módulo.\n\n");
            int probes=0;
            try {
                send("ATZ",1200); send("ATE0",350); send("ATL0",350); send("ATS1",350);
                send("ATH1",350); send("ATCAF1",350); send("ATCFC1",350); send("ATST32",250);
                // 11-bit VAG diagnostic addressing: 700..774, response = request + 6A.
                send("ATCP 00",180); activeElmCanPrefix=""; send("ATSP6",250);
                for(int id=0x700; id<=0x774 && !stopRequested; id++) {
                    String req=String.format(Locale.US,"%03X",id), resp=String.format(Locale.US,"%03X",id+0x6A);
                    VagEndpoint ep=new VagEndpoint("VAG_CAN11",req,resp,"",req);
                    configureElmForEndpoint(ep);
                    String raw=send("3E00",320); probes++;
                    if(responseMatchesEndpoint(raw,ep)) { ep.presenceRaw=raw; responders.add(ep); append("VAG DISCOVERY HIT 11-bit "+req+" → "+resp+" | "+raw.trim()); }
                    if((probes%32)==0) append("VAG DISCOVERY: "+probes+" endereços consultados; "+responders.size()+" respostas físicas confirmadas.");
                }
                // OBD 11-bit endpoints not covered by the VAG address window.
                for(int id=0x7E0; id<=0x7E7 && !stopRequested; id++) {
                    String req=String.format(Locale.US,"%03X",id), resp=String.format(Locale.US,"%03X",id+8);
                    boolean duplicate=false; for(VagEndpoint e:responders) if(e.requestId.equals(req)) duplicate=true;
                    if(duplicate) continue;
                    VagEndpoint ep=new VagEndpoint("OBD_CAN11",req,resp,"",req);
                    configureElmForEndpoint(ep); String raw=send("3E00",320); probes++;
                    if(responseMatchesEndpoint(raw,ep)) { ep.presenceRaw=raw; responders.add(ep); }
                }
                // 29-bit diagnostic candidate family. Treat hits only as endpoint evidence;
                // this address family is not assumed to be the vehicle topology.
                send("ATSP7",250); activeElmCanPrefix="";
                for(int node=0; node<=0xFF && !stopRequested; node++) {
                    String suffix=String.format(Locale.US,"%02X",node);
                    VagEndpoint ep=new VagEndpoint("CAN29","17FC00"+suffix,"17FE00"+suffix,"17","FC00"+suffix);
                    configureElmForEndpoint(ep); String raw=send("3E00",320); probes++;
                    if(responseMatchesEndpoint(raw,ep)) { ep.presenceRaw=raw; responders.add(ep); append("VAG DISCOVERY HIT 29-bit "+ep.requestId+" → "+ep.responseId); }
                    if((probes%64)==0) append("VAG DISCOVERY: "+probes+" endereços consultados; "+responders.size()+" respostas físicas confirmadas.");
                }
                // 29-bit OBD diagnostic candidate family: 18DAxxF1 -> 18DAF1xx.
                for(int node=0; node<=0xFF && !stopRequested; node++) {
                    String suffix=String.format(Locale.US,"%02X",node);
                    VagEndpoint ep=new VagEndpoint("OBD_CAN29","18DA"+suffix+"F1","18DAF1"+suffix,"18","DA"+suffix+"F1");
                    configureElmForEndpoint(ep); String raw=send("3E00",320); probes++;
                    if(responseMatchesEndpoint(raw,ep)) { ep.presenceRaw=raw; responders.add(ep); }
                    if((probes%64)==0) append("VAG DISCOVERY: "+probes+" endereços consultados; "+responders.size()+" respostas físicas confirmadas.");
                }
                report.append("TOTAL DE PROBES: ").append(probes).append("\n");
                report.append("ENDPOINTS COM RESPOSTA FÍSICA: ").append(responders.size()).append("\n\n");
                for(VagEndpoint ep:responders) {
                    if(stopRequested) break;
                    configureElmForEndpoint(ep);
                    String vinRaw=send("22F190",1500);
                    IsoTpPayload vinIso=reassembleIsoTp(vinRaw,ep.responseId);
                    String vin=parseUdsDidAscii(vinRaw,"62","F190");
                    String dtcRaw=send("19022D",1800);
                    IsoTpPayload dtcIso=reassembleIsoTp(dtcRaw,ep.responseId);
                    JSONObject item=new JSONObject();
                    item.put("scheme",ep.scheme); item.put("requestId",ep.requestId); item.put("responseId",ep.responseId);
                    item.put("responded",true); item.put("presenceEvidence",ep.presenceRaw.toUpperCase(Locale.US).contains("7E 00")?"POSITIVE_TESTER_PRESENT_3E00":"NEGATIVE_UDS_RESPONSE_TO_3E00"); item.put("presenceRaw",ep.presenceRaw);
                    item.put("identityStatus",vinIso.complete && vinRaw.toUpperCase(Locale.US).contains("62 F1 90")?"VIN_DID_POSITIVE":"NOT_IDENTIFIED");
                    item.put("vin",vin); item.put("vinRaw",vinRaw==null?"":vinRaw);
                    item.put("dtcStatus","19 02 mask 2D: "+(dtcIso.complete?"ISO_TP_COMPLETE":"NOT_VALIDATED"));
                    item.put("dtcRaw",dtcRaw==null?"":dtcRaw);
                    item.put("writeCapability","NOT_TESTED_READ_ONLY"); found.put(item);
                    report.append(ep.scheme).append(" TX ").append(ep.requestId).append(" → RX ").append(ep.responseId).append("\n");
                    report.append("Presença: resposta UDS correlacionada ao TesterPresent 3E 00 (positiva ou NRC)\nRAW presença: ").append(ep.presenceRaw).append("\n");
                    report.append("Identidade VIN DID: ").append(vin.isEmpty()?"não confirmada":"62 F1 90 = "+vin).append("\nRAW identidade: ").append(vinRaw).append("\n");
                    report.append("DADOS DTC UDS 19 02 / máscara 2D: ").append(dtcIso.complete?"resposta ISO-TP completa":"sem resposta completa validada").append("\nRAW DTC: ").append(dtcRaw).append("\n\n");
                    append("MODULE EVIDENCE "+ep.requestId+"/"+ep.responseId+" | VIN="+(vin.isEmpty()?"não identificado":vin)+" | DTC="+(dtcIso.complete?"ISO-TP completo":"não validado"));
                }
                // Query Gateway installation list only if its candidate endpoint actually answered.
                boolean gatewayCandidate=false;
                for(VagEndpoint ep:responders) if("710".equals(ep.requestId) && "77A".equals(ep.responseId)) gatewayCandidate=true;
                if(gatewayCandidate) {
                    VagEndpoint gw=new VagEndpoint("VAG_CAN11","710","77A","","710"); configureElmForEndpoint(gw);
                    String raw=send("222A26",3000); IsoTpPayload iso=reassembleIsoTp(raw,"77A");
                    report.append("GATEWAY DID 2A26 RAW: ").append(raw).append("\n");
                    if(iso.complete) {
                        List<VagGatewayDiscovery.Node> nodes=VagGatewayDiscovery.decodePositiveResponse(iso.payload);
                        report.append("GATEWAY BITMAP: ").append(nodes.isEmpty()?"formato/tamanho não reconhecido":"positivo; "+nodes.size()+" nós listados").append("\n");
                        for(VagGatewayDiscovery.Node n:nodes) report.append(String.format(Locale.US,"%02X ",n.logicalAddress));
                        report.append("\nObservação: Installation List indica configuração lógica, não presença física atual.\n");
                    } else report.append("Gateway respondeu ao TesterPresent, mas DID 2A26 não foi validado; isso não invalida a presença do Gateway.\n");
                } else report.append("Gateway 710/77A: sem resposta física confirmada; DID 2A26 não consultado.\n");
            } catch(Exception e) {
                report.append("ERRO/INTERRUPÇÃO: ").append(e.getClass().getSimpleName()).append(" — ").append(e.getMessage()).append("\n");
            } finally {
                try { send("ATCP 00",250); send("ATSP0",250); send("ATSH 7DF",350); send("ATCRA",350); send("ATH0",350); send("ATS0",350); } catch(Exception ignored) {}
            }
            lastDiscoveredModules=found;
            getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putString(ECU_MODULES_PREF,found.toString()).apply();
            report.append("\nCLASSIFICAÇÃO: presença física confirmada = resposta ao TesterPresent; identidade confirmada = VIN DID positivo; dados de DTC/status validados = resposta 59 02 completa.\n");
            report.append("Silêncio, NRC, timeout, cabeçalho ausente ou ISO-TP incompleto nunca será exibido como módulo inexistente ou sem falhas.\n");
            report.append("Se o ELM remover os cabeçalhos CAN, a resposta 7E 00 não será atribuída a nenhum endpoint: resultado inconclusivo por segurança.\n");
            report.append("Nenhum comando de escrita, coding, adaptação, Security Access ou limpeza foi transmitido.\n");
            final String result=report.toString();
            append("VAG DISCOVERY FINALIZADA: "+responders.size()+" endpoints com resposta em "+probes+" probes.");
            ui(() -> new AlertDialog.Builder(this).setTitle("VARREDURA VAG MULTIPROTOCOLO")
                .setMessage(result).setPositiveButton("OK",null).show());
            showResult(result);
        });
    }

    private String buildModuleReport(JSONArray modules) {
        int responded = 0, positive = 0, pending = 0, negative = 0;
        StringBuilder b = new StringBuilder("ENDPOINTS CONSULTADOS: ").append(modules.length()).append("\n");
        for (int i=0;i<modules.length();i++) {
            JSONObject m = modules.optJSONObject(i); if (m == null) continue;
            String state = m.optString("classification", "SEM_CLASSIFICAÇÃO");
            if (m.optBoolean("responded", false)) responded++;
            if (state.equals("RESPOSTA_UDS_POSITIVA_DID_F190")) positive++;
            if (state.equals("RESPOSTA_UDS_PENDENTE_DID_F190")) pending++;
            if (state.equals("RESPOSTA_UDS_NEGATIVA_DID_F190")) negative++;
            b.append(m.optString("requestId", "—")).append(" → ")
             .append(m.optString("expectedResponseId", "—")).append(" — ");
            if (state.equals("RESPOSTA_UDS_POSITIVA_DID_F190")) b.append("VIN UDS lido (62 F1 90)");
            else if (state.equals("RESPOSTA_UDS_PENDENTE_DID_F190")) b.append("ECU pediu mais tempo (NRC 0x78); resposta final não confirmada");
            else if (state.equals("RESPOSTA_UDS_NEGATIVA_DID_F190")) b.append("ECU respondeu negativamente ao DID F190");
            else if (state.equals("QUADRO_CAN_NO_ENDPOINTO_SEM_UDS_VALIDO")) b.append("quadro recebido; serviço ainda não identificado");
            else b.append("sem resposta confirmada");
            String nrc = m.optString("nrc", ""); if (!nrc.isEmpty()) b.append("\n   ").append(nrc);
            b.append("\n");
        }
        b.append("\nRESPOSTAS OBSERVADAS: ").append(responded)
         .append(" | VIN UDS positivo: ").append(positive)
         .append(" | UDS pendente: ").append(pending)
         .append(" | UDS negativo: ").append(negative);
        b.append("\nSilêncio ou NRC não prova ausência física do módulo.");
        return b.toString();
    }

    private void showDiscoveredModules() {
        String raw = getSharedPreferences(PREFS_UI, MODE_PRIVATE).getString(ECU_MODULES_PREF, "[]");
        try { lastDiscoveredModules = new JSONArray(raw); } catch (Exception ignored) { lastDiscoveredModules = new JSONArray(); }
        new AlertDialog.Builder(this).setTitle("MÓDULOS IDENTIFICADOS")
            .setMessage(lastDiscoveredModules.length() == 0 ? "Nenhuma varredura real salva nesta sessão. Use IDENTIFICAR MÓDULOS DO VEÍCULO." : buildModuleReport(lastDiscoveredModules))
            .setPositiveButton("OK", null).show();
    }

    private JSONArray readCustomTransactions() {
        File f = new File(getFilesDir(), ECU_TXN_FILE);
        if (!f.exists()) return new JSONArray();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            StringBuilder b = new StringBuilder(); String line; while ((line = r.readLine()) != null) b.append(line);
            return new JSONArray(b.toString());
        } catch (Exception e) { return new JSONArray(); }
    }

    private void appendCustomTransaction(JSONObject transaction) throws Exception {
        JSONArray all = readCustomTransactions(); all.put(transaction);
        File f = new File(getFilesDir(), ECU_TXN_FILE);
        try (FileOutputStream o = new FileOutputStream(f, false)) { o.write(all.toString(2).getBytes(StandardCharsets.UTF_8)); o.flush(); }
    }

    /**
     * Backup local dos dados observáveis pelo V12. Não é um dump completo de ECU
     * nem uma cópia de codificações/adaptações que o ELM não tenha lido.
     */
    private JSONObject buildVehicleStateSnapshot() throws org.json.JSONException {
        JSONObject j = new JSONObject();
        j.put("schema", "v12.vehicle-state-backup.v1");
        j.put("createdAt", new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US).format(new Date()));
        j.put("appVersion", BuildConfig.VERSION_NAME);
        j.put("vin", lastVin == null ? "—" : lastVin);
        j.put("connection", connected ? "ELM_CONNECTED" : simulationMode ? "SIMULATION" : "DISCONNECTED");
        j.put("simulationMode", simulationMode);
        j.put("ecuResponding", ecuResponding);
        j.put("protocol", lastProtocol == null ? "" : lastProtocol);
        j.put("rpm", lastRpm);
        j.put("speedKmh", lastSpeed);
        j.put("engineLoadPct", lastLoad);
        j.put("coolantTempC", lastCoolant);
        j.put("intakeTempC", lastIntake);
        j.put("oilTempC", lastOilTemp);
        j.put("fuelPct", lastFuel);
        j.put("voltageV", lastVolt);
        j.put("throttlePct", lastThrottle);
        j.put("mapKpa", lastMap);
        j.put("baroKpa", lastBaro);
        j.put("boostBar", lastBoost);
        j.put("oilLevel", lastOilLevel == null ? "—" : lastOilLevel);
        j.put("dtcCodes", new JSONArray(new ArrayList<>(lastDtcCodes)));
        j.put("discoveredModules", new JSONArray(lastDiscoveredModules.toString()));
        j.put("customTransactions", readCustomTransactions());
        j.put("backupPurpose", "Observed-state snapshot plus per-parameter originals captured by validated custom transactions, if any.");
        j.put("capturedFields", new JSONArray(Arrays.asList("VIN", "connection", "protocol", "RPM", "speed", "engine load", "coolant temperature", "intake temperature", "oil temperature when supported", "fuel level when supported", "voltage", "throttle", "MAP", "barometric pressure", "boost derived from MAP/BARO", "DTCs previously read by V12")));
        j.put("limitations", "Snapshot of data currently known to V12. Not a complete ECU coding/adaptation backup. Only parameters explicitly read and validated before a future write operation can be candidates for rollback.");
        return j;
    }

    private void createVehicleStateBackup() {
        if (simulationMode) {
            new AlertDialog.Builder(this).setTitle("BACKUP EM SIMULAÇÃO")
                .setMessage("O V12 está em modo de simulação. O arquivo será marcado como simulado e não deve ser usado como estado real do veículo. Conecte ao ELM e confirme a comunicação com a ECU para criar um backup real.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("SALVAR COMO SIMULAÇÃO", (d,w) -> saveVehicleStateBackup())
                .show();
            return;
        }
        if (!connected || !ecuResponding) {
            new AlertDialog.Builder(this).setTitle("VEÍCULO NÃO CONFIRMADO")
                .setMessage("Não há comunicação confirmada com a ECU. Posso salvar um snapshot parcial, mas ele será marcado como desconectado e não servirá como backup confiável para reversão.")
                .setNegativeButton("CANCELAR", null)
                .setPositiveButton("SALVAR SNAPSHOT PARCIAL", (d,w) -> saveVehicleStateBackup())
                .show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("CRIAR BACKUP")
            .setMessage("O V12 salvará o VIN, estado da conexão, telemetria conhecida e códigos de falha já lidos. Isso ainda não inclui todas as codificações/adaptações das centrais. Deseja continuar?")
            .setNegativeButton("CANCELAR", null)
            .setPositiveButton("CRIAR BACKUP", (d,w) -> saveVehicleStateBackup())
            .show();
    }

    private void saveVehicleStateBackup() {
        try {
            JSONObject snapshot = buildVehicleStateSnapshot();
            File file = vehicleBackupFile();
            try (FileOutputStream fos = new FileOutputStream(file, false)) {
                fos.write(snapshot.toString(2).getBytes(StandardCharsets.UTF_8));
                fos.flush();
            }
            String msg = "Backup salvo localmente.\n\nArquivo: " + file.getName() + "\nVIN: " + snapshot.optString("vin", "—") + "\nEstado: " + snapshot.optString("connection") + "\n\nLimite: o arquivo registra o estado observado pelo V12; não é uma imagem integral das centrais nem garante restauração automática de codificações.";
            new AlertDialog.Builder(this).setTitle("BACKUP CRIADO").setMessage(msg)
                .setNeutralButton("COMPARTILHAR JSON", (d,w) -> shareVehicleBackup(file))
                .setPositiveButton("OK", null).show();
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("FALHA NO BACKUP")
                .setMessage("Não foi possível salvar o snapshot: " + e.getClass().getSimpleName() + " — " + String.valueOf(e.getMessage()))
                .setPositiveButton("OK", null).show();
        }
    }

    private void shareVehicleBackup(File file) {
        try {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("application/json");
            intent.putExtra(Intent.EXTRA_SUBJECT, "V12 — backup do estado observado do veículo");
            StringBuilder jsonText = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
                String line; while ((line = br.readLine()) != null) jsonText.append(line).append('\n');
            }
            intent.putExtra(Intent.EXTRA_TEXT, jsonText.toString());
            startActivity(Intent.createChooser(intent, "Compartilhar JSON do backup"));
        } catch (Exception e) { toast("Backup salvo no armazenamento interno do aplicativo; compartilhamento indisponível neste dispositivo."); }
    }

    private void reviewVehicleStateBackup() {
        File file = vehicleBackupFile();
        if (!file.exists()) {
            new AlertDialog.Builder(this).setTitle("NENHUM BACKUP ENCONTRADO")
                .setMessage("Crie um backup antes de solicitar a consulta ou reversão. A restauração de codificações exige que os valores originais tenham sido lidos e registrados individualmente antes da alteração.")
                .setPositiveButton("ENTENDI", null).show();
            return;
        }
        try {
            StringBuilder content = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
                String line; while ((line = br.readLine()) != null) content.append(line).append('\n');
            }
            JSONObject j = new JSONObject(content.toString());
            JSONArray modules = j.optJSONArray("discoveredModules");
            JSONArray transactions = j.optJSONArray("customTransactions");
            int moduleCount = modules == null ? 0 : modules.length();
            int txnCount = transactions == null ? 0 : transactions.length();
            int rollbackReady = 0;
            if (transactions != null) for (int i=0;i<transactions.length();i++) { JSONObject t=transactions.optJSONObject(i); if(t!=null && t.optBoolean("rollbackReady",false)) rollbackReady++; }
            String report = "Criado em: " + j.optString("createdAt", "—") +
                "\nVIN: " + j.optString("vin", "—") +
                "\nConexão registrada: " + j.optString("connection", "—") +
                "\nProtocolo: " + j.optString("protocol", "—") +
                "\nRPM: " + j.optDouble("rpm", -1) +
                "\nVelocidade: " + j.optDouble("speedKmh", -1) + " km/h" +
                "\nTemperatura do líquido: " + j.optDouble("coolantTempC", -1) + " °C" +
                "\nTensão: " + j.optDouble("voltageV", -1) + " V" +
                "\nDTCs capturados anteriormente: " + j.optJSONArray("dtcCodes") +
                "\nMódulos registrados: " + moduleCount +
                "\nOperações de customização registradas: " + txnCount +
                "\nOperações com retorno validado: " + rollbackReady +
                "\n\nESTADO DA REVERSÃO: " + (rollbackReady > 0 ? "há operações marcadas como reversíveis; a validação do VIN, módulo e conexão ainda é obrigatória" : "NÃO DISPONÍVEL — este backup não contém parâmetros de ECU com valor original e procedimento de retorno validado") +
                "\n\nO snapshot de telemetria não é uma cópia integral das centrais. Não será enviado comando de restauração quando não houver um parâmetro de escrita mapeado e validado.";
            new AlertDialog.Builder(this).setTitle("BACKUP / REVERSÃO")
                .setMessage(report)
                .setNeutralButton("COMPARTILHAR JSON", (d,w) -> shareVehicleBackup(file))
                .setNegativeButton("FECHAR", null)
                .setPositiveButton("VERIFICAR RESTAURAÇÃO", (d,w) -> requestVehicleRestore(j))
                .show();
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("BACKUP INVÁLIDO")
                .setMessage("O arquivo de backup não pôde ser interpretado: " + String.valueOf(e.getMessage()))
                .setPositiveButton("OK", null).show();
        }
    }

    private void requestVehicleRestore(JSONObject backup) {
        JSONArray tx = backup.optJSONArray("customTransactions");
        ArrayList<JSONObject> eligible = new ArrayList<>();
        if (tx != null) for (int i=0;i<tx.length();i++) {
            JSONObject item = tx.optJSONObject(i);
            if (item != null && item.optBoolean("rollbackReady", false)) eligible.add(item);
        }
        if (eligible.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("RESTAURAÇÃO BLOQUEADA COM SEGURANÇA")
                .setMessage("Não há parâmetros de ECU neste backup com valor original, serviço de escrita e procedimento de retorno validados. O V12 não vai inventar comandos nem tentar restaurar por aproximação.\n\nQuando houver uma operação suportada e validada, o backup registrará o valor anterior e permitirá revisar o retorno antes de qualquer transmissão.")
                .setPositiveButton("ENTENDI", null).show();
            return;
        }
        new AlertDialog.Builder(this).setTitle("VALIDAR RESTAURAÇÃO")
            .setMessage("Foram encontrados " + eligible.size() + " registro(s) marcados como reversíveis. Antes de transmitir qualquer retorno, confirme o mesmo VIN, módulo responsivo e valor atual do parâmetro. Esta versão ainda não envia uma restauração genérica automática.")
            .setPositiveButton("OK", null).show();
    }

    /**
      * Catálogo inicial de personalização VW. Não envia comandos de escrita.
      * Cada função só deve ser habilitada depois de validar módulo, protocolo,
      * procedimento, valor original e compatibilidade com o veículo conectado.
      */
     private void showCustomizacaoCatalog(){
         final String[] categories={
             "ILUMINAÇÃO EXTERNA E INTERNA",
             "PAINEL E INDICAÇÕES",
             "CLIMATIZAÇÃO E RECIRCULAÇÃO",
             "TRAVAS E CONFORTO",
             "ALERTAS E SINALIZAÇÕES",
             "OUTRAS FUNÇÕES DO MÓDULO"
         };
         new android.app.AlertDialog.Builder(this)
             .setTitle("CUSTOMIZAÇÃO VW • VIRTUS 2023/2024")
             .setItems(categories,(dialog,which)->{
                 String category=categories[which];
                 String message="Categoria: "+category+"\n\n"+
                     "Estado: catálogo em preparação; nenhuma alteração foi enviada ao veículo.\n\n"+
                     "Antes de habilitar uma função, o V12 precisa identificar o módulo e validar o procedimento de leitura/gravação para esta configuração. O ELM327 de placa dupla pode ter suporte variável conforme protocolo, módulo e proteção de acesso.\n\n"+
                     "A próxima etapa é preencher esta categoria com funções verificadas e apresentar o valor atual e o valor original antes de qualquer gravação.";
                 new android.app.AlertDialog.Builder(this).setTitle(category).setMessage(message).setPositiveButton("OK",null).show();
             })
             .setNegativeButton("FECHAR",null)
             .show();
     }

    private LinearLayout buildDiagnosticScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG);
        diagnosticScroll=new ScrollView(this); diagnosticScroll.setFillViewport(false); diagnosticScroll.setBackgroundColor(BG); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(0,0,0,dp(10)); diagnosticScroll.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(diagnosticScroll,new LinearLayout.LayoutParams(-1,0,1));
        diagSection=section("DIAGNÓSTICO • ORGANIZADO POR FUNÇÃO"); addFull(root,diagSection);
        TextView hint=tv("Leitura OBD-II, VAG, DTC, evidências e comunicação. CAN Investigator permanece acessível como ferramenta técnica.",9); hint.setTextColor(MUTED); hint.setPadding(dp(4),dp(2),dp(4),dp(8)); addFull(root,hint);
        addUnifiedDiagnosticSelector(root,CARD2,CYAN,WHITE,MUTED);
        LinearLayout fault=card(CARD2); fault.setPadding(dp(12),dp(9),dp(12),dp(9)); TextView ft=tv("QUADRO DE FALHAS • DTC",13); ft.setTextColor(CYAN); ft.setTypeface(null,android.graphics.Typeface.BOLD); fault.addView(ft);
        dtcStatusView=tv("STATUS: AGUARDANDO LEITURA",10); dtcStatusView.setTextColor(WHITE); dtcStatusView.setTypeface(null,android.graphics.Typeface.BOLD); fault.addView(dtcStatusView);
        dtcCodesView=tv("CÓDIGOS: nenhum DTC lido nesta sessão",11); dtcCodesView.setTextColor(MUTED); dtcCodesView.setPadding(dp(4),dp(4),dp(4),dp(4)); fault.addView(dtcCodesView);
        ScrollView dtcCodesScroll=new ScrollView(this); dtcCodesScroll.setFillViewport(true); dtcCodesScroll.setVerticalScrollBarEnabled(true); dtcCodesScroll.setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS); dtcCodesScroll.setBackgroundColor(Color.TRANSPARENT);
        dtcListContainer=new LinearLayout(this); dtcListContainer.setOrientation(LinearLayout.VERTICAL); dtcListContainer.setPadding(dp(2),dp(2),dp(2),dp(2)); dtcCodesScroll.addView(dtcListContainer,new ScrollView.LayoutParams(-1,-2)); LinearLayout.LayoutParams dtcScrollLp=new LinearLayout.LayoutParams(-1,dp(118)); dtcScrollLp.setMargins(0,dp(2),0,dp(2)); fault.addView(dtcCodesScroll,dtcScrollLp);
        dtcRawView=tv("RAW: —",8.5f); dtcRawView.setTextColor(MUTED); dtcRawView.setTypeface(android.graphics.Typeface.MONOSPACE); dtcRawView.setMaxLines(4); fault.addView(dtcRawView);
        LinearLayout dtcActions=row(); clearDtcButton=btn("APAGAR TODOS"); clearDtcButton.setTextColor(Color.rgb(255,210,210)); bindClick(clearDtcButton,()->clearAllDtc()); selectDtcButton=btn("SELECIONAR DTCs"); selectDtcButton.setTextColor(CYAN); bindClick(selectDtcButton,()->toggleDtcSelectionMode()); addHalf(dtcActions,clearDtcButton); addHalf(dtcActions,selectDtcButton); addFull(fault,dtcActions); addFull(root,fault);
        LinearLayout vagCard=card(CARD2); vagCard.setPadding(dp(12),dp(9),dp(12),dp(9)); TextView vt=tv("VAG DIAGNOSTIC EXPLORER • SOMENTE LEITURA",12); vt.setTextColor(CYAN); vt.setTypeface(null,android.graphics.Typeface.BOLD); vagCard.addView(vt); vagExplorerResult=tv("Aguardando exploração. Nenhum comando de escrita será enviado.",9); vagExplorerResult.setTextColor(MUTED); vagExplorerResult.setTypeface(android.graphics.Typeface.MONOSPACE); vagExplorerResult.setTextIsSelectable(true); vagExplorerResult.setPadding(0,dp(5),0,dp(5)); vagExplorerResult.setSingleLine(false); vagCard.addView(vagExplorerResult,new LinearLayout.LayoutParams(-1,-2)); addFull(root,vagCard);
        LinearLayout diagResultCard=card(CARD2); diagResultCard.setPadding(dp(12),dp(8),dp(12),dp(8)); TextView drh=tv("RESULTADO DO TESTE",11); drh.setTextColor(CYAN); drh.setTypeface(null,android.graphics.Typeface.BOLD); diagResultCard.addView(drh); diagnosticResult=tv("Nenhum teste executado nesta sessão.",9); diagnosticResult.setTextColor(WHITE); diagnosticResult.setTypeface(android.graphics.Typeface.MONOSPACE); diagnosticResult.setTextIsSelectable(true); diagnosticResult.setPadding(0,dp(5),0,dp(5)); diagnosticResult.setSingleLine(false); diagResultCard.addView(diagnosticResult,new LinearLayout.LayoutParams(-1,-2)); addFull(root,diagResultCard);
        return screen;
    }
    private final LinkedHashMap<String,CheckBox> unifiedReadOptions = new LinkedHashMap<>();
    private void addUnifiedDiagnosticSelector(LinearLayout root,int cardColor,int accent,int white,int muted){
        LinearLayout panel=card(cardColor); panel.setPadding(dp(12),dp(10),dp(12),dp(10));
        TextView title=tv("LEITURA • SELECIONE O QUE DESEJA CONSULTAR",12); title.setTextColor(accent); title.setTypeface(null,android.graphics.Typeface.BOLD); panel.addView(title);
        TextView desc=tv("Uma única sessão de leitura. Selecione os grupos; os resultados serão apresentados juntos, preservando respostas RAW e estados sem resposta.",9); desc.setTextColor(muted); panel.addView(desc);
        unifiedReadOptions.clear();
        addUnifiedOption(panel,"DTC confirmados • OBD Mode 03",true);
        addUnifiedOption(panel,"DTC pendentes • OBD Mode 07",true);
        addUnifiedOption(panel,"DTC permanentes • OBD Mode 0A",true);
        addUnifiedOption(panel,"Status e readiness • Mode 01",true);
        addUnifiedOption(panel,"Freeze Frame • Mode 02",false);
        addUnifiedOption(panel,"Identificação do veículo • VIN",true);
        addUnifiedOption(panel,"Dados ao vivo • RPM / velocidade / temperatura",false);
        addUnifiedOption(panel,"Varredura VAG UDS • ECUs conhecidas",false);
        addUnifiedOption(panel,"Gateway • Installation List DID 2A26 (experimental)",false);
        addUnifiedOption(panel,"Explorador VAG • DTC por status UDS",false);
        addUnifiedOption(panel,"Investigação EPC • pacote completo de evidências",false);
        LinearLayout actions=row(); Button all=btn("LEITURA COMPLETA"); Button faults=btn("SOMENTE FALHAS"); Button custom=btn("LER SELEÇÃO");
        all.setTextSize(9); faults.setTextSize(9); custom.setTextSize(9);
        bindClick(all,()->{for(CheckBox c:unifiedReadOptions.values())c.setChecked(true);runUnifiedDiagnostic(true);});
        bindClick(faults,()->{for(Map.Entry<String,CheckBox> e:unifiedReadOptions.entrySet())e.getValue().setChecked(e.getKey().startsWith("DTC "));runUnifiedDiagnostic(false);});
        bindClick(custom,()->runUnifiedDiagnostic(false));
        addHalf(actions,all); addHalf(actions,faults); addFull(panel,actions); addFull(panel,custom); addFull(root,panel);
    }
    private void addUnifiedOption(LinearLayout panel,String label,boolean checked){
        CheckBox c=new CheckBox(this); c.setText(label); c.setTextColor(Color.WHITE); c.setTextSize(10); c.setButtonTintList(android.content.res.ColorStateList.valueOf(SIM_CYAN)); c.setChecked(checked); unifiedReadOptions.put(label,c); panel.addView(c,new LinearLayout.LayoutParams(-1,dp(38)));
    }
    private void runUnifiedDiagnostic(boolean complete){
        if(operationRunning){setStatus("Já existe uma operação em andamento");return;}
        final LinkedHashMap<String,Boolean> selected=new LinkedHashMap<>(); for(Map.Entry<String,CheckBox> e:unifiedReadOptions.entrySet())selected.put(e.getKey(),e.getValue().isChecked());
        runOp(complete?"LEITURA COMPLETA CONSOLIDADA":"LEITURA PERSONALIZADA CONSOLIDADA",()->{
            StringBuilder report=new StringBuilder("V12 • LEITURA CONSOLIDADA\nMODO: ").append(simulationMode?"SIMULAÇÃO":"REAL").append("\nVIN conhecido: ").append(lastVin).append("\n\n");
            String[][] jobs={{"DTC confirmados • OBD Mode 03","03"},{"DTC pendentes • OBD Mode 07","07"},{"DTC permanentes • OBD Mode 0A","0A"},{"Status e readiness • Mode 01","0101"},{"Freeze Frame • Mode 02","0200"},{"Identificação do veículo • VIN","0902"},{"Dados ao vivo • RPM / velocidade / temperatura","010C|010D|0105"}};
            for(String[] job:jobs){if(!Boolean.TRUE.equals(selected.get(job[0])))continue; report.append("\n=== ").append(job[0]).append(" ===\n"); for(String cmd:job[1].split("\\|")){String response=send(cmd,cmd.equals("0902")?2600:1800);report.append(cmd).append(" -> ").append(response==null||response.trim().isEmpty()?"SEM RESPOSTA":response).append("\n");}}
            if(Boolean.TRUE.equals(selected.get("Varredura VAG UDS • ECUs conhecidas"))){report.append("\n=== VAG UDS ===\nA varredura UDS será executada apenas nos endereços conhecidos e configurados pelo mecanismo VAG existente.\n"); String[] ids={"7E0","7E1"}; for(String id:ids){String h=send("ATSH"+id,800);String vin=send("22F190",1800);report.append(id).append(" header=").append(h).append(" VIN DID=").append(vin).append("\n");} send("ATSH7DF",800);}
            report.append("\nNOTA: SEM RESPOSTA não significa módulo inexistente. Nenhum comando de gravação/limpeza foi enviado nesta etapa OBD.\n"); showResult(report.toString());
        });
        // As rotinas avançadas existentes são enfileiradas depois da leitura OBD.
        // O executor io é single-thread: cada runOp termina antes da próxima rotina iniciar.
        if(Boolean.TRUE.equals(selected.get("Gateway • Installation List DID 2A26 (experimental)"))) io.execute(this::readGatewayInstallationList);
        if(Boolean.TRUE.equals(selected.get("Explorador VAG • DTC por status UDS"))) io.execute(this::vagFocusedScan);
        if(Boolean.TRUE.equals(selected.get("Investigação EPC • pacote completo de evidências"))) io.execute(this::investigateEpc);
    }

    private void addDiagSection(LinearLayout root,int cardColor,int accent,String title,String[] labels,Runnable[] actions){
        LinearLayout box=card(cardColor); box.setPadding(dp(10),dp(7),dp(10),dp(8));
        TextView h=tv(title,11.5f); h.setTextColor(accent); h.setTypeface(null,android.graphics.Typeface.BOLD); h.setGravity(Gravity.CENTER); h.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        box.addView(h,new LinearLayout.LayoutParams(-1,dp(32)));
        LinearLayout row=null;
        final int BUTTON_H=dp(78);
        for(int i=0;i<labels.length;i++){
            if(i%2==0){
                row=row();
                box.addView(row,new LinearLayout.LayoutParams(-1,BUTTON_H));
            }
            Button b=diagButton(labels[i],accent);
            bindClick(b,actions[i]);
            if(i==labels.length-1 && labels.length%2==1){
                // Último item ímpar ocupa a largura inteira, mantendo a mesma altura visual.
                row.removeAllViews();
                LinearLayout.LayoutParams full=new LinearLayout.LayoutParams(-1,BUTTON_H);
                full.setMargins(dp(3),0,dp(3),0);
                row.addView(b,full);
            }else addHalf(row,b);
        }
        addFull(root,box);
    }

    private Button diagButton(String label,int accent){
        Button b=btn(label); b.setTextSize(9.5f); b.setSingleLine(false); b.setGravity(Gravity.CENTER); b.setPadding(dp(6),dp(5),dp(6),dp(5));
        b.setMinHeight(dp(74)); b.setMinimumHeight(dp(74));
        int iconRes=diagIconFor(label);
        if(iconRes!=0){
            android.graphics.drawable.Drawable d=getDrawable(iconRes);
            if(d!=null){ d=d.mutate(); if(Build.VERSION.SDK_INT>=21)d.setTint(accent); b.setCompoundDrawablesWithIntrinsicBounds(null,d,null,null); b.setCompoundDrawablePadding(dp(3)); }
        }
        return b;
    }

    private int diagIconFor(String label){
        String s=label==null?"":label.toUpperCase(Locale.US);
        if(s.contains("VIN")) return R.drawable.ic_vehicle;
        if(s.contains("SONDA") || s.contains("READINESS")) return R.drawable.ic_gauge;
        if(s.contains("CAN") || s.contains("UDS")) return R.drawable.ic_can;
        if(s.contains("BIBLIOTECA") || s.contains("FREEZE") || s.contains("LER DADOS")) return R.drawable.ic_document;
        if(s.contains("ESTUDO") || s.contains("MÓDULOS")) return R.drawable.ic_engine;
        if(s.contains("IGNIÇÃO")) return R.drawable.ic_settings;
        if(s.contains("DIAGNÓSTICO") || s.equals("DTC")) return R.drawable.ic_engine;
        return R.drawable.ic_chart;
    }

    private LinearLayout buildCanScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG); ScrollView sv=new ScrollView(this); sv.setFillViewport(true); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); sv.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        canSection=section("CAN INVESTIGATOR • SOMENTE LEITURA"); addFull(root,canSection);
        LinearLayout canStatus=card(CARD2); canStatus.setPadding(dp(12),dp(10),dp(12),dp(10)); TextView cst=tv("STATUS DA CAPTURA CAN",12); cst.setTextColor(CYAN); cst.setTypeface(null,android.graphics.Typeface.BOLD); canStatus.addView(cst); stats=tv("RAW: 0 • FRAMES: 0 • IDs: 0 • BYTES: 0",18); stats.setTextColor(WHITE); stats.setTypeface(null,android.graphics.Typeface.BOLD); stats.setSingleLine(true); canStatus.addView(stats); TextView canHint=tv("Monitor All • sem transmissão CAN arbitrária",10); canHint.setTextColor(MUTED); canStatus.addView(canHint); addFull(root,canStatus);
        LinearLayout diag=card(CARD2); diag.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView dt=tv("DIAGNÓSTICO DO MOTOR CAN",11); dt.setTextColor(CYAN); dt.setTypeface(null,android.graphics.Typeface.BOLD); diag.addView(dt);
        canDiag=tv("ELM: —\nPROTOCOLO: —\nCMD: —\nRX: —\nESTADO: pronto",9); canDiag.setTextColor(MUTED); canDiag.setTypeface(android.graphics.Typeface.MONOSPACE); canDiag.setPadding(0,dp(4),0,0); diag.addView(canDiag); addFull(root,diag);
        LinearLayout r6=row(); Button cap=btn("▶  CAPTURAR CAN"); bindClick(cap,()->startMonitor()); Button stop=btn("■  FINALIZAR"); bindClick(stop,()->stopMonitor()); addHalf(r6,cap); addHalf(r6,stop); addFull(root,r6);
        LinearLayout analyzer=card(CARD2); analyzer.setPadding(dp(12),dp(10),dp(12),dp(10));
        TextView at=tv("CAN INVESTIGATOR 2.1 • CAN LAB • TRÁFEGO EM TEMPO REAL",12); at.setTextColor(CYAN); at.setTypeface(null,android.graphics.Typeface.BOLD); analyzer.addView(at);
        TextView ah=tv("Top IDs por frequência • diagnóstico ATMA/ATMR/ATCRA • somente leitura",9); ah.setTextColor(MUTED); analyzer.addView(ah);
        canFilterInput=new EditText(this); canFilterInput.setSingleLine(true); canFilterInput.setHint("Filtrar ID ou dados (ex.: 7E8 / 3E)"); canFilterInput.setTextColor(WHITE); canFilterInput.setHintTextColor(MUTED); canFilterInput.setTextSize(11); canFilterInput.setPadding(dp(10),0,dp(10),0); canFilterInput.setBackground(cardBg(Color.rgb(3,24,43),12,CYAN2)); analyzer.addView(canFilterInput,new LinearLayout.LayoutParams(-1,dp(44)));
        canTable=tv("AGUARDANDO CAPTURA CAN…",10); canTable.setTextColor(WHITE); canTable.setTextSize(10); canTable.setTypeface(android.graphics.Typeface.MONOSPACE); canTable.setPadding(dp(4),dp(8),dp(4),dp(4)); canTable.setGravity(Gravity.TOP|Gravity.START); analyzer.addView(canTable,new LinearLayout.LayoutParams(-1,dp(168)));
        canFilterHint=tv("0 IDs • 0 frames • análise atualizada durante a captura",9); canFilterHint.setTextColor(MUTED); analyzer.addView(canFilterHint); addFull(root,analyzer);
        canFilterInput.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){updateCanTable();} public void afterTextChanged(android.text.Editable e){}});
        LinearLayout r7=row(); Button lock=btn("LOCK"); bindClick(lock,()->mark("LOCK")); Button unlock=btn("UNLOCK"); bindClick(unlock,()->mark("UNLOCK")); addHalf(r7,lock); addHalf(r7,unlock); addFull(root,r7);
        LinearLayout r8=row(); Button ss=btn("START / STOP"); bindClick(ss,()->mark("START-STOP")); Button trunk=btn("PORTA-MALAS"); bindClick(trunk,()->mark("PORTA-MALAS")); addHalf(r8,ss); addHalf(r8,trunk); addFull(root,r8);
        LinearLayout r9=row(); Button farol=btn("FAROL / OUTRO"); bindClick(farol,()->mark("FAROL-OUTRO")); Button analyze=btn("ANALISAR DIFERENÇAS"); bindClick(analyze,()->analyze()); addHalf(r9,farol); addHalf(r9,analyze); addFull(root,r9);
        LinearLayout r10=row(); Button clearCan=btn("LIMPAR CAPTURA"); bindClick(clearCan,()->clearCanCapture()); Button copyCan=btn("COPIAR RESUMO CAN"); bindClick(copyCan,()->copyCanSummary()); addHalf(r10,clearCan); addHalf(r10,copyCan); addFull(root,r10);
        return screen;
    }

    private LinearLayout buildConfigScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG); ScrollView sv=new ScrollView(this); sv.setFillViewport(true); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); sv.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        configSection=section("CONFIGURAÇÕES"); addFull(root,configSection);
        // FIX10.22 / Code182: preferências persistentes ficam somente em Configurações.
        LinearLayout pedalConfigRow=card(CARD2); pedalConfigRow.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView pedalConfigTitle=tv("CALIBRAÇÃO DO PEDAL",13); pedalConfigTitle.setTextColor(WHITE); pedalConfigTitle.setTypeface(null,android.graphics.Typeface.BOLD); pedalConfigRow.addView(pedalConfigTitle);
        TextView pedalConfigSub=tv("Escolha explicitamente a fonte do sinal e calibre 0% / 100%. Não há troca automática de PID.",9); pedalConfigSub.setTextColor(MUTED); pedalConfigRow.addView(pedalConfigSub);
        Button pedalSourceButton=btn("FONTE DO PEDAL: "+getPedalSourceLabel()); bindClick(pedalSourceButton,()->showPedalSourceDialog(pedalSourceButton)); pedalConfigRow.addView(pedalSourceButton,new LinearLayout.LayoutParams(-1,dp(46)));
        Button pedalCalButton=btn("CALIBRAR FONTE SELECIONADA • 0% / 50% / 100%"); bindClick(pedalCalButton,()->showPedalCalibrationDialog()); pedalConfigRow.addView(pedalCalButton,new LinearLayout.LayoutParams(-1,dp(48)));
        Button pedalTestButton=btn("TESTAR PROGRESSÃO DO PEDAL • 0–100%"); bindClick(pedalTestButton,()->showAcceleratorProgressionTest()); pedalConfigRow.addView(pedalTestButton,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView pedalTestHint=tv("Leitura somente. Veículo parado, ignição ligada e motor desligado. Captura manual em 0%, 25%, 50%, 75% e 100%; não envia comandos de calibração à ECU.",8.5f); pedalTestHint.setTextColor(MUTED); pedalConfigRow.addView(pedalTestHint); addFull(root,pedalConfigRow);
        LinearLayout logMaintenanceRow=card(CARD2); logMaintenanceRow.setPadding(dp(12),dp(8),dp(12),dp(8)); TextView logMaintenanceTitle=tv("MANUTENÇÃO DA PASTA LOG",13); logMaintenanceTitle.setTextColor(WHITE); logMaintenanceTitle.setTypeface(null,android.graphics.Typeface.BOLD); logMaintenanceRow.addView(logMaintenanceTitle); TextView logMaintenanceSub=tv("Localiza CSVs com conteúdo idêntico, mesmo com nomes diferentes. Nada será apagado sem sua confirmação.",9); logMaintenanceSub.setTextColor(MUTED); logMaintenanceRow.addView(logMaintenanceSub); Button checkDuplicates=btn("VERIFICAR CSVs DUPLICADOS"); bindClick(checkDuplicates,()->deduplicateIdenticalLogFiles()); logMaintenanceRow.addView(checkDuplicates,new LinearLayout.LayoutParams(-1,dp(48))); addFull(root,logMaintenanceRow);
        LinearLayout fuelDefaultRow=card(CARD2); fuelDefaultRow.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView fuelDefaultTitle=tv("COMBUSTÍVEL PADRÃO",13); fuelDefaultTitle.setTextColor(WHITE); fuelDefaultTitle.setTypeface(null,android.graphics.Typeface.BOLD); fuelDefaultRow.addView(fuelDefaultTitle);
        TextView fuelDefaultSub=tv("Preferência salva localmente. Não é uma leitura de sensor/ECU.",9); fuelDefaultSub.setTextColor(MUTED); fuelDefaultRow.addView(fuelDefaultSub);
        Button fuelDefaultButton=btn(""); Runnable updateFuelDefaultLabel=()->fuelDefaultButton.setText("PADRÃO: "+getDefaultEthanolPct()+"% ETANOL • EDITAR"); updateFuelDefaultLabel.run(); bindClick(fuelDefaultButton,()->showDefaultEthanolDialog(updateFuelDefaultLabel)); fuelDefaultRow.addView(fuelDefaultButton,new LinearLayout.LayoutParams(-1,dp(48))); addFull(root,fuelDefaultRow);
        LinearLayout keepRow=card(CARD2); keepRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout keepInner=new LinearLayout(this); keepInner.setOrientation(LinearLayout.HORIZONTAL); keepInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout keepTexts=new LinearLayout(this); keepTexts.setOrientation(LinearLayout.VERTICAL); keepTexts.setGravity(Gravity.CENTER_VERTICAL);
        TextView keepTitle=tv("MANTER TELA LIGADA",13); keepTitle.setTextColor(WHITE); keepTitle.setTypeface(null,android.graphics.Typeface.BOLD); keepTitle.setSingleLine(true); TextView keepSub=tv("Evita o desligamento automático enquanto o VIRTUS ELM estiver aberto",9); keepSub.setTextColor(Color.rgb(145,181,210)); keepSub.setSingleLine(false); keepTexts.addView(keepTitle); keepTexts.addView(keepSub); keepInner.addView(keepTexts,new LinearLayout.LayoutParams(0,-2,1));
        android.widget.Switch keepSwitch=new android.widget.Switch(this); styleConfigSwitch(keepSwitch); keepSwitch.setText(""); keepSwitch.setChecked(isKeepScreenOnEnabled()); keepSwitch.setHapticFeedbackEnabled(isHapticEnabled()); keepSwitch.setOnCheckedChangeListener((buttonView,isChecked)->{ if(isHapticEnabled()) buttonView.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_KEEP_SCREEN,isChecked).apply(); applyKeepScreenPreference(); toast(isChecked ? "Tela permanecerá ligada" : "Desligamento automático restaurado"); }); keepInner.addView(keepSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); keepRow.addView(keepInner); addFull(root,keepRow);
        LinearLayout hapticRow=card(CARD2); hapticRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout hapticInner=new LinearLayout(this); hapticInner.setOrientation(LinearLayout.HORIZONTAL); hapticInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout hapticTexts=new LinearLayout(this); hapticTexts.setOrientation(LinearLayout.VERTICAL); hapticTexts.setGravity(Gravity.CENTER_VERTICAL);
        TextView hapticTitle=tv("FEEDBACK TÁTIL",13); hapticTitle.setTextColor(WHITE); hapticTitle.setTypeface(null,android.graphics.Typeface.BOLD); hapticTitle.setSingleLine(true); TextView hapticSub=tv("Ativa ou desativa a vibração ao tocar nos controles",9); hapticSub.setTextColor(MUTED); hapticSub.setSingleLine(false); hapticTexts.addView(hapticTitle); hapticTexts.addView(hapticSub); hapticInner.addView(hapticTexts,new LinearLayout.LayoutParams(0,-2,1));
        android.widget.Switch hapticSwitch=new android.widget.Switch(this); styleConfigSwitch(hapticSwitch); hapticSwitch.setText(""); hapticSwitch.setChecked(isHapticEnabled()); hapticSwitch.setHapticFeedbackEnabled(isHapticEnabled()); hapticSwitch.setOnCheckedChangeListener((buttonView,isChecked)->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_HAPTIC,isChecked).apply(); buttonView.setHapticFeedbackEnabled(isChecked); if(isChecked) buttonView.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); toast(isChecked ? "Feedback tátil ativado" : "Feedback tátil desativado"); }); hapticInner.addView(hapticSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); hapticRow.addView(hapticInner); addFull(root,hapticRow);
        LinearLayout rtRow=card(CARD2); rtRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout rtInner=new LinearLayout(this); rtInner.setOrientation(LinearLayout.HORIZONTAL); rtInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout rtTexts=new LinearLayout(this); rtTexts.setOrientation(LinearLayout.VERTICAL); rtTexts.setGravity(Gravity.CENTER_VERTICAL); TextView rtTitle=tv("DADOS EM TEMPO REAL",13); rtTitle.setTextColor(WHITE); rtTitle.setTypeface(null,android.graphics.Typeface.BOLD); TextView rtSub=tv("Atualiza os painéis e gráficos com os dados recebidos do ELM",9); rtSub.setTextColor(MUTED); rtTexts.addView(rtTitle); rtTexts.addView(rtSub); rtInner.addView(rtTexts,new LinearLayout.LayoutParams(0,-2,1)); android.widget.Switch rtSwitch=new android.widget.Switch(this); styleConfigSwitch(rtSwitch); rtSwitch.setText(""); rtSwitch.setChecked(isRealtimeDataEnabled()); rtSwitch.setHapticFeedbackEnabled(isHapticEnabled()); rtSwitch.setOnCheckedChangeListener((v,c)->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_REALTIME_DATA,c).apply(); if(c) ui(()->updateDashboard()); toast(c?"Dados em tempo real ativados":"Dados em tempo real desativados"); }); rtInner.addView(rtSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); rtRow.addView(rtInner); addFull(root,rtRow);
        LinearLayout tlRow=card(CARD2); tlRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout tlInner=new LinearLayout(this); tlInner.setOrientation(LinearLayout.HORIZONTAL); tlInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout tlTexts=new LinearLayout(this); tlTexts.setOrientation(LinearLayout.VERTICAL); tlTexts.setGravity(Gravity.CENTER_VERTICAL); TextView tlTitle=tv("LOG TÉCNICO",13); tlTitle.setTextColor(WHITE); tlTitle.setTypeface(null,android.graphics.Typeface.BOLD); TextView tlSub=tv("LOG EXTENSO: salva cada investigação em TXT, incluindo comandos, respostas RAW, erros e resultados. Ativado por padrão.",9); tlSub.setTextColor(MUTED); tlTexts.addView(tlTitle); tlTexts.addView(tlSub); tlInner.addView(tlTexts,new LinearLayout.LayoutParams(0,-2,1)); android.widget.Switch tlSwitch=new android.widget.Switch(this); styleConfigSwitch(tlSwitch); tlSwitch.setText(""); tlSwitch.setChecked(isTechLogEnabled()); tlSwitch.setHapticFeedbackEnabled(isHapticEnabled()); tlSwitch.setOnCheckedChangeListener((v,c)->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_TECH_LOG,c).apply(); toast(c?"Log técnico ativado":"Log técnico desativado"); }); tlInner.addView(tlSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); tlRow.addView(tlInner); addFull(root,tlRow);
        LinearLayout exportRow=card(CARD2); exportRow.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView exportTitle=tv("EXPORTAÇÃO DOS LOGS DE DIAGNÓSTICO",13); exportTitle.setTextColor(WHITE); exportTitle.setTypeface(null,android.graphics.Typeface.BOLD); exportRow.addView(exportTitle);
        TextView exportSub=tv("Gera um ZIP com todos os relatórios TXT das investigações realizadas. Escolha onde salvar ou compartilhar.",9); exportSub.setTextColor(MUTED); exportRow.addView(exportSub);
        Button exportButton=btn("EXPORTAR LOGS TÉCNICOS (.ZIP)"); bindClick(exportButton,()->exportDiagnosticLogs()); exportRow.addView(exportButton,new LinearLayout.LayoutParams(-1,dp(48))); addFull(root,exportRow);
        LinearLayout phRow=card(CARD2); phRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout phInner=new LinearLayout(this); phInner.setOrientation(LinearLayout.HORIZONTAL); phInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout phTexts=new LinearLayout(this); phTexts.setOrientation(LinearLayout.VERTICAL); phTexts.setGravity(Gravity.CENTER_VERTICAL); TextView phTitle=tv("HISTÓRICO DE PERFORMANCE",13); phTitle.setTextColor(WHITE); phTitle.setTypeface(null,android.graphics.Typeface.BOLD); TextView phSub=tv("Salva automaticamente a telemetria de desempenho em armazenamento público persistente",9); phSub.setTextColor(MUTED); phTexts.addView(phTitle); phTexts.addView(phSub); phInner.addView(phTexts,new LinearLayout.LayoutParams(0,-2,1)); android.widget.Switch phSwitch=new android.widget.Switch(this); styleConfigSwitch(phSwitch); phSwitch.setText(""); phSwitch.setChecked(isPerformanceHistoryEnabled()); phSwitch.setHapticFeedbackEnabled(isHapticEnabled()); phSwitch.setOnCheckedChangeListener((v,c)->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_PERF_HISTORY,c).apply(); if(c&&connected) openPerformanceHistory(); else if(!c) closePerformanceHistory(); toast(c?"Histórico de performance ativado":"Histórico de performance desativado"); }); phInner.addView(phSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); phRow.addView(phInner); addFull(root,phRow);
        LinearLayout simRow=card(CARD2); simRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout simInner=new LinearLayout(this); simInner.setOrientation(LinearLayout.HORIZONTAL); simInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout simTexts=new LinearLayout(this); simTexts.setOrientation(LinearLayout.VERTICAL); simTexts.setGravity(Gravity.CENTER_VERTICAL); TextView simTitle=tv("SIMULAÇÃO AUTOMÁTICA",13); simTitle.setTextColor(WHITE); simTitle.setTypeface(null,android.graphics.Typeface.BOLD); TextView simSub=tv("Inicia em simulação ao abrir; se a conexão com o ELM falhar, retorna à simulação quando esta opção estiver ativada",9); simSub.setTextColor(isAutoSimulationEnabled()?Color.rgb(80,220,150):Color.rgb(255,150,150)); simTexts.addView(simTitle); simTexts.addView(simSub); simInner.addView(simTexts,new LinearLayout.LayoutParams(0,-2,1)); android.widget.Switch simSwitch=new android.widget.Switch(this); styleConfigSwitch(simSwitch); simSwitch.setText(""); simSwitch.setChecked(isAutoSimulationEnabled()); simSwitch.setHapticFeedbackEnabled(isHapticEnabled()); simSwitch.setOnCheckedChangeListener((v,c)->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_AUTO_SIM,c).apply(); simSub.setText("Inicia em simulação ao abrir; se a conexão com o ELM falhar, retorna à simulação quando esta opção estiver ativada"); simSub.setTextColor(MUTED); if(c&&!simulationMode&&!connected){ io.execute(()->startSimulationMode("configuração — simulação automática ativada")); } else if(!c&&simulationMode){ simulationMode=false; connected=false; ecuResponding=false; closeSocket(); ui(()->{updateDashboard(); if(dashConn!=null){dashConn.setText("● SIMULAÇÃO AUTOMÁTICA OFF");dashConn.setTextColor(MUTED);} }); } toast(c?"Simulação automática ativada":"Simulação automática desativada"); }); simInner.addView(simSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); simRow.addView(simInner); addFull(root,simRow);
        LinearLayout acRow=card(CARD2); acRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout acInner=new LinearLayout(this); acInner.setOrientation(LinearLayout.HORIZONTAL); acInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout acTexts=new LinearLayout(this); acTexts.setOrientation(LinearLayout.VERTICAL); acTexts.setGravity(Gravity.CENTER_VERTICAL); TextView acTitle=tv("CONEXÃO AUTOMÁTICA ELM",13); acTitle.setTextColor(WHITE); acTitle.setTypeface(null,android.graphics.Typeface.BOLD); TextView acSub=tv("Procura e tenta conectar o ELM automaticamente ao iniciar o aplicativo",9); acSub.setTextColor(MUTED); acTexts.addView(acTitle); acTexts.addView(acSub); acInner.addView(acTexts,new LinearLayout.LayoutParams(0,-2,1)); android.widget.Switch acSwitch=new android.widget.Switch(this); styleConfigSwitch(acSwitch); acSwitch.setText(""); acSwitch.setChecked(isAutoConnectEnabled()); acSwitch.setHapticFeedbackEnabled(isHapticEnabled()); acSwitch.setOnCheckedChangeListener((v,c)->{ getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_AUTO_CONNECT,c).apply(); autoConnectActive=c; if(c&&!connected&&!intentionalDisconnect) dashboardExec.schedule(this::automaticConnectionAttempt,200,TimeUnit.MILLISECONDS); toast(c?"Conexão automática ELM ativada":"Conexão automática ELM desativada"); }); acInner.addView(acSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); acRow.addView(acInner); addFull(root,acRow);
        addConfigChoice(root,CARD2,WHITE,MUTED,"UNIDADE DE PRESSÃO","Exibição de pressão e boost",getPressureUnit(),new String[]{"bar","kPa"},PREF_PRESSURE_UNIT);
        addConfigChoice(root,CARD2,WHITE,MUTED,"UNIDADE DE VELOCIDADE","Exibição de velocidade",getSpeedUnit(),new String[]{"km/h","mph"},PREF_SPEED_UNIT);
        LinearLayout dtcLibRow=card(CARD2); dtcLibRow.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView dtcLibTitle=tv("BIBLIOTECA DTC",13); dtcLibTitle.setTextColor(WHITE); dtcLibTitle.setTypeface(null,android.graphics.Typeface.BOLD); dtcLibRow.addView(dtcLibTitle);
        dtcConfigStatusView=tv("Carregando biblioteca local...",9); dtcConfigStatusView.setTextColor(MUTED); dtcLibRow.addView(dtcConfigStatusView);
        Button dtcUpdate=btn("ATUALIZAR BIBLIOTECA DTC"); bindClick(dtcUpdate,()->updateDtcLibraryFromNetwork()); dtcLibRow.addView(dtcUpdate,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView dtcLibSub=tv("Atualização controlada por HTTPS. O aplicativo consulta somente a biblioteca do projeto, valida versão e SHA-256 e mantém a cópia anterior se a validação falhar.",8.5f); dtcLibSub.setTextColor(MUTED); dtcLibRow.addView(dtcLibSub); addFull(root,dtcLibRow);
        Button dtcLibOpenCfg=btn("ABRIR BIBLIOTECA DTC"); dtcLibOpenCfg.setTextColor(CYAN); bindClick(dtcLibOpenCfg,()->showDtcLibraryScreen()); dtcLibRow.addView(dtcLibOpenCfg,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout resetRow=card(CARD2); resetRow.setPadding(dp(12),dp(8),dp(12),dp(8)); TextView resetTitle=tv("SISTEMA",13); resetTitle.setTextColor(WHITE); resetTitle.setTypeface(null,android.graphics.Typeface.BOLD); resetRow.addView(resetTitle); Button reset=btn("RESTAURAR CONFIGURAÇÕES PADRÃO"); bindClick(reset,()->resetPreferencesToDefault()); resetRow.addView(reset,new LinearLayout.LayoutParams(-1,dp(48))); TextView resetSub=tv("ON: simulação automática • conexão automática • tela ligada • feedback tátil • dados em tempo real • histórico de performance",8.5f); resetSub.setTextColor(MUTED); resetRow.addView(resetSub); addFull(root,resetRow);
        return screen;
    }

    private double parsePercentPid(String raw, String pid){
        try{ Matcher m=Pattern.compile("41\\s*"+pid.substring(2)+"\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(raw==null?"":raw); if(m.find()) return Integer.parseInt(m.group(1),16)*100.0/255.0; }catch(Exception ignored){} return -1;
    }
    private String rawPidValue(String raw, String pid){
        if(raw==null||raw.trim().isEmpty())return "SEM RESPOSTA"; return raw.trim().replaceAll("\\s+"," ");
    }
    private void showAcceleratorProgressionTest() {
        if(simulationMode || !connected || out==null || in==null) {
            new AlertDialog.Builder(this).setTitle("TESTE REAL DO PEDAL NECESSÁRIO").setMessage("Este teste exige comunicação real com o ELM327. A simulação não será aceita como evidência de sensor. Conecte o adaptador, desligue o motor, ligue a ignição e mantenha o veículo imobilizado.").setPositiveButton("OK",null).show(); return;
        }
        final String source=getPedalSource(); final String[] labels={"0% • PEDAL EM REPOUSO","25% • ACIONAMENTO LEVE","50% • MEIO CURSO","75% • ACIONAMENTO ALTO","100% • FIM DE CURSO"};
        final double[] captured=new double[5]; java.util.Arrays.fill(captured,-1);
        final String[] rawValues=new String[5]; final int[] next={0};
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(14),dp(8),dp(14),dp(6));
        TextView instructions=tv("FONTE: "+getPedalSourceLabel()+"\nCOMPARAÇÃO: throttle PID 0111\nVeículo parado, ignição ligada e motor desligado. Siga a ordem e mantenha cada posição estável.",10);instructions.setTextColor(TEXT);box.addView(instructions);
        TextView result=tv("Nenhuma amostra capturada.",10);result.setTextColor(Color.WHITE);result.setTypeface(android.graphics.Typeface.MONOSPACE);result.setPadding(0,dp(8),0,dp(8));box.addView(result);
        Button capture=btn(labels[0]);box.addView(capture,new LinearLayout.LayoutParams(-1,dp(46)));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("TESTE DE PROGRESSÃO DO PEDAL").setView(box).setNegativeButton("FECHAR",null).setNeutralButton("LIMPAR AMOSTRAS",null).create();
        capture.setOnClickListener(v->{ if(next[0]>=labels.length){toast("Cinco pontos já foram capturados. Feche e execute novamente para repetir.");return;} final int idx=next[0];capture.setEnabled(false);capture.setText("LENDO FONTE SELECIONADA…"); io.execute(()->{String selectedRaw="",throttleRaw="";double selectedPct=-1,throttlePct=-1;String failure=null;try{selectedRaw=send(source,1800);throttleRaw=send("0111",1800);selectedPct=parsePercentPid(selectedRaw,source);throttlePct=parsePercentPid(throttleRaw,"0111");}catch(Exception ex){failure=ex.getClass().getSimpleName()+": "+String.valueOf(ex.getMessage());}final String sr=selectedRaw,tr=throttleRaw,err=failure;final double sp=selectedPct,tp=throttlePct;ui(()->{if(!dialog.isShowing())return; if(err!=null||sp<0||sp>100){capture.setEnabled(true);capture.setText(labels[idx]);result.setText("PONTO "+(idx+1)+" NÃO CAPTURADO. Tente novamente.\n"+(err==null?"PID sem resposta válida.":err)+"\nRAW "+source+": "+rawPidValue(sr,source)+"\nTHROTTLE 0111: "+rawPidValue(tr,"0111"));return;}captured[idx]=sp;rawValues[idx]="Fonte "+source+": "+String.format(Locale.US,"%.1f%%",sp)+" | Throttle 0111: "+(tp>=0?String.format(Locale.US,"%.1f%%",tp):"sem leitura")+" | RAW: "+rawPidValue(sr,source);next[0]++;StringBuilder report=new StringBuilder("AMOSTRAS REAIS • SOMENTE LEITURA\n");for(int i=0;i<next[0];i++)report.append(labels[i]).append("\n").append(rawValues[i]).append("\n\n");if(next[0]==5){boolean increasing=true;for(int i=1;i<5;i++)if(captured[i]+1.0<captured[i-1])increasing=false;report.append("RESULTADO: ").append(increasing?"sequência não decrescente; confira a coerência com o comportamento esperado do sensor.":"variação não monotônica detectada; repita o teste e investigue a fonte/interpretador.").append("\n\nAs porcentagens são leituras PID, não posição física garantida. Este teste não escreve nem calibra a ECU.");capture.setText("AMOSTRAS CONCLUÍDAS");capture.setEnabled(false);}else{capture.setText(labels[next[0]]);capture.setEnabled(true);}result.setText(report.toString());});});});
        dialog.setOnShowListener(d->{dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{java.util.Arrays.fill(captured,-1);java.util.Arrays.fill(rawValues,null);next[0]=0;capture.setEnabled(true);capture.setText(labels[0]);result.setText("Amostras limpas. Nenhuma captura salva.");});});dialog.show();
    }

    private void showAcceleratorTest(){
        if(!connected && !simulationMode){ toast("Conecte o ELM antes do teste"); return; }
        if(devPedalResult!=null)devPedalResult.setText("LENDO PIDs 49/4A/4B • THROTTLE 11/45/47/48/4C…");
        io.execute(()->{
            String[] pids={"0149","014A","014B","0111","0145","0147","0148","014C"};
            StringBuilder outText=new StringBuilder("TESTE DO ACELERADOR • SOMENTE LEITURA\n\n");
            for(String pid:pids){ String raw=send(pid,900); double pct=parsePercentPid(raw,pid); outText.append(pid).append("  ").append(rawPidValue(raw,pid)).append("  ").append(pct>=0?String.format(Locale.US,"%.1f %%",pct):"não interpretado").append("\n"); }
            String d=send("0149",900), e=send("014A",900), f=send("014B",900), th=send("0111",900);
            lastPedalD=parsePercentPid(d,"0149"); lastPedalE=parsePercentPid(e,"014A"); lastPedalF=parsePercentPid(f,"014B"); lastThrottle=parseThrottle(th);
            outText.append("\nPEDAL D: ").append(fmtDev(lastPedalD)).append("\nPEDAL E: ").append(fmtDev(lastPedalE)).append("\nPEDAL F: ").append(fmtDev(lastPedalF)).append("\nTHROTTLE 11: ").append(fmtDev(lastThrottle)).append("\n");
            outText.append("\nPara validar: repita em repouso e depois com 25%, 50%, 75% e 100% do pedal. O gráfico de performance usa o pedal quando houver leitura válida; o throttle continua disponível aqui.");
            final String result=outText.toString(); ui(()->{ if(devPedalResult!=null)devPedalResult.setText(result); new AlertDialog.Builder(this).setTitle("TESTE DO ACELERADOR").setMessage(result).setPositiveButton("OK",null).show(); });
        });
    }
    private String fmtDev(double v){return v>=0?String.format(Locale.US,"%.1f %%",v):"—";}

    private void addConfigChoice(LinearLayout root,int CARD2,int WHITE,int MUTED,String title,String sub,String current,String[] options,String prefKey){
        LinearLayout row=card(CARD2); row.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout inner=new LinearLayout(this); inner.setOrientation(LinearLayout.HORIZONTAL); inner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setGravity(Gravity.CENTER_VERTICAL); TextView t=tv(title,13); t.setTextColor(WHITE); t.setTypeface(null,android.graphics.Typeface.BOLD); TextView st=tv(sub,9); st.setTextColor(MUTED); texts.addView(t); texts.addView(st); inner.addView(texts,new LinearLayout.LayoutParams(0,-2,1)); Button choice=btn(current); choice.setTextSize(11); bindClick(choice,()->{ AlertDialog.Builder b=new AlertDialog.Builder(this); b.setTitle(title); b.setSingleChoiceItems(options,Arrays.asList(options).indexOf(getSharedPreferences(PREFS_UI,MODE_PRIVATE).getString(prefKey,options[0])),(d,which)->{ String v=options[which]; getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putString(prefKey,v).apply(); choice.setText(v); d.dismiss(); if(PREF_PRESSURE_UNIT.equals(prefKey)){ if(graphView!=null)graphView.setMetric(graphMetric); updateGraphScaleInfo(); } else if(PREF_SPEED_UNIT.equals(prefKey)){ if(graphView!=null)graphView.setMetric(graphMetric); updateGraphScaleInfo(); } toast(title+": "+v); }); b.setNegativeButton("CANCELAR",null); b.show(); }); inner.addView(choice,new LinearLayout.LayoutParams(dp(96),dp(48))); row.addView(inner); addFull(root,row);
    }

    private void resetPreferencesToDefault(){
        getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_KEEP_SCREEN,true).putBoolean(PREF_HAPTIC,true).putBoolean(PREF_REALTIME_DATA,true).putBoolean(PREF_TECH_LOG,true).putBoolean(PREF_PERF_HISTORY,true).putBoolean(PREF_AUTO_SIM,true).putBoolean(PREF_AUTO_CONNECT,false).putString(PREF_PRESSURE_UNIT,"bar").putString(PREF_SPEED_UNIT,"km/h").putInt(PREF_DEFAULT_ETHANOL,100).remove(PREF_PERF_ETHANOL).remove(PREF_PEDAL_CAL_MIN).remove(PREF_PEDAL_CAL_MAX).remove("pedal_cal_min").remove("pedal_cal_mid").remove("pedal_cal_max").apply(); performanceEthanolOverride=-1; applyKeepScreenPreference(); autoConnectActive=true; if(!connected&&!simulationMode) io.execute(()->startSimulationMode("restauração das configurações padrão")); if(graphView!=null)graphView.setMetric(graphMetric); updateGraphScaleInfo(); toast("Configurações padrão restauradas");
    }

    private LinearLayout buildDataScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG);
        ScrollView page=new ScrollView(this); page.setFillViewport(false); page.setBackgroundColor(BG); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(0,0,0,dp(8)); page.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(page,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout header=card(CARD); header.setPadding(dp(10),dp(8),dp(10),dp(8)); TextView h=tv("DADOS / LOGS",18); h.setTextColor(WHITE); h.setTypeface(null,android.graphics.Typeface.BOLD); h.setGravity(Gravity.CENTER); header.addView(h,new LinearLayout.LayoutParams(-1,dp(42)));
        LinearLayout tabs=row(); dataTabButtons.clear(); Button telemetry=btn("TELEMETRIA"); Button graphs=btn("GRÁFICOS"); Button logsBtn=btn("LOGS"); dataTabButtons.add(telemetry); dataTabButtons.add(graphs); dataTabButtons.add(logsBtn);
        bindClick(telemetry,()->{dataLogsTab=false;setSelectedButton(telemetry,true);setSelectedButton(graphs,false);setSelectedButton(logsBtn,false);showDataScreen();});
        bindClick(graphs,()->{dataLogsTab=false;setSelectedButton(telemetry,false);setSelectedButton(graphs,true);setSelectedButton(logsBtn,false);showGraphScreen();});
        bindClick(logsBtn,()->{dataLogsTab=true;setSelectedButton(telemetry,false);setSelectedButton(graphs,false);setSelectedButton(logsBtn,true);showDataScreen();});
        addHalf(tabs,telemetry);addHalf(tabs,graphs);addHalf(tabs,logsBtn); header.addView(tabs); addFull(root,header);

        dataTelemetryContent=new LinearLayout(this); dataTelemetryContent.setOrientation(LinearLayout.VERTICAL);
        LinearLayout telemetryPanel=card(CARD2); telemetryPanel.setPadding(dp(10),dp(8),dp(10),dp(8));
        TextView telemetryTitle=tv("TELEMETRIA • AO VIVO",12); telemetryTitle.setTextColor(CYAN); telemetryTitle.setTypeface(null,android.graphics.Typeface.BOLD); telemetryTitle.setGravity(Gravity.CENTER); telemetryPanel.addView(telemetryTitle,new LinearLayout.LayoutParams(-1,dp(28)));
        dataLiveTelemetry=tv("Aguardando dados…",10); dataLiveTelemetry.setTextColor(WHITE); dataLiveTelemetry.setTypeface(android.graphics.Typeface.MONOSPACE); dataLiveTelemetry.setPadding(dp(6),dp(8),dp(6),dp(6)); telemetryPanel.addView(dataLiveTelemetry); addFull(dataTelemetryContent,telemetryPanel);

        LinearLayout rec=card(CARD2); rec.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView rt=tv("GRAVAÇÃO DE TELEMETRIA",12); rt.setTextColor(CYAN); rt.setTypeface(null,android.graphics.Typeface.BOLD); rt.setGravity(Gravity.CENTER); rec.addView(rt,new LinearLayout.LayoutParams(-1,dp(26)));
        TextView rs=tv("MAP / BARO / BOOST / RPM em alta frequência",9); rs.setTextColor(MUTED); rs.setGravity(Gravity.CENTER); rec.addView(rs,new LinearLayout.LayoutParams(-1,dp(24)));
        TextView rf=tv("STATUS: aguardando gravação",9); rf.setTextColor(MUTED); rf.setGravity(Gravity.CENTER); rf.setTag("recordFile"); rec.addView(rf,new LinearLayout.LayoutParams(-1,dp(24)));
        LinearLayout recButtons=row(); Button recStart=btn("INICIAR"); Button recStop=btn("FINALIZAR"); Button recSummary=btn("RESUMO"); bindClick(recStart,()->startRecording()); bindClick(recStop,()->stopRecording()); bindClick(recSummary,()->showRecordingSummary()); addThird(recButtons,recStart); addThird(recButtons,recStop); addThird(recButtons,recSummary); rec.addView(recButtons,new LinearLayout.LayoutParams(-1,dp(50))); addFull(dataTelemetryContent,rec);
        root.addView(dataTelemetryContent,new LinearLayout.LayoutParams(-1,-2));

        dataLogsContent=new LinearLayout(this); dataLogsContent.setOrientation(LinearLayout.VERTICAL);
        LinearLayout logHeader=card(CARD2); logHeader.setPadding(dp(10),dp(6),dp(10),dp(6)); TextView lt=tv("LOG TÉCNICO — ATUALIZAÇÃO EM TEMPO REAL",11); lt.setTextColor(CYAN); lt.setTypeface(null,android.graphics.Typeface.BOLD); lt.setGravity(Gravity.CENTER); logHeader.addView(lt,new LinearLayout.LayoutParams(-1,dp(32))); addFull(dataLogsContent,logHeader);
        TextView logInfo=tv("Comunicações e eventos internos do aplicativo. Útil para diagnóstico e validação; pode ser desativado em Configurações.",9); logInfo.setTextColor(MUTED); logInfo.setGravity(Gravity.CENTER); logInfo.setPadding(dp(6),0,dp(6),dp(4)); addFull(dataLogsContent,logInfo);
        logScroll=new ScrollView(this); logScroll.setFillViewport(false); logScroll.setNestedScrollingEnabled(false); logScroll.setVerticalScrollBarEnabled(true); logScroll.setMinimumHeight(dp(220)); logScroll.setBackground(cardBg(Color.rgb(2,20,38),18,Color.rgb(25,80,120))); logScroll.setClipToPadding(true); log=tv("",10); log.setTextColor(Color.rgb(185,210,230)); log.setTextIsSelectable(false); log.setVerticalScrollBarEnabled(false); log.setPadding(dp(12),dp(12),dp(12),dp(12)); log.setMinHeight(dp(196)); log.setGravity(Gravity.TOP|Gravity.LEFT); logScroll.addView(log,new ScrollView.LayoutParams(-1,-2)); LinearLayout.LayoutParams lsp=new LinearLayout.LayoutParams(-1,dp(220)); lsp.setMargins(dp(6),dp(4),dp(6),dp(4)); dataLogsContent.addView(logScroll,lsp);
        LinearLayout tools=row(); Button copy=btn("COPIAR LOG"); bindClick(copy,()->copyLog()); Button clear=btn("LIMPAR LOG"); bindClick(clear,()->clearLog()); addHalf(tools,copy); addHalf(tools,clear); addFull(dataLogsContent,tools);
        result=tv("RESULTADO: —",10); result.setTextColor(WHITE); result.setTypeface(android.graphics.Typeface.MONOSPACE); result.setTextIsSelectable(true); result.setPadding(dp(12),dp(8),dp(12),dp(8)); result.setBackground(cardBg(CARD2,16,CYAN2)); ScrollView resultScroll=new ScrollView(this); resultScroll.setFillViewport(false); resultScroll.setNestedScrollingEnabled(false); resultScroll.setVerticalScrollBarEnabled(true); resultScroll.addView(result,new ScrollView.LayoutParams(-1,-2)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(150)); rp.setMargins(dp(6),0,dp(6),dp(6)); dataLogsContent.addView(resultScroll,rp);
        root.addView(dataLogsContent,new LinearLayout.LayoutParams(-1,-2));
        dataTelemetryContent.setVisibility(View.VISIBLE); dataLogsContent.setVisibility(View.GONE);
        return screen;
    }

    private LinearLayout buildGraphScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(3),dp(10),dp(8)); screen.setBackgroundColor(BG);
        LinearLayout header=card(CARD); header.setPadding(dp(10),dp(5),dp(10),dp(5));
        graphHeaderTitle=tv("GRÁFICO COMBINADO • DADOS AO VIVO",16); graphHeaderTitle.setTextColor(WHITE); graphHeaderTitle.setTypeface(null,android.graphics.Typeface.BOLD); graphHeaderTitle.setGravity(Gravity.CENTER);
        header.addView(graphHeaderTitle,new LinearLayout.LayoutParams(-1,dp(34)));
        screen.addView(header,new LinearLayout.LayoutParams(-1,dp(48)));
        graphHistoryStatus=tv("AGUARDANDO DADOS • ao vivo ou histórico da puxada",9); graphHistoryStatus.setTextColor(Color.rgb(255,190,0)); graphHistoryStatus.setGravity(Gravity.CENTER); screen.addView(graphHistoryStatus,new LinearLayout.LayoutParams(-1,dp(30)));
        combinedGraphView=new CombinedGraphView(this); screen.addView(combinedGraphView,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout modes=row(); Button live=btn("TEMPO REAL"); Button history=btn("HISTÓRICO");
        bindClick(live,()->showLiveCombinedGraph()); bindClick(history,()->showHistoricalCombinedGraph());
        addHalf(modes,live); addHalf(modes,history); LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(-1,dp(42)); mp.setMargins(dp(2),dp(2),dp(2),dp(2)); screen.addView(modes,mp);
        LinearLayout nav=row(); Button performance=btn("← PERFORMANCE"); Button data=btn("DADOS →");
        performance.setMinWidth(0); performance.setMinimumWidth(0); data.setMinWidth(0); data.setMinimumWidth(0);
        performance.setGravity(Gravity.CENTER); data.setGravity(Gravity.CENTER);
        bindClick(performance,()->showPerformanceScreen()); bindClick(data,()->showDataScreen()); addHalf(nav,performance); addHalf(nav,data);
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(46)); bp.setMargins(dp(2),dp(2),dp(2),dp(2)); screen.addView(nav,bp);
        return screen;
    }

    private LinearLayout buildPerformanceScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        final int black=Color.rgb(5,7,11), panel=Color.rgb(12,14,19), line=Color.rgb(55,30,36), red=Color.rgb(230,42,58), soft=Color.rgb(255,70,82), muted=Color.rgb(164,180,197);
        final boolean landscape=getResources().getConfiguration().orientation==android.content.res.Configuration.ORIENTATION_LANDSCAPE;
        final int metricColumns=landscape?4:2;
        final int gaugeHeight=landscape?dp(205):dp(142);
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(4),dp(3),dp(4),dp(5)); screen.setBackgroundColor(black);
        ScrollView sv=new ScrollView(this); sv.setFillViewport(false); sv.setBackgroundColor(black); sv.setVerticalScrollBarEnabled(false);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(black); root.setPadding(0,0,0,dp(5)); sv.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout heading=card(panel); heading.setBackground(cardBg(panel,12,red)); heading.setPadding(dp(8),0,dp(8),0);
        TextView ht=tv("🏁 PERFORMANCE",landscape?17:16); ht.setTextColor(soft); ht.setTypeface(null,android.graphics.Typeface.BOLD); ht.setGravity(Gravity.CENTER); ht.setLetterSpacing(.035f);
        heading.addView(ht,new LinearLayout.LayoutParams(-1,dp(34))); LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(38)); hp.setMargins(dp(2),dp(1),dp(2),dp(3)); root.addView(heading,hp);

        // Three instruments share one responsive row: RPM, turbo pressure, and speed.
        LinearLayout gaugeRow=new LinearLayout(this); gaugeRow.setOrientation(LinearLayout.HORIZONTAL); gaugeRow.setGravity(Gravity.CENTER); gaugeRow.setPadding(0,0,0,0); gaugeRow.setClipChildren(false); gaugeRow.setClipToPadding(false);
        perfRpmGauge=new PerformanceGaugeView("CONTA-GIROS","rpm",8000,Color.rgb(240,45,62),8);
        perfBoostGauge=new PerformanceGaugeView("PRESSÃO TURBO","bar",3,Color.rgb(255,54,65),6);
        perfSpeedGauge=new PerformanceGaugeView("VELOCIDADE","km/h",280,Color.rgb(240,45,62),14);
        for(PerformanceGaugeView g:new PerformanceGaugeView[]{perfRpmGauge,perfBoostGauge,perfSpeedGauge}){
            LinearLayout.LayoutParams gl=new LinearLayout.LayoutParams(0,gaugeHeight,1f); gl.setMargins(dp(1),dp(1),dp(1),dp(2)); gaugeRow.addView(g,gl);
        }
        root.addView(gaugeRow,new LinearLayout.LayoutParams(-1,gaugeHeight+dp(3)));
        TextView liveHint=tv("DADOS REAIS • OBD/ELM  |  TURBO: MAP − BARO",8); liveHint.setTextColor(muted); liveHint.setGravity(Gravity.CENTER); liveHint.setPadding(0,0,0,dp(2)); addTight(root,liveHint);
        perfPower=perfValue("POTÊNCIA ESTIMADA","— cv",Color.rgb(255,45,75));
        perfTorque=perfValue("TORQUE ESTIMADO","— Nm",Color.rgb(255,145,35));
        perf0060=perfValue("0–60 km/h","— s",Color.rgb(25,155,255));
        perf0100=perfValue("0–100 km/h","— s",Color.rgb(25,155,255));
        perfBoost=perfValue("BOOST MÁX.","— bar",Color.rgb(30,225,105));
        perfMaxRpm=perfValue("RPM MÁX.","— rpm",Color.rgb(25,205,230));
        perfMaxSpeed=perfValue("VELOCIDADE MÁX.","— km/h",Color.rgb(45,225,100));
        perfQuality=perfValue("QUALIDADE AQUISIÇÃO","— %",Color.rgb(255,205,25));
        perfDuration=perfValue("DURAÇÃO DO TESTE","— s",Color.rgb(255,35,165));
        perfSessionCount=perfValue("SESSÕES","—",Color.rgb(255,130,40));
        TextView[] metrics={perfPower,perfTorque,perf0060,perf0100,perfBoost,perfMaxRpm,perfMaxSpeed,perfQuality,perfDuration,perfSessionCount};
        LinearLayout metricGrid=new LinearLayout(this); metricGrid.setOrientation(LinearLayout.VERTICAL); metricGrid.setPadding(dp(1),0,dp(1),0);
        for(int i=0;i<metrics.length;i+=metricColumns){
            LinearLayout mr=new LinearLayout(this); mr.setOrientation(LinearLayout.HORIZONTAL); mr.setGravity(Gravity.CENTER_VERTICAL); mr.setPadding(0,0,0,0);
            for(int c=0;c<metricColumns;c++){
                int idx=i+c;
                if(idx<metrics.length){ LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,landscape?dp(58):dp(58),1f); mp.setMargins(dp(2),dp(2),dp(2),dp(2)); mr.addView(metrics[idx],mp); }
                else { View spacer=new View(this); mr.addView(spacer,new LinearLayout.LayoutParams(0,dp(58),1f)); }
            }
            metricGrid.addView(mr,new LinearLayout.LayoutParams(-1,-2));
        }
        addTight(root,metricGrid);

        LinearLayout meta=card(panel); meta.setBackground(cardBg(panel,12,line)); meta.setPadding(dp(8),dp(4),dp(8),dp(4));
        perfFuel=tv("⛽  COMBUSTÍVEL: "+getPerformanceEthanolLabel(),10); perfFuel.setTextColor(Color.rgb(225,232,241)); perfFuel.setGravity(Gravity.CENTER_VERTICAL); perfFuel.setSingleLine(false); meta.addView(perfFuel,new LinearLayout.LayoutParams(-1,dp(25)));
        perfEthanolButton=btn("SELECIONAR COMBUSTÍVEL"); perfEthanolButton.setTextSize(10); perfEthanolButton.setMinHeight(dp(38)); perfEthanolButton.setMinimumHeight(dp(38)); bindClick(perfEthanolButton,()->showEthanolDialog()); meta.addView(perfEthanolButton,new LinearLayout.LayoutParams(-1,dp(39)));
        LinearLayout statusRow=new LinearLayout(this); statusRow.setOrientation(LinearLayout.HORIZONTAL); statusRow.setGravity(Gravity.CENTER_VERTICAL);
        perfConfidence=tv("CONFIANÇA: —",8.5f); perfConfidence.setTextColor(muted); statusRow.addView(perfConfidence,new LinearLayout.LayoutParams(0,dp(23),1));
        perfStatus=tv("PRONTO PARA TESTE",10); perfStatus.setTextColor(soft); perfStatus.setTypeface(null,android.graphics.Typeface.BOLD); perfStatus.setGravity(Gravity.CENTER); statusRow.addView(perfStatus,new LinearLayout.LayoutParams(0,dp(23),1));
        meta.addView(statusRow,new LinearLayout.LayoutParams(-1,dp(23))); addTight(root,meta);

        Button start=btn("🏁  INICIAR 0–60 / 0–100 / 0–280");
        start.setTextSize(11); start.setSingleLine(false); start.setMaxLines(2); start.setIncludeFontPadding(true);
        if(Build.VERSION.SDK_INT>=26) start.setAutoSizeTextTypeWithDefaults(TextView.AUTO_SIZE_TEXT_TYPE_NONE);
        start.setGravity(Gravity.CENTER); start.setPadding(dp(8),dp(10),dp(8),dp(10));
        start.setMinHeight(dp(72)); start.setMinimumHeight(dp(72));
        start.setClipToOutline(false); bindClick(start,()->startPerformanceTest());
        Button stop=btn("■  FINALIZAR");
        stop.setTextSize(11); stop.setSingleLine(false); stop.setMaxLines(2); stop.setIncludeFontPadding(true);
        if(Build.VERSION.SDK_INT>=26) stop.setAutoSizeTextTypeWithDefaults(TextView.AUTO_SIZE_TEXT_TYPE_NONE);
        stop.setGravity(Gravity.CENTER); stop.setPadding(dp(8),dp(8),dp(8),dp(8));
        stop.setMinHeight(dp(60)); stop.setMinimumHeight(dp(60)); bindClick(stop,()->stopPerformanceTest());
        if(landscape){
            LinearLayout actions=row(); actions.setClipChildren(false); actions.setClipToPadding(false); addHalf(actions,start); addHalf(actions,stop); actions.setMinimumHeight(dp(78)); addTight(root,actions);
            LinearLayout extra=row(); Button data=btn("▥  GRÁFICOS DO TESTE"); data.setTextSize(10); data.setMinHeight(dp(40)); data.setMinimumHeight(dp(40)); bindClick(data,()->showPerformanceTestGraph()); Button hist=btn("▣  HISTÓRICO DE SESSÕES"); hist.setTextSize(10); hist.setMinHeight(dp(40)); hist.setMinimumHeight(dp(40)); bindClick(hist,()->showHistoryScreen()); addHalf(extra,data); addHalf(extra,hist); addTight(root,extra);
        }else{
            addTight(root,start); addTight(root,stop);
            LinearLayout extra=row(); Button data=btn("▥  GRÁFICOS DO TESTE"); data.setTextSize(10); data.setMinHeight(dp(42)); data.setMinimumHeight(dp(42)); bindClick(data,()->showPerformanceTestGraph()); Button hist=btn("▣  HISTÓRICO DE SESSÕES"); hist.setTextSize(10); hist.setMinHeight(dp(42)); hist.setMinimumHeight(dp(42)); bindClick(hist,()->showHistoryScreen()); addHalf(extra,data); addHalf(extra,hist); addTight(root,extra);
        }
        TextView note=tv("0–60 e 0–100 no mesmo ensaio • curva até 280 km/h • compare testes em condições equivalentes.",7.5f); note.setTextColor(Color.rgb(135,150,165)); note.setGravity(Gravity.CENTER); note.setPadding(dp(5),dp(3),dp(5),dp(3)); addTight(root,note);
        return screen;
    }

    /** Instrumento automotivo desenhado em Canvas; valores só aparecem quando há leitura válida. */
    private class PerformanceGaugeView extends View {
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final String label,unit; private final double max; private final int accent, divisions;
        private double value=0, maximumValue=-1; private boolean valid=false;
        PerformanceGaugeView(String label,String unit,double max,int accent,int divisions){ super(MainActivity.this); this.label=label;this.unit=unit;this.max=max;this.accent=accent;this.divisions=divisions;setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        private float sp(float v){ return v*getResources().getDisplayMetrics().scaledDensity; }
        void setValue(double v,boolean ok){ valid=ok&&!Double.isNaN(v)&&!Double.isInfinite(v)&&v>=0; value=valid?Math.min(max,v):0; invalidate(); }
        void setMaximum(double v){ maximumValue=(v>=0&&!Double.isNaN(v)&&!Double.isInfinite(v))?Math.min(max,v):-1; invalidate(); }
        private void text(Canvas c,String value,float x,float y,float size,int color,boolean bold){p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(sp(size));p.setColor(color);p.setTypeface(android.graphics.Typeface.create("sans-serif",bold?android.graphics.Typeface.BOLD:android.graphics.Typeface.NORMAL));c.drawText(value,x,y,p);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c); float w=getWidth(),h=getHeight(); if(w<=0||h<=0)return;
            float cx=w/2f, cy=h*.62f, radius=Math.min(w*.405f,h*.43f); radius=Math.max(dp(25),radius);
            p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(7,9,13));c.drawRoundRect(new RectF(0,0,w,h),dp(10),dp(10),p);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(Color.rgb(42,25,31));c.drawRoundRect(new RectF(.5f,.5f,w-.5f,h-.5f),dp(10),dp(10),p);
            RectF oval=new RectF(cx-radius,cy-radius,cx+radius,cy+radius);
            p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(dp(4));p.setColor(Color.rgb(39,40,48));c.drawArc(oval,135,270,false,p);
            boolean showingMaximum=!valid&&maximumValue>=0; double shownValue=valid?value:(showingMaximum?maximumValue:0); boolean shown=valid||showingMaximum;
            p.setColor(accent);p.setStrokeWidth(dp(2.3f));c.drawArc(oval,135,(float)(270*(shown?shownValue/max:0)),false,p);
            for(int i=0;i<=divisions;i++){
                double a=Math.toRadians(135+i*(270.0/divisions));
                float r1=radius-dp(i%2==0?9:6),r2=radius-dp(1);
                float x1=(float)(cx+r1*Math.cos(a)),y1=(float)(cy+r1*Math.sin(a)),x2=(float)(cx+r2*Math.cos(a)),y2=(float)(cy+r2*Math.sin(a));
                p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(i%2==0?1.5f:0.8f));p.setColor(i/(double)divisions <= (shown?shownValue/max:0)?accent:Color.rgb(208,214,224));c.drawLine(x1,y1,x2,y2,p);
                int labelEvery=max>=200?2:Math.max(1,divisions/8);
                if(i%labelEvery==0){double tickValue=max*i/divisions;String tick=max==8000?String.format(Locale.US,"%.0f",tickValue/1000.0):String.format(Locale.US,max>=100?"%.0f":"%.1f",tickValue);float tx=(float)(cx+(radius-dp(17))*Math.cos(a)),ty=(float)(cy+(radius-dp(17))*Math.sin(a))+sp(3);text(c,tick,tx,ty,Math.max(6.5f,w<dp(145)?7.0f:9),Color.rgb(221,228,238),true);}
            }
            text(c,label,cx,dp(13),Math.max(7,w<dp(145)?7.5f:9),Color.rgb(174,190,208),true);
            // Needle points to the measured value; unavailable data remains a dash.
            double a=Math.toRadians(135+270*(shown?shownValue/max:0)); float nx=(float)(cx+(radius-dp(13))*Math.cos(a)),ny=(float)(cy+(radius-dp(13))*Math.sin(a));
            p.setStyle(Paint.Style.STROKE);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeWidth(dp(2));p.setColor(accent);c.drawLine(cx,cy,nx,ny,p);
            p.setStyle(Paint.Style.FILL);p.setColor(accent);c.drawCircle(cx,cy,dp(3),p);
            text(c,shown?(max>=100?String.format(Locale.US,"%.0f",shownValue):String.format(Locale.US,"%.2f",shownValue)):"—",cx,cy+sp(6),w<dp(145)?17:23,Color.WHITE,true);
            text(c,unit,cx,cy+sp(21),w<dp(145)?8:10,Color.rgb(174,198,218),true);
            text(c,valid?"LIVE":showingMaximum?"MÁXIMO ATINGIDO":"SEM DADO",cx,h-dp(4),Math.max(6,w<dp(145)?6.5f:7.5f),Color.rgb(126,151,173),false);
        }
    }
    private TextView perfValue(String label,String value,int accent){ TextView t=tv("",10); t.setTextColor(Color.rgb(242,248,255)); t.setGravity(Gravity.CENTER); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setPadding(dp(3),dp(2),dp(3),dp(2)); t.setMinHeight(dp(54)); t.setBackground(cardBg(Color.rgb(10,12,17),10,Color.rgb(104,38,47))); setPerfText(t,label,value); return t; }
    private void setPerfText(TextView t,String label,String value){
        if(t==null)return;
        String v=value==null?"—":value.trim();
        if(v.toLowerCase(Locale.ROOT).contains("dados insuficientes")||v.toLowerCase(Locale.ROOT).contains("não concluído")||v.toLowerCase(Locale.ROOT).contains("nao concluido")) v="—";
        String icon=""; int iconColor=Color.WHITE;
        if(label.contains("POTÊNCIA")){icon="◉  ";iconColor=Color.rgb(255,45,75);} 
        else if(label.contains("TORQUE")){icon="◉  ";iconColor=Color.rgb(255,145,35);} 
        else if(label.contains("0–60")){icon="◷  ";iconColor=Color.rgb(25,155,255);} 
        else if(label.contains("0–100")){icon="◷  ";iconColor=Color.rgb(160,75,255);} 
        else if(label.contains("BOOST")){icon="◎  ";iconColor=Color.rgb(30,225,105);} 
        else if(label.contains("QUALIDADE")){icon="▥  ";iconColor=Color.rgb(255,205,25);} 
        else if(label.contains("RPM")){icon="◉  ";iconColor=Color.rgb(25,205,230);} 
        else if(label.contains("VELOCIDADE")){icon="◉  ";iconColor=Color.rgb(45,225,100);} 
        else if(label.contains("DURAÇÃO")){icon="◷  ";iconColor=Color.rgb(255,35,165);} 
        else if(label.contains("SESSÕES")){icon="⚑  ";iconColor=Color.WHITE;} 
        String displayLabel=icon+label;
        String unit=""; String number=v;
        String[] units={"km/h","rpm","bar","Nm","CV","s"};
        for(String u:units){ if(number.toLowerCase(Locale.US).endsWith(" "+u.toLowerCase(Locale.US))){ unit=" "+number.substring(number.length()-u.length()); number=number.substring(0,number.length()-u.length()).trim(); break; } }
        android.text.SpannableString sp=new android.text.SpannableString(displayLabel+"\n"+number+unit);
        int textLength=sp.length();
        int valueStart=Math.min(textLength,displayLabel.length()+1);
        int valueEnd=Math.max(valueStart,Math.min(textLength,valueStart+number.length()));
        if(valueEnd>valueStart){
            sp.setSpan(new android.text.style.AbsoluteSizeSpan(18,true),valueStart,valueEnd,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sp.setSpan(new android.text.style.TypefaceSpan("monospace"),valueStart,valueEnd,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sp.setSpan(new android.text.style.ForegroundColorSpan(Color.WHITE),valueStart,valueEnd,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        if(!unit.isEmpty() && valueEnd<textLength){ int us=valueEnd; int ue=textLength; if(ue>us){ sp.setSpan(new android.text.style.AbsoluteSizeSpan(10,true),us,ue,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); sp.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(165,195,220)),us,ue,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); } }
        int labelEnd=Math.min(textLength,displayLabel.length());
        if(labelEnd>0){
            sp.setSpan(new android.text.style.AbsoluteSizeSpan(9,true),0,labelEnd,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sp.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(235,248,255)),0,labelEnd,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        }
        int iconEnd=Math.min(textLength,icon.length());
        if(iconEnd>0) sp.setSpan(new android.text.style.ForegroundColorSpan(iconColor),0,iconEnd,android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        t.setText(sp);
    }

    private LinearLayout buildHistoryScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG);
        LinearLayout head=card(CARD); head.setPadding(dp(12),dp(8),dp(12),dp(8)); TextView t=tv("🗂 HISTÓRICO DE SESSÕES",18); t.setTextColor(WHITE); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setGravity(Gravity.CENTER); head.addView(t,new LinearLayout.LayoutParams(-1,dp(34))); TextView st=tv("Arquivos persistentes • puxadas e telemetria",9); st.setTextColor(MUTED); st.setGravity(Gravity.CENTER); head.addView(st,new LinearLayout.LayoutParams(-1,dp(24))); screen.addView(head,new LinearLayout.LayoutParams(-1,dp(72)));
        LinearLayout quickActions=row(); quickActions.setBaselineAligned(false); quickActions.setGravity(Gravity.TOP); Button best=btn("🏆 TOP 3"); Button chooseFolder=btn("📁 PASTA DE LOGS");
        styleHistoryActionButton(best, 9.5f, 52);
        styleHistoryActionButton(chooseFolder, 8.5f, 52);
        bindClick(best,()->showBestPullsDialog()); bindClick(chooseFolder,()->chooseHistoryFolder());
        addHalf(quickActions,best); addHalf(quickActions,chooseFolder); addFull(screen,quickActions);
        ScrollView sv=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setTag("historyList"); sv.addView(list,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        TextView folderHint=tv("Pasta de logs do veículo • escolha a pasta correspondente para liberar leitura e exclusão dos CSVs antigos",8.5f); folderHint.setTextColor(MUTED); folderHint.setGravity(Gravity.CENTER); folderHint.setPadding(dp(4),dp(2),dp(4),dp(6)); addFull(screen,folderHint);
        LinearLayout acts=row(); acts.setBaselineAligned(false); acts.setGravity(Gravity.TOP); Button refresh=btn("↻ ATUALIZAR"); Button pending=btn("☑ PENDENTES"); Button back=btn("← PERFORMANCE");
        styleHistoryActionButton(refresh, 8.5f, 50);
        styleHistoryActionButton(pending, 8.5f, 50);
        styleHistoryActionButton(back, 7.5f, 50);
        bindClick(refresh,()->refreshHistorySessions()); bindClick(pending,()->showPendingFilesManager()); bindClick(back,()->showPerformanceScreen());
        addThird(acts,refresh); addThird(acts,pending); addThird(acts,back); addFull(screen,acts); return screen;
    }
    private void styleHistoryActionButton(Button button,float textSize,int heightDp){
        button.setMinWidth(0); button.setMinimumWidth(0);
        button.setMinHeight(dp(heightDp)); button.setMinimumHeight(dp(heightDp));
        button.setTextSize(textSize); button.setGravity(Gravity.CENTER);
        button.setSingleLine(true); button.setMaxLines(1);
        button.setEllipsize(android.text.TextUtils.TruncateAt.END); button.setIncludeFontPadding(false);
        button.setHorizontallyScrolling(false);
        if(Build.VERSION.SDK_INT>=26) button.setAutoSizeTextTypeUniformWithConfiguration(7,10,1,android.util.TypedValue.COMPLEX_UNIT_SP);
        button.setPadding(dp(3),0,dp(3),0);
    }
    private static class PendingLogEntry { Uri uri; String name; PendingLogEntry(Uri u,String n){uri=u;name=n;} }
    private void showPendingFilesManager(){
        if(Build.VERSION.SDK_INT<29){toast("A seleção de arquivos pendentes requer Android 10 ou superior");return;}
        ArrayList<PendingLogEntry> entries=new ArrayList<>();
        LinkedHashSet<String> seen=new LinkedHashSet<>();
        Cursor c=null;
        try{
            Uri collection=MediaStore.Files.getContentUri("external");
            String[] projection={MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.RELATIVE_PATH,MediaStore.MediaColumns.IS_PENDING};
            c=getContentResolver().query(collection,projection,MediaStore.MediaColumns.RELATIVE_PATH+" LIKE ?",new String[]{"%VirtusELM/logs%"},MediaStore.MediaColumns.DATE_ADDED+" DESC");
            if(c!=null){
                int idIdx=c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID),nameIdx=c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME),pathIdx=c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH),pendingIdx=c.getColumnIndex(MediaStore.MediaColumns.IS_PENDING);
                while(c.moveToNext()){
                    String name=c.getString(nameIdx),path=c.getString(pathIdx);
                    if(name==null||path==null||!isVirtusLogsRelativePath(path))continue;
                    boolean named=name.toLowerCase(Locale.US).startsWith(".pending");
                    boolean flagged=pendingIdx>=0&&!c.isNull(pendingIdx)&&c.getInt(pendingIdx)==1;
                    if(!named&&!flagged)continue;
                    Uri uri=ContentUris.withAppendedId(collection,c.getLong(idIdx));
                    String key=uri.toString();if(seen.add(key))entries.add(new PendingLogEntry(uri,name));
                }
            }
        }catch(Exception e){append("PENDENTES: MediaStore indisponível — "+e.getClass().getSimpleName());}
        finally{if(c!=null)c.close();}
        // Alguns .pending-* não são indexados pelo MediaStore. A pasta SAF persistida é a fonte complementar.
        Uri tree=getSavedHistoryTree();
        if(tree!=null){Cursor children=null;try{
            String rootId=DocumentsContract.getTreeDocumentId(tree);
            Uri childUri=DocumentsContract.buildChildDocumentsUriUsingTree(tree,rootId);
            String[] cols={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
            children=getContentResolver().query(childUri,cols,null,null,DocumentsContract.Document.COLUMN_DISPLAY_NAME+" ASC");
            if(children!=null){int idCol=children.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID),nameCol=children.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME),mimeCol=children.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                while(children.moveToNext()){
                    String name=children.getString(nameCol);if(name==null||!name.toLowerCase(Locale.US).startsWith(".pending"))continue;
                    String id=children.getString(idCol);if(id==null)continue;
                    Uri doc=DocumentsContract.buildDocumentUriUsingTree(tree,id);String key=doc.toString();
                    if(seen.add(key))entries.add(new PendingLogEntry(doc,name));
                }
            }
        }catch(Exception e){append("PENDENTES: SAF não conseguiu listar a pasta autorizada — "+e.getClass().getSimpleName());}
        finally{if(children!=null)children.close();}}
        if(entries.isEmpty()){
            new AlertDialog.Builder(this).setTitle("ARQUIVOS PENDENTES")
                .setMessage(tree==null?"Nenhum arquivo .pending foi localizado. Para permitir a busca e exclusão, selecione primeiro a pasta Download/VirtusELM/logs. Deseja selecioná-la agora?":"Nenhum arquivo .pending foi localizado na pasta Download/VirtusELM/logs.")
                .setNegativeButton("CANCELAR",null)
                .setPositiveButton(tree==null?"SELECIONAR PASTA":"OK",(d,w)->{if(tree==null)chooseHistoryFolder();}).show();
            return;
        }
        String[] labels=new String[entries.size()];boolean[] checked=new boolean[entries.size()];
        for(int i=0;i<entries.size();i++)labels[i]=entries.get(i).name;
        AlertDialog pendingDialog=new AlertDialog.Builder(this).setTitle("SELECIONE OS PENDENTES PARA EXCLUIR")
            .setMultiChoiceItems(labels,checked,(dialog,which,isChecked)->checked[which]=isChecked)
            .setNegativeButton("CANCELAR",null)
            .setPositiveButton("EXCLUIR SELECIONADOS",(dialog,which)->{
                ArrayList<Integer> selected=new ArrayList<>();for(int i=0;i<checked.length;i++)if(checked[i])selected.add(i);
                if(selected.isEmpty()){toast("Nenhum arquivo selecionado");return;}
                new AlertDialog.Builder(this).setTitle("CONFIRMAR EXCLUSÃO")
                    .setMessage("Excluir permanentemente "+selected.size()+" arquivo(s) .pending?")
                    .setNegativeButton("MANTER",null)
                    .setPositiveButton("EXCLUIR",(d,w)->{
                        int deleted=0,failed=0;
                        for(int i:selected){PendingLogEntry entry=entries.get(i);try{
                            int count=getContentResolver().delete(entry.uri,null,null);
                            if(count>0)deleted++;else if(DocumentsContract.isDocumentUri(this,entry.uri)&&DocumentsContract.deleteDocument(getContentResolver(),entry.uri))deleted++;else failed++;
                        }catch(Exception ex){try{if(DocumentsContract.isDocumentUri(this,entry.uri)&&DocumentsContract.deleteDocument(getContentResolver(),entry.uri))deleted++;else failed++;}catch(Exception ignored){failed++;}}
                        }
                        toast("Pendentes excluídos: "+deleted+" • falhas: "+failed);
                        append("LIMPEZA DE PENDENTES: "+deleted+" excluído(s), "+failed+" falha(s)");
                        refreshHistorySessions();
                    }).show();
            }).create();
        pendingDialog.setOnShowListener(dialog -> {
            android.view.Window window=pendingDialog.getWindow();
            if(window!=null){android.util.DisplayMetrics dm=new android.util.DisplayMetrics();getWindowManager().getDefaultDisplay().getMetrics(dm);window.setLayout((int)(dm.widthPixels*0.92f),(int)(dm.heightPixels*0.90f));}
        });
        pendingDialog.show();
    }

    private LinearLayout buildDtcLibraryScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG);
        LinearLayout head=card(CARD); head.setPadding(dp(12),dp(8),dp(12),dp(8));
        TextView title=tv("BIBLIOTECA DTC • CONSULTA E ATUALIZAÇÃO",16); title.setTextColor(WHITE); title.setTypeface(null,android.graphics.Typeface.BOLD); head.addView(title,new LinearLayout.LayoutParams(-1,dp(38)));
        TextView info=tv("Base controlada do VirtusELM • códigos OBD-II e referências VAG documentadas",9); info.setTextColor(MUTED); head.addView(info);
        dtcLibraryStatusView=tv("Carregando biblioteca...",10); dtcLibraryStatusView.setTextColor(CYAN); dtcLibraryStatusView.setTypeface(null,android.graphics.Typeface.BOLD); head.addView(dtcLibraryStatusView);
        screen.addView(head,new LinearLayout.LayoutParams(-1,dp(90)));
        LinearLayout acts=row(); Button update=btn("ATUALIZAR"); update.setTextColor(CYAN); bindClick(update,()->updateDtcLibraryFromNetwork()); Button back=btn("← DIAGNÓSTICO"); bindClick(back,()->showDiagnosticScreen()); addHalf(acts,update); addHalf(acts,back); addFull(screen,acts);
        dtcLibrarySearch=new EditText(this); dtcLibrarySearch.setHint("Pesquisar código ou descrição..."); dtcLibrarySearch.setTextColor(WHITE); dtcLibrarySearch.setHintTextColor(MUTED); dtcLibrarySearch.setSingleLine(true); dtcLibrarySearch.setTextSize(13); dtcLibrarySearch.setPadding(dp(12),0,dp(12),0); dtcLibrarySearch.setBackground(cardBg(CARD2,16,CYAN2)); dtcLibrarySearch.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int before,int count){renderDtcLibraryList();} public void afterTextChanged(android.text.Editable e){}}); screen.addView(dtcLibrarySearch,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView hint=tv("Toque em um código para consultar detalhes. A atualização usa HTTPS + SHA-256 e somente substitui a biblioteca após validação.",8.5f); hint.setTextColor(MUTED); hint.setPadding(dp(4),dp(6),dp(4),dp(6)); screen.addView(hint);
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); dtcLibraryListContainer=new LinearLayout(this); dtcLibraryListContainer.setOrientation(LinearLayout.VERTICAL); sv.addView(dtcLibraryListContainer,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        return screen;
    }
    private void renderDtcLibraryList(){ if(dtcLibraryListContainer==null)return; dtcLibraryListContainer.removeAllViews(); String q=dtcLibrarySearch==null?"":dtcLibrarySearch.getText().toString().trim().toUpperCase(Locale.US); int shown=0; synchronized(dtcLibraryRecords){ for(Map.Entry<String,JSONObject> e:dtcLibraryRecords.entrySet()){ JSONObject o=e.getValue(); String code=e.getKey(); String desc=o.optString("description",""); String hay=(code+" "+desc+" "+o.optString("system","")+" "+o.optString("vag_reference","")).toUpperCase(Locale.US); if(!q.isEmpty()&&!hay.contains(q))continue; LinearLayout item=card(Color.rgb(4,28,55)); item.setPadding(dp(10),dp(8),dp(10),dp(8)); TextView a=tv(code,13); a.setTextColor(Color.rgb(0,194,255)); a.setTypeface(null,android.graphics.Typeface.BOLD); TextView b=tv(desc,10); b.setTextColor(Color.rgb(242,248,255)); b.setSingleLine(false); TextView c=tv((o.optString("type","OBD-II").toUpperCase(Locale.US))+" • "+o.optString("system","—")+(o.has("vag_reference")?" • VAG "+o.optString("vag_reference"):""),8.5f); c.setTextColor(Color.rgb(145,181,210)); item.addView(a); item.addView(b); item.addView(c); bindClick(item,()->showDtcLibraryRecord(code)); dtcLibraryListContainer.addView(item,new LinearLayout.LayoutParams(-1,-2)); LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)item.getLayoutParams(); lp.setMargins(0,0,0,dp(6)); item.setLayoutParams(lp); if(++shown>=250)break; } } if(shown==0){TextView empty=tv(q.isEmpty()?"Nenhum código carregado.":"Nenhum DTC encontrado para: "+q,10);empty.setTextColor(Color.rgb(145,181,210));empty.setGravity(Gravity.CENTER);empty.setPadding(dp(12),dp(30),dp(12),dp(30));dtcLibraryListContainer.addView(empty);} }
    private void showDtcLibraryRecord(String code){ JSONObject o; synchronized(dtcLibraryRecords){o=dtcLibraryRecords.get(code);} if(o==null){showDtcDetails(code);return;} String desc=o.optString("description","Descrição não disponível na biblioteca DTC atual."); new AlertDialog.Builder(this).setTitle(code).setMessage(desc).setPositiveButton("OK",null).show(); }
    private boolean isVirtusLogsRelativePath(String rawPath){
        if(rawPath==null)return false;
        String p=rawPath.replace('\\','/').trim().toLowerCase(Locale.US);
        while(p.endsWith("/"))p=p.substring(0,p.length()-1);
        return p.equals("download/virtuselm/logs") || p.endsWith("/download/virtuselm/logs");
    }
    private Uri getSavedHistoryTree(){
        String saved=getSharedPreferences(PREFS_UI,MODE_PRIVATE).getString("history_tree_uri","");
        if(saved==null||saved.isEmpty())return null;
        try{return Uri.parse(saved);}catch(Exception e){return null;}
    }
    private void chooseHistoryFolder(){
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        if(Build.VERSION.SDK_INT>=26){Uri current=getSavedHistoryTree();if(current!=null)intent.putExtra(DocumentsContract.EXTRA_INITIAL_URI,current);}
        try{startActivityForResult(intent,REQ_HISTORY_TREE);}catch(Exception e){toast("Não foi possível abrir o seletor de pastas");}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQUEST_EXPORT_DIAGNOSTIC_ZIP){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null && pendingDiagnosticExport!=null){
                try(OutputStream os=getContentResolver().openOutputStream(data.getData())){if(os==null)throw new IOException("Destino indisponível");os.write(pendingDiagnosticExport);os.flush();toast("ZIP de LOGs técnicos exportado com sucesso");}
                catch(Exception e){toast("Falha ao salvar ZIP de LOGs: "+e.getMessage());}
            }else toast("Exportação cancelada");
            pendingDiagnosticExport=null;
            return;
        }
        if(requestCode!=REQ_HISTORY_TREE||resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri tree=data.getData();
        try{
            String docId=DocumentsContract.getTreeDocumentId(tree);
            String normalized=docId==null?"":docId.replace('\\','/').toLowerCase(Locale.US);
            if(!normalized.endsWith("/virtuselm/logs")&&!normalized.endsWith(":download/virtuselm/logs")){
                new AlertDialog.Builder(this).setTitle("PASTA INCORRETA").setMessage("Selecione a pasta Download/VirtusELM/logs para o aplicativo listar, abrir e apagar os CSVs corretos.").setPositiveButton("OK",null).show();return;
            }
            int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContentResolver().takePersistableUriPermission(tree,flags);
            getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putString("history_tree_uri",tree.toString()).apply();
            historyTreeUri=tree;refreshHistorySessions();toast("Pasta de logs vinculada com acesso persistente");
        }catch(Exception e){toast("Não foi possível guardar o acesso à pasta: "+e.getClass().getSimpleName());}
    }
    private ArrayList<String> listPersistentHistoryFiles(){
        LinkedHashSet<String> found=new LinkedHashSet<>(); historyFileUris.clear();
        // SAF: lista inclusive CSVs antigos que o MediaStore pode ocultar por causa do armazenamento restrito.
        Uri tree=getSavedHistoryTree(); historyTreeUri=tree;
        if(tree!=null){Cursor c=null;try{
            String rootId=DocumentsContract.getTreeDocumentId(tree);
            Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,rootId);
            String[] pr={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
            c=getContentResolver().query(children,pr,null,null,DocumentsContract.Document.COLUMN_DISPLAY_NAME+" ASC");
            if(c!=null){int idIdx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID),nameIdx=c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME),mimeIdx=c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                while(c.moveToNext()){String name=nameIdx>=0?c.getString(nameIdx):null;String mime=mimeIdx>=0?c.getString(mimeIdx):"";String id=idIdx>=0?c.getString(idIdx):null;
                    if(name!=null&&name.toLowerCase(Locale.US).endsWith(".csv")&&!isTemporaryLogFileName(name)&&id!=null){found.add(name);historyFileUris.put(name,DocumentsContract.buildDocumentUriUsingTree(tree,id));}
                }
            }
        }catch(Exception e){append("HISTÓRICO: SAF não conseguiu listar a pasta vinculada — "+e.getClass().getSimpleName());}finally{if(c!=null)c.close();}}
        if(Build.VERSION.SDK_INT>=29){Cursor c=null;try{
            Uri collection=MediaStore.Files.getContentUri("external");String[] pr={MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.RELATIVE_PATH};
            c=getContentResolver().query(collection,pr,null,null,MediaStore.MediaColumns.DATE_MODIFIED+" DESC");
            if(c!=null){int idIdx=c.getColumnIndex(MediaStore.MediaColumns._ID),nameIdx=c.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME),pathIdx=c.getColumnIndex(MediaStore.MediaColumns.RELATIVE_PATH);
                while(c.moveToNext()){String name=nameIdx>=0?c.getString(nameIdx):null;String path=pathIdx>=0?c.getString(pathIdx):null;
                    if(name!=null&&name.toLowerCase(Locale.US).endsWith(".csv")&&isVirtusLogsRelativePath(path)){if(!found.contains(name)&&idIdx>=0)historyFileUris.put(name,ContentUris.withAppendedId(collection,c.getLong(idIdx)));found.add(name);}
                }
            }
        }catch(Exception e){append("HISTÓRICO: MediaStore falhou — "+e.getClass().getSimpleName());}finally{if(c!=null)c.close();}}
        try{File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs");File[] fs=dir.listFiles((d,n)->n.toLowerCase(Locale.US).endsWith(".csv"));if(fs!=null){Arrays.sort(fs,(a,b)->Long.compare(b.lastModified(),a.lastModified()));for(File f:fs)if(f.isFile())found.add(f.getName());}}catch(Exception e){append("HISTÓRICO: leitura direta indisponível — "+e.getClass().getSimpleName());}
        ArrayList<String> names=new ArrayList<>(found);Collections.sort(names,(a,b)->b.compareToIgnoreCase(a));return names;
    }
    private void refreshHistorySessions(){
        // Rebuild the list from the persistent folder and verify that each indexed CSV can actually be opened.
        loadHistorySessions(); int count=historySessionNames.size(), readable=0;
        for(String name:new ArrayList<>(historySessionNames)){try(InputStream in=openPersistentHistoryInput(name)){if(in!=null){in.read();readable++;}}catch(Exception e){append("HISTÓRICO: arquivo listado mas sem leitura confirmada: "+name);}}
        String folder=getSavedHistoryTree()!=null?"pasta vinculada":"Download/VirtusELM/logs";
        toast("Histórico atualizado • "+count+" CSV listado(s) • "+readable+" acessível(is) • "+folder);
    }
    private InputStream openPersistentHistoryInput(String name) throws IOException{
        Uri selected=historyFileUris.get(name);
        if(selected!=null){
            try{InputStream stream=getContentResolver().openInputStream(selected);if(stream!=null)return stream;}
            catch(Exception e){append("HISTÓRICO: URI selecionada indisponível para "+name+" — "+e.getClass().getSimpleName());}
        }
        if(Build.VERSION.SDK_INT>=29){
            Cursor c=null;
            try{
                Uri collection=MediaStore.Downloads.EXTERNAL_CONTENT_URI;
                String[] projection={MediaStore.Downloads._ID,MediaStore.Downloads.DISPLAY_NAME,MediaStore.Downloads.RELATIVE_PATH};
                String selection=MediaStore.Downloads.DISPLAY_NAME+"=? AND "+MediaStore.Downloads.RELATIVE_PATH+"=?";
                String[] args={name,Environment.DIRECTORY_DOWNLOADS+"/VirtusELM/logs/"};
                c=getContentResolver().query(collection,projection,selection,args,MediaStore.Downloads.DATE_MODIFIED+" DESC");
                if(c!=null){
                    int idIdx=c.getColumnIndex(MediaStore.Downloads._ID);
                    while(c.moveToNext()){
                        if(idIdx<0)break;
                        Uri item=ContentUris.withAppendedId(collection,c.getLong(idIdx));
                        try{InputStream stream=getContentResolver().openInputStream(item);if(stream!=null)return stream;}
                        catch(Exception e){append("HISTÓRICO: MediaStore não abriu "+name+" — "+e.getClass().getSimpleName());}
                    }
                }
            }catch(Exception e){append("HISTÓRICO: consulta Downloads falhou para "+name+" — "+e.getClass().getSimpleName());}
            finally{if(c!=null)c.close();}
        }
        File f=new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs"),name);
        if(f.isFile())return new FileInputStream(f);
        throw new FileNotFoundException(name);
    }
    private void deleteHistoryFile(String name){
        Uri target=historyFileUris.get(name);
        try{
            if(target!=null){boolean deleted=false;try{deleted=DocumentsContract.deleteDocument(getContentResolver(),target);}catch(Exception ignored){}if(!deleted){int n=getContentResolver().delete(target,null,null);deleted=n>0;}if(!deleted)throw new IOException("O provedor não confirmou a exclusão");}
            else{File f=new File(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs"),name);if(!f.isFile()||!f.delete())throw new IOException("Arquivo não removido");}
            toast("Sessão apagada: "+name);loadHistorySessions();
        }catch(Exception e){toast("Não foi possível apagar o CSV: "+e.getClass().getSimpleName());}
    }
    private void loadHistorySessions(){
        if(historyScreen==null)return; LinearLayout list=(LinearLayout)historyScreen.findViewWithTag("historyList"); if(list==null)return; list.removeAllViews(); historySessionNames.clear(); ArrayList<String> names=listPersistentHistoryFiles(); historySessionNames.addAll(names);
        if(names.isEmpty()){if(perfSessionCount!=null)setPerfText(perfSessionCount,"SESSÕES","0");TextView empty=tv("NENHUMA SESSÃO PERSISTENTE ENCONTRADA\n\nOs arquivos são procurados em Download/VirtusELM/logs. Faça uma puxada e finalize o teste para gerar um registro.",11);empty.setTextColor(Color.rgb(145,181,210));empty.setGravity(Gravity.CENTER);empty.setPadding(dp(12),dp(30),dp(12),dp(30));list.addView(empty);return;}
        TextView countLabel=tv("ARQUIVOS ENCONTRADOS: "+names.size()+" • exibindo até 500",9);countLabel.setTextColor(Color.rgb(0,194,255));countLabel.setPadding(dp(8),dp(8),dp(8),dp(8));list.addView(countLabel);
        int shown=0;for(String name:names){if(shown++>=500)break;LinearLayout item=card(Color.rgb(4,28,55));item.setPadding(dp(10),dp(8),dp(10),dp(8));TextView a=tv(name,11);a.setTextColor(Color.rgb(242,248,255));a.setTypeface(null,android.graphics.Typeface.BOLD);TextView b=tv("CSV persistente • toque para abrir resumo",9);b.setTextColor(Color.rgb(145,181,210));item.addView(a);item.addView(b);bindClick(item,()->showHistoryFile(name));list.addView(item,new LinearLayout.LayoutParams(-1,dp(66)));}
        if(perfSessionCount!=null)setPerfText(perfSessionCount,"SESSÕES",String.valueOf(names.size()));
    }
    private static class BestPull { long ts=0; String file="",vin="",fuel="",source=""; double z60=-1,z100=-1,power=-1,torque=-1,boost=-1,rpm=-1,speed=-1,pedal=-1,pedalE=-1,pedalF=-1,throttle=-1,load=-1,map=-1,baro=-1,coolant=-1,intake=-1,oilTemp=-1,fuelPct=-1,voltage=-1,quality=-1,duration=-1; int shifts=-1,samples=-1; }
    private int historyCol(String[] header,String key){if(header==null)return -1;for(int i=0;i<header.length;i++)if(key.equalsIgnoreCase(header[i].trim()))return i;return -1;}
    private String historyField(String[] fields,String[] header,String key){int i=historyCol(header,key);return i>=0&&i<fields.length?fields[i].trim():"";}
    private double historyNumber(String[] fields,String[] header,String key){int i=historyCol(header,key);return parseHistoryDouble(fields,i);}
    private ArrayList<BestPull> readBestPulls(){
        ArrayList<BestPull> pulls=new ArrayList<>(); HashSet<String> seen=new HashSet<>();
        for(String name:listPersistentHistoryFiles()){
            try(BufferedReader br=new BufferedReader(new InputStreamReader(openPersistentHistoryInput(name),StandardCharsets.UTF_8))){String line;String[] header=null;double observedSpeed=-1,observedRpm=-1,observedBoost=-1,observedPedal=-1;while((line=br.readLine())!=null){if(line.startsWith("tipo;")){header=line.split(";",-1);continue;}if(header==null)continue;String[] f=line.split(";",-1);if(f.length<2)continue;double rowSpeed=historyNumber(f,header,"speed_kmh"),rowRpm=historyNumber(f,header,"rpm"),rowBoost=historyNumber(f,header,"boost_max_bar"),rowPedal=historyNumber(f,header,"pedal_d_pct");if(rowSpeed>observedSpeed)observedSpeed=rowSpeed;if(rowRpm>observedRpm)observedRpm=rowRpm;if(rowBoost<0)rowBoost=historyNumber(f,header,"boost_bar");if(rowBoost>observedBoost)observedBoost=rowBoost;if(rowPedal>observedPedal)observedPedal=rowPedal;if(!line.startsWith("PERFORMANCE_TEST;"))continue;
                BestPull p=new BestPull();p.file=name;try{p.ts=Long.parseLong(historyField(f,header,"timestamp_ms"));}catch(Exception ignored){} p.vin=historyField(f,header,"vin");String ethanol=historyField(f,header,"ethanol_pct");p.fuel=!ethanol.isEmpty()?ethanol+"% etanol":"não informado";p.power=historyNumber(f,header,"power_est_cv");p.torque=historyNumber(f,header,"torque_est_nm");p.z60=historyNumber(f,header,"zero60_s");p.z100=historyNumber(f,header,"zero100_s");p.quality=historyNumber(f,header,"quality_pct");p.duration=historyNumber(f,header,"pull_duration_s");try{p.shifts=(int)historyNumber(f,header,"gear_shifts");}catch(Exception ignored){}p.pedal=historyNumber(f,header,"pedal_d_pct");p.pedalE=historyNumber(f,header,"pedal_e_pct");p.pedalF=historyNumber(f,header,"pedal_f_pct");p.source=historyField(f,header,"speed_source");p.map=historyNumber(f,header,"map_kpa");p.baro=historyNumber(f,header,"baro_kpa");p.boost=historyNumber(f,header,"boost_max_bar");if(p.boost<0)p.boost=historyNumber(f,header,"boost_bar");p.throttle=historyNumber(f,header,"throttle_pct");p.load=historyNumber(f,header,"load_pct");p.coolant=historyNumber(f,header,"coolant_c");p.intake=historyNumber(f,header,"intake_c");p.oilTemp=historyNumber(f,header,"oil_temp_c");p.fuelPct=historyNumber(f,header,"fuel_pct");p.voltage=historyNumber(f,header,"voltage_v");p.rpm=historyNumber(f,header,"rpm");p.speed=historyNumber(f,header,"speed_kmh");if(observedSpeed>p.speed)p.speed=observedSpeed;if(observedRpm>p.rpm)p.rpm=observedRpm;if(observedBoost>p.boost)p.boost=observedBoost;if(observedPedal>p.pedal)p.pedal=observedPedal;p.samples=(int)historyNumber(f,header,"samples");
                String key=String.format(Locale.US,"%d|%.2f|%.2f|%.0f|%.0f|%s",p.ts/60000L,p.z60,p.z100,p.power,p.rpm,p.vin);if(seen.add(key))pulls.add(p);
            }}catch(Exception ignored){}
        }
        Collections.sort(pulls,(a,b)->{boolean av=a.z100>0,bv=b.z100>0;if(av&&bv)return Double.compare(a.z100,b.z100);if(av!=bv)return av?-1:1;if(a.z60>0&&b.z60>0)return Double.compare(a.z60,b.z60);if(a.z60>0)return -1;if(b.z60>0)return 1;return Long.compare(b.ts,a.ts);});return pulls;
    }
    private TextView tableCell(String text,boolean header){TextView v=tv(text,header?9:8.5f);v.setTextColor(header?Color.rgb(0,220,255):Color.rgb(238,247,255));if(header)v.setTypeface(null,android.graphics.Typeface.BOLD);v.setGravity(Gravity.CENTER_VERTICAL);v.setPadding(dp(7),dp(8),dp(7),dp(8));v.setMinWidth(dp(header?84:84));v.setBackground(cardBg(header?Color.rgb(7,54,82):Color.rgb(4,28,55),8,Color.rgb(30,100,145)));return v;}
    private void showBestPullsDialog(){
        ArrayList<BestPull> all=readBestPulls();if(all.isEmpty()){new AlertDialog.Builder(this).setTitle("3 MELHORES PUXADAS").setMessage("Ainda não encontrei registros PERFORMANCE_TEST nos CSVs arquivados. Faça uma puxada e finalize o teste; a nova versão salvará um arquivo próprio para cada puxada.").setPositiveButton("OK",null).show();return;}
        int count=Math.min(3,all.size());LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);TextView info=tv("Ordenação: menor 0–100; quando indisponível, menor 0–60. Deslize horizontalmente para ver todas as colunas.",9);info.setTextColor(Color.rgb(145,181,210));info.setPadding(dp(4),dp(4),dp(4),dp(8));outer.addView(info);
        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setFillViewport(false);LinearLayout table=new LinearLayout(this);table.setOrientation(LinearLayout.VERTICAL);
        String[] headers={"#","DATA/HORA","0–60 s","0–100 s","POTÊNCIA cv","TORQUE Nm","BOOST máx. bar","RPM máx.","VEL. máx. km/h","PEDAL D %","PEDAL E %","PEDAL F %","THROTTLE %","CARGA %","MAP kPa","BARO kPa","LÍQUIDO °C","ADMISSÃO °C","ÓLEO °C","COMB. %","TENSÃO V","QUAL. %","DURAÇÃO s","TROCAS","ETANOL","AMOSTRAS","FONTE","VIN","ARQUIVO"};LinearLayout hr=row();for(String h:headers)hr.addView(tableCell(h,true));table.addView(hr);
        for(int i=0;i<count;i++){BestPull p=all.get(i);String dt=p.ts>0?new SimpleDateFormat("dd/MM HH:mm:ss",Locale.getDefault()).format(new Date(p.ts)):"—";String[] vals={String.valueOf(i+1),dt,fmtHistory(p.z60,"",2),fmtHistory(p.z100,"",2),fmtHistory(p.power,"",0),fmtHistory(p.torque,"",0),fmtHistory(p.boost,"",2),fmtHistory(p.rpm,"",0),fmtHistory(p.speed,"",0),fmtHistory(p.pedal,"",0),fmtHistory(p.pedalE,"",0),fmtHistory(p.pedalF,"",0),fmtHistory(p.throttle,"",0),fmtHistory(p.load,"",0),fmtHistory(p.map,"",1),fmtHistory(p.baro,"",1),fmtHistory(p.coolant,"",0),fmtHistory(p.intake,"",0),fmtHistory(p.oilTemp,"",0),fmtHistory(p.fuelPct,"",0),fmtHistory(p.voltage,"",2),fmtHistory(p.quality,"",0),fmtHistory(p.duration,"",2),(p.shifts>=0?String.valueOf(p.shifts):"—"),p.fuel,p.samples>=0?String.valueOf(p.samples):"—",p.source,p.vin.isEmpty()?"—":p.vin,p.file};LinearLayout rr=row();for(String v:vals)rr.addView(tableCell(v,false));table.addView(rr);}
        hsv.addView(table,new HorizontalScrollView.LayoutParams(-2,-2));outer.addView(hsv,new LinearLayout.LayoutParams(-1,-2));TextView footer=tv("Registros encontrados: "+all.size()+" • exibindo "+count+" melhores. Os campos sem dados no CSV aparecem como —.",8.5f);footer.setTextColor(Color.rgb(145,181,210));footer.setPadding(dp(4),dp(8),dp(4),0);outer.addView(footer);
        ScrollView sv=new ScrollView(this);sv.addView(outer,new ScrollView.LayoutParams(-1,-2));new AlertDialog.Builder(this).setTitle("🏆 3 MELHORES PUXADAS").setView(sv).setPositiveButton("FECHAR",null).show();
    }
    private static class HistorySummary{
        int telemetrySamples=0, performanceTests=0, sampleCount=-1;
        long firstTs=-1,lastTs=-1;
        double maxSpeed=-1,maxRpm=-1,maxBoost=-1,maxThrottle=-1,maxAcceleration=-1;
        double zero60=-1,zero100=-1,power=-1,torque=-1,quality=-1,pullDuration=-1,pedalMax=-1,boostMax=-1,maxSpeedRecorded=-1,maxRpmRecorded=-1; int gearShifts=0;
        String vin="", speedSource="", fuel="";
    }
    private double parseHistoryDouble(String[] f,int idx){
        if(idx<0||idx>=f.length||f[idx]==null||f[idx].trim().isEmpty())return -1;
        try{return Double.parseDouble(f[idx].trim());}catch(Exception e){return -1;}
    }
    private HistorySummary readHistorySummary(BufferedReader br) throws IOException{
        HistorySummary h=new HistorySummary();String line;double prevSpeed=-1;long prevTs=-1;String[] header=null;
        while((line=br.readLine())!=null){if(line.startsWith("tipo;")){header=line.split(";",-1);continue;}if(header==null)continue;String[] f=line.split(";",-1);if(f.length<2)continue;
            String type=historyField(f,header,"tipo");long ts=-1;try{ts=Long.parseLong(historyField(f,header,"timestamp_ms"));}catch(Exception ignored){}if(ts>0){if(h.firstTs<0)h.firstTs=ts;h.lastTs=ts;}
            double rpm=historyNumber(f,header,"rpm"),speed=historyNumber(f,header,"speed_kmh"),gps=historyNumber(f,header,"gps_speed_kmh"),boost=historyNumber(f,header,"boost_max_bar"),throttle=historyNumber(f,header,"throttle_pct"),pedal=historyNumber(f,header,"pedal_d_pct");if(boost<0)boost=historyNumber(f,header,"boost_bar");String source=historyField(f,header,"speed_source");double preferred=("GPS".equalsIgnoreCase(source)&&gps>=0)?gps:(speed>=0?speed:gps);
            if(preferred>=0&&preferred>h.maxSpeed)h.maxSpeed=preferred;if(rpm>h.maxRpm)h.maxRpm=rpm;if(boost>h.maxBoost)h.maxBoost=boost;if(throttle>h.maxThrottle)h.maxThrottle=throttle;if(pedal>h.pedalMax)h.pedalMax=pedal;if(!source.isEmpty())h.speedSource=source;
            if(ts>0&&prevTs>0&&ts>prevTs&&preferred>=0&&prevSpeed>=0){double dt=(ts-prevTs)/1000.0;if(dt>0&&dt<=2.0){double acc=((preferred-prevSpeed)/3.6)/dt;if(acc>h.maxAcceleration)h.maxAcceleration=acc;}}if(preferred>=0){prevSpeed=preferred;prevTs=ts;}
            String vin=historyField(f,header,"vin");if(!vin.isEmpty())h.vin=vin;double pd=historyNumber(f,header,"pull_duration_s");if(pd>=0)h.pullDuration=pd;
            if("PERFORMANCE_TEST".equalsIgnoreCase(type)){h.performanceTests++;double p=historyNumber(f,header,"power_est_cv"),tq=historyNumber(f,header,"torque_est_nm"),z60=historyNumber(f,header,"zero60_s"),z100=historyNumber(f,header,"zero100_s"),q=historyNumber(f,header,"quality_pct");if(p>=0)h.power=p;if(tq>=0)h.torque=tq;if(z60>=0)h.zero60=z60;if(z100>=0)h.zero100=z100;if(q>=0)h.quality=q;double shifts=historyNumber(f,header,"gear_shifts");if(shifts>=0)h.gearShifts=(int)shifts;double samples=historyNumber(f,header,"samples");if(samples>=0)h.sampleCount=(int)samples;}
            else if("TELEMETRIA".equalsIgnoreCase(type))h.telemetrySamples++;
        }return h;
    }
    private String fmtHistory(double v,String unit,int decimals){
        if(v<0)return "—"; return String.format(Locale.US,"%."+decimals+"f %s",v,unit);
    }
    private void showHistoryFile(String name){
        try{
            BufferedReader br=new BufferedReader(new InputStreamReader(openPersistentHistoryInput(name),StandardCharsets.UTF_8));
            HistorySummary h=readHistorySummary(br); br.close();
            double duration=h.firstTs>0&&h.lastTs>h.firstTs?(h.lastTs-h.firstTs)/1000.0:-1;
            StringBuilder msg=new StringBuilder();
            msg.append("RESUMO DA SESSÃO\n\n");
            msg.append("VELOCIDADE MÁXIMA: ").append(fmtHistory(h.maxSpeed,"km/h",0)).append("\n");
            msg.append("BOOST MÁXIMO: ").append(fmtHistory(h.maxBoost,"bar",2)).append("\n");
            msg.append("ACELERAÇÃO MÁXIMA: ").append(h.maxAcceleration>=0?String.format(Locale.US,"%.2f m/s²",h.maxAcceleration):"—").append("\n");
            msg.append("RPM MÁXIMO: ").append(fmtHistory(h.maxRpm,"rpm",0)).append("\n");
            msg.append("PEDAL MÁXIMO: ").append(fmtHistory(h.pedalMax>=0?h.pedalMax:h.maxThrottle,"%",0)).append("\n");
            msg.append("TEMPO TOTAL: ").append(duration>=0?String.format(Locale.US,"%.1f s",duration):"—").append("\n");
            if(h.performanceTests>0){
                msg.append("\nPERFORMANCE\n");
                msg.append("0–60 km/h: ").append(fmtHistory(h.zero60,"s",2)).append("\n");
                msg.append("0–100 km/h: ").append(fmtHistory(h.zero100,"s",2)).append("\n");
                msg.append("DURAÇÃO DA PUXADA: ").append(fmtHistory(h.pullDuration,"s",2)).append("\n");
                msg.append("TROCAS DE MARCHA: ").append(h.gearShifts).append(" (estimadas)\n");
                msg.append("POTÊNCIA ESTIMADA: ").append(fmtHistory(h.power,"cv",0)).append("\n");
                msg.append("TORQUE ESTIMADO: ").append(fmtHistory(h.torque,"Nm",0)).append("\n");
                msg.append("QUALIDADE DA AQUISIÇÃO: ").append(fmtHistory(h.quality,"%",0)).append("\n");
            }
            if(!h.speedSource.isEmpty())msg.append("\nFONTE DA VELOCIDADE: ").append(h.speedSource);
            if(!h.vin.isEmpty())msg.append("\nVIN: ").append(h.vin);
            msg.append("\n\nREGISTRO: ").append(h.telemetrySamples).append(" amostras");
            if(h.performanceTests>0)msg.append(" • ").append(h.performanceTests).append(" teste(s) de performance");
            LinearLayout detail=new LinearLayout(this);detail.setOrientation(LinearLayout.VERTICAL);detail.setPadding(dp(18),dp(8),dp(18),dp(8));
            TextView detailText=tv(msg.toString(),12);detailText.setTextColor(Color.rgb(24,39,56));detailText.setLinkTextColor(Color.rgb(0,76,130));detailText.setLineSpacing(dp(2),1.0f);detailText.setMovementMethod(new ScrollingMovementMethod());detailText.setMaxHeight(dp(420));detail.addView(detailText,new LinearLayout.LayoutParams(-1,-2));
            LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);actions.setGravity(Gravity.CENTER);actions.setPadding(0,dp(12),0,dp(2));
            Button ok=btn("OK");Button del=btn("APAGAR");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(46),1);bp.setMargins(dp(6),0,dp(6),0);actions.addView(ok,bp);LinearLayout.LayoutParams dpb=new LinearLayout.LayoutParams(0,dp(46),1);dpb.setMargins(dp(6),0,dp(6),0);actions.addView(del,dpb);detail.addView(actions);
            AlertDialog detailDialog=new AlertDialog.Builder(this).setTitle("SESSÃO • "+name.replace("VirtusELM_Performance_","").replace(".csv","")).setView(detail).create();
            ok.setOnClickListener(v->detailDialog.dismiss());
            del.setOnClickListener(v->{AlertDialog confirm=new AlertDialog.Builder(this).setTitle("APAGAR SESSÃO?").setMessage("Deseja realmente apagar este arquivo CSV?\n\n"+name+"\n\nEssa ação não pode ser desfeita.").setNegativeButton("CANCELAR",(d,w)->{d.dismiss();detailDialog.dismiss();loadHistorySessions();}).setPositiveButton("APAGAR",(d,w)->{d.dismiss();detailDialog.dismiss();deleteHistoryFile(name);}).create();confirm.setOnCancelListener(d->{detailDialog.dismiss();loadHistorySessions();});confirm.show();});
            detailDialog.show();
        }catch(Exception e){toast("Não foi possível ler a sessão: "+e.getClass().getSimpleName());}
    }

    private void showScreen(int screen){
        currentScreen=screen;
        applyPerformanceImmersive(screen==6);
        updateNavSelection(screen);
        if(homeScreen!=null)homeScreen.setVisibility(screen==0?View.VISIBLE:View.GONE);
        if(dataScreen!=null)dataScreen.setVisibility(screen==1?View.VISIBLE:View.GONE);
        if(diagnosticScreen!=null)diagnosticScreen.setVisibility(screen==2?View.VISIBLE:View.GONE);
        if(canScreen!=null)canScreen.setVisibility(screen==9?View.VISIBLE:View.GONE);
        if(customScreen!=null)customScreen.setVisibility(screen==3?View.VISIBLE:View.GONE);
        if(configScreen!=null)configScreen.setVisibility(screen==4?View.VISIBLE:View.GONE);
        if(graphScreen!=null)graphScreen.setVisibility(screen==5?View.VISIBLE:View.GONE);
        if(performanceScreen!=null)performanceScreen.setVisibility(screen==6?View.VISIBLE:View.GONE);
        if(historyScreen!=null)historyScreen.setVisibility(screen==7?View.VISIBLE:View.GONE);
        if(dtcLibraryScreen!=null)dtcLibraryScreen.setVisibility(screen==8?View.VISIBLE:View.GONE);
        if(screen==1){
            if(!dataTabButtons.isEmpty()){setSelectedButton(dataTabButtons.get(0),!dataLogsTab);setSelectedButton(dataTabButtons.get(1),false);setSelectedButton(dataTabButtons.get(2),dataLogsTab);}
            if(dataTelemetryContent!=null)dataTelemetryContent.setVisibility(dataLogsTab?View.GONE:View.VISIBLE);
            if(dataLogsContent!=null)dataLogsContent.setVisibility(dataLogsTab?View.VISIBLE:View.GONE);
            if(log!=null&&log.getText().length()==0){synchronized(logLock){log.setText(technical.toString());}} updateRecordingUi();
        }
    }
    /** Tema imersivo Performance: aplica a identidade esportiva à moldura fixa e à tela inteira. */
    private void applyPerformanceImmersive(boolean enabled){
        performanceImmersive=enabled;
        int black=Color.rgb(7,9,12), deep=Color.rgb(10,13,16), red=Color.rgb(238,32,48), white=Color.rgb(250,245,246);
        if(fixedHero!=null){
            GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,enabled?new int[]{Color.rgb(45,5,10),Color.rgb(10,5,8),Color.rgb(35,4,8)}:new int[]{Color.rgb(4,38,82),Color.rgb(2,12,28)});
            g.setCornerRadius(dp(20)); g.setStroke(dp(1),enabled?red:Color.rgb(45,142,255)); fixedHero.setBackground(g);
        }
        if(fixedNav!=null){ fixedNav.setBackground(cardBg(enabled?black:Color.rgb(3,24,47),24,enabled?red:Color.rgb(45,142,255))); }
        if(fixedBrandLogo!=null) fixedBrandLogo.setColorFilter(enabled?red:Color.rgb(0,170,245));
        if(fixedBrandSubtitle!=null) fixedBrandSubtitle.setTextColor(enabled?red:Color.rgb(80,190,255));
        // O carro acompanha o tema do cabeçalho; o overlay HeadlightFlashView continua intacto.
        if(fixedCarImage!=null) fixedCarImage.setImageResource(R.drawable.v12_car_header_motion);
        if(performanceScreen!=null){ performanceScreen.setBackgroundColor(enabled?black:Color.rgb(1,10,22)); }
        if(enabled){
            if(perfStatus!=null){ if(performanceRunning){perfStatus.setTextColor(red);} else if(perfStatus.getText()!=null && perfStatus.getText().toString().startsWith("ARMADO")){perfStatus.setTextColor(Color.rgb(255,190,0));} else {perfStatus.setTextColor(Color.rgb(255,90,100));} }
            if(perfFuel!=null)perfFuel.setTextColor(white);
            if(perfConfidence!=null)perfConfidence.setTextColor(Color.rgb(205,185,190));
            if(perfPower!=null)perfPower.setBackground(cardBg(deep,12,Color.rgb(95,43,52)));
            if(perfTorque!=null)perfTorque.setBackground(cardBg(deep,12,Color.rgb(72,47,53)));
            if(perf0060!=null)perf0060.setBackground(cardBg(deep,12,Color.rgb(54,56,65)));
            if(perf0100!=null)perf0100.setBackground(cardBg(deep,12,Color.rgb(54,56,65)));
            if(perfBoost!=null)perfBoost.setBackground(cardBg(deep,12,Color.rgb(72,58,42)));
            if(perfQuality!=null)perfQuality.setBackground(cardBg(deep,12,Color.rgb(54,56,65)));
            if(perfMaxRpm!=null)perfMaxRpm.setBackground(cardBg(deep,12,Color.rgb(54,56,65)));
            if(perfMaxSpeed!=null)perfMaxSpeed.setBackground(cardBg(deep,12,Color.rgb(54,56,65)));
            if(perfDuration!=null)perfDuration.setBackground(cardBg(deep,12,Color.rgb(54,56,65)));
            if(perfSessionCount!=null)perfSessionCount.setBackground(cardBg(deep,12,Color.rgb(72,58,42)));
            stylePerformanceChildren(performanceScreen,true);
        }else{
            stylePerformanceChildren(performanceScreen,false);
        }
    }
    private void stylePerformanceChildren(View view,boolean enabled){
        if(view==null)return;
        if(view instanceof Button){ Button b=(Button)view; String label=String.valueOf(b.getText()).toUpperCase(Locale.ROOT); boolean primary=enabled&&(label.contains("INICIAR TESTE")||label.contains("INICIAR 0")); int bg=enabled?(primary?Color.rgb(126,29,44):Color.rgb(20,17,22)):Color.rgb(7,38,70); int stroke=enabled?(primary?Color.rgb(176,53,69):Color.rgb(75,43,51)):Color.rgb(25,125,195); GradientDrawable d=new GradientDrawable(); d.setColor(bg); d.setCornerRadius(dp(13)); d.setStroke(dp(1),stroke); b.setBackground(d); b.setTextColor(enabled?Color.rgb(245,239,241):Color.rgb(235,248,255)); }
        else if(view instanceof TextView && !(view instanceof Button)){ TextView t=(TextView)view; if(enabled && t.getText()!=null && t.getText().toString().contains("PUXADA CONCLUÍDA"))t.setTextColor(Color.WHITE); }
        if(view instanceof ViewGroup){ ViewGroup g=(ViewGroup)view; for(int i=0;i<g.getChildCount();i++)stylePerformanceChildren(g.getChildAt(i),enabled); }
    }
    private void showHomeScreen(){showScreen(0);}
    private void showDataScreen(){historicalGraphMode=false;showScreen(1);}
    private void showDiagnosticScreen(){showScreen(2);}
    private void showCanScreen(){showScreen(9);}
    private void showCustomScreen(){showScreen(3);}
    private void showConfigScreen(){showScreen(4);}
    private void showGraphScreen(){
        showScreen(5);
        // Abrir sempre no modo ao vivo; sem ECU o gráfico permanece vazio e identificado como aguardando dados.
        showLiveCombinedGraph();
    }
    private void showLiveCombinedGraph(){
        historicalGraphMode=false; combinedRpmValues.clear();combinedSpeedValues.clear();combinedPedalValues.clear();combinedBoostValues.clear();combinedTimeValues.clear();
        if(graphHeaderTitle!=null)graphHeaderTitle.setText("GRÁFICO COMBINADO • TEMPO REAL");
        if(graphHistoryStatus!=null){String msg=(ecuResponding&&!simulationMode)?"AGUARDANDO NOVAS AMOSTRAS DO ELM":simulationMode?"SIMULAÇÃO ATIVA • DADOS NÃO REAIS":"SEM CONEXÃO • gráfico aguardando telemetria";graphHistoryStatus.setText(msg);graphHistoryStatus.setTextColor(Color.rgb(55,150,255));}
        if(combinedGraphView!=null)combinedGraphView.invalidate();
        if(ecuResponding&&!simulationMode)ui(()->updateDashboard());
    }
    private void showHistoricalCombinedGraph(){
        historicalGraphMode=true; combinedRpmValues.clear();combinedSpeedValues.clear();combinedPedalValues.clear();combinedBoostValues.clear();combinedTimeValues.clear();
        if(graphHeaderTitle!=null)graphHeaderTitle.setText("GRÁFICO • HISTÓRICO DA PUXADA");
        loadLastPerformanceGraph();
    }
    private void showPerformanceTestGraph(){showScreen(5);loadLastPerformanceGraph();}
    private void showPerformanceScreen(){ if(currentScreen!=5)performanceEthanolOverride=-1; historicalGraphMode=false; combinedRpmValues.clear();combinedSpeedValues.clear();combinedPedalValues.clear();combinedBoostValues.clear();combinedTimeValues.clear(); showScreen(6); startGpsTracking(); if(performanceScreen!=null){ ScrollView sv=(ScrollView)performanceScreen.getChildAt(0); if(sv!=null)sv.post(()->sv.scrollTo(0,0)); } loadHistorySessions(); loadBestPullSummaryIntoPerformance(); }
    private void loadBestPullSummaryIntoPerformance(){
        ArrayList<BestPull> pulls=readBestPulls();
        if(perfSessionCount!=null)setPerfText(perfSessionCount,"SESSÕES",String.valueOf(listPersistentHistoryFiles().size()));
        if(pulls.isEmpty())return;
        BestPull p=pulls.get(0);
        if(p.power>=0)setPerfText(perfPower,"POTÊNCIA ESTIMADA",String.format(Locale.US,"%.0f cv",p.power));
        if(p.torque>=0)setPerfText(perfTorque,"TORQUE ESTIMADO",String.format(Locale.US,"%.0f Nm",p.torque));
        if(p.z60>0)setPerfText(perf0060,"0–60 km/h",String.format(Locale.US,"%.2f s",p.z60));
        if(p.z100>0)setPerfText(perf0100,"0–100 km/h",String.format(Locale.US,"%.2f s",p.z100));
        if(p.boost>=0)setPerfText(perfBoost,"BOOST MÁX.",String.format(Locale.US,"%.2f bar",p.boost));
        if(p.rpm>=0)setPerfText(perfMaxRpm,"RPM MÁX.",String.format(Locale.US,"%.0f rpm",p.rpm));
        if(p.speed>=0)setPerfText(perfMaxSpeed,"VELOCIDADE MÁX.",String.format(Locale.US,"%.0f km/h",p.speed));
        if(p.quality>=0)setPerfText(perfQuality,"QUALIDADE AQUISIÇÃO",String.format(Locale.US,"%.0f %%",p.quality));
        if(p.duration>0)setPerfText(perfDuration,"DURAÇÃO DO TESTE",String.format(Locale.US,"%.2f s",p.duration));
    }
    private void showHistoryScreen(){showScreen(7); loadHistorySessions();}
    private void showDtcLibraryScreen(){showScreen(8); renderDtcLibraryList();}

    private LinearLayout diagSection, canSection, logSection, configSection, recordSection;
    private GradientDrawable cardBg(int color,float radius,int stroke){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); g.setStroke(dp(1),stroke); return g; }
    private LinearLayout card(int color){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setBackground(cardBg(color,22,Color.rgb(20,95,150))); return l; }
    private ImageView icon(int res,int tint){ ImageView v=new ImageView(this); v.setImageResource(res); v.setColorFilter(tint); v.setScaleType(ImageView.ScaleType.CENTER_INSIDE); return v; }
    private TextView metric(String label,String value,int fg,int accent){ TextView t=tv("",10); t.setTextColor(fg); t.setGravity(Gravity.CENTER); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setSingleLine(false); t.setIncludeFontPadding(false); t.setPadding(dp(2),dp(5),dp(2),dp(5)); t.setBackground(cardBg(Color.rgb(5,34,64),16,accent)); setMetricText(t,label,value,""); return t; }
    private void setMetricText(TextView t,String label,String value,String unit){ if(t==null)return; String v=value==null?"—":value; String u=unit==null?"":unit; android.text.SpannableStringBuilder b=new android.text.SpannableStringBuilder(); int a=b.length(); b.append(label); b.setSpan(new android.text.style.AbsoluteSizeSpan(dp(9)),a,b.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); b.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(150,190,220)),a,b.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); b.append("\n"); int c=b.length(); b.append(v); b.setSpan(new android.text.style.AbsoluteSizeSpan(dp(18)),c,b.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); b.append("\n"); int d=b.length(); b.append(u); b.setSpan(new android.text.style.AbsoluteSizeSpan(dp(9)),d,b.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); t.setText(b); }
    private void addHalfView(LinearLayout r,TextView t){ LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(84),1); lp.setMargins(dp(3),dp(3),dp(3),dp(3)); r.addView(t,lp); }
    private void addModule(LinearLayout r,int iconRes,String title,String sub,int accent,final Runnable action){
        LinearLayout c=card(Color.rgb(4,28,55)); c.setPadding(dp(7),dp(6),dp(7),dp(6)); c.setBackground(pressableBg(Color.rgb(4,28,55),Color.rgb(8,58,92),accent,18));
        LinearLayout inner=new LinearLayout(this); inner.setOrientation(LinearLayout.HORIZONTAL); inner.setGravity(Gravity.CENTER_VERTICAL);
        ImageView ic=icon(iconRes,accent); ic.setScaleType(ImageView.ScaleType.CENTER_INSIDE); inner.addView(ic,new LinearLayout.LayoutParams(dp(46),dp(86)));
        LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setGravity(Gravity.CENTER_VERTICAL); texts.setPadding(dp(5),0,dp(2),0);
        TextView a=tv(title,10.5f); a.setTextColor(Color.WHITE); a.setTypeface(null,android.graphics.Typeface.BOLD); a.setSingleLine(true); a.setEllipsize(TextUtils.TruncateAt.END); a.setGravity(Gravity.CENTER_VERTICAL);
        if(Build.VERSION.SDK_INT>=26){ a.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP); }
        TextView b=tv(sub,8.2f); b.setTextColor(Color.rgb(165,195,220)); b.setSingleLine(true); b.setEllipsize(TextUtils.TruncateAt.END); b.setGravity(Gravity.CENTER_VERTICAL);
        if(Build.VERSION.SDK_INT>=26){ b.setAutoSizeTextTypeUniformWithConfiguration(7,9,1,android.util.TypedValue.COMPLEX_UNIT_SP); }
        texts.addView(a,new LinearLayout.LayoutParams(-1,dp(34))); texts.addView(b,new LinearLayout.LayoutParams(-1,dp(30)));
        inner.addView(texts,new LinearLayout.LayoutParams(0,dp(78),1));
        TextView arrow=tv("›",23); arrow.setTextColor(accent); arrow.setGravity(Gravity.CENTER); arrow.setIncludeFontPadding(false); inner.addView(arrow,new LinearLayout.LayoutParams(dp(16),dp(70)));
        c.addView(inner); bindClick(c,action); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(110),1); lp.setMargins(dp(4),dp(4),dp(4),dp(4)); r.addView(c,lp);
    }
    private void addNav(LinearLayout nav,int iconRes,String label,int accent,final Runnable action){
        LinearLayout item=new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setGravity(Gravity.CENTER);
        ImageView i=icon(iconRes,accent);
        TextView n=tv(label,11);
        n.setTextColor(accent);
        n.setGravity(Gravity.CENTER);
        item.addView(i,new LinearLayout.LayoutParams(-1,dp(52)));
        item.addView(n,new LinearLayout.LayoutParams(-1,dp(30)));
        item.setPadding(dp(3),dp(2),dp(3),dp(2));
        item.setBackground(pressableBg(Color.TRANSPARENT,Color.rgb(8,52,88),Color.TRANSPARENT,16));
        bindClick(item,action);
        navItems.add(item);
        navIcons.add(i);
        navLabels.add(n);
        nav.addView(item,new LinearLayout.LayoutParams(0,-1,1));
    }
    private void updateNavSelection(int screen){
        int selected=-1;
        if(screen>=0&&screen<=4) selected=screen;
        else if(screen==5) selected=1;
        else if(screen==6) selected=0;
        for(int i=0;i<navItems.size();i++){
            boolean active=i==selected;
            int color=(performanceImmersive?(active?Color.rgb(255,55,65):Color.rgb(190,170,175)):(active?NAV_ACTIVE:NAV_INACTIVE));
            navIcons.get(i).setColorFilter(color);
            navLabels.get(i).setTextColor(color);
        }
    }
    private void scrollToSection(LinearLayout root,View v){ if(v==null)return; v.post(()->{ ScrollView sv=(ScrollView)root.getParent(); if(sv!=null)sv.smoothScrollTo(0,Math.max(0,v.getTop()-16)); }); }

    private TextView healthChip(String text,int fg,int bg){ TextView t=tv(text,11); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setTextColor(fg); t.setGravity(Gravity.CENTER); t.setPadding(dp(6),dp(5),dp(6),dp(5)); t.setSingleLine(false); t.setMaxLines(2); if(Build.VERSION.SDK_INT>=26){ t.setAutoSizeTextTypeUniformWithConfiguration(9,11,1,android.util.TypedValue.COMPLEX_UNIT_SP); } android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(bg); g.setCornerRadius(dp(30)); g.setStroke(dp(1),fg); t.setBackground(g); return t; }
    private void setHealth(String mode,String detail){ ui(()->{ if(healthChip==null)return; String text; int fg,bg; if("GREEN".equals(mode)){ text="● SISTEMA OK"; fg=Color.rgb(0,190,120); bg=Color.rgb(7,52,48); } else if("SIM".equals(mode)){ text="● SIMULAÇÃO"; fg=Color.rgb(0,210,255); bg=Color.rgb(7,38,58); } else if("YELLOW".equals(mode)){ text="● ATENÇÃO"; fg=Color.rgb(255,184,45); bg=Color.rgb(61,45,9); } else { text="● OFFLINE"; fg=Color.rgb(255,88,88); bg=Color.rgb(61,16,24); } healthChip.setText(text); healthChip.setTextColor(fg); android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(bg); g.setCornerRadius(dp(30)); g.setStroke(dp(1),fg); healthChip.setBackground(g); }); }
    private void addHalfText(LinearLayout r, TextView t){ LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(2),0,dp(2),0); r.addView(t,lp); }
    private void resetSession(){ simulationMode=false; simulationStartMs=0; simulationIndex=0; simulationSamples.clear(); monitoring=false; operationRunning=false; markers.clear(); rawCount=frameCount=rxBytes=0; ids.clear(); noDataCycles=0; recoveringSession=false; closeSocket(); }
    private boolean hasBluetoothPermission(){
        if(Build.VERSION.SDK_INT<31) return true;
        try { return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED; }
        catch(Throwable e){ return false; }
    }
    private void clearSimulationResidueForRealVehicle(){
        lastVin="—"; lastRpm=0; lastSpeed=-1; lastLoad=-1; lastCoolant=-1; lastIntake=-1; lastOilTemp=-1; lastFuel=-1; lastVolt=-1; lastThrottle=-1; lastPedalD=-1; lastPedalE=-1; lastPedalF=-1; lastMap=-1; lastBaro=-1; lastBoost=-1; maxBoost=-1; lastOilLevel="—"; ecuResponding=false; lastDtcCodes.clear(); selectedDtcCodes.clear(); dtcSelectionMode=false;
        combinedRpmValues.clear(); combinedSpeedValues.clear(); combinedThrottleValues.clear(); combinedPedalValues.clear(); combinedBoostValues.clear();
        ui(()->{ if(vagExplorerResult!=null)vagExplorerResult.setText("Aguardando exploração real. Nenhum dado de simulação será mantido após a conexão."); if(diagnosticResult!=null)diagnosticResult.setText("Nenhum teste executado nesta conexão."); if(result!=null)result.setText("RESULTADO: —"); if(resultHome!=null)resultHome.setText("RESULTADO: —"); if(dtcStatusView!=null)dtcStatusView.setText("STATUS: AGUARDANDO LEITURA"); if(dtcCodesView!=null)dtcCodesView.setText("CÓDIGOS: nenhum DTC lido nesta sessão"); if(dtcRawView!=null)dtcRawView.setText("RAW: —"); if(combinedGraphView!=null)combinedGraphView.clear(); });
    }

    private void applyConnectStyle(boolean isConnected){ ui(()->{ if(connectButton==null)return; GradientDrawable g=new GradientDrawable(); g.setCornerRadius(dp(24)); if(isConnected){ g.setColor(simulationMode?Color.rgb(18,48,64):Color.rgb(48,12,22)); g.setStroke(dp(2),simulationMode?Color.rgb(0,210,255):Color.rgb(255,82,82)); connectButton.setText(simulationMode?"SAIR DA SIMULAÇÃO":"DESCONECTAR"); connectButton.setTextColor(Color.WHITE); } else { g.setColor(Color.rgb(7,38,70)); g.setStroke(dp(1),Color.rgb(25,125,195)); connectButton.setText("CONECTAR ELM"); connectButton.setTextColor(Color.rgb(235,248,255)); } connectButton.setBackground(g); }); }

    private void toggleConnection(){
        try{
            if(connectAttempt || operationRunning){ setStatus("Conexão em andamento — aguarde a conclusão"); return; }
            // Em simulação, o botão deve tentar Bluetooth — nunca tratar a simulação como conexão real.
            if(simulationMode){ connect(); return; }
            if(connected){ if(monitoring){toast("Finalize a captura antes de desconectar");return;} if(recordingActive){toast("Finalize a gravação antes de desconectar");return;} disconnect(); }
            else connect();
        }catch(Throwable t){
            append("ERRO NO BOTÃO DE CONEXÃO: "+t.getClass().getSimpleName()+" — "+String.valueOf(t.getMessage()));
            setStatus("Falha de conexão — aplicativo mantido aberto");
            ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});
        }
    }
    private void disconnect(){
        epcEvidenceSavedThisSession=false; lastEpcEvidenceFile="";
        try{io.execute(()->{
            autoConnectActive=false; autoConnectAttempts=0;
            operationRunning=true; intentionalDisconnect=true; monitoring=false; stopRequested=true; connected=false; simulationMode=false;
            try{closeSocket();}catch(Throwable ignored){} closePerformanceHistory(); noDataCycles=0;
            setHealth("RED","DESCONECTADO"); setStatus("Bluetooth desconectado");
            ui(()->{if(connectButton!=null){connectButton.setEnabled(true);} applyConnectStyle(false);if(dashConn!=null){dashConn.setText("● ELM: DESCONECTADO");dashConn.setTextColor(Color.rgb(150,35,35));}});
            append("ELM desconectado pelo usuário."); operationRunning=false;
        });}catch(Throwable t){operationRunning=false;append("ERRO AO DESCONECTAR: "+t.getClass().getSimpleName());ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});}
    }
    // ===== V12.0 FIX 01 — SIMULAÇÃO IMEDIATA + ATÉ 3 TENTATIVAS DE ELM =====
    private void startAutomaticConnectionSequence(){
        autoConnectActive=isAutoConnectEnabled();
        autoConnectAttempts=0;
        if(isAutoSimulationEnabled()) io.execute(()->startSimulationMode("inicialização automática — aguardando tentativa de conexão com o ELM"));
        if(autoConnectActive) dashboardExec.schedule(this::automaticConnectionAttempt,700,TimeUnit.MILLISECONDS);
    }

    private void automaticConnectionAttempt(){
        if(!autoConnectActive || intentionalDisconnect || (connected && !simulationMode)) return;
        if(autoConnectAttempts>=3){
            autoConnectActive=false;
            setStatus("3 tentativas concluídas — permanecendo em modo simulação");
            append("=== AUTO-CONEXÃO FINALIZADA ===");
            append("Nenhum ELM conectado após 3 tentativas. Modo simulação permanece ativo.");
            return;
        }
        autoConnectAttempts++;
        final int tentativa=autoConnectAttempts;
        append("AUTO-CONEXÃO: tentativa "+tentativa+"/3");
        connectAttempt=true;
        ui(()->{ if(connectButton!=null) connectButton.setEnabled(false); setStatus("Tentativa automática "+tentativa+"/3 — procurando ELM..."); });
        io.execute(()->{
            connectWorker();
            if(autoConnectActive && !connected){
                if(isAutoSimulationEnabled()) startSimulationMode("tentativa automática "+tentativa+" sem ELM — simulação preservada"); else setStatus("ELM indisponível — simulação automática OFF");
                if(autoConnectAttempts>=3){
                    autoConnectActive=false;
                    setStatus("3 tentativas concluídas — permanecendo em modo simulação");
                    append("=== AUTO-CONEXÃO FINALIZADA ===");
                    append("Nenhum ELM conectado após 3 tentativas. Modo simulação permanece ativo.");
                }else{
                    dashboardExec.schedule(this::automaticConnectionAttempt,2200,TimeUnit.MILLISECONDS);
                }
            }else if(connected && !simulationMode){
                autoConnectActive=false;
                append("AUTO-CONEXÃO: ELM conectado — modo veículo assumido.");
            }
        });
    }

    private void connect(){
        try{
            if(connectAttempt||operationRunning){setStatus("Conexão já em andamento — aguarde");return;}
            epcEvidenceSavedThisSession=false; lastEpcEvidenceFile="";
            connectAttempt=true;
            // Ao solicitar conexão, suspende explicitamente a simulação enquanto tenta o ELM.
            simulationMode=false; connected=false; ecuResponding=false; closeSocket();
            setHealth("YELLOW","CONECTANDO ELM"); setStatus("Tentando conexão Bluetooth com o ELM…");
            ui(()->{if(connectButton!=null)connectButton.setEnabled(false); if(dashConn!=null){dashConn.setText("● CONECTANDO ELM");dashConn.setTextColor(Color.rgb(255,184,45));}});
            if(Build.VERSION.SDK_INT>=31&&!hasBluetoothPermission()){
                connectAttempt=false;
                ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});
                setStatus("Permissão 'Dispositivos por perto' necessária");
                io.execute(()->{ if(isAutoSimulationEnabled()) startSimulationMode("permissão Bluetooth necessária — retorno à simulação"); else setStatus("Permissão Bluetooth necessária — simulação automática OFF"); });
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},20); return;
            }
            if(bt==null){ io.execute(()->{if(isAutoSimulationEnabled()) startSimulationMode("Bluetooth indisponível neste aparelho"); else setStatus("Bluetooth indisponível — simulação automática OFF");}); connectAttempt=false; ui(()->{if(connectButton!=null)connectButton.setEnabled(true);}); return; }
            boolean enabled; try{enabled=bt.isEnabled();}catch(Throwable e){connectAttempt=false;io.execute(()->startSimulationMode("permissão Bluetooth indisponível — retorno à simulação"));ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});setStatus("Permissão Bluetooth não concedida — modo simulação");return;}
            if(!enabled){ io.execute(()->{if(isAutoSimulationEnabled()) startSimulationMode("Bluetooth desligado — nenhum ELM pode ser localizado"); else setStatus("Bluetooth desligado — simulação automática OFF");}); connectAttempt=false; ui(()->{if(connectButton!=null)connectButton.setEnabled(true);}); return; }
            try{io.execute(()->connectWorker());}catch(Throwable t){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});append("ERRO AO AGENDAR CONEXÃO: "+t.getClass().getSimpleName());}
        }catch(Throwable t){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});append("ERRO AO INICIAR CONEXÃO: "+t.getClass().getSimpleName()+" — "+String.valueOf(t.getMessage()));setStatus("Falha ao iniciar conexão — aplicativo mantido aberto");}
    }
    private void connectWorker(){
        if(operationRunning||monitoring){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);setStatus("Operação em andamento — finalize antes de reconectar");});return;}
        epcEvidenceSavedThisSession=false; lastEpcEvidenceFile="";
        operationRunning=true;intentionalDisconnect=false;connected=false;simulationMode=false;ecuResponding=false;
        try{
            closeSocket(); if(bt==null)throw new IOException("BluetoothAdapter indisponível");
            if(Build.VERSION.SDK_INT>=31&&!hasBluetoothPermission())throw new SecurityException("BLUETOOTH_CONNECT não concedida");
            boolean enabled=true; try{enabled=bt.isEnabled();}catch(Throwable ignored){}
            if(!enabled){
                append("Bluetooth desligado — tentativa automática mantida em modo simulação.");
                if(isAutoSimulationEnabled()) startSimulationMode("Bluetooth desligado"); else setStatus("Bluetooth desligado — simulação automática OFF");
                return;
            }
            BluetoothDevice dev=null; Set<BluetoothDevice> bonded=bt.getBondedDevices();
            if(bonded!=null)for(BluetoothDevice d:bonded){String n=null;try{n=d.getName();}catch(Throwable ignored){}if(n!=null){String u=n.toUpperCase(Locale.US);if(u.contains("OBD")||u.contains("ELM")||u.contains("V-LINK")||u.contains("OBDLINK")){dev=d;break;}}}
            if(dev==null){
                append("ELM não encontrado entre os dispositivos Bluetooth pareados.");
                if(isAutoSimulationEnabled()) startSimulationMode("nenhum ELM327 compatível encontrado entre os dispositivos pareados"); else setStatus("Nenhum ELM compatível — simulação automática OFF");
                return;
            }
            append("ELM encontrado: "+safeDeviceName(dev));
            socket=dev.createRfcommSocketToServiceRecord(SPP);socket.connect();in=socket.getInputStream();out=socket.getOutputStream();connected=true;simulationMode=false;autoConnectActive=false; clearSimulationResidueForRealVehicle();
            setStatus("Bluetooth conectado — inicializando ELM");setHealth("YELLOW","ELM CONECTADO");
            ui(()->{applyConnectStyle(true);if(dashConn!=null){dashConn.setText("● ELM: CONECTADO");dashConn.setTextColor(BLUE);}});
            send("ATZ",2500);send("ATE0",1000);send("ATL0",1000);send("ATS1",1000);send("ATH1",1000);send("ATAT1",1000);String dp=send("ATDP",1800);lastProtocol=dp;send("ATSP0",2500);append("Inicialização concluída."); if(isPerformanceHistoryEnabled()) openPerformanceHistory();
            maxBoost=-1;lastBaro=-1;lastBoost=-1;lastOilTemp=-1;lastOilLevel="—";recordingMaxBoost=-999;noDataCycles=0;recoveringSession=false;setHealth("YELLOW","AGUARDANDO OBD");ui(()->updateDashboard());
        }catch(SecurityException e){connected=false;append("ERRO CONEXÃO/PERMISSÃO: "+String.valueOf(e.getMessage()));setStatus("Permissão Bluetooth não concedida — aplicativo mantido aberto");closeSocket();}
        catch(IOException e){connected=false;append("ERRO CONEXÃO: "+String.valueOf(e.getMessage()));setStatus("Falha de comunicação — ELM não conectado");closeSocket();}
        catch(Throwable t){connected=false;append("ERRO CONEXÃO: "+t.getClass().getSimpleName()+" — "+String.valueOf(t.getMessage()));setStatus("Falha inesperada — aplicativo mantido aberto");closeSocket();}
        finally{
            operationRunning=false;connectAttempt=false;
            if(!connected && !simulationMode && isAutoSimulationEnabled()){ startSimulationMode("conexão Bluetooth não estabelecida — retorno automático à simulação"); } else if(!connected && !simulationMode){ setStatus("Conexão Bluetooth não estabelecida — simulação automática OFF"); }
            ui(()->{if(connectButton!=null)connectButton.setEnabled(true); if(!connected && !simulationMode){applyConnectStyle(false); if(dashConn!=null){dashConn.setText("● ELM: DESCONECTADO");dashConn.setTextColor(Color.rgb(150,35,35));}} else if(simulationMode){applyConnectStyle(true); if(dashConn!=null){dashConn.setText("● MODO SIMULAÇÃO");dashConn.setTextColor(SIM_CYAN);}}});
        }
    }
    private String safeDeviceName(BluetoothDevice d){try{String n=d.getName();return n==null?"OBDII":n;}catch(Throwable t){return "OBDII";}}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==20){
            boolean ok=false;
            for(int i=0;i<permissions.length&&i<grantResults.length;i++)if(Manifest.permission.BLUETOOTH_CONNECT.equals(permissions[i])){ok=grantResults[i]==PackageManager.PERMISSION_GRANTED;break;}
            if(ok){setStatus("Permissão concedida — conectando ao ELM");connect();}
            else{setStatus("Permissão Bluetooth não concedida");ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});}
        } else if(requestCode==REQ_GPS_LOCATION){
            boolean ok=false; for(int i=0;i<permissions.length&&i<grantResults.length;i++) if((Manifest.permission.ACCESS_FINE_LOCATION.equals(permissions[i])||Manifest.permission.ACCESS_COARSE_LOCATION.equals(permissions[i])) && grantResults[i]==PackageManager.PERMISSION_GRANTED){ok=true;break;}
            if(ok){ startGpsTracking(); toast("GPS habilitado — velocidade disponível no painel e no Performance"); } else toast("Permissão de localização necessária para usar a velocidade GPS");
        }
    }

    private void dashboardSnapshot(){
        if(monitoring||operationRunning) return;
        if(simulationMode){ simulationSnapshot(); return; }
        if(out==null||in==null) return;
        try{
            String rpm=send("010C",900); String speed=send("010D",900); String load=send("0104",900); String coolant=send("0105",900); String intake=send("010F",900); String oil=send("015C",900); String fuel=send("012F",900); String volt=send("0142",900); String thr=send("0111",900); String map=send("010B",900); String baro=send("0133",900); String vin=send("0902",1500);
            boolean gotObd = rpm.matches("(?s).*41\\s*0C.*") || fuel.matches("(?s).*41\\s*2F.*") || map.matches("(?s).*41\\s*0B.*");
            if(gotObd){
                noDataCycles=0; ecuResponding=true;
                lastRpm=parseObdNumeric(rpm, "010C"); lastSpeed=parseObdNumeric(speed,"010D"); lastLoad=parseLoad(load); lastCoolant=parseCoolant(coolant); lastIntake=parseIntakeTemp(intake); lastOilTemp=parseOilTemp(oil); lastFuel=parseObdNumeric(fuel,"012F"); lastVolt=parseVoltage(volt); lastThrottle=parseThrottle(thr); lastPedalD=parsePercentPid(send("0149",700),"0149"); lastMap=parseMap(map); lastBaro=parseBaro(baro); lastBoost=calculateBoost(lastMap,lastBaro); if(lastBoost>=0 && lastBoost>maxBoost) maxBoost=lastBoost;
                String pv=parseVin(vin); if(!pv.isEmpty()) lastVin=pv;
                setHealth("GREEN","OBD ATIVO");
            } else {
                noDataCycles++; ecuResponding=false;
                setHealth("YELLOW", "ELM CONECTADO • SEM DADOS");
                append("WATCHDOG OBD: ciclo sem resposta ("+noDataCycles+").");
                if(noDataCycles==2 && !recoveringSession){ recoverObdSession(); }
                else if(noDataCycles>=4 && !recoveringSession){ append("WATCHDOG OBD: sem recuperação após 4 ciclos; reconexão automática será iniciada."); intentionalDisconnect=false; closeSocket(); setHealth("RED","RECONEXÃO AUTOMÁTICA"); scheduleReconnect(); }
            }
            if(gotObd && isPerformanceHistoryEnabled()) writePerformanceHistorySample();
            ui(()->updateDashboard());
        }catch(Exception e){ ecuResponding=false; setHealth("YELLOW","ELM CONECTADO • ERRO RX"); append("WATCHDOG OBD: erro de leitura — "+e.getClass().getSimpleName()); }
    }
    private void recoverObdSession(){
        recoveringSession=true;
        io.execute(()->{ try{ append("WATCHDOG OBD: recuperando sessão no mesmo socket."); send("AT AR",900); send("ATSP0",1200); send("ATAT1",700); append("WATCHDOG OBD: sessão OBD reinicializada."); }catch(Exception e){ append("WATCHDOG OBD: falha na recuperação — "+e.getMessage()); } finally { recoveringSession=false; } });
    }
    private double parseObdNumeric(String r,String pid){ try{String u=r.toUpperCase(Locale.US).replaceAll("[^0-9A-F ]"," ").replaceAll("\\s+"," ").trim(); Matcher m=Pattern.compile("41\\s*"+pid.substring(2)+"\\s*([0-9A-F]{2})(?:\\s*([0-9A-F]{2}))?").matcher(u); if(!m.find())return -1; int a=Integer.parseInt(m.group(1),16); int b=m.group(2)==null?0:Integer.parseInt(m.group(2),16); if(pid.equals("010C"))return (a*256+b)/4.0; if(pid.equals("012F"))return a*100.0/255.0; return a;}catch(Exception e){return -1;} }
    private double parseVoltage(String r){ try{Matcher m=Pattern.compile("41\\s*42\\s*([0-9A-F]{2})\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return (Integer.parseInt(m.group(1),16)*256+Integer.parseInt(m.group(2),16))/1000.0; }catch(Exception ignored){} return -1;}
    private double parseLoad(String r){ return parseObdNumeric(r,"0104")*100.0/255.0; }
    private double parseCoolant(String r){ double v=parseObdNumeric(r,"0105"); return v<0?-1:v-40; }
    // PID 010F = Intake Air Temperature: A - 40 °C. Não reutilizar o parser de 0105 semanticamente.
    private double parseIntakeTemp(String r){ double v=parseObdNumeric(r,"010F"); return v<0?-1:v-40; }

    private double parseOilTemp(String r){ double v=parseObdNumeric(r,"015C"); return v<0?-1:v-40; }
    private double oilColorTemp(double t){ return t; }
    private double oilTextColor(double t){ return t; }
    private void updateDataTelemetry(){ if(dataLiveTelemetry==null||!isRealtimeDataEnabled()){ if(dataLiveTelemetry!=null) dataLiveTelemetry.setText("DADOS EM TEMPO REAL DESATIVADOS"); return; } double speedPrimary=getPreferredSpeedKmh(); String rpm=String.format(Locale.US,"RPM          %6.0f     VELOCIDADE   %6.0f km/h\nCARGA        %6.0f %%     THROTTLE     %6.0f %%\nMAP          %6.0f kPa   BARO         %6.0f kPa\nBOOST        %6.2f bar   BOOST MÁX.   %6.2f bar\nLÍQUIDO      %6.0f °C    ADMISSÃO     %6.0f °C\nÓLEO         %6.0f °C    TENSÃO       %6.2f V\nCOMBUSTÍVEL  %6.0f %%",lastRpm,speedPrimary,lastLoad,lastThrottle,lastMap,lastBaro,lastBoost,maxBoost,lastCoolant,lastIntake,lastOilTemp,lastVolt,lastFuel); dataLiveTelemetry.setText(rpm); }

    private void updateOilUi(){ if(dashOilTemp==null||dashOilLevel==null)return; if(lastOilTemp<0){dashOilTemp.setText("🛢️ — °C");dashOilTemp.setTextColor(Color.rgb(145,181,210));} else {dashOilTemp.setText(String.format(Locale.US,"🛢️ %.0f °C",lastOilTemp)); int c=lastOilTemp<70?Color.rgb(70,170,255):lastOilTemp<120?Color.rgb(242,248,255):lastOilTemp<130?Color.rgb(255,180,60):Color.rgb(255,70,70);dashOilTemp.setTextColor(c);} dashOilLevel.setText("NÍVEL "+lastOilLevel); }
    private double parseThrottle(String r){ try{Matcher m=Pattern.compile("41\\s*11\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return Integer.parseInt(m.group(1),16)*100.0/255.0;}catch(Exception ignored){} return -1;}
    private double parseMap(String r){ try{Matcher m=Pattern.compile("41\\s*0B\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return Integer.parseInt(m.group(1),16);}catch(Exception ignored){} return -1;}
    private double parseBaro(String r){ try{Matcher m=Pattern.compile("41\\s*33\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return Integer.parseInt(m.group(1),16);}catch(Exception ignored){} return -1;}
    private double calculateBoost(double mapKpa,double baroKpa){ if(mapKpa<0||baroKpa<0) return -1; return (mapKpa-baroKpa)/100.0; }
    private int getDefaultEthanolPct(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getInt(PREF_DEFAULT_ETHANOL,100); }
    private int getPerformanceEthanolPct(){ return performanceEthanolOverride>=0?performanceEthanolOverride:getDefaultEthanolPct(); }
    private String getPerformanceEthanolLabel(){ int p=getPerformanceEthanolPct(); return String.format(Locale.US,"%d%% etanol (%s)",p,performanceEthanolOverride>=0?"seleção desta sessão":"padrão configurado"); }
    private void showDefaultEthanolDialog(Runnable onSaved){
        final EditText input=new EditText(this); input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); input.setSingleLine(true); input.setText(String.valueOf(getDefaultEthanolPct())); input.setHint("0 a 100"); input.setSelectAllOnFocus(true);
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(20),dp(4),dp(20),0); box.addView(input,new LinearLayout.LayoutParams(-1,dp(52)));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("COMBUSTÍVEL PADRÃO").setMessage("Defina a preferência padrão de etanol. Valor informativo, salvo neste dispositivo; não é medido pela ECU.").setView(box).setNegativeButton("CANCELAR",null).setPositiveButton("SALVAR PADRÃO",null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{int p=Integer.parseInt(input.getText().toString().trim());if(p<0||p>100)throw new NumberFormatException();getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putInt(PREF_DEFAULT_ETHANOL,p).apply();if(onSaved!=null)onSaved.run();if(perfFuel!=null&&performanceEthanolOverride<0)perfFuel.setText("COMBUSTÍVEL DESTA SESSÃO: "+getPerformanceEthanolLabel());toast("Combustível padrão salvo: "+p+"% etanol");dialog.dismiss();}catch(Exception e){input.setError("Informe um valor entre 0 e 100");}})); dialog.show();
    }
    private void showEthanolDialog(){
        final EditText input=new EditText(this); input.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); input.setSingleLine(true); input.setText(String.valueOf(getPerformanceEthanolPct())); input.setHint("0 a 100"); input.setSelectAllOnFocus(true);
        LinearLayout box=new LinearLayout(this); box.setPadding(dp(20),dp(4),dp(20),0); box.addView(input,new LinearLayout.LayoutParams(-1,dp(52)));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("COMBUSTÍVEL DESTA SESSÃO").setMessage("Esta seleção vale apenas para a sessão atual e não altera o combustível padrão salvo em Configurações. É uma informação manual, não uma leitura da ECU.").setView(box).setNegativeButton("CANCELAR",null).setNeutralButton("USAR PADRÃO",null).setPositiveButton("APLICAR À SESSÃO",null).create();
        dialog.setOnShowListener(x->{dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{performanceEthanolOverride=-1;if(perfFuel!=null)perfFuel.setText("COMBUSTÍVEL DESTA SESSÃO: "+getPerformanceEthanolLabel());toast("Usando combustível padrão");dialog.dismiss();});dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{try{int p=Integer.parseInt(input.getText().toString().trim());if(p<0||p>100)throw new NumberFormatException();performanceEthanolOverride=p;if(perfFuel!=null)perfFuel.setText("COMBUSTÍVEL DESTA SESSÃO: "+getPerformanceEthanolLabel());toast("Combustível desta sessão: "+p+"% etanol");dialog.dismiss();}catch(Exception e){input.setError("Informe um valor entre 0 e 100");}});});dialog.show();
    }
    // Calibração isolada por VIN e fonte: não mistura veículos nem sensores.
    private String pedalCalibrationKey(String base){
        String vin=(lastVin==null||lastVin.trim().isEmpty()||"—".equals(lastVin))?"SEM_VIN":lastVin.replaceAll("[^A-Za-z0-9]","_").toUpperCase(Locale.US);
        return base+"_"+vin+"_"+getPedalSource();
    }
    private float getPedalCalibrationValue(android.content.SharedPreferences prefs,String base){return prefs.getFloat(pedalCalibrationKey(base),-1f);}
    private String getPedalSource(){return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getString(PREF_PEDAL_SOURCE,"0149");}
    private String getPedalSourceLabel(){String s=getPedalSource();if("014A".equals(s))return "APP E / PID 014A";if("014B".equals(s))return "APP F / PID 014B";if("0111".equals(s))return "THROTTLE / PID 0111";return "APP D / PID 0149";}
    private void showPedalSourceDialog(Button button){final String[] labels={"APP D • PID 0149","APP E • PID 014A","APP F • PID 014B","Throttle position • PID 0111"};final String[] ids={"0149","014A","014B","0111"};int selected=0;for(int i=0;i<ids.length;i++)if(ids[i].equals(getPedalSource()))selected=i;new AlertDialog.Builder(this).setTitle("FONTE EXPLÍCITA DO PEDAL").setMessage("A calibração e o gráfico usarão somente a fonte escolhida. Se ela não responder, o valor será indisponível; não haverá substituição automática por outro PID.").setSingleChoiceItems(labels,selected,(d,w)->{getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putString(PREF_PEDAL_SOURCE,ids[w]).apply();if("0149".equals(ids[w]))lastPedalD=-1;else if("014A".equals(ids[w]))lastPedalE=-1;else if("014B".equals(ids[w]))lastPedalF=-1;else if("0111".equals(ids[w]))lastThrottle=-1;if(button!=null)button.setText("FONTE DO PEDAL: "+getPedalSourceLabel());toast("Fonte selecionada: "+labels[w]+". A calibração fica preservada por veículo e fonte.");d.dismiss();}).setNegativeButton("FECHAR",null).show();}

    private boolean hasLocationPermission(){ return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED; }
    private boolean hasFineLocationPermission(){ return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED; }
    private boolean isGpsSpeedValid(){ long ageMs=gpsLastElapsedNs>0?Math.max(0,(SystemClock.elapsedRealtimeNanos()-gpsLastElapsedNs)/1000000L):Long.MAX_VALUE; return gpsHasFix && lastGpsSpeed>=0 && ageMs<=2500 && gpsAccuracyM<=50f; }
    private double getPreferredSpeedKmh(){ return isGpsSpeedValid()?lastGpsSpeed:(simulationMode?lastSpeed:-1); }
    private void startGpsTracking(){
        if(gpsTrackingActive)return;
        if(!hasLocationPermission()){ if(Build.VERSION.SDK_INT>=23) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_GPS_LOCATION); return; }
        try{
            if(locationManager==null) locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
            if(locationManager==null)return;
            if(gpsListener==null) gpsListener=new LocationListener(){ @Override public void onLocationChanged(Location location){ if(location==null)return; if(Build.VERSION.SDK_INT>=26 && location.hasSpeed()){ lastGpsSpeed=Math.max(0,location.getSpeed()*3.6); gpsAccuracyM=location.hasAccuracy()?location.getAccuracy():Float.MAX_VALUE; gpsLastElapsedNs=location.getElapsedRealtimeNanos(); gpsHasFix=true; ui(()->{if(dashSpeed!=null)updateDashboard();}); } } @Override public void onStatusChanged(String provider,int status,Bundle extras){} @Override public void onProviderEnabled(String provider){} @Override public void onProviderDisabled(String provider){} };
            if(hasFineLocationPermission() && locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,200L,0f,gpsListener,Looper.getMainLooper());
            if(locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,500L,0f,gpsListener,Looper.getMainLooper());
            gpsTrackingActive=true;
        }catch(SecurityException e){ append("GPS: permissão não concedida."); }catch(Exception e){ append("GPS: falha ao iniciar — "+e.getClass().getSimpleName()); }
    }
    private void stopGpsTracking(){ try{ if(locationManager!=null && gpsListener!=null) locationManager.removeUpdates(gpsListener); }catch(Exception ignored){} gpsTrackingActive=false; }
    private long crossingNs(double prevSpeed,long prevNs,double curSpeed,long curNs,double target){ if(prevNs<=0||curNs<=prevNs||curSpeed<target||prevSpeed>=target)return -1; if(curSpeed==prevSpeed)return curNs; double f=(target-prevSpeed)/(curSpeed-prevSpeed); f=Math.max(0,Math.min(1,f)); return prevNs+(long)((curNs-prevNs)*f); }

    private void startPerformanceTest(){
        if(performanceRunning){toast("Teste já está em andamento");return;}
        if(!connected||in==null||out==null){toast("Conecte o ELM antes do teste");return;}
        startGpsTracking();
        if(!isGpsSpeedValid()){toast("GPS ainda sem velocidade válida. Aguarde o fix e tente novamente."); ui(()->perfStatus.setText("AGUARDANDO GPS • VELOCIDADE PRINCIPAL = GPS")); return;}
        synchronized(activePerfGraphSamples){activePerfGraphSamples.clear();}
        performanceGraphBoostPeak=-1;
        maxBoost=-1;
        // Uma nova puxada inicia um gráfico ao vivo, sem manter o modo histórico anterior.
        historicalGraphMode=false;
        if(combinedGraphView!=null)combinedGraphView.clear();
        synchronized(combinedRpmValues){ combinedRpmValues.clear(); combinedSpeedValues.clear(); combinedPedalValues.clear(); combinedBoostValues.clear(); combinedTimeValues.clear(); }
        performanceRunning=true; performanceStop=false; ui(()->{perfStatus.setText("ARMADO • GPS • PARTIDA PRÓXIMA DE 0 km/h"); perfStatus.setTextColor(Color.rgb(255,190,0));});
        io.execute(()->{
            long t0=0,t60=0,t100=0; boolean startedFromStop=false; double prevSpeed=-1,prevRpm=-1; long prevGpsNs=0,firstMovingNs=0,lastSampleNs=0; double bestEnginePower=0,bestEngineTorque=0;
            ArrayList<Double> powerSamples=new ArrayList<>(), torqueSamples=new ArrayList<>();
            double[] speedWin=new double[5]; long[] timeWin=new long[5]; int speedWinCount=0;
            double maxB=-1,maxR=0,maxS=0; int samples=0,validDt=0,gearShifts=0; double maxDt=0; final GearShiftEstimator shiftEstimator=new GearShiftEstimator();
            final double[] gridNs=new double[29]; Arrays.fill(gridNs,-1);
            final double massKg=1250.0, crr=0.012, cdA=0.62, rho=1.225, g=9.80665, drivetrainEff=0.88; long lastProcessedGpsNs=0;
            final double stockPowerCv=128.0, stock0100s=10.1;
            try{
                while(performanceRunning && !performanceStop && connected && samples<900){
                    long now=System.nanoTime();
                    // Uma solicitação por vez no canal ELM (sem concorrência serial).
                    // RPM/MAP/BARO em todos os ciclos; velocidade CAN e pedal a cada 4 ciclos.
                    // Timeout reduzido de 220 para 160 ms para diminuir a latência sem
                    // sacrificar a leitura com timeouts agressivos de 80–100 ms.
                    double canSpeed=lastSpeed;
                    if(samples%4==0)canSpeed=parseObdNumeric(send("010D",160),"010D");
                    double rpm=parseObdNumeric(send("010C",160),"010C");
                    if(samples%4==0){
                        String pedalSrc=getPedalSource();
                        if("014A".equals(pedalSrc)){double v=parsePercentPid(send("014A",160),"014A");if(v>=0)lastPedalE=v;}
                        else if("014B".equals(pedalSrc)){double v=parsePercentPid(send("014B",160),"014B");if(v>=0)lastPedalF=v;}
                        else if("0111".equals(pedalSrc)){double v=parseThrottle(send("0111",160));if(v>=0)lastThrottle=v;}
                        else{double v=parsePercentPid(send("0149",160),"0149");if(v>=0)lastPedalD=v;}
                    }
                    double speed=getGpsSpeedForPerformance();
                    if(rpm>maxR)maxR=rpm; if(speed>maxS)maxS=speed; lastSampleNs=now;
                    String mapRaw=send("010B",160), baroRaw=send("0133",160);
                    double map=parseMap(mapRaw); double baro=parseBaro(baroRaw); double boost=calculateBoost(map,baro);
                    if((map<0||baro<0)&&samples%10==0){
                        append("BOOST OBD: leitura inválida; MAP 010B=["+String.valueOf(mapRaw).trim()+"] BARO 0133=["+String.valueOf(baroRaw).trim()+"]");
                    }
                    // Publica a amostra real no estado compartilhado da telemetria.
                    // O loop de Performance ocupa o executor de I/O; sem esta publicação,
                    // dashboardSnapshot fica enfileirado e os gauges/gráficos congelam durante a puxada.
                    lastRpm=rpm;
                    lastSpeed=canSpeed;
                    lastMap=map;
                    lastBaro=baro;
                    if(map>=0&&baro>=0){ lastBoost=boost; if(t0>0 && boost>=0){ if(boost>maxB)maxB=boost; if(boost>maxBoost)maxBoost=boost; if(boost>performanceGraphBoostPeak)performanceGraphBoostPeak=boost; } }
                    else lastBoost=-1;
                    ecuResponding=true;
                    gearShifts=shiftEstimator.update(rpm,speed,now);
                    long gpsNs=gpsLastElapsedNs;
                    if(t0>0){ double elapsed=Math.max(0,(now-t0)/1e9); double pedal=getPerformancePedalPct(); double boostSample=(lastMap>=0&&lastBaro>=0)?calculateBoost(lastMap,lastBaro):-1; if(boostSample<0)boostSample=boost; synchronized(activePerfGraphSamples){ if(activePerfGraphSamples.isEmpty()) activePerfGraphSamples.add(new PerfGraphSample(0,rpm,0,pedal,boostSample)); if(activePerfGraphSamples.size()<1200) activePerfGraphSamples.add(new PerfGraphSample(elapsed,rpm,speed,pedal,boostSample)); } }
                    if(t0>0 && samples%2==0){ final float gr=(float)Math.max(0,rpm), gs=speed>=0?(float)speed:Float.NaN, gp=getPerformancePedalPct()>=0?(float)getPerformancePedalPct():Float.NaN, gb=boost>=0?(float)boost:Float.NaN; final float gt=(float)Math.max(0,(now-t0)/1e9); ui(()->{ if(performanceRunning && !historicalGraphMode){ combinedTimeValues.add(gt); combinedRpmValues.add(gr); combinedSpeedValues.add(gs); combinedPedalValues.add(gp); combinedBoostValues.add(gb); if(!Float.isNaN(gb)&&!Float.isInfinite(gb)&&gb>=0&&gb>performanceGraphBoostPeak)performanceGraphBoostPeak=gb; while(combinedTimeValues.size()>180){combinedTimeValues.removeFirst();combinedRpmValues.removeFirst();combinedSpeedValues.removeFirst();combinedPedalValues.removeFirst();combinedBoostValues.removeFirst();} if(combinedGraphView!=null)combinedGraphView.invalidate(); } }); }
                    if(speed>=0 && gpsNs>0 && gpsNs!=lastProcessedGpsNs){
                        lastProcessedGpsNs=gpsNs;
                        if(t0==0 && speed<=2) startedFromStop=true;
                        if(prevGpsNs>0){
                            double dt=(gpsNs-prevGpsNs)/1e9;
                            if(dt>0.03&&dt<2.0){
                                validDt++; if(dt>maxDt)maxDt=dt;
                                if(t0==0 && startedFromStop && speed>prevSpeed && speed>=1){
                                    long c=crossingNs(prevSpeed,prevGpsNs,speed,gpsNs,1);
                                    if(c>0){
                                        t0=c; firstMovingNs=c;
                                        ui(()->{ if(perfStatus!=null){ perfStatus.setText("TESTE EM ANDAMENTO • GPS"); perfStatus.setTextColor(Color.rgb(238,32,48)); } });
                                    }
                                }
                                if(t0>0){
                                    if(speed>prevSpeed){
                                        for(int target=10;target<=280;target+=10){ int idx=target/10-1; if(gridNs[idx]<0){ long c=crossingNs(prevSpeed,prevGpsNs,speed,gpsNs,target); if(c>0)gridNs[idx]=c; } }
                                        if(t60==0){ long c=crossingNs(prevSpeed,prevGpsNs,speed,gpsNs,60); if(c>0)t60=c; }
                                        if(t100==0){ long c=crossingNs(prevSpeed,prevGpsNs,speed,gpsNs,100); if(c>0)t100=c; }
                                    }
                                    // Potência por dinâmica longitudinal: usa regressão linear em uma janela GPS de 5 pontos
                                    // em vez de derivar dois pontos consecutivos. Isso reduz fortemente picos artificiais do GPS.
                                    if(speedWinCount<5){ speedWin[speedWinCount]=speed; timeWin[speedWinCount]=gpsNs; speedWinCount++; }
                                    else { for(int wi=0;wi<4;wi++){ speedWin[wi]=speedWin[wi+1]; timeWin[wi]=timeWin[wi+1]; } speedWin[4]=speed; timeWin[4]=gpsNs; }
                                    if(speedWinCount>=5){
                                        double sumT=0,sumV=0,sumTT=0,sumTV=0;
                                        for(int wi=0;wi<5;wi++){ double tw=(timeWin[wi]-timeWin[0])/1e9; double vw=speedWin[wi]/3.6; sumT+=tw; sumV+=vw; sumTT+=tw*tw; sumTV+=tw*vw; }
                                        double den=5.0*sumTT-sumT*sumT; double a=den>1e-9?(5.0*sumTV-sumT*sumV)/den:0;
                                        double v=speed/3.6;
                                        if(a>0.0 && a<4.5 && v>5.0){
                                            double force=massKg*a + massKg*g*crr + 0.5*rho*cdA*v*v;
                                            double wheelW=force*v; double engineW=wheelW/drivetrainEff; double engineCv=engineW/735.49875;
                                            if(engineCv>0 && engineCv<220) powerSamples.add(engineCv);
                                            if(rpm>1200 && rpm<7000 && engineW>0){ double tq=engineW*60.0/(2*Math.PI*rpm); if(tq>0 && tq<320) torqueSamples.add(tq); }
                                        }
                                    }
                                }
                            }
                        }
                        prevSpeed=speed; prevRpm=rpm; prevGpsNs=gpsNs;
                    }
                    prevRpm=rpm; samples++;
                    // Atualização ao vivo: só apresenta métricas calculadas com amostras já recebidas.
                    if(samples%5==0){
                        final double liveRpm=rpm, liveCanSpeed=canSpeed, liveMap=map, liveBaro=baro, liveBoost=boost;
                        ui(()->{
                            if(connected&&!simulationMode){
                                lastRpm=liveRpm;
                                lastSpeed=liveCanSpeed;
                                lastMap=liveMap;
                                lastBaro=liveBaro;
                                if(liveMap>=0&&liveBaro>=0)lastBoost=liveBoost;
                                else lastBoost=-1;
                                ecuResponding=true;
                                updateDashboard();
                            }
                        });
                    }
                    if(t0>0 && samples%5==0){
                        double livePower=0, liveTorque=0;
                        for(double x:powerSamples) if(x>livePower) livePower=x;
                        for(double x:torqueSamples) if(x>liveTorque) liveTorque=x;
                        final double uiPower=livePower, uiTorque=liveTorque, uiBoost=maxB, uiRpm=maxR, uiSpeed=maxS;
                        final double uiElapsed=Math.max(0,(now-t0)/1e9);
                        final long uiT0=t0, uiT60=t60, uiT100=t100;
                        int liveQuality=0;
                        if(startedFromStop)liveQuality+=25;
                        if(t60>0)liveQuality+=25;
                        if(t100>0)liveQuality+=25;
                        if(samples>=20)liveQuality+=15;
                        if(validDt>=10&&maxDt<=0.20)liveQuality+=10;
                        final int uiQuality=liveQuality;
                        ui(()->{
                            if(perfStatus!=null){perfStatus.setText("TESTE EM ANDAMENTO • GPS");perfStatus.setTextColor(Color.rgb(238,32,48));}
                            if(uiPower>0)setPerfText(perfPower,"POTÊNCIA ESTIMADA",String.format(Locale.US,"%.0f cv",uiPower));
                            if(uiTorque>0)setPerfText(perfTorque,"TORQUE ESTIMADO",String.format(Locale.US,"%.0f Nm",uiTorque));
                            setPerfText(perfBoost,"BOOST MÁX.",uiBoost>0?String.format(Locale.US,"%.2f bar",uiBoost):"— bar");
                            setPerfText(perfQuality,"QUALIDADE AQUISIÇÃO",uiQuality+" %");
                            setPerfText(perfMaxRpm,"RPM MÁX.",uiRpm>0?String.format(Locale.US,"%.0f rpm",uiRpm):"— rpm");
                            setPerfText(perfMaxSpeed,"VELOCIDADE MÁX. GPS",uiSpeed>0?String.format(Locale.US,"%.0f km/h",uiSpeed):"— km/h");
                            setPerfText(perfDuration,"DURAÇÃO",String.format(Locale.US,"%.1f s",uiElapsed));
                            if(uiT60>0)setPerfText(perf0060,"0–60 km/h",String.format(Locale.US,"%.2f s",(uiT60-uiT0)/1e9));
                            if(uiT100>0)setPerfText(perf0100,"0–100 km/h",String.format(Locale.US,"%.2f s",(uiT100-uiT0)/1e9));
                        });
                    }
                    Thread.sleep(70);
                }
            }catch(Exception e){append("PERFORMANCE: erro no teste — "+e.getClass().getSimpleName());}
            // Consolidação robusta: percentil 90 da curva filtrada + referência de 0–100 do Virtus original.
            // A referência serve como regularização, não como limite: evita que um único pico de GPS vire "dinamômetro da Disney".
            if(!powerSamples.isEmpty()){ Collections.sort(powerSamples); bestEnginePower=powerSamples.get((int)Math.round((powerSamples.size()-1)*0.90)); }
            if(!torqueSamples.isEmpty()){ Collections.sort(torqueSamples); bestEngineTorque=torqueSamples.get((int)Math.round((torqueSamples.size()-1)*0.90)); }
            double timeRefPower=0; if(t100>t0 && t0>0){ double sec=(t100-t0)/1e9; if(sec>6 && sec<20) timeRefPower=stockPowerCv*(stock0100s/sec); }
            if(bestEnginePower>0 && timeRefPower>0) bestEnginePower=0.80*bestEnginePower+0.20*timeRefPower;
            performanceRunning=false; final long f0=t0,f60=t60,f100=t100; final double fp=bestEnginePower, ft=bestEngineTorque, fb=maxB, fMaxR=maxR, fMaxS=maxS; performanceGraphBoostPeak=fb; maxBoost=fb; if(combinedGraphView!=null)ui(()->combinedGraphView.invalidate()); final int fSamples=samples,fValidDt=validDt,fShifts=gearShifts; final double fMaxDt=maxDt;
            lastPerf0060=(f60>f0&&f0>0)?(f60-f0)/1e9:-1; lastPerf0100=(f100>f0&&f0>0)?(f100-f0)/1e9:-1; lastPerfPower=fp; lastPerfTorque=ft; lastPerfMaxRpm=maxR; lastPerfMaxSpeed=maxS; lastPerfMaxBoost=fb; lastPerfPullDuration=(f100>f0)?(f100-f0)/1e9:-1; lastPerfDuration=(firstMovingNs>0&&lastSampleNs>firstMovingNs)?(lastSampleNs-firstMovingNs)/1e9:-1; lastPerfGearShifts=fShifts;
            StringBuilder gridText=new StringBuilder(); for(int target=10;target<=280;target+=10){ int idx=target/10-1; if(gridNs[idx]>0&&f0>0){ if(gridText.length()>0)gridText.append('|'); gridText.append(target).append('=').append(String.format(Locale.US,"%.3f",(gridNs[idx]-f0)/1e9)); } } lastPerfSpeedGrid=gridText.toString();
            synchronized(lastPerfGraphSamples){lastPerfGraphSamples.clear(); synchronized(activePerfGraphSamples){lastPerfGraphSamples.addAll(activePerfGraphSamples);} }
            int quality=0; if(f0>0&&startedFromStop)quality+=25; if(f60>f0)quality+=25; if(f100>f0)quality+=25; if(fSamples>=20)quality+=15; if(fValidDt>=10&&fMaxDt<=0.20)quality+=10; lastPerfQuality=quality; final int fQuality=quality; final String fComparison=buildPullComparison(fp,ft,lastPerf0060,lastPerf0100,fQuality,fSamples); persistPerformancePull(fSamples,new ArrayList<>(lastPerfGraphSamples)); if(isPerformanceHistoryEnabled()) writePerformanceEvent();
            ui(()->{ setPerfText(perf0060,"0–60 km/h",lastPerf0060>0?String.format(Locale.US,"%.2f s",lastPerf0060):"não concluído"); setPerfText(perf0100,"0–100 km/h",lastPerf0100>0?String.format(Locale.US,"%.2f s",lastPerf0100):"não concluído"); if(fp>0){setPerfText(perfPower,"POTÊNCIA ESTIMADA",String.format(Locale.US,"%.0f cv",fp)); setPerfText(perfTorque,"TORQUE ESTIMADO",String.format(Locale.US,"%.0f Nm",ft));} else {setPerfText(perfPower,"POTÊNCIA ESTIMADA","dados insuficientes"); setPerfText(perfTorque,"TORQUE ESTIMADO","dados insuficientes");} setPerfText(perfBoost,"BOOST MÁX.",fb>0?String.format(Locale.US,"%.2f bar",fb):"— bar"); setPerfText(perfQuality,"QUALIDADE AQUISIÇÃO",fQuality+" %"); setPerfText(perfMaxRpm,"RPM MÁX.",fMaxR>0?String.format(Locale.US,"%.0f rpm",fMaxR):"— rpm"); setPerfText(perfMaxSpeed,"VELOCIDADE MÁX. GPS",fMaxS>0?String.format(Locale.US,"%.0f km/h",fMaxS):"— km/h"); setPerfText(perfDuration,"DURAÇÃO",lastPerfPullDuration>0?String.format(Locale.US,"%.2f s",lastPerfPullDuration):"— s"); perfConfidence.setText("GPS COMO FONTE PRINCIPAL • CAN PRESERVADA • 0–280 km/h em memória • TROCAS ESTIMADAS: "+fShifts+" • QUALIDADE: "+fQuality+"% • amostras "+fSamples+" • inclinação da via: NÃO MEDIDA • VIN: "+(lastVin==null||lastVin.isEmpty()?"não identificado":lastVin)); perfStatus.setText(fQuality>=50&&(lastPerf0060>0||lastPerf0100>0)?"🏁 PUXADA CONCLUÍDA":"DADOS INSUFICIENTES • PUXADA NÃO VALIDADA"); perfStatus.setTextColor(Color.rgb(255,65,75)); perfFuel.setText("COMBUSTÍVEL DO TESTE: "+getPerformanceEthanolLabel()); if(fComparison!=null&&!fComparison.isEmpty()&&currentScreen==6)new AlertDialog.Builder(MainActivity.this).setTitle(fComparison.startsWith("MELHORIA")?"🏆 RESULTADO DA PUXADA":"🏁 PUXADA CONCLUÍDA").setMessage(fComparison).setPositiveButton("OK",null).setNeutralButton("VER 3 MELHORES",(d,w)->showBestPullsDialog()).show(); if(currentScreen==5&&historicalGraphMode)loadLastPerformanceGraph(); });
        });
    }
    private String buildPullComparison(double power,double torque,double z60,double z100,int quality,int samples){
        if(quality<50 || samples<20 || (z60<=0&&z100<=0)) return "Dados insuficientes para validar esta puxada. Não será comparada como recorde.";
        ArrayList<BestPull> previous=readBestPulls();
        String currentVin=lastVin==null?"":lastVin.trim();
        ArrayList<BestPull> comparable=new ArrayList<>();
        for(BestPull p:previous){ if(!currentVin.isEmpty()&&!p.vin.isEmpty()&&!currentVin.equalsIgnoreCase(p.vin)) continue; if(p.z60>0||p.z100>0||p.power>0||p.torque>0)comparable.add(p); if(comparable.size()>=3)break; }
        if(comparable.isEmpty()) return "Puxada concluída com dados válidos. Ainda não há até 3 puxadas anteriores comparáveis para confirmar recorde; consulte o histórico.";
        boolean improved=false; StringBuilder msg=new StringBuilder();
        double best60=Double.POSITIVE_INFINITY,best100=Double.POSITIVE_INFINITY,bestPower=-1,bestTorque=-1;
        for(BestPull p:comparable){if(p.z60>0)best60=Math.min(best60,p.z60);if(p.z100>0)best100=Math.min(best100,p.z100);if(p.power>0)bestPower=Math.max(bestPower,p.power);if(p.torque>0)bestTorque=Math.max(bestTorque,p.torque);}
        if(z60>0&&best60<Double.POSITIVE_INFINITY&&z60<best60){msg.append(String.format(Locale.US,"0–60 km/h melhorou: %.2f s (antes %.2f s).\n",z60,best60));improved=true;}
        if(z100>0&&best100<Double.POSITIVE_INFINITY&&z100<best100){msg.append(String.format(Locale.US,"0–100 km/h melhorou: %.2f s (antes %.2f s).\n",z100,best100));improved=true;}
        if(power>0&&bestPower>0&&power>bestPower){msg.append(String.format(Locale.US,"Potência estimada aumentou: %.0f cv (antes %.0f cv).\n",power,bestPower));improved=true;}
        if(torque>0&&bestTorque>0&&torque>bestTorque){msg.append(String.format(Locale.US,"Torque estimado aumentou: %.0f Nm (antes %.0f Nm).\n",torque,bestTorque));improved=true;}
        if(improved)return "MELHORIA DETECTADA vs. até 3 puxadas anteriores comparáveis:\n\n"+msg+"\nPotência/torque são estimativas e não substituem dinamômetro. Comparação válida depende de condições semelhantes.";
        return "Puxada concluída, mas nenhum indicador disponível superou os melhores registros comparáveis. Sem troféu de recorde nesta execução.";
    }
    private double getRawPerformancePedalPct(){ String src=getPedalSource(); if("014A".equals(src))return lastPedalE; if("014B".equals(src))return lastPedalF; if("0111".equals(src))return lastThrottle; return lastPedalD; }
    private double getPerformancePedalPct(){
        double raw=getRawPerformancePedalPct(); if(raw<0)return -1;
        android.content.SharedPreferences prefs=getSharedPreferences(PREFS_UI,MODE_PRIVATE);
        double lo=getPedalCalibrationValue(prefs,"pedal_cal_min");
        double mid=getPedalCalibrationValue(prefs,"pedal_cal_mid"), hi=getPedalCalibrationValue(prefs,"pedal_cal_max");
        if(lo>=0 && mid>lo+3 && hi>mid+3){ if(raw<=mid)return Math.max(0,Math.min(50,(raw-lo)*50.0/(mid-lo))); return Math.max(50,Math.min(100,50.0+(raw-mid)*50.0/(hi-mid))); }
        if(lo>=0 && hi>lo+10) return Math.max(0,Math.min(100,(raw-lo)*100.0/(hi-lo)));
        return Math.max(0,Math.min(100,raw));
    }
    private void showPedalCalibrationDialog(){
        if(performanceRunning){toast("Finalize o teste antes de calibrar");return;}
        final android.content.SharedPreferences prefs=getSharedPreferences(PREFS_UI,MODE_PRIVATE);
        final TextView rawView=tv("Leitura bruta: —",16); rawView.setTextColor(Color.WHITE); rawView.setGravity(Gravity.CENTER);
        final TextView calView=tv("Leitura calibrada: —",22); calView.setTextColor(SIM_CYAN); calView.setTypeface(null,android.graphics.Typeface.BOLD); calView.setGravity(Gravity.CENTER);
        final TextView help=tv("Veículo parado e em condição segura. Mantenha o pedal na posição física indicada e toque no botão correspondente. Nenhum comando é enviado à ECU.",10); help.setTextColor(TEXT); help.setGravity(Gravity.CENTER);
        final android.widget.ProgressBar bar=new android.widget.ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal); bar.setMax(100); bar.setProgress(0);
        LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(16),dp(8),dp(16),dp(4)); content.addView(rawView,new LinearLayout.LayoutParams(-1,dp(30))); content.addView(bar,new LinearLayout.LayoutParams(-1,dp(12))); content.addView(calView,new LinearLayout.LayoutParams(-1,dp(42))); content.addView(help,new LinearLayout.LayoutParams(-1,-2));
        final double[] points={getPedalCalibrationValue(prefs,"pedal_cal_min"),getPedalCalibrationValue(prefs,"pedal_cal_mid"),getPedalCalibrationValue(prefs,"pedal_cal_max")};
        final String[] names={"Registrar pedal em repouso — 0%","Registrar pedal em aproximadamente 50%","Registrar pedal totalmente pressionado — 100%"};
        final Button[] recordButtons=new Button[3];
        final AlertDialog dialog=new AlertDialog.Builder(this).setTitle("CALIBRAÇÃO REAL DO PEDAL").setView(content).setNegativeButton("FECHAR",null).setNeutralButton("REDEFINIR",(d,w)->{prefs.edit().remove(pedalCalibrationKey("pedal_cal_min")).remove(pedalCalibrationKey("pedal_cal_mid")).remove(pedalCalibrationKey("pedal_cal_max")).apply();toast("Calibração deste veículo/fonte redefinida");}).create();
        LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.VERTICAL); buttons.setPadding(dp(16),0,dp(16),dp(10));
        for(int i=0;i<3;i++){final int idx=i; Button b=btn(names[i]); recordButtons[i]=b; LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(44)); lp.setMargins(0,dp(3),0,dp(3)); buttons.addView(b,lp); b.setOnClickListener(v->{double raw=getRawPerformancePedalPct();if(raw<0||raw>100){toast("Leitura bruta indisponível ou fora de 0–100%; ponto não gravado");return;} if(idx==1&&(points[0]<0||raw<=points[0]+3)){toast("Registre primeiro o repouso; a leitura intermediária deve ser maior");return;} if(idx==2&&(points[0]<0||raw<=points[0]+10)){toast("Registre primeiro o repouso; o fim de curso precisa superar o zero em pelo menos 10 pontos");return;} if(idx==2&&points[1]>=0&&raw<=points[1]+3){toast("O ponto de 100% precisa ser maior que o ponto de 50%");return;} points[idx]=raw; String key=idx==0?"pedal_cal_min":idx==1?"pedal_cal_mid":"pedal_cal_max"; prefs.edit().putFloat(pedalCalibrationKey(key),(float)raw).apply(); updatePedalCalibrationDisplay(rawView,calView,bar,points); toast(String.format(Locale.US,"Ponto %d%% registrado: %.1f%% bruto",idx==0?0:idx==1?50:100,raw)); }); }
        content.addView(buttons,new LinearLayout.LayoutParams(-1,-2));
        dialog.setOnShowListener(d->{dialog.getWindow(); updatePedalCalibrationDisplay(rawView,calView,bar,points); final android.os.Handler handler=new android.os.Handler(getMainLooper()); final Runnable refresh=new Runnable(){public void run(){if(!dialog.isShowing())return; updatePedalCalibrationDisplay(rawView,calView,bar,points);handler.postDelayed(this,250);}};handler.post(refresh);});
        dialog.show();
    }
    private void updatePedalCalibrationDisplay(TextView rawView,TextView calView,android.widget.ProgressBar bar,double[] points){
        double raw=getRawPerformancePedalPct(); double calibrated=getPerformancePedalPct(); rawView.setText("LEITURA BRUTA: "+(raw>=0?String.format(Locale.US,"%.1f%%",raw):"—")); calView.setText("CALIBRADO: "+(calibrated>=0?String.format(Locale.US,"%.1f%%",calibrated):"—")); bar.setProgress(calibrated>=0?(int)Math.round(calibrated):0);
    }
    /** Reconstrói uma curva ilustrativa quando o CSV possui apenas o resumo da puxada.
     * Não representa telemetria medida: os pontos intermediários são estimativas. */
    private ArrayList<PerfGraphSample> buildEstimatedPullGraph(BestPull p){
        ArrayList<PerfGraphSample> out=new ArrayList<>();
        if(p==null||p.duration<=0||p.speed<=0)return out;
        final int count=100; double duration=Math.max(1.0,Math.min(60.0,p.duration));
        double maxSpeed=Math.max(0,p.speed), maxBoost=Math.max(0,p.boost), maxRpm=p.rpm>0?p.rpm:6500;
        double pedal=p.pedal>=0?Math.max(0,Math.min(100,p.pedal)):100;
        double throttle=p.throttle>=0?Math.max(0,Math.min(100,p.throttle)):pedal;
        int shifts=Math.max(0,Math.min(8,p.shifts));
        for(int i=0;i<count;i++){
            double f=i/(double)(count-1), t=duration*f;
            // Curva de velocidade crescente, suavizada; não presume aceleração linear.
            double speed=maxSpeed*(0.12*f+0.88*(1-Math.pow(1-f,1.65)));
            double boost=maxBoost*(1-Math.exp(-7*f));
            double rpm=maxRpm*(0.28+0.72*Math.min(1,f*2.8));
            if(shifts>0){
                for(int g=1;g<=shifts;g++){double center=(double)g/(shifts+1);double d=Math.abs(f-center);double dip=Math.max(0,1-d/0.025);rpm-=maxRpm*0.22*dip;}
            }
            double pedalValue=(f<0.015?pedal:pedal);
            double throttleValue=(f<0.015?throttle:throttle);
            out.add(new PerfGraphSample(t,Math.max(0,rpm),Math.max(0,speed),Math.max(pedalValue,throttleValue),Math.max(0,boost)));
        }
        return out;
    }
    private void loadLastPerformanceGraph(){
        historicalGraphMode=true; if(graphHeaderTitle!=null)graphHeaderTitle.setText("GRÁFICO • HISTÓRICO DA PUXADA"); combinedRpmValues.clear();combinedSpeedValues.clear();combinedPedalValues.clear();combinedBoostValues.clear();combinedTimeValues.clear();
        ArrayList<PerfGraphSample> samples=new ArrayList<>();
        synchronized(lastPerfGraphSamples){
            if(!lastPerfGraphSamples.isEmpty()){
                double previous=-1; boolean valid=true;
                for(PerfGraphSample sample:lastPerfGraphSamples){
                    if(sample==null||Double.isNaN(sample.t)||Double.isInfinite(sample.t)||sample.t<0||sample.t<=previous){valid=false;break;}
                    previous=sample.t;
                }
                if(valid && lastPerfGraphSamples.size()>=2) samples.addAll(lastPerfGraphSamples);
            }
        }
        if(performanceRunning){if(graphHistoryStatus!=null){graphHistoryStatus.setText("TESTE EM ANDAMENTO • finalize a puxada para visualizar o histórico novo");graphHistoryStatus.setTextColor(Color.rgb(255,190,0));}if(combinedGraphView!=null)combinedGraphView.invalidate();return;}
        String source="melhor puxada registrada";
        if(samples.isEmpty()){
            // Usa o ranking já consolidado no histórico: menor 0–100, depois 0–60.
            ArrayList<BestPull> ranked=readBestPulls();
            if(!ranked.isEmpty()){
                String bestFile=ranked.get(0).file;
                try(BufferedReader br=new BufferedReader(new InputStreamReader(openPersistentHistoryInput(bestFile),StandardCharsets.UTF_8))){
                    String line; String[] header=null; double firstTime=-1;
                    while((line=br.readLine())!=null){
                        if(line.startsWith("tipo;")){header=line.split(";",-1);continue;}
                        if(header==null||!line.startsWith("PERFORMANCE_SAMPLE;"))continue;
                        String[] f=line.split(";",-1);
                        double t=historyNumber(f,header,"elapsed_s"),r=historyNumber(f,header,"rpm"),v=historyNumber(f,header,"speed_kmh"),ped=historyNumber(f,header,"throttle_pct"),boost=historyNumber(f,header,"boost_bar");
                        if(t<0||r<0||v<0)continue;
                        if(firstTime<0)firstTime=t;
                        double elapsed=t-firstTime;
                        if(elapsed<0 || (!samples.isEmpty() && elapsed<=samples.get(samples.size()-1).t)) continue;
                        if(samples.size()<1200)samples.add(new PerfGraphSample(elapsed,r,v,ped,boost));
                    }
                    source=bestFile;
                }catch(Exception e){append("GRÁFICO MELHOR PUXADA: falha ao ler "+bestFile+" — "+e.getClass().getSimpleName());}
            }
            if(samples.isEmpty()){
                // Compatibilidade com CSVs antigos sem resumo PERFORMANCE_TEST.
                ArrayList<String> files=listPersistentHistoryFiles();
                for(String name:files){
                    if((!name.startsWith("VirtusELM_Pull_")&&!name.startsWith("VirtusELM_Performance_"))||!name.toLowerCase(Locale.US).endsWith(".csv"))continue;
                    try(BufferedReader br=new BufferedReader(new InputStreamReader(openPersistentHistoryInput(name),StandardCharsets.UTF_8))){
                        String line;String[] header=null;double firstTime=-1;
                        while((line=br.readLine())!=null){
                            if(line.startsWith("tipo;")){header=line.split(";",-1);continue;}
                            if(header==null||!line.startsWith("PERFORMANCE_SAMPLE;"))continue;
                            String[] f=line.split(";",-1);double t=historyNumber(f,header,"elapsed_s"),r=historyNumber(f,header,"rpm"),v=historyNumber(f,header,"speed_kmh"),ped=historyNumber(f,header,"throttle_pct"),boost=historyNumber(f,header,"boost_bar");
                            if(t<0||r<0||v<0)continue;if(firstTime<0)firstTime=t;
                            double elapsed=t-firstTime;
                            if(elapsed<0 || (!samples.isEmpty() && elapsed<=samples.get(samples.size()-1).t)) continue;
                            if(samples.size()<1200)samples.add(new PerfGraphSample(elapsed,r,v,ped,boost));
                        }
                    }catch(Exception e){append("GRÁFICO HISTÓRICO: falha ao ler "+name+" — "+e.getClass().getSimpleName());}
                    if(samples.size()>=2){source=name;break;}
                    samples.clear();
                }
            }
            if(samples.size()<2 && !ranked.isEmpty()){
                samples.clear();
                BestPull best=ranked.get(0);
                samples=buildEstimatedPullGraph(best);
                if(!samples.isEmpty())source=best.file+" • CURVA ESTIMADA A PARTIR DO RESUMO";
            }
            synchronized(lastPerfGraphSamples){lastPerfGraphSamples.clear();lastPerfGraphSamples.addAll(samples);}
        }
        if(samples.size()<2){
            if(graphHistoryStatus!=null){graphHistoryStatus.setText("SEM DADOS SUFICIENTES PARA CURVA • histórico sem amostras e sem resumo válido");graphHistoryStatus.setTextColor(Color.rgb(255,190,0));}
            if(combinedGraphView!=null)combinedGraphView.invalidate(); return;
        }
        for(PerfGraphSample s:samples){combinedTimeValues.add((float)s.t);combinedRpmValues.add((float)s.rpm);combinedSpeedValues.add(s.speed<0?Float.NaN:(float)s.speed);combinedPedalValues.add(s.pedal<0?Float.NaN:(float)s.pedal);combinedBoostValues.add(s.boost<0?Float.NaN:(float)s.boost);}
        if(graphHistoryStatus!=null){PerfGraphSample last=samples.get(samples.size()-1);graphHistoryStatus.setText("PUXADA REGISTRADA • "+samples.size()+" amostras • "+String.format(Locale.US,"%.2f s",last.t)+" • "+source);graphHistoryStatus.setTextColor(Color.rgb(0,220,180));}
        if(combinedGraphView!=null)combinedGraphView.invalidate();
    }
    private double getGpsSpeedForPerformance(){ return isGpsSpeedValid()?lastGpsSpeed:-1; }
    private void stopPerformanceTest(){ if(!performanceRunning){toast("Nenhum teste em andamento");return;} performanceStop=true; ui(()->{perfStatus.setText("FINALIZANDO TESTE…");perfStatus.setTextColor(Color.rgb(255,190,0));}); }

    private void setSelectedButton(Button b,boolean active){
        if(b==null)return; int normal=active?Color.rgb(7,72,112):Color.rgb(7,38,70); int stroke=active?Color.rgb(0,220,255):Color.rgb(25,125,195); int text=active?Color.rgb(255,255,255):Color.rgb(235,248,255);
        GradientDrawable g=new GradientDrawable(); g.setColor(normal); g.setCornerRadius(dp(24)); g.setStroke(dp(active?2:1),stroke); b.setBackground(g); b.setTextColor(text);
    }
    private void updateGraphButtonSelection(){ for(Button b:graphButtons){String label=b.getText().toString(); setSelectedButton(b,label.equals(graphMetric));} }
    private void updateGraphScaleInfo(){ if(graphScreen==null||graphView==null)return; TextView r=(TextView)graphScreen.findViewWithTag("graphRange"); if(r!=null)r.setText("ESCALA FIXA: "+graphView.range()); }

    private void updateGraph(){
        if(historicalGraphMode)return;
        // A tela de tempo real nunca recebe valores da simulação nem estimativas.
        if(!ecuResponding||simulationMode){
            if(graphHistoryStatus!=null&&currentScreen==5){graphHistoryStatus.setText("SEM TELEMETRIA REAL • conecte o ELM para iniciar o gráfico");graphHistoryStatus.setTextColor(Color.rgb(255,190,0));}
            updateGraphScaleInfo();return;
        }
        double speedPrimary=getPreferredSpeedKmh();
        float rpmSample=lastRpm>=0?(float)lastRpm:Float.NaN;
        float speedSample=speedPrimary>=0?(float)displaySpeed(speedPrimary):Float.NaN;
        // Usa a leitura real do acelerador selecionada na configuração; sem fallback estimado.
        double pedalRaw=getRawPerformancePedalPct();
        float pedalSample=pedalRaw>=0?(float)getPerformancePedalPct():Float.NaN;
        float boostSample=(lastMap>=0&&lastBaro>=0&&lastBoost>=0)?(float)displayPressureBar(lastBoost):Float.NaN;
        if(graphView!=null){float v=Float.NaN;if("RPM".equals(graphMetric))v=rpmSample;else if("BOOST".equals(graphMetric))v=boostSample;else if("THROTTLE".equals(graphMetric))v=pedalSample;else if("VELOCIDADE".equals(graphMetric))v=speedSample;if(!Float.isNaN(v))graphView.add(v);}
        if(combinedGraphView!=null){combinedGraphView.add(rpmSample,speedSample,pedalSample,boostSample);if(graphHistoryStatus!=null&&currentScreen==5){graphHistoryStatus.setText("DADOS AO VIVO • leituras recebidas do ELM");graphHistoryStatus.setTextColor(Color.rgb(55,150,255));}}
        updateGraphScaleInfo();
    }
    private void updateDashboard(){ if(!connected) setHealth("RED","DESCONECTADO"); else if(simulationMode) setHealth("SIM","MODO SIMULAÇÃO"); else if(monitoring) setHealth("YELLOW","CAN CAPTURANDO • OBD PAUSADO"); else if(ecuResponding) setHealth("GREEN","OBD ATIVO"); else setHealth("YELLOW","ELM CONECTADO • SEM DADOS"); boolean ownVehicle = PROFILE_VIN.equalsIgnoreCase(lastVin == null ? "" : lastVin.trim()); String vehicleLabel = ownVehicle ? "Volkswagen Virtus 1.0 TSI • Stage 2" : (lastVin == null || lastVin.isEmpty() || "—".equals(lastVin) ? "VEÍCULO NÃO IDENTIFICADO" : "VEÍCULO IDENTIFICADO"); dashVin.setText("VIN: "+(lastVin==null||lastVin.isEmpty()?"—":lastVin)+"\n"+vehicleLabel); TextView profile=(TextView)dashVin.getRootView().findViewWithTag("vehicleProfile"); if(profile!=null) profile.setText(ownVehicle ? "VIRTUS 1.0 TSI • STAGE 2" : ""); String ig=simulationMode?("SIMULAÇÃO • DADOS HISTÓRICOS"):ecuResponding?(lastRpm>0?"IG: ON • RUN":"IG: ON • ECU") : "IG: —"; dashIgnition.setText(ig); dashRpm.setText(lastRpm>=0?String.format(Locale.US,"%.0f rpm",lastRpm):"— rpm"); double speedPrimary=getPreferredSpeedKmh(); if(perfRpmGauge!=null)perfRpmGauge.setValue(lastRpm,lastRpm>=0&&(ecuResponding||simulationMode)); if(perfBoostGauge!=null){ perfBoostGauge.setValue(lastBoost,lastMap>=0&&lastBaro>=0&&lastBoost>=0&&(ecuResponding||simulationMode)); perfBoostGauge.setMaximum(maxBoost); } if(perfSpeedGauge!=null)perfSpeedGauge.setValue(speedPrimary,speedPrimary>=0&&(ecuResponding||simulationMode||isGpsSpeedValid())); setMetricText(dashSpeed,"VELOCIDADE",speedPrimary>=0?String.format(Locale.US,"%.0f",displaySpeed(speedPrimary)):"—",speedUnitLabel()); setMetricText(dashBoost,"BOOST",lastMap>=0&&lastBaro>=0?String.format(Locale.US,"%.2f",displayPressureBar(lastBoost)):"—",pressureUnitLabel()); if(dashBoost!=null){ dashBoost.append("\nMAX "+(maxBoost>=0?String.format(Locale.US,"%.2f",displayPressureBar(maxBoost)):"—")+" "+pressureUnitLabel()); } setMetricText(dashLoad,"CARGA MOTOR",lastLoad>=0?String.format(Locale.US,"%.0f",lastLoad):"—","%"); setMetricText(dashFuel,"COMBUSTÍVEL",lastFuel>=0?String.format(Locale.US,"%.0f",lastFuel):"—","%"); setMetricText(dashVolt,"TENSÃO",lastVolt>=0?String.format(Locale.US,"%.2f",lastVolt):"—","V"); setMetricText(dashMap,"MAP",lastMap>=0?String.format(Locale.US,"%.0f",getPressureUnit().equals("kPa")?lastMap:displayPressureBar(lastMap/100.0)):"—",pressureUnitLabel()); setMetricText(dashBaro,"BARO",lastBaro>=0?String.format(Locale.US,"%.0f",getPressureUnit().equals("kPa")?lastBaro:displayPressureBar(lastBaro/100.0)):"—",pressureUnitLabel()); setMetricText(dashThrottle,"THROTTLE",lastThrottle>=0?String.format(Locale.US,"%.0f",lastThrottle):"—","%"); dashCoolant.setText(lastCoolant>=0?String.format(Locale.US,"TEMP. LÍQUIDO\n%.0f °C",lastCoolant):"TEMP. LÍQUIDO\n— °C"); dashIntake.setText(lastIntake>=0?String.format(Locale.US,"TEMP. ADMISSÃO\n%.0f °C",lastIntake):"TEMP. ADMISSÃO\n— °C"); if(isRealtimeDataEnabled()){ updateDataTelemetry(); updateOilUi(); rpmBar.setRpm(lastRpm); updateGraph(); } dashCan.setText(simulationMode?"MODO\nSIMULAÇÃO\nCAN OFF":String.format(Locale.US,"PROTOCOLO\nCAN 11/500\n%s",monitoring?"LIVE":"PRONTO")); if(dashConn!=null&&simulationMode){dashConn.setText("● MODO SIMULAÇÃO");dashConn.setTextColor(SIM_CYAN);} }
    private void startDashboardPolling(){
        dashboardExec.scheduleAtFixedRate(()->{
            if(connected&&!monitoring&&!operationRunning){
                // Toda leitura Bluetooth passa pelo executor único de I/O.
                // Isso elimina concorrência entre dashboard, gravação, diagnóstico e CAN Monitor.
                io.execute(()->{
                    if(!connected||monitoring||operationRunning)return;
                    if(recordingActive) recordingSnapshot();
                    else { recordingTick++; if(recordingTick%3==0) dashboardSnapshot(); else ui(()->updateDashboard()); }
                });
            }else{
                ui(()->{ if(!connected){ applyConnectStyle(false); if(dashConn!=null){dashConn.setText("● ELM: DESCONECTADO"); dashConn.setTextColor(Color.rgb(150,35,35));} setHealth("RED","DESCONECTADO"); } updateDashboard(); });
            }
        },0,1,TimeUnit.SECONDS);
    }

    private void startRecording(){
        if(recordingActive){ toast("Gravação já está ativa"); return; }
        if(!connected){ toast("Conecte o ELM antes de gravar"); return; }
        try{
            File dir=new File(getFilesDir(),"recordings"); if(!dir.exists()&&!dir.mkdirs()) throw new IOException("Não foi possível criar a pasta de gravações");
            String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
            recordingFile=new File(dir,"VirtusELM_"+stamp+".csv");
            recordingWriter=new BufferedWriter(new FileWriter(recordingFile,false));
            recordingWriter.write("timestamp_ms;hora;rpm;speed_kmh;gps_speed_kmh;speed_source;map_kpa;baro_kpa;boost_bar;boost_max_bar;throttle_pct;load_pct;coolant_c;intake_c;oil_temp_c;oil_level;fuel_pct;voltage_v;vin\n"); recordingWriter.flush();
            recordingStartMs=System.currentTimeMillis(); recordingSamples=0; recordingMaxBoost=-999; recordingActive=true; recordingTick=0;
            append("=== INÍCIO DA GRAVAÇÃO DE TELEMETRIA ==="); append("CSV: "+recordingFile.getAbsolutePath());
            startRecordingKeepAlive(); setStatus("GRAVANDO TELEMETRIA • MAP/BARO/BOOST/RPM"); setHealth("GREEN","GRAVAÇÃO ATIVA"); updateRecordingUi();
        }catch(Exception e){ append("ERRO AO INICIAR GRAVAÇÃO: "+e.getMessage()); closeRecordingWriter(); toast("Não foi possível iniciar a gravação"); }
    }
    private void stopRecording(){
        if(!recordingActive){ toast("Nenhuma gravação ativa"); return; }
        recordingActive=false; closeRecordingWriter(); stopRecordingKeepAlive();
        append("=== FIM DA GRAVAÇÃO DE TELEMETRIA ==="); append("AMOSTRAS: "+recordingSamples+" | BOOST MÁX.: "+(recordingMaxBoost>-900?String.format(Locale.US,"%.2f bar",recordingMaxBoost):"não disponível"));
        setStatus(connected?"Gravação finalizada — dados preservados":"Gravação finalizada — ELM desconectado"); updateRecordingUi(); showRecordingSummary();
    }
    private void closeRecordingWriter(){ try{if(recordingWriter!=null){recordingWriter.flush();recordingWriter.close();}}catch(Exception ignored){} recordingWriter=null; }
    private void recordingSnapshot(){
        if(!recordingActive||monitoring||(!simulationMode&&(out==null||in==null))) return;
        try{
            String rpm=send("010C",700); String map=send("010B",700); String baro=send("0133",700);
            lastRpm=parseObdNumeric(rpm,"010C"); lastMap=parseMap(map); lastBaro=parseBaro(baro); lastBoost=calculateBoost(lastMap,lastBaro);
            if(lastBoost>=0){ if(lastBoost>recordingMaxBoost) recordingMaxBoost=lastBoost; if(lastBoost>maxBoost) maxBoost=lastBoost; }
            // Dados secundários a cada 3 segundos para manter alta frequência no conjunto MAP/BARO/BOOST/RPM.
            if(recordingSamples%3==0){
                lastSpeed=parseObdNumeric(send("010D",700),"010D"); lastThrottle=parseThrottle(send("0111",700)); lastPedalD=parsePercentPid(send("0149",700),"0149"); lastLoad=parseLoad(send("0104",700)); lastCoolant=parseCoolant(send("0105",700)); lastIntake=parseIntakeTemp(send("010F",700)); lastOilTemp=parseOilTemp(send("015C",700)); lastFuel=parseObdNumeric(send("012F",700),"012F"); lastVolt=parseVoltage(send("0142",700));
                String pv=parseVin(send("0902",1200)); if(!pv.isEmpty()) lastVin=pv;
            }
            ecuResponding=true; noDataCycles=0;
            String now=new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date());
            if(recordingWriter!=null){ recordingWriter.write(System.currentTimeMillis()+";"+now+";"+fmt(lastRpm)+";"+fmt(lastSpeed)+";"+fmt(lastGpsSpeed)+";"+(isGpsSpeedValid()?"GPS":"CAN")+";"+fmt(lastMap)+";"+fmt(lastBaro)+";"+fmt(lastBoost)+";"+fmt(recordingMaxBoost)+";"+fmt(lastThrottle)+";"+fmt(lastLoad)+";"+fmt(lastCoolant)+";"+fmt(lastIntake)+";"+fmt(lastOilTemp)+";"+lastOilLevel+";"+fmt(lastFuel)+";"+fmt(lastVolt)+";"+(lastVin==null?"":lastVin)+"\n"); recordingWriter.flush(); }
            recordingSamples++;
            ui(()->{updateDashboard();updateRecordingUi();});
        }catch(Exception e){ append("GRAVAÇÃO: erro de amostragem — "+e.getClass().getSimpleName()); }
    }
    private String fmt(double v){ return v<0?"":String.format(Locale.US,"%.3f",v); }
    private void updateRecordingUi(){ ui(()->{
        if(dataScreen==null)return;
        View rootView=dataScreen;
        TextView f=rootView.findViewWithTag("recordFile");
        if(f!=null){
            if(recordingActive){
                String file=recordingFile==null?"—":recordingFile.getName();
                f.setText("GRAVANDO • "+recordingSamples+" amostras • "+file);
            }else if(recordingFile!=null){
                f.setText("FINALIZADA • "+recordingSamples+" amostras • "+recordingFile.getName());
            }else{
                f.setText("STATUS: aguardando gravação");
            }
        }
    }); }
    private void showRecordingSummary(){ String file=recordingFile==null?"—":recordingFile.getName(); String max=recordingMaxBoost>-900?String.format(Locale.US,"%.2f bar",recordingMaxBoost):"não registrado"; String estado=recordingSamples>0?"GRAVAÇÃO VÁLIDA — amostras preservadas":"GRAVAÇÃO SEM AMOSTRAS — verificar ciclo de captura"; showResult("GRAVAÇÃO DE TELEMETRIA\n\nSTATUS: "+estado+"\nAMOSTRAS: "+recordingSamples+"\nBOOST MÁX.: "+max+"\nARQUIVO: "+file+"\n\nMAP, BARO, BOOST e RPM são registrados no CSV."); }
    private void copyCsv(){ if(recordingFile==null||!recordingFile.exists()){toast("Nenhuma gravação disponível");return;} try{StringBuilder b=new StringBuilder(); BufferedReader r=new BufferedReader(new FileReader(recordingFile)); String line; while((line=r.readLine())!=null)b.append(line).append('\n'); r.close(); ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("VIRTUS ELM CSV",b.toString())); toast("CSV copiado para a área de transferência");}catch(Exception e){toast("Erro ao copiar CSV");} }
    private void startRecordingKeepAlive(){
        // Em MODO SIMULAÇÃO não existe dispositivo Bluetooth conectado.
        // O serviço foreground do tipo connectedDevice pode ser rejeitado pelo Android
        // e derrubar o processo. A gravação simulada não precisa desse serviço.
        if(simulationMode) return;
        try{ Intent i=new Intent(this,RecordingKeepAliveService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); }catch(Exception e){ append("AVISO: serviço de gravação não iniciado — "+e.getClass().getSimpleName()); }
    }
    private void stopRecordingKeepAlive(){ try{ stopService(new Intent(this,RecordingKeepAliveService.class)); }catch(Exception ignored){} }

    // ===== V12 — SIMULAÇÃO INTEGRADA PRESERVADA =====
    private void startSimulationMode(String reason){
        simulationSamples.clear(); simulationIndex=0; simulationStartMs=System.currentTimeMillis();
        loadSimulationHistory();
        if(simulationSamples.isEmpty()){
            simulationSource="perfil interno baseado em telemetria histórica";
            buildFallbackSimulation();
        }
        simulationMode=true; connected=true; ecuResponding=true; lastVin=PROFILE_VIN; noDataCycles=0; maxBoost=-1; if(isPerformanceHistoryEnabled()) openPerformanceHistory();
        setHealth("SIM","MODO SIMULAÇÃO");
        setStatus("ELM não disponível — modo simulação ativo");
        ui(()->{ applyConnectStyle(true); if(dashConn!=null){dashConn.setText("● MODO SIMULAÇÃO");dashConn.setTextColor(SIM_CYAN);} updateDashboard(); });
        append("=== MODO SIMULAÇÃO ATIVADO ===");
        append("Motivo: "+reason);
        append("Fonte: "+simulationSource);
        append("Nenhum comando foi enviado ao veículo. CAN permanece bloqueado no modo simulação.");
        simulationSnapshot();
    }
    private void loadSimulationHistory(){
        if(Build.VERSION.SDK_INT<29) return;
        Cursor c=null; try{
            String[] proj={MediaStore.Downloads._ID,MediaStore.Downloads.DISPLAY_NAME,MediaStore.Downloads.RELATIVE_PATH,MediaStore.Downloads.DATE_ADDED};
            c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,proj,null,null,MediaStore.Downloads.DATE_ADDED+" DESC");
            Uri chosen=null; String chosenName=null;
            if(c!=null){ while(c.moveToNext()){
                String path=c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.RELATIVE_PATH)); String name=c.getString(c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME));
                if(path!=null&&path.contains("Download/VirtusELM/logs/")&&name!=null&&name.toLowerCase(Locale.US).endsWith(".csv")){ long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID)); chosen=ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,id); chosenName=name; break; }
            }}
            if(chosen==null) return;
            InputStream is=getContentResolver().openInputStream(chosen); if(is==null)return;
            BufferedReader br=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8)); String line; boolean header=true;
            while((line=br.readLine())!=null){ if(header){header=false;continue;} String[] p=line.split(";",-1); if(p.length<18)continue; try{
                    boolean newHistory=p.length>=27;
                    double rpm=num(p,3), speed=newHistory?num(p,5):num(p,4), map=newHistory?num(p,7):num(p,5), baro=newHistory?num(p,8):num(p,6), boost=newHistory?num(p,9):num(p,7), thr=newHistory?num(p,11):num(p,9), load=newHistory?num(p,12):num(p,10), cool=newHistory?num(p,13):num(p,11), intake=newHistory?num(p,14):num(p,12), fuel=newHistory?num(p,17):num(p,14), volt=newHistory?num(p,18):num(p,15), oil=newHistory?num(p,15):num(p,13);
                    if(rpm<0||speed<0||map<0||baro<0)continue; if(boost<0)boost=(map-baro)/100.0;
                    simulationSamples.add(new SimSample(rpm,speed,map,baro,thr<0?10:thr,load<0?15:load,cool<0?87:cool,intake<0?35:intake,fuel<0?55:fuel,volt<0?13.4:volt,oil<0?100:oil));
                    while(simulationSamples.size()>180)simulationSamples.remove(0);
                }catch(Exception ignored){} }
            br.close(); if(!simulationSamples.isEmpty()) simulationSource="último histórico persistente: "+chosenName;
        }catch(Exception e){ append("SIMULAÇÃO: não foi possível ler histórico público — usando perfil interno."); }
        finally{try{if(c!=null)c.close();}catch(Exception ignored){}}
    }
    private double num(String[] p,int i){ if(i<0||i>=p.length||p[i]==null||p[i].trim().isEmpty())return -1; return Double.parseDouble(p[i].trim().replace(',','.')); }
    private void buildFallbackSimulation(){
        simulationSamples.clear();
        double[] speeds={0,0,10,25,35,46,57,64,68,68,66,57,44,32,16,0};
        double[] rpms={890,1000,1814,2288,1720,1615,1490,1323,1792,1775,1750,1470,1550,1250,960,890};
        double[] maps={30,36,129,151,80,37,69,80,29,32,41,27,28,27,35,30};
        for(int i=0;i<speeds.length;i++){ double baro=92; double boost=Math.max(0,(maps[i]-baro)/100.0); double thr=speeds[i]>5?Math.min(88,12+speeds[i]*1.1):14; double load=Math.min(45,8+thr*0.65); simulationSamples.add(new SimSample(rpms[i],speeds[i],maps[i],baro,thr,load,87,35,55,13.4,100)); }
    }
    private SimSample currentSimulationSample(){ if(simulationSamples.isEmpty())buildFallbackSimulation(); long elapsed=(System.currentTimeMillis()-simulationStartMs)/250L; int idx=(int)(elapsed%simulationSamples.size()); simulationIndex=idx; return simulationSamples.get(idx); }
    private void simulationSnapshot(){
        if(!simulationMode)return; SimSample s=currentSimulationSample(); lastRpm=s.rpm; lastSpeed=s.speed; lastMap=s.map; lastBaro=s.baro; lastBoost=(s.map-s.baro)/100.0; if(lastBoost>maxBoost)maxBoost=lastBoost; lastThrottle=s.throttle; lastLoad=s.load; lastCoolant=s.coolant; lastIntake=s.intake; lastFuel=s.fuel; lastVolt=s.volt; lastOilTemp=s.oil; lastOilLevel="SIMULADO"; ecuResponding=true;
        if(isPerformanceHistoryEnabled()&&historyWriter!=null)writePerformanceHistorySample();
        ui(()->updateDashboard());
    }
    private String simulateResponse(String cmd){
        String u=cmd==null?"":cmd.replaceAll("\\s+","").toUpperCase(Locale.US); SimSample s=currentSimulationSample();
        if(u.startsWith("ATSH ")||u.equals("ATCFC1")||u.equals("ATCAF1")||u.equals("ATZ")||u.equals("ATE0")||u.equals("ATL0")||u.equals("ATS0")||u.equals("ATS1")||u.equals("ATH0")||u.equals("ATH1")||u.equals("ATAT1")||u.equals("ATAT0")||u.equals("ATSP0")||u.equals("ATSP6")||u.equals("ATD1")||u.equals("ATAL"))return "OK";
        if(u.equals("ATI"))return "ELM327 v1.5 SIMULATION";
        if(u.equals("ATDP")||u.equals("ATDPN"))return "ISO 15765-4 (CAN 11/500)";
        if(u.equals("ATCRA"))return "OK";
        if(u.equals("0100"))return "41 00 BE 3E B8 13";
        if(u.equals("0120"))return "41 20 80 00 00 01";
        if(u.equals("0140"))return "41 40 7A 28 00 01";
        if(u.equals("0160"))return "41 60 00 00 00 00";
        if(u.equals("010C")){int v=(int)Math.max(0,s.rpm*4);return String.format(Locale.US,"41 0C %02X %02X",(v>>8)&255,v&255);}
        if(u.equals("010D"))return String.format(Locale.US,"41 0D %02X",Math.max(0,Math.min(255,(int)s.speed)));
        if(u.equals("0104"))return String.format(Locale.US,"41 04 %02X",Math.max(0,Math.min(255,(int)(s.load*255/100))));
        if(u.equals("0105"))return String.format(Locale.US,"41 05 %02X",Math.max(0,Math.min(255,(int)(s.coolant+40))));
        if(u.equals("010F"))return String.format(Locale.US,"41 0F %02X",Math.max(0,Math.min(255,(int)(s.intake+40))));
        if(u.equals("010B"))return String.format(Locale.US,"41 0B %02X",Math.max(0,Math.min(255,(int)s.map)));
        if(u.equals("0133"))return String.format(Locale.US,"41 33 %02X",Math.max(0,Math.min(255,(int)s.baro)));
        if(u.equals("0111"))return String.format(Locale.US,"41 11 %02X",Math.max(0,Math.min(255,(int)(s.throttle*255/100))));
        if(u.equals("0149"))return String.format(Locale.US,"41 49 %02X",Math.max(0,Math.min(255,(int)(s.throttle*255/100))));
        if(u.equals("014A"))return String.format(Locale.US,"41 4A %02X",Math.max(0,Math.min(255,(int)(s.throttle*255/100))));
        if(u.equals("014B"))return String.format(Locale.US,"41 4B %02X",Math.max(0,Math.min(255,(int)(s.throttle*255/100))));
        if(u.equals("0145")||u.equals("0147")||u.equals("0148")||u.equals("014C"))return String.format(Locale.US,"41 %s %02X",u.substring(2),Math.max(0,Math.min(255,(int)(s.throttle*255/100))));
        if(u.equals("012F"))return String.format(Locale.US,"41 2F %02X",Math.max(0,Math.min(255,(int)(s.fuel*255/100))));
        if(u.equals("0142")){int v=(int)(s.volt*1000);return String.format(Locale.US,"41 42 %02X %02X",(v>>8)&255,v&255);}
        if(u.equals("015C"))return String.format(Locale.US,"41 5C %02X",Math.max(0,Math.min(255,(int)(s.oil+40))));
        if(u.equals("0902"))return "49 02 01 00 00 00 00 39 42 57 44 48 36 42 5A 33 52 50 30 30 32 32 30 31";
        if(u.equals("22F190"))return "62 F1 90 39 42 57 44 48 36 42 5A 33 52 50 30 30 32 32 30 31";
        if(u.equals("03")){ if(simulatedDtcCodes.isEmpty()) return "43 00 00 00 00 00 00"; StringBuilder d=new StringBuilder("43 "); int n=0; for(String code:simulatedDtcCodes){ String hx=encodeDtc(code); if(hx.length()==4){d.append(hx.substring(0,2)).append(" ").append(hx.substring(2)).append(" "); n++;} if(n>=3)break;} while(n<3){d.append("00 00 ");n++;} return d.toString().trim(); }
        if(u.equals("04")){ simulatedDtcCodes.clear(); return "44"; }
        if(u.equals("07"))return "47 00";
        if(u.equals("0A"))return "4A 00";
        if(u.equals("0101")){ int count=Math.min(0x7F,simulatedDtcCodes.size()); return String.format(Locale.US,"41 01 %02X 00 00 00",count); }
        if(u.equals("0102"))return "41 02 00 00";
        if(u.equals("0200")||u.equals("0201"))return "42 00 00 00 00";
        return "NO DATA";
    }


    private File diagnosticLogsDirectory(){
        File base=getExternalFilesDir("diagnosticos");
        if(base==null) base=new File(getFilesDir(),"diagnosticos");
        if(!base.exists()&&!base.mkdirs()) return null;
        return base;
    }
    private void startDiagnosticSession(String name){
        if(!isTechLogEnabled()) return;
        synchronized(diagnosticFileLock){
            closeDiagnosticSessionLocked();
            try{
                File dir=diagnosticLogsDirectory();
                if(dir==null) return;
                String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(new Date());
                String safe=(name==null?"DIAGNOSTICO":name.toUpperCase(Locale.US).replaceAll("[^A-Z0-9]+","_").replaceAll("^_+|_+$",""));
                diagnosticSessionFile=new File(dir,"V12_"+safe+"_"+stamp+".txt");
                diagnosticSessionWriter=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(diagnosticSessionFile,false),StandardCharsets.UTF_8));
                diagnosticWriteLocked("VIRTUS ELM — LOG TÉCNICO DE INVESTIGAÇÃO");
                diagnosticWriteLocked("INÍCIO: "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS",Locale.getDefault()).format(new Date()));
                diagnosticWriteLocked("APP: "+BuildConfig.VERSION_NAME+" (code "+BuildConfig.VERSION_CODE+")");
                diagnosticWriteLocked("VIN: "+(lastVin==null?"—":lastVin));
                diagnosticWriteLocked("TRANSPORTE: "+(simulationMode?"SIMULAÇÃO":(connected?"ELM REAL CONECTADO":"ELM NÃO CONECTADO")));
                diagnosticWriteLocked("PROTOCOLO: "+(lastProtocol==null||lastProtocol.isEmpty()?"a identificar":lastProtocol));
                diagnosticWriteLocked("OPERAÇÃO: "+name);
                diagnosticWriteLocked("------------------------------------------------------------");
            }catch(Exception e){ diagnosticSessionWriter=null; diagnosticSessionFile=null; }
        }
    }
    private void diagnosticWriteLocked(String line){
        try{ if(diagnosticSessionWriter!=null){diagnosticSessionWriter.write("["+new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date())+"] "+String.valueOf(line));diagnosticSessionWriter.newLine();diagnosticSessionWriter.flush();} }catch(Exception ignored){}
    }
    private void diagnosticWrite(String line){
        synchronized(diagnosticFileLock){diagnosticWriteLocked(line);}
    }
    private void finishDiagnosticSession(String statusText){
        synchronized(diagnosticFileLock){
            if(diagnosticSessionWriter!=null){
                diagnosticWriteLocked("FIM: "+new SimpleDateFormat("dd/MM/yyyy HH:mm:ss.SSS",Locale.getDefault()).format(new Date()));
                diagnosticWriteLocked("STATUS: "+statusText);
                diagnosticWriteLocked("============================================================");
                closeDiagnosticSessionLocked();
            }
        }
    }
    private void closeDiagnosticSessionLocked(){
        try{if(diagnosticSessionWriter!=null)diagnosticSessionWriter.close();}catch(Exception ignored){}
        diagnosticSessionWriter=null;
    }
    private void exportDiagnosticLogs(){
        if(operationRunning){toast("Aguarde a investigação terminar antes de exportar");return;}
        try{
            File dir=diagnosticLogsDirectory();
            File[] files=dir==null?null:dir.listFiles((d,n)->n.toLowerCase(Locale.US).endsWith(".txt"));
            if(files==null||files.length==0){toast("Nenhum LOG técnico disponível ainda");return;}
            Arrays.sort(files,(a,b)->Long.compare(a.lastModified(),b.lastModified()));
            ByteArrayOutputStream bytes=new ByteArrayOutputStream();
            ZipOutputStream zip=new ZipOutputStream(bytes);
            for(File f:files){
                ZipEntry entry=new ZipEntry(f.getName());zip.putNextEntry(entry);
                FileInputStream inFile=new FileInputStream(f);byte[] buf=new byte[8192];int n;
                while((n=inFile.read(buf))>0)zip.write(buf,0,n);
                inFile.close();zip.closeEntry();
            }
            zip.finish();zip.close();pendingDiagnosticExport=bytes.toByteArray();
            Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("application/zip");
            intent.putExtra(Intent.EXTRA_TITLE,"V12_LOGS_TECNICOS_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date())+".zip");
            startActivityForResult(intent,REQUEST_EXPORT_DIAGNOSTIC_ZIP);
        }catch(Exception e){toast("Não foi possível preparar os LOGs: "+e.getMessage());}
    }

    private String send(String cmd,long timeout){
        diagnosticWrite("TX ["+timeout+" ms]: "+cmd);
        if(simulationMode){ String simulated=simulateResponse(cmd); diagnosticWrite("RX [SIMULAÇÃO]: "+simulated); return simulated; }
        if(out==null||in==null){append("ERRO: ELM não conectado para "+cmd);diagnosticWrite("ERRO: ELM não conectado para "+cmd);return "";}
        try{out.write((cmd+"\r").getBytes(StandardCharsets.US_ASCII));out.flush(); append(">> "+cmd); String response=readUntilPrompt(timeout); diagnosticWrite("RX: "+(response==null||response.isEmpty()?"<SEM RESPOSTA>":response)); return response;}catch(Exception e){append("ERRO TX/RX: "+e);diagnosticWrite("ERRO TX/RX: "+e); if(!intentionalDisconnect && !monitoring) safeUnexpectedDisconnect(e); return "";}
    }
    private String readUntilPrompt(long timeout){ long end=System.currentTimeMillis()+timeout; ByteArrayOutputStream b=new ByteArrayOutputStream(); try{while(System.currentTimeMillis()<end){if(in.available()>0){int x=in.read(); if(x<0)break; b.write(x); if(x=='>')break;} else Thread.sleep(4);}}catch(Exception e){append("ERRO LEITURA: "+e);} String raw=new String(b.toByteArray(),StandardCharsets.US_ASCII); String n=normalize(raw); if(!n.isEmpty())append("<< "+n); return n; }
    private String normalize(String s){ return s.replace("\u0000","").replace("\r","\n").replace("\n\n","\n").replaceAll("\n+","\n").trim(); }
    private void runOp(String name, Runnable op){ if(operationRunning){setStatus("Já existe uma operação em andamento");return;} io.execute(()->{operationRunning=true; boolean success=false; startDiagnosticSession(name); try{ if(!simulationMode&&(out==null||in==null)) throw new IOException("ELM não conectado"); append("=== "+name+(simulationMode?" • SIMULAÇÃO":"")+" ==="); diagnosticWrite("EVENTO: início da operação; modo="+(simulationMode?"simulação":"real")); op.run(); append("=== FIM: "+name+" ==="); success=true; }catch(Exception e){append("ERRO "+name+": "+e);diagnosticWrite("EXCEÇÃO: "+e.getClass().getName()+": "+e.getMessage());setStatus("Erro na operação — aplicativo mantido aberto");}finally{finishDiagnosticSession(success?"CONCLUÍDA":"FALHA/INTERRUPÇÃO");operationRunning=false;}}); }
    private void showResult(String s){ diagnosticWrite("RESULTADO COMPLETO:\n"+(s==null||s.trim().isEmpty()?"Nenhum dado retornado.":s)); ui(()->{ String text="RESULTADO:\n"+(s==null||s.trim().isEmpty()?"Nenhum dado retornado.":s); if(result!=null) result.setText(text); if(resultHome!=null) resultHome.setText(text); if(diagnosticResult!=null) diagnosticResult.setText(text); /* Preserve the user's current position on the diagnostic page. The technical log has its own independent scroll container. */ });}

    private String firstPayload(String resp){ String[] ls=resp.split("\n"); for(String l:ls){String u=l.trim().toUpperCase(Locale.US); if(u.matches("^(7E[0-9A-F]|[0-9A-F]{3,8})\\s+41\\s+.*")||u.matches("^41\\s+.*")||u.matches("^43\\s+.*")||u.matches("^47\\s+.*")||u.matches("^49\\s+.*")) return u;} return resp.trim(); }
    private void queryPid(String pid,String label){ String r=send(pid,1500); String[] lines=r.split("\n"); StringBuilder outv=new StringBuilder(); for(String l:lines){String t=l.trim(); if(t.isEmpty())continue; if(t.matches("(?i).*(41|43|47|49)\\s+.*")){outv.append(t).append("\n");}} if(outv.length()>0) append(label+": "+outv.toString().trim()); else append(label+": sem resposta estruturada"); }

    private void quickDiagnostic(){ runOp("DIAGNÓSTICO RÁPIDO — SOMENTE LEITURA",()->{String p=send("0100",1800); StringBuilder r=new StringBuilder(); r.append("0100 / PIDs 01–20:\n").append(p).append("\n"); queryPid("010C","RPM"); queryPid("010D","VELOCIDADE"); queryPid("0105","TEMPERATURA ARREFECIMENTO"); String d=send("03",1800); append("DTC: "+d); r.append("DTC:\n").append(d); showResult(r.toString());}); }
    private void automaticDiagnostic(){ runOp("DIAGNÓSTICO COMPLETO — SOMENTE LEITURA",()->{StringBuilder r=new StringBuilder(); String[] pids={"0100","0120","0140","0160","0104","0105","010B","010C","010D","010F","015C","0111","011F","012F","0133","0142","03","07","0A","0902","0101"}; for(String p:pids){String x=send(p,p.equals("0902")?2500:1600); append(p+": "+x); r.append(p).append(" -> ").append(x).append("\n");} r.append("\nG266/NÍVEL DO ÓLEO: leitura VAG não padronizada via OBD-II; nenhum valor é inventado.\n"); showResult(r.toString());}); }
    private void vehicleData(){ runOp("LER DADOS DO VEÍCULO",()->{StringBuilder r=new StringBuilder(); String[] pids={"0100","0120","0140","0160","0104","0105","010B","010C","010D","010F","015C","0111","011F","012F","0133","0142"}; for(String p:pids){String x=send(p,1600); append(p+": "+x); r.append(p).append(" -> ").append(x).append("\n");} showResult(r.toString());}); }
    private void readDtc(){ runOp("LER CÓDIGOS DE FALHA — DTC",()->{ String r=send("03",2000); ArrayList<String> codes=parseDtcCodes(r); StringBuilder outv=new StringBuilder(); outv.append(simulationMode?"SIMULAÇÃO — ":"REAL — ").append("MODE 03\nRAW: ").append(r).append("\n\n"); if(codes.isEmpty()){ outv.append(formatDtcSummary(r,"43","MODE 03")); } else { outv.append("CÓDIGOS ENCONTRADOS: ").append(codes.size()).append("\n"); for(String c:codes)outv.append("• ").append(c).append("\n"); } updateDtcPanel(codes,r); append("DTC: "+(codes.isEmpty()?"nenhum código decodificado":codes.toString())); showResult(outv.toString()); }); }
    private void updateDtcPanel(final ArrayList<String> codes,final String raw){ ui(()->{ if(dtcStatusView==null)return; lastDtcCodes.clear(); lastDtcCodes.addAll(codes); selectedDtcCodes.retainAll(lastDtcCodes); String mode=simulationMode?"SIMULAÇÃO":"VEÍCULO / ELM"; dtcStatusView.setText("STATUS: "+mode+" • "+(codes.isEmpty()?"NENHUMA FALHA DECODIFICADA":codes.size()+" FALHA(S) ENCONTRADA(S)")); dtcStatusView.setTextColor(codes.isEmpty()?Color.rgb(255,190,0):Color.rgb(255,120,80)); dtcCodesView.setText(codes.isEmpty()?"CÓDIGOS: nenhum DTC decodificado":(dtcSelectionMode?"MARQUE OS DTCs PARA SELECIONAR:":"CÓDIGOS RECONHECIDOS:")); renderDtcList(codes); dtcRawView.setText("RAW: "+(raw==null||raw.isEmpty()?"—":raw)); }); }
    private void renderDtcList(final ArrayList<String> codes){ if(dtcListContainer==null)return; dtcListContainer.removeAllViews(); if(codes==null||codes.isEmpty()){ TextView empty=tv("Nenhum DTC",11); empty.setTextColor(NAV_INACTIVE); dtcListContainer.addView(empty); return; } for(final String code:codes){ if(dtcSelectionMode){ CheckBox cb=new CheckBox(this); cb.setText(code); cb.setTextColor(NAV_INACTIVE); cb.setTextSize(12); cb.setSingleLine(true); cb.setChecked(selectedDtcCodes.contains(code)); cb.setButtonTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{Color.rgb(0,200,255),Color.rgb(170,200,225)})); cb.setOnCheckedChangeListener((v,checked)->{if(checked)selectedDtcCodes.add(code);else selectedDtcCodes.remove(code); updateDtcSelectionButton();}); dtcListContainer.addView(cb,new LinearLayout.LayoutParams(-1,dp(40))); } else { TextView item=tv("• "+code,12); item.setTextColor(NAV_INACTIVE); item.setTypeface(null,android.graphics.Typeface.BOLD); item.setPadding(dp(8),dp(5),dp(8),dp(5)); bindClick(item,()->showDtcDetails(code)); dtcListContainer.addView(item,new LinearLayout.LayoutParams(-1,dp(38))); } } }
    private void updateDtcSelectionButton(){ if(selectDtcButton==null)return; selectDtcButton.setText(dtcSelectionMode?(selectedDtcCodes.isEmpty()?"CANCELAR SELEÇÃO":"APAGAR SELECIONADAS") : "SELECIONAR DTCs"); }
    private void toggleDtcSelectionMode(){ if(lastDtcCodes.isEmpty()){toast("Nenhum DTC disponível para selecionar");return;} if(!dtcSelectionMode){dtcSelectionMode=true;selectedDtcCodes.clear();renderDtcList(new ArrayList<>(lastDtcCodes));updateDtcSelectionButton();toast("Selecione um ou mais DTCs");}else if(selectedDtcCodes.isEmpty()){dtcSelectionMode=false;renderDtcList(new ArrayList<>(lastDtcCodes));updateDtcSelectionButton();toast("Seleção cancelada");}else{clearSelectedDtc();} }
    private void showDtcDetails(String code){ String desc=dtcDescription(code); new AlertDialog.Builder(this).setTitle(code).setMessage(desc).setPositiveButton("OK",null).show(); }
    private String dtcDescription(String code){
        String key=code==null?"":code.toUpperCase(Locale.US);
        String d;
        synchronized(dtcLibraryDescriptions){ d=dtcLibraryDescriptions.get(key); }
        // The library is initialized asynchronously at startup. On an early tap, load the bundled asset before declaring the code unknown.
        if(d==null || d.trim().isEmpty()){
            loadBundledDtcLibrary();
            synchronized(dtcLibraryDescriptions){ d=dtcLibraryDescriptions.get(key); }
        }
        if(d==null || d.trim().isEmpty()) return "Código reconhecido; descrição detalhada não disponível na biblioteca DTC atual.";
        JSONObject record;
        synchronized(dtcLibraryRecords){ record=dtcLibraryRecords.get(key); }
        if(record==null) return d;
        StringBuilder detail=new StringBuilder(d);
        String location=record.optString("location","").trim();
        if(!location.isEmpty()) detail.append("\n\nLOCALIZAÇÃO: ").append(location);
        JSONArray causes=record.optJSONArray("possible_causes");
        if(causes!=null && causes.length()>0){ detail.append("\n\nPOSSÍVEIS CAUSAS:"); for(int i=0;i<causes.length();i++){String cause=causes.optString(i,"").trim(); if(!cause.isEmpty())detail.append("\n• ").append(cause);} }
        String note=record.optString("diagnostic_note","").trim();
        if(!note.isEmpty()) detail.append("\n\nORIENTAÇÃO: ").append(note);
        String source=record.optString("source","").trim();
        if(!source.isEmpty()) detail.append("\n\nREFERÊNCIA: ").append(source);
        return detail.toString();
    }
    private void initializeDtcLibrary(){ io.execute(()->{ try{ loadBundledDtcLibrary(); loadExternalDtcLibrary(); ui(()->updateDtcLibraryStatus()); checkDtcLibraryUpdateSilently(); }catch(Exception e){ ui(()->updateDtcLibraryStatus()); } }); }
    private boolean loadBundledDtcLibrary(){ try{ InputStream is=getAssets().open("dtc_vag.json"); String json=readAll(is); is.close(); parseDtcLibrary(json); return !dtcLibraryDescriptions.isEmpty(); }catch(Exception e){ return false; } }
    private void loadExternalDtcLibrary(){ try{ String json=null; if(Build.VERSION.SDK_INT>=29){ Cursor c=null; try{ String[] pr={MediaStore.Downloads._ID,MediaStore.Downloads.DISPLAY_NAME,MediaStore.Downloads.RELATIVE_PATH}; c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,pr,"relative_path=? AND display_name=?",new String[]{"VirtusELM/library/","dtc_vag.json"},MediaStore.Downloads.DATE_ADDED+" DESC"); if(c!=null&&c.moveToFirst()){ long id=c.getLong(c.getColumnIndexOrThrow(MediaStore.Downloads._ID)); Uri u=ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,id); InputStream is=getContentResolver().openInputStream(u); json=readAll(is); is.close(); } }finally{if(c!=null)c.close();} } else { File f=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/library/dtc_vag.json"); if(f.exists())json=readAll(new FileInputStream(f)); } if(json!=null&&!json.trim().isEmpty()){ JSONObject r=new JSONObject(json); String externalVersion=r.optString("version","0.0.0"); if(versionCompare(externalVersion,dtcLibraryVersion)>=0)parseDtcLibrary(json); } }catch(Exception ignored){} }
    private int versionCompare(String a,String b){ try{String[] x=a.split("\\."),y=b.split("\\."); for(int i=0;i<3;i++){int xi=i<x.length?Integer.parseInt(x[i].replaceAll("\\D.*","")):0;int yi=i<y.length?Integer.parseInt(y[i].replaceAll("\\D.*","")):0;if(xi!=yi)return xi>yi?1:-1;}return 0;}catch(Exception e){return a.equals(b)?0:-1;} }
    private void parseDtcLibrary(String json) throws Exception{
        JSONObject root=new JSONObject(json);
        String ver=root.optString("version","").trim();
        JSONArray arr=root.optJSONArray("dtcs");
        if(ver.isEmpty() || root.optInt("schema_version",0)<1 || arr==null || arr.length()==0) throw new IOException("Biblioteca DTC sem versão/schema/códigos válidos");
        LinkedHashMap<String,String> parsed=new LinkedHashMap<>();
        LinkedHashMap<String,JSONObject> records=new LinkedHashMap<>();
        for(int i=0;i<arr.length();i++){
            JSONObject o=arr.optJSONObject(i); if(o==null) throw new IOException("Registro DTC inválido no índice "+i);
            String code=o.optString("code","").trim().toUpperCase(Locale.US), desc=o.optString("description","").trim();
            if(!code.matches("[PCBU][0-3][0-9A-F]{3}") || desc.isEmpty()) throw new IOException("Código/descrição DTC inválido no índice "+i);
            if(parsed.containsKey(code)) throw new IOException("Código DTC duplicado: "+code);
            parsed.put(code,desc); records.put(code,new JSONObject(o.toString()));
        }
        synchronized(dtcLibraryDescriptions){dtcLibraryDescriptions.clear();dtcLibraryDescriptions.putAll(parsed);dtcLibraryRecords.clear();dtcLibraryRecords.putAll(records);dtcLibraryVersion=ver;}
        ui(()->{updateDtcLibraryStatus(); if(dtcLibraryScreen!=null&&dtcLibraryScreen.getVisibility()==View.VISIBLE)renderDtcLibraryList();});
    }
    private String readAll(InputStream is) throws IOException{ BufferedReader br=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8)); StringBuilder b=new StringBuilder(); String line; while((line=br.readLine())!=null)b.append(line).append('\n'); br.close(); return b.toString(); }
    private void updateDtcLibraryStatus(){ String t="Biblioteca local: v"+dtcLibraryVersion+" • "+dtcLibraryDescriptions.size()+" códigos carregados"; if(dtcLibraryStatusView!=null)dtcLibraryStatusView.setText(t); if(dtcConfigStatusView!=null)dtcConfigStatusView.setText(t); }
    private void checkDtcLibraryUpdateSilently(){
        if(!"true".equalsIgnoreCase(getSharedPreferences(PREFS_UI,MODE_PRIVATE).getString("dtc_auto_update_enabled","true"))) return;
        HttpURLConnection manifestConn=null, libraryConn=null;
        try{
            URL u=new URL(DTC_LIBRARY_MANIFEST_URL); manifestConn=(HttpURLConnection)u.openConnection();
            manifestConn.setConnectTimeout(7000); manifestConn.setReadTimeout(9000); manifestConn.setRequestMethod("GET"); manifestConn.setRequestProperty("User-Agent","VirtusELM-V12");
            if(manifestConn.getResponseCode()!=200) return;
            JSONObject m=new JSONObject(readAll(manifestConn.getInputStream())); String ver=m.optString("version",""); String url=m.optString("library_url",""); String expected=m.optString("sha256","").toLowerCase(Locale.US);
            if(ver.isEmpty()||url.isEmpty()||!expected.matches("[0-9a-f]{64}")||versionCompare(ver,dtcLibraryVersion)<=0) return;
            libraryConn=(HttpURLConnection)new URL(url).openConnection(); libraryConn.setConnectTimeout(7000); libraryConn.setReadTimeout(12000); libraryConn.setRequestMethod("GET"); libraryConn.setRequestProperty("User-Agent","VirtusELM-V12");
            if(libraryConn.getResponseCode()!=200) return; byte[] bytes=readBytes(libraryConn.getInputStream()); if(!expected.equals(sha256(bytes))) return;
            String json=new String(bytes,StandardCharsets.UTF_8); JSONObject root=new JSONObject(json); if(!ver.equals(root.optString("version",""))) return;
            // Validate before persisting; malformed remote content never replaces the working local library.
            parseDtcLibrary(json); saveDtcLibrary(json); append("DTC: biblioteca atualizada automaticamente para v"+ver+".");
        }catch(Exception e){append("DTC: atualização automática indisponível; mantendo biblioteca local ("+e.getClass().getSimpleName()+").");}
        finally{if(manifestConn!=null)manifestConn.disconnect();if(libraryConn!=null)libraryConn.disconnect();}
    }
    private void updateDtcLibraryFromNetwork(){ if(operationRunning){toast("Aguarde a operação atual terminar");return;} operationRunning=true; toast("Verificando atualização da biblioteca DTC..."); io.execute(()->{ HttpURLConnection conn=null; try{ URL u=new URL(DTC_LIBRARY_MANIFEST_URL); conn=(HttpURLConnection)u.openConnection(); conn.setConnectTimeout(10000); conn.setReadTimeout(15000); conn.setRequestMethod("GET"); conn.setRequestProperty("User-Agent","VirtusELM-V12"); int code=conn.getResponseCode(); if(code!=200)throw new IOException("Manifest HTTP "+code); String manifest=readAll(conn.getInputStream()); JSONObject m=new JSONObject(manifest); String remoteVersion=m.optString("version",""); String libraryUrl=m.optString("library_url",""); String expectedSha=m.optString("sha256","").toLowerCase(Locale.US); if(remoteVersion.isEmpty()||libraryUrl.isEmpty()||expectedSha.length()!=64)throw new IOException("Manifesto inválido"); if(remoteVersion.equals(dtcLibraryVersion)){ ui(()->{operationRunning=false;updateDtcLibraryStatus();toast("Biblioteca DTC já está atualizada (v"+remoteVersion+")");}); return; } URL lu=new URL(libraryUrl); HttpURLConnection lc=(HttpURLConnection)lu.openConnection(); try{ lc.setConnectTimeout(10000); lc.setReadTimeout(20000); lc.setRequestMethod("GET"); lc.setRequestProperty("User-Agent","VirtusELM-V12"); int lcode=lc.getResponseCode(); if(lcode!=200)throw new IOException("Biblioteca HTTP "+lcode); byte[] data=readBytes(lc.getInputStream()); String actual=sha256(data); if(!expectedSha.equals(actual))throw new IOException("SHA-256 inválido"); String json=new String(data,StandardCharsets.UTF_8); JSONObject root=new JSONObject(json); if(!remoteVersion.equals(root.optString("version","")))throw new IOException("Versão da biblioteca divergente"); parseDtcLibrary(json); saveDtcLibrary(json); }finally{lc.disconnect();} ui(()->{operationRunning=false;updateDtcLibraryStatus();toast("Biblioteca DTC atualizada para v"+remoteVersion);}); }catch(Exception e){ ui(()->{operationRunning=false;toast("Atualização DTC não concluída: "+e.getMessage());}); }finally{if(conn!=null)conn.disconnect();} }); }
    private byte[] readBytes(InputStream is) throws IOException{ ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] buf=new byte[8192]; int n; while((n=is.read(buf))!=-1)b.write(buf,0,n); is.close(); return b.toByteArray(); }
    private String sha256(byte[] data) throws Exception{ MessageDigest md=MessageDigest.getInstance("SHA-256"); byte[] h=md.digest(data); StringBuilder s=new StringBuilder(); for(byte x:h)s.append(String.format(Locale.US,"%02x",x)); return s.toString(); }
    private void saveDtcLibrary(String json) throws Exception{ if(Build.VERSION.SDK_INT>=29){ ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,"dtc_vag.json"); v.put(MediaStore.Downloads.MIME_TYPE,"application/json"); v.put(MediaStore.Downloads.RELATIVE_PATH,"VirtusELM/library/"); v.put(MediaStore.Downloads.IS_PENDING,1); Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(u==null)throw new IOException("Não foi possível criar a biblioteca"); try{OutputStream os=getContentResolver().openOutputStream(u,"w"); os.write(json.getBytes(StandardCharsets.UTF_8)); os.close(); ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(u,done,null,null);}catch(Exception e){getContentResolver().delete(u,null,null);throw e;} } else { File f=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/library/dtc_vag.json"); File parent=f.getParentFile(); if(!parent.exists()&&!parent.mkdirs())throw new IOException("Não foi possível criar a pasta da biblioteca"); File tmp=new File(parent,"dtc_vag.json.tmp"); FileOutputStream os=new FileOutputStream(tmp,false); os.write(json.getBytes(StandardCharsets.UTF_8)); os.close(); if(f.exists()&&!f.delete())throw new IOException("Não foi possível substituir a biblioteca"); if(!tmp.renameTo(f))throw new IOException("Não foi possível finalizar a biblioteca"); } }
    private void clearAllDtc(){
        if(simulationMode){
            simulatedDtcCodes.clear(); lastDtcCodes.clear(); selectedDtcCodes.clear(); dtcSelectionMode=false;
            updateDtcPanel(new ArrayList<>(),"43 00 00 00 00 00 00");
            toast("SIMULAÇÃO: todos os DTCs foram removidos");
            append("DTC: limpeza total simulada — nenhum comando enviado ao veículo.");
            return;
        }
        if(!epcEvidenceSavedThisSession){
            new AlertDialog.Builder(this)
                .setTitle("PRESERVE AS EVIDÊNCIAS PRIMEIRO")
                .setMessage("Nenhum comando de limpeza foi enviado. Antes de apagar DTCs, execute INVESTIGAR EPC para ler os modos 03/07/0A, status OBD, VIN, freeze frame e respostas UDS/ISO-TP, e salvar o relatório em Download/VirtusELM/logs. A ausência de códigos decodificados não comprova ausência de falhas.")
                .setNegativeButton("CANCELAR",null)
                .setPositiveButton("INVESTIGAR EPC",(d,w)->investigateEpc())
                .show();
            return;
        }
        new AlertDialog.Builder(this)
            .setTitle("APAGAR TODOS OS DTCs?")
            .setMessage("Evidência desta sessão salva: "+(lastEpcEvidenceFile.isEmpty()?"sim":lastEpcEvidenceFile)+"\n\nO comando OBD-II Mode 04 solicita à ECU a limpeza de todos os códigos de falha; não apaga um DTC individual e pode zerar monitores de readiness. Só prossiga se o relatório e os RAWs foram preservados e você aceita essas consequências.")
            .setNegativeButton("CANCELAR",null)
            .setPositiveButton("APAGAR TODOS",(d,w)->runOp("LIMPAR TODOS OS DTCs — MODE 04",()->{
                if(!epcEvidenceSavedThisSession){
                    toast("Limpeza bloqueada: salve as evidências novamente");
                    append("MODE 04 BLOQUEADO: evidência EPC não está marcada como salva nesta sessão.");
                    return;
                }
                String evidenceFile=lastEpcEvidenceFile;
                epcEvidenceSavedThisSession=false; lastEpcEvidenceFile="";
                String r=send("04",2500); append("MODE 04: "+r);
                toast("Comando de limpeza enviado. Leia os DTCs novamente para confirmar.");
                showResult("LIMPEZA TOTAL DTC\nEvidência preservada: "+(evidenceFile.isEmpty()?"registro desta sessão":evidenceFile)+"\n\nRAW:\n"+r+"\n\nLeia os DTCs novamente para confirmar o resultado.");
            })).show();
    }

    private void clearSelectedDtc(){ ArrayList<String> selected=new ArrayList<>(selectedDtcCodes); if(simulationMode){for(String c:selected)simulatedDtcCodes.remove(c);lastDtcCodes.removeAll(selected);selectedDtcCodes.clear();dtcSelectionMode=false;updateDtcPanel(new ArrayList<>(lastDtcCodes),"43 — SIMULAÇÃO");toast(selected.size()+" DTC(s) removido(s) da simulação");append("DTC: remoção seletiva simulada: "+selected);return;} toast("LIMPEZA INDIVIDUAL: não suportada pelo OBD-II padrão. Nenhum comando foi enviado."); append("DTC: seleção individual solicitada para "+selected+" — sem transmissão; Mode 04 só limpa todos."); }
    private ArrayList<String> parseDtcCodes(String raw){
        ArrayList<String> codes=new ArrayList<>(); if(raw==null)return codes; String u=raw.toUpperCase(Locale.US).replaceAll("[^0-9A-F]+"," ").trim(); if(u.isEmpty())return codes; String[] tok=u.split("\\s+"); int svc=-1; for(int i=0;i<tok.length;i++){ if("43".equals(tok[i])){svc=i;break;} } if(svc<0||svc+1>=tok.length)return codes; for(int i=svc+1;i+1<tok.length;i+=2){ String a=tok[i],b=tok[i+1]; if("00".equals(a)&&"00".equals(b))break; if(a.length()!=2||b.length()!=2)break; try{ codes.add(decodeDtcBytePair(a,b)); }catch(Exception ignored){break;} } return codes; }
    private ArrayList<String> parseDtcCodesForResponse(String raw, String positiveSid){
        ArrayList<String> codes=new ArrayList<>();
        if(raw==null||positiveSid==null)return codes;
        String u=raw.toUpperCase(Locale.US).replaceAll("[^0-9A-F]+"," ").trim();
        if(u.isEmpty())return codes;
        String[] tok=u.split("\\s+"); int sid=-1;
        for(int i=0;i<tok.length;i++)if(positiveSid.equals(tok[i])){sid=i;break;}
        if(sid<0)return codes;
        for(int i=sid+1;i+1<tok.length;i+=2){
            String a=tok[i],b=tok[i+1];
            if(a.length()!=2||b.length()!=2)break;
            if("00".equals(a)&&"00".equals(b))break;
            try{codes.add(decodeDtcBytePair(a,b));}catch(Exception ignored){break;}
        }
        return codes;
    }
    private String formatDtcSummary(String raw, String positiveSid, String status){
        ArrayList<String> codes=parseDtcCodesForResponse(raw,positiveSid);
        if(!codes.isEmpty())return status+" ("+codes.size()+"): "+android.text.TextUtils.join(", ",codes);
        String u=raw==null?"":raw.toUpperCase(Locale.US).replaceAll("\\s+"," ").trim();
        if(u.contains("NO DATA")||u.contains("UNABLE TO CONNECT")||u.contains("ERROR"))return status+": ECU/serviço não respondeu de forma utilizável; RAW preservado.";
        if(u.contains("7F "))return status+": resposta negativa da ECU; não interpretar como ausência de falhas.";
        if(u.contains(positiveSid))return status+": resposta positiva sem DTC decodificável; conferir RAW/terminação ISO-TP.";
        return status+": nenhum DTC decodificável nesta resposta; isso não confirma ausência de falhas.";
    }
    private String decodeDtcBytePair(String a,String b){ int x=Integer.parseInt(a,16),y=Integer.parseInt(b,16); char system; switch((x>>6)&3){case 0:system='P';break;case 1:system='C';break;case 2:system='B';break;default:system='U';break;} int d2=(x>>4)&3; int d3=x&15; int d4=(y>>4)&15; int d5=y&15; return String.format(Locale.US,"%c%d%X%X%X",system,d2,d3,d4,d5); }
    private String encodeDtc(String code){ try{ if(code==null||code.length()!=5)return ""; char s=Character.toUpperCase(code.charAt(0)); int prefix=s=='P'?0:s=='C'?1:s=='B'?2:3; int v=Integer.parseInt(code.substring(1),16); int x=(prefix<<6)|((v>>8)&0x3F); int y=v&0xFF; return String.format(Locale.US,"%02X%02X",x,y); }catch(Exception e){return "";} }
    /**
     * Experimental, read-only Gateway list request. The classic CAN identifiers
     * 0x710/0x77A are treated as a documented candidate only; failure is never
     * interpreted as proof that the Gateway or listed modules are absent.
     */
    private void readGatewayInstallationList(){
        runOp("GATEWAY INSTALLATION LIST • READ ONLY",()->{
            StringBuilder report=new StringBuilder("GATEWAY • INSTALLATION LIST DID 2A26\\n");
            boolean real=connected && !simulationMode && out!=null && in!=null;
            report.append("TRANSPORTE: ").append(real?"ELM REAL":"SIMULAÇÃO/SEM TRANSPORTE REAL").append("\\n");
            report.append("ENDEREÇAMENTO: CAN 11-bit candidato TX 710 / RX 77A; não universal.\\n");
            if(!real){
                report.append("SEM LEITURA REAL. Simulação não será considerada evidência do veículo.\\n");
                showResult(report.toString()); return;
            }
            String raw="";
            try{
                send("ATSP6",1000); send("ATE0",500); send("ATL0",500);
                send("ATS1",500); send("ATH1",500); send("ATCAF1",500); send("ATCFC1",500);
                send("ATSTFF",500); send("ATSH 710",700);
                raw=send("222A26",4500);
                IsoTpPayload iso=reassembleIsoTp(raw,"77A");
                report.append("RAW:\\n").append(raw).append("\\n");
                report.append("ISO-TP: ").append(iso.complete?"COMPLETO":"NÃO VALIDADO").append(" — ").append(iso.note).append("\\n");
                if(iso.complete && !iso.sequenceError && !iso.bufferFull){
                    java.util.List<VagGatewayDiscovery.Node> nodes=VagGatewayDiscovery.decodePositiveResponse(iso.payload);
                    if(!nodes.isEmpty()){
                        report.append("RESPOSTA POSITIVA 62 2A 26; BITMAP 32 BYTES.\\n");
                        report.append("NÓS LISTADOS PELO GATEWAY: ");
                        for(int i=0;i<nodes.size();i++){ if(i>0)report.append(", "); report.append(String.format(Locale.US,"%02X",nodes.get(i).logicalAddress)); }
                        report.append("\\n");
                        report.append("IMPORTANTE: listagem configurada não prova presença atual, identidade, nem capacidade de escrita.\\n");
                    }else report.append("PAYLOAD NÃO CORRESPONDE AO FORMATO E TAMANHO ESPERADOS (62 2A 26 + 32 bytes).\\n");
                }else report.append("SEM BITMAP VÁLIDO. ").append(VagGatewayDiscovery.classifyNoResponse()).append("\\n");
            }catch(Exception e){report.append("ERRO: ").append(e.getClass().getSimpleName()).append(": ").append(e.getMessage()).append("\\n");}
            finally{try{send("ATSH 7DF",700);send("ATSP0",1000);send("ATH0",500);}catch(Exception ignored){}}
            String result=report.toString(); append(result.replace("\\n", " ")); showResult(result);
        });
    }

    private void vagFocusedScan(){
        if(simulationMode || !connected || out==null || in==null){
            final String message = "EXPLORADOR VAG • DTC POR STATUS UDS\n\nSTATUS: NÃO EXECUTADO\nCAUSA: ELM327 desconectado ou modo de simulação ativo.\n\nNenhuma consulta foi transmitida. Não é possível concluir que existam ou não existam módulos/DTCs sem comunicação com a ECU.\n\nAÇÃO: conecte o ELM327, confirme a conexão na tela inicial e execute novamente.\n\nO aplicativo continuará aberto e os demais resultados desta sessão serão preservados.";
            append("VAG EXPLORER: leitura bloqueada com segurança — adaptador ausente/desconectado.");
            showResult(message);
            ui(() -> {
                if (vagExplorerResult != null) vagExplorerResult.setText(message);
                if (!isFinishing() && !isDestroyed()) new AlertDialog.Builder(this).setTitle("EXPLORADOR VAG • SEM CONEXÃO").setMessage(message).setPositiveButton("OK", null).show();
            });
            return;
        }
        runOp("VAG SCAN UDS 1.0 — EVIDÊNCIA 7E8 / 7E9",()->{
        final boolean realTransport = connected && !simulationMode && out != null && in != null;
        StringBuilder r=new StringBuilder();
        r.append("VAG SCAN UDS 1.0\n\n");
        r.append("OBJETIVO: testar somente leitura UDS 0x22/F190 nos endpoints de resposta CAN já observados.\n");
        r.append("BASE DE EVIDÊNCIA: CAN 11-bit / 500 kbps; respostas 7E8 e 7E9 observadas anteriormente.\n");
        r.append("TRANSPORTE: ").append(realTransport?"ELM REAL":"SIMULAÇÃO").append("\n\n");

        String proto=send("ATDP",1500);
        r.append("ATDP: ").append(proto).append("\n");
        if(realTransport){
            send("ATSP6",1200);
            send("ATE0",800); send("ATL0",800); send("ATS1",800); send("ATH1",800); send("ATCAF1",800); send("ATCFC1",800);
        }

        String functional=probeUdsVinHeader("7DF");
        String e7e0=probeUdsVinHeader("7E0");
        String e7e1=probeUdsVinHeader("7E1");
        r.append("ENDPOINT 7DF (FUNCIONAL): ").append(formatProbeResult(functional)).append("\n");
        r.append("ENDPOINT 7E0 → resposta esperada 7E8: ").append(formatProbeResult(e7e0)).append("\n");
        r.append("ENDPOINT 7E1 → resposta esperada 7E9: ").append(formatProbeResult(e7e1)).append("\n\n");

        String vin7df=parseUdsDidAscii(functional,"62","F190");
        String vin7e0=parseUdsDidAscii(e7e0,"62","F190");
        String vin7e1=parseUdsDidAscii(e7e1,"62","F190");
        r.append("VIN 7DF: ").append(vin7df.isEmpty()?"não identificado":vin7df).append("\n");
        r.append("VIN 7E0/7E8: ").append(vin7e0.isEmpty()?"não identificado":vin7e0).append("\n");
        r.append("VIN 7E1/7E9: ").append(vin7e1.isEmpty()?"não identificado":vin7e1).append("\n\n");

        r.append("INTERPRETAÇÃO\n");
        r.append("• Resposta positiva 62 F1 90 = endpoint aceitou a leitura VIN UDS.\n");
        r.append("• Ausência de resposta NÃO identifica o módulo como inexistente.\n");
        r.append("• Nenhum nome de módulo VAG é atribuído sem evidência específica.\n");
        r.append("• Nenhuma escrita, coding, adaptation, Security Access ou atuação foi executada.\n\n");
        r.append("RAW 7DF:\n").append(functional).append("\n\n");
        r.append("RAW 7E0 / VIN:\n").append(e7e0).append("\n\n");
        r.append("RAW 7E1 / VIN:\n").append(e7e1).append("\n\n");
        r.append("UDS DTC POR MÁSCARAS DE STATUS — RESPOSTAS ISO-TP REMONTADAS\n");
        send("ATSTFF",700);
        int[] masks={0x01,0x02,0x04,0x08,0x20,0x80};
        String[] maskNames={"TEST FAILED","FAILED THIS CYCLE","PENDING","CONFIRMED","FAILED SINCE CLEAR","WARNING INDICATOR"};
        for(int endpoint=0;endpoint<2;endpoint++){
            String req=endpoint==0?"7E0":"7E1", resp=endpoint==0?"7E8":"7E9";
            r.append("\nENDPOINT ").append(req).append(" → ").append(resp).append("\n");
            for(int mi=0;mi<masks.length;mi++)r.append(maskNames[mi]).append(" / ").append(String.format(Locale.US,"%02X",masks[mi])).append("\n").append(readUdsDtcStatusMask(req,resp,masks[mi])).append("\n");
        }

        // Retorna o ELM a um estado OBD funcional sem manter um header físico fixo.
        try{ send("ATSH 7DF",1000); send("ATSP0",1200); }catch(Exception ignored){}
        String text=r.toString();
        append(text.replace('\n',' '));
        ui(()->{if(vagExplorerResult!=null)vagExplorerResult.setText(text);});
        showResult(text);
    }); }

    private String probeUdsVinHeader(String header){
        try{
            send("ATSH "+header,1000);
            return send("22F190",3500);
        }catch(Exception e){ return "ERRO: "+e.getClass().getSimpleName(); }
    }
    private String probeUdsDtcHeader(String header){
        try{
            send("ATSH "+header,1000);
            return send("1902FF",3500);
        }catch(Exception e){ return "ERRO: "+e.getClass().getSimpleName(); }
    }
    private static final class IsoTpPayload {
        byte[] payload = new byte[0];
        int expectedLength = -1;
        boolean started = false;
        boolean complete = false;
        boolean bufferFull = false;
        boolean sequenceError = false;
        String note = "";
    }

    // Reassemble ISO-TP frames printed by ELM clones when the adapter does not
    // deliver a single normalized UDS payload. Only frames for the expected ECU are used.
    private IsoTpPayload reassembleIsoTp(String raw, String expectedCanId) {
        IsoTpPayload result = new IsoTpPayload();
        if (raw == null) { result.note = "sem RAW"; return result; }
        result.bufferFull = raw.toUpperCase(Locale.US).contains("BUFFER FULL");
        ByteArrayOutputStream payload = new ByteArrayOutputStream();
        int nextSequence = 1;
        String[] lines = raw.toUpperCase(Locale.US).split("\r?\n");
        for (String line : lines) {
            String clean = line.replaceAll("[^0-9A-F ]", " ").trim().replaceAll("\\s+", " ");
            if (clean.isEmpty()) continue;
            String[] t = clean.split(" ");
            int idAt = -1;
            for (int i=0; i<t.length; i++) {
                if (t[i].equals(expectedCanId)) { idAt=i; break; }
            }
            if (idAt >= 0 && idAt + 1 < t.length) {
                int[] b = new int[t.length-idAt-1]; int n=0;
                for (int i=idAt+1; i<t.length; i++) {
                    if (t[i].length()!=2) { n=0; break; }
                    try { b[n++]=Integer.parseInt(t[i],16); } catch(Exception e) { n=0; break; }
                }
                if (n==0) continue;
                int pci=b[0], type=(pci>>4)&0xF;
                if (type==0) { // Single Frame
                    int len=pci&0xF;
                    payload.reset();
                    int take=Math.min(len,n-1);
                    for(int i=0;i<take;i++)payload.write(b[i+1]);
                    result.started=true; result.expectedLength=len;
                    result.complete=take==len; nextSequence=1;
                } else if (type==1 && n>=2) { // First Frame
                    payload.reset();
                    result.expectedLength=((pci&0xF)<<8)|b[1];
                    for(int i=2;i<n;i++)payload.write(b[i]);
                    result.started=true; result.complete=payload.size()>=result.expectedLength; nextSequence=1;
                } else if (type==2 && result.started && !result.complete) { // Consecutive Frame
                    int seq=pci&0xF;
                    if(seq!=nextSequence) { result.sequenceError=true; result.note="sequência ISO-TP interrompida (esperado " + nextSequence + ", recebido " + seq + ")"; }
                    nextSequence=(seq+1)&0xF;
                    for(int i=1;i<n;i++)payload.write(b[i]);
                    if(result.expectedLength>=0 && payload.size()>=result.expectedLength) result.complete=true;
                }
            } else {
                // Some ELMs return the already-reassembled payload without a CAN ID.
                String[] a=clean.split(" ");
                if(a.length>=2 && (a[0].equals("59") || a[0].equals("62") || a[0].equals("7F"))) {
                    ByteArrayOutputStream direct=new ByteArrayOutputStream();
                    for(String v:a){ if(v.length()!=2)break; try{direct.write(Integer.parseInt(v,16));}catch(Exception e){break;} }
                    if(direct.size()>0){ payload.reset(); try{payload.write(direct.toByteArray());}catch(Exception ignored){} result.started=true; result.expectedLength=payload.size(); result.complete=true; }
                }
            }
        }
        byte[] assembled=payload.toByteArray();
        if(result.expectedLength>=0 && assembled.length>result.expectedLength) assembled=java.util.Arrays.copyOf(assembled,result.expectedLength);
        result.payload=assembled;
        if(result.sequenceError || result.bufferFull) result.complete=false;
        if(result.expectedLength<0) result.note=result.note.isEmpty()?"nenhum quadro ISO-TP reconhecido":result.note;
        else if(!result.complete) result.note=(result.note.isEmpty()?"resposta ISO-TP incompleta":result.note)+"; recebidos "+result.payload.length+"/"+result.expectedLength+" bytes"+(result.bufferFull?"; ELM reportou BUFFER FULL":"");
        return result;
    }

    private static final class UdsDtcRecord {
        String dtc; int status;
        UdsDtcRecord(String d,int s){dtc=d;status=s;}
    }

    private ArrayList<UdsDtcRecord> parseUdsDtcRecords(byte[] p) {
        ArrayList<UdsDtcRecord> outv=new ArrayList<>();
        if(p==null||p.length<3||(p[0]&255)!=0x59||(p[1]&255)!=0x02)return outv;
        // 59 02 = reportDTCByStatusMask positive response; byte 2 is statusAvailabilityMask.
        // Each DTCAndStatusRecord is exactly 3 DTC bytes followed by 1 status byte.
        for(int i=3;i+3<p.length;i+=4){
            int a=p[i]&255,b=p[i+1]&255,c=p[i+2]&255,st=p[i+3]&255;
            outv.add(new UdsDtcRecord(String.format(Locale.US,"%02X %02X %02X",a,b,c),st));
        }
        return outv;
    }

    private String udsStatusFlags(int status){
        ArrayList<String> f=new ArrayList<>();
        if((status&0x01)!=0)f.add("falha detectada");
        if((status&0x02)!=0)f.add("falhou neste ciclo");
        if((status&0x04)!=0)f.add("pendente");
        if((status&0x08)!=0)f.add("confirmada");
        if((status&0x10)!=0)f.add("teste não concluído desde a limpeza");
        if((status&0x20)!=0)f.add("falhou desde a limpeza");
        if((status&0x40)!=0)f.add("teste não concluído neste ciclo");
        if((status&0x80)!=0)f.add("solicita luz de avaria");
        return f.isEmpty()?"sem bits de status ativos":android.text.TextUtils.join(", ",f);
    }

    private String describeUdsNrc(String raw, String expectedService){
        if(raw==null)return "";
        String u=raw.toUpperCase(Locale.US).replaceAll("[^0-9A-F]+"," ").trim();
        String[] t=u.isEmpty()?new String[0]:u.split("\\s+");
        for(int i=0;i+2<t.length;i++){
            if("7F".equals(t[i]) && expectedService.equals(t[i+1])){
                String n=t[i+2]; String meaning;
                switch(n){
                    case "11": meaning="serviço não suportado"; break;
                    case "12": meaning="subfunção não suportada"; break;
                    case "13": meaning="comprimento/formato de mensagem inválido"; break;
                    case "22": meaning="condições de operação não atendidas"; break;
                    case "31": meaning="request out of range (pedido fora da faixa suportada)"; break;
                    case "33": meaning="acesso de segurança negado"; break;
                    case "78": meaning="resposta pendente; a ECU ainda está processando"; break;
                    default: meaning="NRC não mapeado pela biblioteca local"; break;
                }
                return "NRC 0x"+n+": "+meaning+". A rejeição não prova ausência de DTCs nem identifica sozinha o módulo.";
            }
        }
        return "";
    }

    private String readUdsDtcStatusMask(String requestHeader, String responseCanId, int mask){
        try{
            send("ATSH "+requestHeader,800);
            String raw=send(String.format(Locale.US,"1902%02X",mask),3500);
            IsoTpPayload iso=reassembleIsoTp(raw,responseCanId);
            StringBuilder b=new StringBuilder();
            b.append("REQUEST 1902").append(String.format(Locale.US,"%02X",mask)).append(" | ECU ").append(responseCanId).append("\n");
            b.append("RAW:\n").append(raw==null?"":raw).append("\n");
            if(iso.payload.length>=3 && (iso.payload[0]&255)==0x59 && (iso.payload[1]&255)==0x02){
                b.append("ISO-TP: ").append(iso.complete?"completo":"INCOMPLETO");
                if(iso.expectedLength>=0)b.append(" ( ").append(iso.payload.length).append("/").append(iso.expectedLength).append(" bytes)");
                if(!iso.note.isEmpty())b.append(" — ").append(iso.note);
                b.append("\nSTATUS AVAILABILITY MASK: ").append(String.format(Locale.US,"%02X",iso.payload[2]&255)).append("\n");
                ArrayList<UdsDtcRecord> records=parseUdsDtcRecords(iso.payload);
                if(records.isEmpty())b.append(iso.complete?"DTCs para esta máscara: nenhum registro retornado.\n":"Nenhum registro completo pode ser confirmado porque a resposta está incompleta.\n");
                else{
                    b.append("REGISTROS UDS: ").append(records.size()).append(iso.complete?"":" (parciais; resposta incompleta)").append("\n");
                    for(UdsDtcRecord d:records)b.append("• DTC ").append(d.dtc).append(" | STATUS ").append(String.format(Locale.US,"%02X",d.status)).append(" | ").append(udsStatusFlags(d.status)).append("\n");
                }
                if(!iso.complete)b.append("CONCLUSÃO: não tratar esta resposta como lista completa de falhas.\n");
            }else{
                b.append("ISO-TP: ").append(iso.note.isEmpty()?"sem resposta positiva 59 02":iso.note).append("\n");
                String nrc=describeUdsNrc(raw,"19");
                if(!nrc.isEmpty())b.append(nrc).append("\n");
                else if(raw!=null&&raw.toUpperCase(Locale.US).contains("7F 19"))b.append("A ECU rejeitou a solicitação UDS; isso não significa ausência de falhas.\n");
                else b.append("Sem decodificação UDS válida; RAW preservado.\n");
            }
            return b.toString();
        }catch(Exception e){return "REQUEST 1902"+String.format(Locale.US,"%02X",mask)+" | ERRO: "+e.getClass().getSimpleName();}
    }

    private String formatUdsDtcResult(String raw){
        if(raw==null||raw.trim().isEmpty()) return "sem resposta";
        String u=raw.toUpperCase(Locale.US);
        if(u.contains("59 02")) return "POSITIVA 59 02 (DTC UDS retornado)";
        if(u.contains("7F 19")) return "RESPOSTA NEGATIVA UDS: "+raw.trim();
        return "sem resposta positiva: "+raw.trim();
    }
    private String formatProbeResult(String raw){
        if(raw==null||raw.trim().isEmpty()) return "sem resposta";
        if(hasUdsPositiveResponse(raw,"62","F190")) return "POSITIVA 62 F190";
        String u=raw.toUpperCase(Locale.US);
        if(u.contains("7F 22")) return "RESPOSTA NEGATIVA UDS: "+raw.trim();
        return "sem resposta positiva: "+raw.trim();
    }

    private void vagDiagnosticExplorer(){ runOp("VAG DIAGNOSTIC EXPLORER 2.2 — SOMENTE LEITURA",()->{
        // VAG Explorer 2.2: primeira etapa UDS somente leitura, sem endereço VAG arbitrário.
        // 0x22 F190 é uma leitura de DID VIN; a resposta só é considerada evidência se o veículo responder.
        final boolean realTransport = connected && !simulationMode && out != null && in != null;
        String proto=send("ATDP",1500), dpn=send("ATDPN",1200),
               p100=send("0100",1800), p101=send("0101",1800),
               dtc=send("03",1800), vin=send("0902",2500);
        String udsVin;
        if(realTransport){
            // A leitura UDS precisa usar o endpoint físico já validado no teste de campo.
            // O teste confirmou 7E0 → 7E8 para 0x22/F190; não usar 7DF aqui.
            try{ send("ATSH 7E0",1000); udsVin=send("22F190",3500); }finally{ try{send("ATSH 7DF",1000);}catch(Exception ignored){} }
        }else udsVin=send("22F190",3000);
        String rpm=send("010C",1500), speed=send("010D",1500),
               thr=send("0111",1500), volt=send("0142",1500);

        boolean obdEvidence = hasObdPositiveResponse(p100) || hasObdPositiveResponse(p101)
                || hasObdPositiveResponse(dtc) || hasObdPositiveResponse(vin)
                || hasObdPositiveResponse(rpm) || hasObdPositiveResponse(speed)
                || hasObdPositiveResponse(thr) || hasObdPositiveResponse(volt);
        boolean udsVinPositive = hasUdsPositiveResponse(udsVin,"62","F190");
        String udsVinText = parseUdsDidAscii(udsVin,"62","F190");

        StringBuilder r=new StringBuilder();
        r.append("VAG DIAGNOSTIC EXPLORER 2.2\n\n");
        if(simulationMode) r.append("MODO: SIMULAÇÃO — dados não são evidência do veículo\n");
        else if(realTransport) r.append("MODO: VEÍCULO / ELM REAL\n");
        else r.append("MODO: SEM ELM REAL\n");
        r.append("TRANSPORTE REAL: ").append(realTransport?"SIM":"NÃO").append("\n");
        r.append("EVIDÊNCIA OBD: ").append(obdEvidence?"RESPOSTA POSITIVA":"NÃO IDENTIFICADA").append("\n");
        r.append("PROTOCOLO: ").append(proto).append("\n");
        r.append("PROTOCOLO NUM.: ").append(dpn).append("\n\n");

        r.append("VAG / UDS — LEITURA VALIDADA NESTA ETAPA\n");
        r.append("SERVIÇO: 0x22 • DID F190 (VIN)\n");
        r.append("RESPOSTA UDS: ").append(udsVinPositive?"POSITIVA (0x62 F190)":"NÃO IDENTIFICADA").append("\n");
        r.append("VIN UDS: ").append(udsVinText.isEmpty()?"não identificado":udsVinText).append("\n");


        r.append("CAN IDs / ENDEREÇOS DE RESPOSTA OBSERVADOS\n");
        ArrayList<String> idsFound=parseCanIds(
                p100+"\n"+p101+"\n"+dtc+"\n"+vin+"\n"+udsVin+"\n"+rpm+"\n"+speed+"\n"+thr+"\n"+volt);
        if(idsFound.isEmpty()){
            r.append("• Nenhum CAN ID identificável no retorno textual\n");
        }else{
            for(String id:idsFound)
                r.append("• CAN ").append(id).append(" — resposta observada").append(realTransport?" (REAL)":" (SIMULAÇÃO)").append("\n");
        }

        r.append("\nMÓDULOS VAG — EVIDÊNCIA ATUAL\n");
        r.append("01 ENGINE / OBD — ").append(hasObdPositiveResponse(p100)?"resposta OBD observada":"sem resposta positiva observada").append("\n");
        r.append("UDS VIN / DID F190 — ").append(udsVinPositive?"resposta positiva observada":"sem resposta positiva observada").append("\n");
        r.append("03 ABS — NÃO IDENTIFICADO nesta etapa (nenhuma resposta específica observada)\n");
        r.append("17 INSTRUMENTS — NÃO IDENTIFICADO nesta etapa (nenhuma resposta específica observada)\n");
        r.append("19 CAN GATEWAY — NÃO IDENTIFICADO nesta etapa (nenhuma resposta específica observada)\n");
        r.append("DESCOBERTA: nenhum endereço físico específico de módulo VAG foi inventado ou transmitido.\n");

        r.append("\nDADOS OBSERVADOS\n");
        r.append("0100 PIDs: ").append(p100).append("\n");
        r.append("0101 STATUS: ").append(p101).append("\n");
        r.append("RPM 010C: ").append(rpm).append("\n");
        r.append("VELOCIDADE 010D: ").append(speed).append("\n");
        r.append("THROTTLE 0111: ").append(thr).append("\n");
        r.append("TENSÃO 0142: ").append(volt).append("\n\n");
        r.append("DTC MODE 03:\n").append(dtc).append("\n\n");
        r.append("VIN OBD 0902:\n").append(vin).append("\n\n");
        r.append("VIN UDS 22 F1 90:\n").append(udsVin).append("\n\n");
        r.append("SOMENTE LEITURA — serviço UDS 0x22 usado apenas para leitura do DID F190. Nenhum coding, adaptation, Security Access, limpeza DTC ou escrita de módulo foi executado.");

        String text=r.toString();
        append(text.replace('\n',' '));
        ui(()->{if(vagExplorerResult!=null)vagExplorerResult.setText(text);});
        showResult(text);
    }); }

    private boolean hasObdPositiveResponse(String raw){
        if(raw==null||raw.trim().isEmpty()) return false;
        return Pattern.compile("(?i)(?:^|\\s)(?:41|43|47|49)(?:\\s|$)").matcher(raw).find();
    }

    private ArrayList<String> parseCanIds(String raw){
        ArrayList<String> out=new ArrayList<>();
        if(raw==null) return out;
        Matcher m=Pattern.compile("(?i)\\b([0-9A-F]{3})\\b\\s+(?:[0-9A-F]{2}\\s+)?(?:41|43|47|49|62|6E|7F)\\b").matcher(raw);
        while(m.find()){
            String id=m.group(1).toUpperCase(Locale.US);
            if(!out.contains(id)) out.add(id);
        }
        // Importante: IDs 7E8/7E9 nunca são inventados no modo simulação.
        return out;
    }
    private boolean hasUdsPositiveResponse(String raw,String service,String did){
        if(raw==null||raw.trim().isEmpty()) return false;
        String u=raw.toUpperCase(Locale.US).replaceAll("\\s+", " ");
        return u.matches(".*\\b62\\s+F1\\s+90\\b.*") || u.contains(service+" "+did);
    }
    private String parseUdsDidAscii(String raw,String service,String did){
        if(raw==null||raw.trim().isEmpty()) return "";
        String u=raw.toUpperCase(Locale.US).replaceAll("[^0-9A-F]", " ").trim();
        String[] tok=u.isEmpty()?new String[0]:u.split("\\s+");
        for(int i=0;i+3<tok.length;i++){
            if(service.equals(tok[i]) && "F1".equals(tok[i+1]) && did.endsWith(tok[i+2])){
                StringBuilder outv=new StringBuilder();
                for(int j=i+3;j<tok.length;j++){ if(tok[j].length()!=2) continue; try{int b=Integer.parseInt(tok[j],16); if(b>=32&&b<=126) outv.append((char)b);}catch(Exception ignored){} }
                return outv.toString().trim();
            }
            if("62".equals(tok[i]) && "F1".equals(tok[i+1]) && "90".equals(tok[i+2])){
                StringBuilder outv=new StringBuilder();
                for(int j=i+3;j<tok.length;j++){ try{int b=Integer.parseInt(tok[j],16); if(b>=32&&b<=126) outv.append((char)b);}catch(Exception ignored){} }
                String v=outv.toString().trim(); if(!v.isEmpty()) return v;
            }
        }
        return "";
    }
    private void readVin(){ runOp("LER VIN — SE DISPONÍVEL",()->{String r=send("0902",3000); String vin=parseVin(r); append("VIN: "+(vin.isEmpty()?"não identificado no parser; RAW preservado":vin)); showResult("VIN: "+(vin.isEmpty()?"não identificado":vin)+"\nRAW:\n"+r);}); }
    private String parseVin(String r){
        if(r==null||r.isEmpty()) return "";
        String[] lines=r.toUpperCase(Locale.US).replace('\r','\n').split("\n");
        StringBuilder vinHex=new StringBuilder(); boolean found=false;
        for(String rawLine:lines){
            String line=rawLine.trim(); if(line.isEmpty()) continue;
            ArrayList<String> tok=new ArrayList<>(); Matcher m=Pattern.compile("[0-9A-F]{2}").matcher(line);
            while(m.find()) tok.add(m.group());
            if(tok.size()<3) continue;
            int svc=-1;
            for(int i=0;i+2<tok.size();i++) if(tok.get(i).equals("49")&&tok.get(i+1).equals("02")&&tok.get(i+2).equals("01")){svc=i;break;}
            if(svc>=0){ found=true; for(int j=svc+3;j<tok.size();j++) vinHex.append(tok.get(j)); continue; }
            if(found){
                // Multi-frame ISO-TP continuation: 7E8 21 ... / 7E8 22 ...
                // Ignore the CAN header and PCI byte; keep only payload bytes.
                int pci=-1;
                for(int i=0;i<tok.size();i++){ if(tok.get(i).equals("21")||tok.get(i).equals("22")||tok.get(i).equals("23")||tok.get(i).equals("24")){pci=i;break;} }
                if(pci>=0){ for(int j=pci+1;j<tok.size();j++) vinHex.append(tok.get(j)); }
            }
        }
        StringBuilder vin=new StringBuilder();
        for(int i=0;i+1<vinHex.length()&&vin.length()<17;i+=2){
            try{int v=Integer.parseInt(vinHex.substring(i,i+2),16); if(v>=32&&v<=126) vin.append((char)v);}catch(Exception ignored){}
        }
        String out=vin.toString().trim();
        return out.length()==17?out:"";
    }
    private String saveEpcEvidenceReport(String fileName, String report) throws IOException {
        byte[] data=report.getBytes(StandardCharsets.UTF_8);
        if(Build.VERSION.SDK_INT>=29){
            ContentValues v=new ContentValues();
            v.put(MediaStore.Downloads.DISPLAY_NAME,fileName);
            v.put(MediaStore.Downloads.MIME_TYPE,"text/plain");
            v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/VirtusELM/logs/");
            v.put(MediaStore.Downloads.IS_PENDING,1);
            Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
            if(u==null)throw new IOException("MediaStore não criou o arquivo de evidência");
            try(OutputStream os=getContentResolver().openOutputStream(u,"w")){
                if(os==null)throw new IOException("Não foi possível abrir o arquivo de evidência");
                os.write(data); os.flush();
            }catch(Exception e){getContentResolver().delete(u,null,null);if(e instanceof IOException)throw (IOException)e;throw new IOException("Falha ao gravar evidência",e);}
            ContentValues done=new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING,0);
            int updated=getContentResolver().update(u,done,null,null);
            if(updated<=0)throw new IOException("Arquivo gravado, mas não foi possível finalizar a publicação");
        }else{
            File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs");
            if(!dir.exists()&&!dir.mkdirs())throw new IOException("Não foi possível criar Download/VirtusELM/logs");
            File f=new File(dir,fileName);
            try(FileOutputStream os=new FileOutputStream(f,false)){os.write(data);os.flush();}
        }
        return fileName;
    }

    private void investigateEpc(){ runOp("INVESTIGAÇÃO EPC — PACOTE DE EVIDÊNCIAS SOMENTE LEITURA",()->{
        final boolean realTransport = connected && !simulationMode && out != null && in != null;
        String stamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US).format(new Date());
        StringBuilder r=new StringBuilder();
        r.append("VIRTUS ELM V12 — INVESTIGAÇÃO EPC\n");
        r.append("DATA/HORA: ").append(stamp).append("\n");
        r.append("ORIGEM: ").append(realTransport?"VEÍCULO REAL / ELM327":"SIMULAÇÃO OU TRANSPORTE NÃO CONFIRMADO").append("\n");
        r.append("MODO: SOMENTE LEITURA — NÃO APAGA FALHAS\n\n");
        if(!realTransport){
            r.append("ATENÇÃO: não há transporte ELM real confirmado. Os resultados abaixo não devem ser tratados como evidência do veículo.\n\n");
        }
        String proto=send("ATDP",1200); r.append("PROTOCOLO ATDP: ").append(proto).append("\n\n");
        String[] cmds={"03","07","0A","0101","0902","020200","020C00","020D00","020500","020B00","021100","020400","020F00","0142","0146"};
        String[] labels={"DTC CONFIRMADOS / MODE 03","DTC PENDENTES / MODE 07","DTC PERMANENTES / MODE 0A","STATUS OBD / MIL E READINESS","VIN OBD-II","FREEZE FRAME: DTC CAUSADOR / 020200","FREEZE FRAME: RPM / 020C00","FREEZE FRAME: VELOCIDADE / 020D00","FREEZE FRAME: TEMP. ARREFECIMENTO / 020500","FREEZE FRAME: MAP / 020B00","FREEZE FRAME: BORBOLETA / 021100","FREEZE FRAME: CARGA / 020400","FREEZE FRAME: TEMP. ADMISSÃO / 020F00","TENSÃO MÓDULO / 0142","TEMP. AR AMBIENTE / 0146"};
        int positiveObdResponses=0;
        for(int i=0;i<cmds.length;i++){
            String value;
            try{ value=send(cmds[i],cmds[i].equals("0902")?2500:1800); }
            catch(Exception e){ value="ERRO DE LEITURA: "+e.getClass().getSimpleName(); }
            r.append(labels[i]).append("\nCOMANDO: ").append(cmds[i]).append("\nRAW: ").append(value==null?"(null)":value).append("\n");
            if(hasObdPositiveResponse(value) || hasUdsPositiveResponse(value,"62","F190") || (value!=null && value.toUpperCase(Locale.US).contains("59 02"))) positiveObdResponses++;
            if(i==0) r.append("INTERPRETAÇÃO: ").append(formatDtcSummary(value,"43","DTC CONFIRMADOS")).append("\n");
            else if(i==1) r.append("INTERPRETAÇÃO: ").append(formatDtcSummary(value,"47","DTC PENDENTES")).append("\n");
            else if(i==2) r.append("INTERPRETAÇÃO: ").append(formatDtcSummary(value,"4A","DTC PERMANENTES")).append("\n");
            r.append("\n");
            append("EPC PACKET | "+labels[i]+" | "+cmds[i]+" | "+(value==null?"(null)":value).replace('\n',' '));
        }
        if(realTransport){
            try{
                send("ATSP6",1000); send("ATE0",700); send("ATL0",700); send("ATS1",700); send("ATH1",700); send("ATCAF1",700); send("ATCFC1",700); send("ATSTFF",700);
                r.append("VAG UDS — LEITURA DTC POR MÁSCARAS DE STATUS; DTCs UDS preservados em hexadecimal\n");
                r.append("MÉTODO: ISO-TP é remontado e a resposta só é considerada completa quando o tamanho anunciado é recebido. Consultas separadas reduzem o risco de BUFFER FULL.\n");
                int[] masks={0x01,0x02,0x04,0x08,0x20,0x80};
                String[] names={"TEST FAILED","FAILED THIS CYCLE","PENDING","CONFIRMED","FAILED SINCE CLEAR","WARNING INDICATOR"};
                for(int endpoint=0;endpoint<2;endpoint++){
                    String req=endpoint==0?"7E0":"7E1", resp=endpoint==0?"7E8":"7E9";
                    r.append("\nENDPOINT ").append(req).append(" → ").append(resp).append(" (identidade do módulo não presumida)\n");
                    for(int mi=0;mi<masks.length;mi++){
                        String detail=readUdsDtcStatusMask(req,resp,masks[mi]);
                        r.append("STATUS FILTER ").append(names[mi]).append(" / ").append(String.format(Locale.US,"%02X",masks[mi])).append("\n").append(detail).append("\n");
                        append("EPC UDS "+req+" MASK "+String.format(Locale.US,"%02X",masks[mi])+" | "+detail.replace('\n',' '));
                    }
                }
            }catch(Exception e){ r.append("VAG UDS: erro durante leitura: ").append(e.getClass().getSimpleName()).append("\n\n"); }
            finally{ try{send("ATSH 7DF",800);send("ATSP0",1000);send("ATH0",700);send("ATS0",700);send("ATST32",700);}catch(Exception ignored){} }
        } else {
            r.append("VAG UDS: ignorado porque não há conexão real confirmada.\n\n");
        }
        r.append("QUALIDADE DA CAPTURA\n");
        r.append("Respostas positivas OBD identificadas: ").append(positiveObdResponses).append("\n");
        r.append("Critério de evidência: conexão ELM real e ao menos uma resposta positiva OBD reconhecida. Uma conexão aberta, isoladamente, não comprova comunicação válida com o veículo.\n\n");
        r.append("COMO INTERPRETAR\n");
        r.append("• OBD-II Mode 03/07/0A é avaliado separadamente; respostas positivas sem código decodificável não são tratadas como ausência de falhas.\n");
        r.append("• UDS 59 02 é interpretado como registros de 3 bytes de DTC + 1 byte de status; os DTCs UDS são mantidos em hexadecimal e não convertidos artificialmente para códigos Pxxxx.\n");
        r.append("• Cada máscara UDS é consultada separadamente; respostas ISO-TP incompletas ou com BUFFER FULL são marcadas e não são consideradas listas completas.\n");
        r.append("• Resposta sem código decodificável não equivale a ‘sem falhas’: pode ser ausência de suporte, timeout, resposta negativa ou fragmentação ISO-TP.\n");
        r.append("• Compare DTC confirmado, pendente e permanente; diferenças entre modos são relevantes.\n");
        r.append("• Freeze frame pode não existir; resposta vazia/NO DATA não prova que o sistema esteja sem falha.\n");
        r.append("• Resposta negativa UDS ou ausência de resposta não identifica, por si só, o módulo nem a causa.\n");
        r.append("• Guarde este relatório antes de limpar qualquer código. Não use APAGAR TODOS antes de registrar as evidências.\n");
        r.append("• EPC recorrente, perda de potência ou funcionamento irregular requer diagnóstico automotivo; se houver perda de potência, pare em local seguro.\n");
        String report=r.toString();
        String evidenceName="VirtusELM_EPC_Evidence_"+new java.text.SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(new Date())+".txt";
        try{
            report += "\nARQUIVO DE EVIDÊNCIA: Download/VirtusELM/logs/"+evidenceName+"\n";
            boolean eligibleForClear=realTransport && positiveObdResponses>0;
            report += "STATUS DE PRESERVAÇÃO: "+(eligibleForClear?"relatório salvo com transporte ELM real e resposta positiva OBD reconhecida; a limpeza ainda exige confirmação explícita.":"relatório salvo, mas não há evidência suficiente de comunicação positiva real com o veículo; NÃO autoriza limpeza de DTCs.")+"\n";
            saveEpcEvidenceReport(evidenceName,report);
            epcEvidenceSavedThisSession=eligibleForClear;
            lastEpcEvidenceFile=eligibleForClear?evidenceName:"";
            append("EVIDÊNCIA EPC SALVA: Download/VirtusELM/logs/"+evidenceName+(eligibleForClear?" • elegível para confirmação de limpeza":" • evidência positiva insuficiente; limpeza bloqueada"));
        }catch(Exception saveError){
            epcEvidenceSavedThisSession=false;
            lastEpcEvidenceFile="";
            report += "\nFALHA AO SALVAR EVIDÊNCIA: "+saveError.getClass().getSimpleName()+" — "+String.valueOf(saveError.getMessage())+"\n";
            append("ERRO: relatório EPC não foi salvo em arquivo: "+saveError.getClass().getSimpleName()+" — "+String.valueOf(saveError.getMessage()));
            toast("Atenção: relatório EPC não foi salvo em arquivo");
        }
        append("===== INÍCIO RELATÓRIO EPC =====");
        for(String line:report.split("\n")) if(!line.trim().isEmpty()) append(line);
        append("===== FIM RELATÓRIO EPC =====");
        showResult(report);
    }); }

    private void dtcFreeze(){ runOp("DTC + FREEZE FRAME — SOMENTE LEITURA",()->{String a=send("03",2000); String b=send("0200",2000); String c=send("0201",2000); append("MODE 03: "+a); append("FREEZE FRAME 0200: "+b); append("FREEZE FRAME 0201: "+c); showResult("MODE 03:\n"+a+"\n\n0200:\n"+b+"\n\n0201:\n"+c);}); }
    private void obdStatus(){ runOp("STATUS OBD / READINESS",()->{StringBuilder r=new StringBuilder(); for(String p:new String[]{"0101","0102","0106","0107","0110"}){String x=send(p,1600);append(p+": "+x);r.append(p).append(" -> ").append(x).append("\n");}showResult(r.toString());}); }
    private void o2Test(){ runOp("TESTAR MONITORAMENTO DA SONDA",()->{StringBuilder r=new StringBuilder();for(String p:new String[]{"05","06","07","0A"}){String x=send(p,1800);append(p+": "+x);r.append(p).append(" -> ").append(x).append("\n");}showResult(r.toString());}); }
    private void ignitionOffTest(){ runOp("TESTE COM IGNIÇÃO DESLIGADA",()->{String a=send("ATI",1500);String b=send("ATDP",1500);String c=send("0100",2200);boolean ecu=c.matches("(?s).*(41\\s+00|41 00).*");String conclusion=ecu?"ELM respondeu e houve resposta OBD/CAN com a condição testada.":"ELM respondeu, mas nenhuma resposta CAN/ECU foi identificada para 0100. Isso não significa que não existam outros módulos.";append("CONCLUSÃO: "+conclusion);showResult(a+"\n"+b+"\n0100:\n"+c+"\n\n"+conclusion);}); }
    private void bodyStudy(){ runOp("ESTUDO DE MÓDULOS — SOMENTE LEITURA",()->{String a=send("ATDP",1600);String b=send("0100",2200);append("PROTOCOLO: "+a);append("0100: "+b);showResult("PROTOCOLO:\n"+a+"\n\n0100:\n"+b+"\n\nNenhum comando de atuação, segurança, coding ou lock/unlock foi transmitido.");}); }

    private volatile boolean monitorRejected = false;
    private long monitorStartedAt = 0;

    // ===== V11.6.10 — CAN LAB / INVESTIGATOR 2.1 =====
    // Baseado em implementações abertas de monitoramento ELM327:
    // ATCAF0 para CAN raw, ATAL para mensagens longas, ATD1 para DLC,
    // ATMA para Monitor All e ATCRA como teste passivo de filtro por CAN ID.
    // Nenhuma rotina desta versão transmite frames CAN arbitrários.
    private void startMonitor(){
        if(operationRunning||monitoring){setStatus(operationRunning?"Finalize a operação atual antes de capturar":"Captura já ativa");return;}
        if(!connected){setStatus("Conecte o ELM primeiro");return;}
        if(simulationMode){setStatus("CAN indisponível no modo simulação");toast("CAN exige ELM327 real");return;}

        operationRunning=true;
        monitoring=true;
        stopRequested=false;
        monitorRejected=false;
        monitorStartedAt=System.currentTimeMillis();
        rawCount=frameCount=rxBytes=0; ids.clear(); idCounts.clear(); markers.clear();
        setHealth("YELLOW","CAN LAB • OBD PAUSADO");
        setStatus("CAN LAB: preparando captura passiva");

        io.execute(()->{
            try{
                append("=== V11.6.10 — CAN LAB / INVESTIGATOR 2.1 ===");
                append("Objetivo: descobrir por que o ELM responde aos PIDs, mas não permanece em monitoramento CAN.");
                append("SOMENTE LEITURA — nenhum frame CAN arbitrário é transmitido.");

                canDiagUi("ELM: conectado\nPROTOCOLO: consultando...\nCMD: ATDP / ATDPN\nRX: —\nESTADO: CAN LAB inicial");
                String dp=send("ATDP",1500);
                String dpn=send("ATDPN",1200);
                String proto=dp.toUpperCase(Locale.US);
                append("ATDP -> "+dp);
                append("ATDPN -> "+dpn);

                String protoCmd;
                if(proto.contains("29/500")||proto.contains("29")){
                    protoCmd="ATSP7";
                    append("Protocolo detectado: CAN 29/500 — fixando protocolo 7.");
                }else{
                    protoCmd="ATSP6";
                    append("Protocolo detectado: CAN 11/500 — fixando protocolo 6.");
                }
                String sp=send(protoCmd,1200); append(protoCmd+" -> "+sp);
                canDiagUi("ELM: conectado\nPROTOCOLO: "+(proto.contains("29")?"CAN 29/500":"CAN 11/500")+"\nCMD: "+protoCmd+"\nRX: "+safeDiag(sp)+"\nESTADO: preparando CAN raw");

                // Sequência inspirada em implementações abertas de sniffer ELM327.
                // Mantemos headers/espaços/DLC visíveis para facilitar a investigação.
                String[] setup={"ATE0","ATH1","ATS1","ATL0","ATAL","ATD1","ATCAF0","ATAT0"};
                for(String cmd:setup){
                    String r=send(cmd,900);
                    append(cmd+" -> "+r);
                    if(cmd.equals("ATCAF0") && !isOk(r)){
                        append("AVISO: ATCAF0 não confirmado pelo ELM; tentando ATCAF1 para compatibilidade.");
                        String rf=send("ATCAF1",900);
                        append("ATCAF1 -> "+rf);
                    }
                }
                drainInput(180);

                // ===== V11.6.10 — TESTE FINAL: ATMR 07 =====
                // IMPORTANTE: ATMR/MR não recebe um CAN ID completo de 11 bits.
                // No CAN 11-bit ele filtra os bits 8..10 do ID (3 bits). Para o ID 7E8,
                // esses bits são 111b = 7h. Portanto o teste correto é ATMR 07,
                // não ATMR 7E8. Este teste é deliberadamente amplo (IDs 700..7FF)
                // e serve para verificar se o ELM consegue monitorar por MR.
                String mr=send("ATMR 07",1200);
                append("ATMR 07 -> "+mr);
                if(!isOk(mr) && mr.toUpperCase(Locale.US).contains("?")) append("AVISO: ELM rejeitou ATMR 07.");
                drainInput(180);

                canDiagUi("ELM: conectado\nPROTOCOLO: "+(proto.contains("29")?"CAN 29/500":"CAN 11/500")+"\nCMD: ATMR 07\nRX: aguardando...\nESTADO: Monitor Receiver por 10 s");
                append("TESTE FINAL — ATMR 07 / janela 10 s");
                append(">> ATMR 07");
                final long mrStartedAt=System.currentTimeMillis();
                monitorStartedAt=mrStartedAt;
                monitorRejected=false;
                main.postDelayed(()->{
                    if(monitoring && monitorStartedAt==mrStartedAt && !stopRequested){
                        stopRequested=true;
                        append("JANELA ATMR: 10 s atingidos — enviando interrupção CR ao ELM.");
                        try{ if(out!=null){ out.write('\r'); out.flush(); } }catch(Exception e){ append("ERRO AO INTERROMPER ATMR: "+e); }
                    }
                },10000);
                monitorLoop();

                if(frameCount>0){
                    append("=== TESTE FINAL: FRAMES CAN RECEBIDOS COM ATMR 07 ===");
                    canDiagUi("ELM: conectado\nPROTOCOLO: "+(proto.contains("29")?"CAN 29/500":"CAN 11/500")+"\nCMD: ATMR 07\nRX: frames recebidos\nESTADO: ATMR ativo — CAN RAW recebido");
                    setStatus("CAN LAB — ATMR 07 funcionou: "+frameCount+" frames");
                }else if(monitorRejected){
                    append("=== TESTE FINAL: ATMR REJEITADO IMEDIATAMENTE ===");
                    append("O ELM retornou prompt antes de permanecer em Monitor Receiver.");
                    canDiagUi("ELM: conectado\nPROTOCOLO: "+(proto.contains("29")?"CAN 29/500":"CAN 11/500")+"\nCMD: ATMR 07\nRX: >\nESTADO: ATMR rejeitado imediatamente");
                    setStatus("CAN LAB — ATMR 07 rejeitado");
                }else{
                    append("=== TESTE FINAL: ATMR 07 SEM FRAMES NA JANELA DE 10 s ===");
                    append("O ELM permaneceu em Monitor Receiver, mas não entregou frames nesta janela.");
                    canDiagUi("ELM: conectado\nPROTOCOLO: "+(proto.contains("29")?"CAN 29/500":"CAN 11/500")+"\nCMD: ATMR 07\nRX: sem frames\nESTADO: 10 s concluídos — nenhum RAW");
                    setStatus("CAN LAB — ATMR 07 ativo, porém sem frames");
                }
                // Restaura o filtro de recepção antes de devolver o ELM ao OBD normal.
                try{ String resetCra=send("ATCRA",1200); append("ATCRA (reset) -> "+resetCra); }catch(Exception e){ append("AVISO: falha ao resetar ATCRA: "+e); }
            }catch(Exception e){
                append("ERRO CAN LAB: "+e);
                setStatus("CAN LAB interrompido — dados preservados");
                monitoring=false;
                operationRunning=false;
                if(!intentionalDisconnect){
                    connected=false;
                    closeSocket();
                    setHealth("RED","RECONEXÃO AUTOMÁTICA");
                    scheduleReconnect();
                }
            }finally{
                monitoring=false;
                operationRunning=false;
            }
        });
    }

    private boolean preparePassiveTest(String label,String diagLabel) throws IOException{
        if(stopRequested) return false;
        monitoring=true;
        monitorRejected=false;
        monitorStartedAt=System.currentTimeMillis();
        drainInput(120);
        canDiagUi("ELM: conectado\nPROTOCOLO: ativo\n"+diagLabel+"\nRX: aguardando...\nESTADO: captura passiva");
        append(">> "+label);
        out.write((label+"\r").getBytes(StandardCharsets.US_ASCII));
        out.flush();
        setStatus("CAN LAB — "+diagLabel+" • OBD pausado");
        return true;
    }

    private boolean isOk(String s){
        if(s==null)return false;
        String u=s.toUpperCase(Locale.US);
        return u.contains("OK");
    }
    private String safeDiag(String s){return s==null||s.trim().isEmpty()?"—":s.replace("\n"," / ").replace("\r"," ").trim();}

    private void drainInput(long quietMs){
        if(in==null)return;
        long end=System.currentTimeMillis()+quietMs;
        int drained=0;
        try{
            while(System.currentTimeMillis()<end){
                if(in.available()>0){
                    int x=in.read();
                    if(x<0)break;
                    drained++;
                    end=System.currentTimeMillis()+40;
                }else Thread.sleep(4);
            }
        }catch(Exception e){ append("AVISO: falha ao drenar buffer antes do Monitor All: "+e.getClass().getSimpleName()); }
        if(drained>0) append("Buffer ELM drenado antes da captura: "+drained+" bytes.");
    }

    private boolean monitorLoop() throws IOException {
        ByteArrayOutputStream line=new ByteArrayOutputStream();
        ByteArrayOutputStream binary=new ByteArrayOutputStream();
        byte[] buf=new byte[1024]; long lastUi=0;
        while(monitoring){
            int n=in.read(buf);
            if(n<0) throw new IOException("socket fechado durante Monitor All");
            if(n==0) continue;
            rxBytes+=n;
            for(int i=0;i<n;i++){
                int x=buf[i]&0xFF;
                // ELM returns the prompt as a single '>' character; detect it immediately
                // so FINALIZAR CAPTURA does not depend on a trailing CR/LF.
                if(x=='>'){
                    if(line.size()>0) flushMonitorLine(line);
                    if(binary.size()>0) flushMonitorBinary(binary);
                    processMonitorRaw(">");
                    if(stopRequested) break;
                    continue;
                }
                if(x=='\r'||x=='\n'){
                    flushMonitorBinary(binary);
                    flushMonitorLine(line);
                } else if(x>=32&&x<=126){
                    if(binary.size()>0) flushMonitorBinary(binary);
                    line.write(x);
                    if(line.size()>2048) flushMonitorLine(line);
                } else {
                    if(line.size()>0) flushMonitorLine(line);
                    binary.write(x);
                    if(binary.size()>=256) flushMonitorBinary(binary);
                }
            }
            if(System.currentTimeMillis()-lastUi>200){ lastUi=System.currentTimeMillis(); updateStats(); }
        }
        if(line.size()>0) flushMonitorLine(line);
        if(binary.size()>0) flushMonitorBinary(binary);
        return !monitorRejected && stopRequested;
    }
    private void flushMonitorLine(ByteArrayOutputStream line){ if(line.size()==0)return; String s=new String(line.toByteArray(),StandardCharsets.US_ASCII).trim();line.reset();if(s.isEmpty())return;processMonitorRaw(s); }
    private void flushMonitorBinary(ByteArrayOutputStream binary){
        if(binary.size()==0)return;
        byte[] b=binary.toByteArray(); binary.reset();
        StringBuilder h=new StringBuilder();
        for(byte v:b){ if(h.length()>0) h.append(' '); h.append(String.format(Locale.US,"%02X",v&0xFF)); }
        rawCount++;
        synchronized(logLock){ technical.append("[MONITOR HEX] ").append(h).append('\n'); }
        if(rawCount<=8||rawCount%50==0) append("RAW HEX #"+rawCount+": "+h);
    }
    private void processMonitorRaw(String s){
        String u=s.toUpperCase(Locale.US).trim();
        // ELM control responses are not CAN frames and must never inflate the CAN counters.
        if(u.equals("OK")||u.equals(">")||u.equals("STOPPED")||u.contains("SEARCHING")||u.contains("NO DATA")){
            append("ELM CONTROL (fora da captura CAN): "+u);
            if(u.equals(">") && stopRequested){ canDiagUi("ELM: conectado\nPROTOCOLO: ativo\nCMD: monitor passivo\nRX: >\nESTADO: prompt recebido — captura finalizada"); monitoring=false; append("<< > — ELM retornou ao prompt; captura encerrada corretamente."); append("=== FIM DA CAPTURA CAN PASSIVA ==="); append("RAW RECEBIDOS: "+rawCount+" | FRAMES DECODIFICADOS: "+frameCount+" | IDS: "+ids.size()+" | BYTES: "+rxBytes); setStatus("Captura finalizada — retomando OBD"); setHealth("YELLOW","RETOMANDO OBD"); updateStats(); return; }
            if(u.equals(">") && !stopRequested && System.currentTimeMillis()-monitorStartedAt<2500){
                monitorRejected=true;
                canDiagUi("ELM: conectado\nPROTOCOLO: ativo\nCMD: monitor passivo\nRX: >\nESTADO: teste rejeitado — tentando próxima estratégia");
                append("PROMPT IMEDIATO: estratégia de monitoramento não permaneceu ativa.");
                monitoring=false;
                return;
            }
            return;
        }
        rawCount++;
        canDiagUi("ELM: conectado\nPROTOCOLO: ativo\nCMD: AT MA\nRX: "+s.replace("\n"," / ")+"\nESTADO: dados recebidos");
        synchronized(logLock){technical.append("[MONITOR RAW] ").append(s).append('\n');}
        if(u.contains("BUFFER FULL")){append("!! ELM REPORTOU BUFFER FULL — RAW preservado.");updateStats();return;}
        ParsedCan pc=parseCan(s);
        if(pc.ok){frameCount++; ids.add(pc.id); synchronized(canDataLock){idCounts.put(pc.id,idCounts.getOrDefault(pc.id,0L)+1L); recentCanFrames.addLast(pc.id+"  ["+pc.data+"]"); while(recentCanFrames.size()>80)recentCanFrames.removeFirst();} if(frameCount<=8||frameCount%50==0)append("CAN "+pc.id+" DLC="+pc.dlc+" DATA="+pc.data);}
        else if(rawCount<=8||rawCount%100==0){append("RAW não classificado #"+rawCount+": "+s);}
        updateStats();
    }
    static class ParsedCan {boolean ok;String id="",data="";int dlc;}
    private ParsedCan parseCan(String s){
        ParsedCan p=new ParsedCan();
        String clean=s.replaceAll("[^0-9A-Fa-f ]"," ").trim().replaceAll("\\s+"," ");
        if(clean.isEmpty())return p;
        String[] a=clean.split(" ");
        // Clone ELMs may emit compact Monitor All lines such as 7E803412FCD.
        if(a.length==1){
            String z=a[0].toUpperCase(Locale.US);
            Matcher cm=Pattern.compile("^([0-9A-F]{3}|[0-9A-F]{8})([0-8])([0-9A-F]{2,16})$").matcher(z);
            if(cm.matches()){
                int d=Integer.parseInt(cm.group(2),16); String data=cm.group(3);
                if(data.length()==d*2){p.ok=true;p.id=cm.group(1);p.dlc=d;StringBuilder db=new StringBuilder();for(int i=0;i<data.length();i+=2){if(db.length()>0)db.append(' ');db.append(data.substring(i,i+2));}p.data=db.toString();return p;}
            }
            return p;
        }
        // Common ELM CAN monitor forms: header followed by DLC and data.
        for(int i=1;i<a.length;i++){try{int d=Integer.parseInt(a[i],16);if(d>=0&&d<=8&&a.length>=i+1+d){String id=String.join(" ",Arrays.copyOfRange(a,0,i)); if(id.length()>=2&&id.length()<=12){p.ok=true;p.id=id;p.dlc=d;StringBuilder db=new StringBuilder();for(int j=i+1;j<a.length;j++){if(db.length()>0)db.append(' ');db.append(a[j]);}p.data=db.toString();return p;}}}catch(Exception ignored){}}
        return p;
    }
    private void canDiagUi(String text){ ui(()->{ if(canDiag!=null) canDiag.setText(text); }); }
    private void updateStats(){long now=System.currentTimeMillis();if(now-lastStatsUi<250)return;lastStatsUi=now;ui(()->{stats.setText("RAW: "+rawCount+" • FRAMES: "+frameCount+" • IDs: "+ids.size()+" • BYTES: "+rxBytes); updateCanTable();});}
    private void updateCanTable(){
        if(canTable==null)return;
        String filter=canFilterInput==null?"":canFilterInput.getText().toString().trim().toUpperCase(Locale.US);
        ArrayList<Map.Entry<String,Long>> top;
        synchronized(canDataLock){top=new ArrayList<>(idCounts.entrySet());}
        top.sort((a,b)->Long.compare(b.getValue(),a.getValue()));
        StringBuilder out=new StringBuilder(); int shown=0;
        if(top.isEmpty()) out.append("AGUARDANDO FRAMES CAN…");
        else { out.append(String.format(Locale.US,"%-6s %8s %8s\n","ID","FRAMES","PERCENT")); out.append("--------------------------------\n"); long total=Math.max(1,frameCount);
            for(Map.Entry<String,Long> e:top){String id=e.getKey(); if(!filter.isEmpty()&&!id.toUpperCase(Locale.US).contains(filter))continue; double pct=e.getValue()*100.0/total; out.append(String.format(Locale.US,"%-6s %8d %7.1f%%\n",id,e.getValue(),pct)); if(++shown>=12)break;}
            if(shown==0)out.append("Nenhum ID corresponde ao filtro.\n"); }
        synchronized(canDataLock){if(!recentCanFrames.isEmpty()){out.append("\nÚLTIMOS FRAMES:\n"); Iterator<String> it=recentCanFrames.descendingIterator(); int n=0; while(it.hasNext()&&n<4){String line=it.next(); if(filter.isEmpty()||line.toUpperCase(Locale.US).contains(filter)){out.append(line).append('\n');n++;}}}}
        canTable.setText(out.toString()); if(canFilterHint!=null)canFilterHint.setText(top.size()+" IDs • "+frameCount+" frames • atualização automática");
    }
    private void clearCanCapture(){if(monitoring||operationRunning){toast("Finalize a captura CAN antes de limpar");return;} synchronized(canDataLock){idCounts.clear();ids.clear();recentCanFrames.clear();markers.clear();} rawCount=frameCount=rxBytes=0; updateStats(); append("CAN INVESTIGATOR 2.0: captura limpa — conexão preservada.");}
    private void copyCanSummary(){String text; synchronized(canDataLock){StringBuilder b=new StringBuilder("VIRTUS ELM — CAN INVESTIGATOR 2.0\n"); b.append("RAW=").append(rawCount).append(" | FRAMES=").append(frameCount).append(" | IDS=").append(ids.size()).append(" | BYTES=").append(rxBytes).append("\n"); ArrayList<Map.Entry<String,Long>> top=new ArrayList<>(idCounts.entrySet()); top.sort((a,c)->Long.compare(c.getValue(),a.getValue())); int lim=Math.min(20,top.size()); for(int i=0;i<lim;i++)b.append(top.get(i).getKey()).append(" = ").append(top.get(i).getValue()).append(" frames\n"); text=b.toString();} ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("CAN INVESTIGATOR 2.0",text)); toast("RESUMO CAN COPIADO");}
    private void mark(String type){
        if(!monitoring){append("MARCADOR ignorado: captura não está ativa");return;}
        Marker m; synchronized(canDataLock){m=new Marker(type,rawCount,frameCount,rxBytes,idCounts);} markers.add(m);
        append("*** MARCADOR "+type+" | RAW="+m.raw+" | FRAMES="+m.frames+" | BYTES="+m.bytes+" | IDS="+m.idsAt.size()+" | "+sdf.format(new Date(m.when))+" ***");
    }
    private void stopMonitor(){
        if(!monitoring){ toast("Nenhuma captura CAN ativa"); return; }
        stopRequested=true; stopDeadline=System.currentTimeMillis()+8000;
        try{ if(out!=null){ out.write('\r'); out.flush(); append(">> [INTERRUPÇÃO] 1 caractere enviado ao ELM"); } }catch(Exception e){ append("ERRO AO ENVIAR INTERRUPÇÃO: "+e); }
        setStatus("Finalizando captura CAN…");
        main.postDelayed(()->{
            if(monitoring && System.currentTimeMillis()>=stopDeadline){
                monitoring=false; operationRunning=false;
                append("TIMEOUT: ELM não retornou o prompt. A conexão será reiniciada automaticamente; log e marcadores serão preservados.");
                intentionalDisconnect=false; closeSocket();
                append("=== FIM DA CAPTURA CAN PASSIVA — TIMEOUT ===");
                setStatus("Captura finalizada — reconectando ELM"); setHealth("RED","RECONEXÃO AUTOMÁTICA");
                scheduleReconnect(); updateStats();
            }
        },8100);
    }
    private void analyze(){
        if(markers.isEmpty()){append("=== ANÁLISE DIFERENCIAL DE EVENTOS ===");append("Nenhum marcador registrado.");return;}
        append("=== ANÁLISE DIFERENCIAL DE EVENTOS ===");
        for(int i=0;i<markers.size();i++){
            Marker m=markers.get(i); append("EVENTO "+(i+1)+": "+m.type+" | RAW="+m.raw+" | FRAMES="+m.frames+" | BYTES="+m.bytes+" | IDS="+m.idsAt.size()+" | "+sdf.format(new Date(m.when)));
            if(i>0){
                Marker prev=markers.get(i-1);
                LinkedHashMap<String,Long> delta=new LinkedHashMap<>();
                for(Map.Entry<String,Long> e:m.idsAt.entrySet()){long before=prev.idsAt.getOrDefault(e.getKey(),0L);long d=e.getValue()-before;if(d>0)delta.put(e.getKey(),d);}
                ArrayList<Map.Entry<String,Long>> top=new ArrayList<>(delta.entrySet()); top.sort((a,b)->Long.compare(b.getValue(),a.getValue()));
                if(top.isEmpty()) append("  DIFERENCIAL: nenhum ID CAN novo entre os marcadores.");
                else {StringBuilder z=new StringBuilder("  IDS ATIVOS NO INTERVALO: ");int lim=Math.min(12,top.size());for(int j=0;j<lim;j++){if(j>0)z.append(", ");z.append(top.get(j).getKey()).append("(").append(top.get(j).getValue()).append("x)");}append(z.toString());}
            }
        }
        append("A análise identifica candidatos por mudança de tráfego entre marcadores; ela NÃO envia quadros CAN nem tenta acionar funções do veículo.");
        showResult("Marcadores: "+markers.size()+"\nRAW: "+rawCount+"\nFrames: "+frameCount+"\nIDs: "+ids.size()+"\nVeja no LOG os IDs que mudaram entre cada evento.");
    }

    private void copyLog(){String text; synchronized(logLock){text=technical.toString();} if(text.isEmpty()){toast("Log vazio");return;} ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("VIRTUS ELM V11.6.12 — LOG",text));toast("LOG COPIADO");}
    private void clearLog(){ if(monitoring||operationRunning){toast("Finalize a operação antes de limpar o log");return;} synchronized(logLock){technical.setLength(0);} log.setText(""); if(result!=null)result.setText("RESULTADO: —"); if(resultHome!=null)resultHome.setText("RESULTADO: —"); rawCount=frameCount=rxBytes=0;ids.clear();markers.clear();stats.setText("RAW: 0 • FRAMES: 0 • IDs: 0 • BYTES: 0");append("[00] LOG LIMPO — V11.4 • conexão Bluetooth preservada"); setStatus(connected?"Conectado — log limpo":"Bluetooth não conectado"); }
    private void toast(String s){ui(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
    private void setStatus(String s){ui(()->{ if(status!=null) status.setText("Status: "+s); });}
    private void ui(Runnable r){main.post(r);}
    private void append(String s){
        String line="["+sdf.format(new Date())+"] "+s;
        diagnosticWrite("EVENTO: "+s);
        if(!isTechLogEnabled()) return;
        synchronized(logLock){technical.append(line).append('\n');}
        ui(()->{
            if(log!=null){
                boolean followTail = logScroll!=null && logScroll.getChildAt(0)!=null &&
                    logScroll.getScrollY() >= (logScroll.getChildAt(0).getHeight()-logScroll.getHeight()-dp(24));
                log.append(line+"\n");
                if(logScroll!=null && followTail) logScroll.post(()->logScroll.smoothScrollTo(0,logScroll.getChildAt(0).getHeight()));
            }
        });
    }
    private void safeUnexpectedDisconnect(Exception cause){ if(intentionalDisconnect) return; boolean wasConnected=connected || socket!=null; connected=false; try{closeSocket();}catch(Exception ignored){} if(wasConnected){ append("CONEXÃO PERDIDA — preservando log e tentando reconexão automática."); setStatus("Conexão perdida — reconectando automaticamente"); scheduleReconnect(); } }
    private void scheduleReconnect(){ if(reconnecting||intentionalDisconnect||bt==null) return; reconnecting=true; dashboardExec.schedule(()->{ reconnecting=false; if(!intentionalDisconnect && !connected && !monitoring && !operationRunning) io.execute(()->connectWorker()); },1500,TimeUnit.MILLISECONDS); }
    private void closeSocket(){ connected=false; try{if(in!=null)in.close();}catch(Exception ignored){}try{if(out!=null)out.close();}catch(Exception ignored){}try{if(socket!=null)socket.close();}catch(Exception ignored){}in=null;out=null;socket=null;}
    @Override protected void onResume(){ super.onResume(); applyKeepScreenPreference(); if(hasLocationPermission())startGpsTracking(); }

    private boolean isKeepScreenOnEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_KEEP_SCREEN,true); }
    private boolean isRealtimeDataEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_REALTIME_DATA,true); }
    private boolean isTechLogEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_TECH_LOG,true); }
    private boolean isPerformanceHistoryEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_PERF_HISTORY,true); }
    private boolean isAutoSimulationEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_AUTO_SIM,true); }
    private boolean isAutoConnectEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_AUTO_CONNECT,false); }
    private String getPressureUnit(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getString(PREF_PRESSURE_UNIT,"bar"); }
    private String getSpeedUnit(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getString(PREF_SPEED_UNIT,"km/h"); }
    private double displaySpeed(double kmh){ return "mph".equals(getSpeedUnit()) ? kmh*0.621371 : kmh; }
    private String speedUnitLabel(){ return getSpeedUnit(); }
    private double displayPressureBar(double bar){ return "kPa".equals(getPressureUnit()) ? bar*100.0 : bar; }
    private String pressureUnitLabel(){ return getPressureUnit(); }
    // ===== V12.0-FIX10.27 — IMPORTAÇÃO IDEMPOTENTE + DEDUPLICAÇÃO POR CONTEÚDO =====
    // Os CSVs embarcados são importados somente se nenhum arquivo com o mesmo
    // SHA-256 já existir em Download/VirtusELM/logs/. Também remove cópias
    // idênticas desses três arquivos, inclusive nomes que o Android renomeou
    // para "(1)", "(2)" etc. Outros logs nunca são removidos por esta rotina.
    private void seedBundledPerformanceHistory(){
        // Importação idempotente: não executa exclusão automática de arquivos do usuário.
        final String[] files={
            "VirtusELM_Performance_20261006_142242.csv",
            "VirtusELM_Performance_20261007_164420.csv",
            "VirtusELM_Performance_20261007_165229.csv"
        };
        for(String name:files){
            try{
                String assetPath="history_seed/"+name;
                String assetHash;
                try(InputStream asset=getAssets().open(assetPath)){
                    assetHash=sha256Stream(asset);
                }
                // Se o conteúdo já existe, não importa outra cópia. Antes disso,
                // remove somente as cópias cujo conteúdo bate exatamente com o asset.
                if(dedupeBundledSeedCopies(name,assetHash)) continue;
                if(Build.VERSION.SDK_INT>=29){
                    ContentValues v=new ContentValues();
                    v.put(MediaStore.Downloads.DISPLAY_NAME,name);
                    v.put(MediaStore.Downloads.MIME_TYPE,"text/csv");
                    v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/VirtusELM/logs/");
                    v.put(MediaStore.Downloads.IS_PENDING,1);
                    Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);
                    if(u==null) continue;
                    try(InputStream inA=getAssets().open(assetPath); OutputStream outA=getContentResolver().openOutputStream(u,"w")){
                        if(outA==null) throw new IOException("output nulo");
                        byte[] buf=new byte[8192]; int n; while((n=inA.read(buf))!=-1) outA.write(buf,0,n);
                    }catch(Exception e){getContentResolver().delete(u,null,null);throw e;}
                    ContentValues done=new ContentValues(); done.put(MediaStore.Downloads.IS_PENDING,0);
                    if(getContentResolver().update(u,done,null,null)<=0) append("HISTÓRICO: arquivo importado, mas publicação pendente: "+name);
                }else{
                    File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs");
                    if(!dir.exists()&&!dir.mkdirs()) continue;
                    File dst=new File(dir,name);
                    // Segunda proteção para armazenamento legado, incluindo concorrência.
                    if(dst.exists() || dedupeBundledSeedCopies(name,assetHash)) continue;
                    try(InputStream inA=getAssets().open(assetPath); OutputStream outA=new FileOutputStream(dst,false)){
                        byte[] buf=new byte[8192]; int n; while((n=inA.read(buf))!=-1) outA.write(buf,0,n);
                    }
                }
            }catch(Exception e){append("HISTÓRICO: não foi possível verificar/importar "+name+" — "+e.getClass().getSimpleName());}
        }
        ui(()->{ if(historyScreen!=null) loadHistorySessions(); });
    }

    private String sha256Stream(InputStream input) throws Exception{
        MessageDigest digest=MessageDigest.getInstance("SHA-256");
        byte[] buffer=new byte[8192]; int count;
        while((count=input.read(buffer))!=-1) digest.update(buffer,0,count);
        byte[] hash=digest.digest(); StringBuilder out=new StringBuilder(hash.length*2);
        for(byte b:hash) out.append(String.format(Locale.US,"%02x",b&0xff));
        return out.toString();
    }

    // Deduplicação LOG: usa a mesma pasta persistente escolhida pelo usuário (SAF).
    // MediaStore é fallback; não se mistura SAF + MediaStore para evitar contar
    // o mesmo documento duas vezes. Só remove CSVs byte a byte idênticos.
    private static class LogDuplicateEntry {
        Uri uri; File file; String name; String hash; long modified;
        LogDuplicateEntry(Uri u, File f, String n, String h, long m){uri=u;file=f;name=n;hash=h;modified=m;}
    }
    // Arquivos .pending-* são gravações temporárias do MediaStore (IS_PENDING=1).
    // Não são sessões finalizadas e não podem bloquear nem participar da deduplicação.
    private static boolean isTemporaryLogFileName(String name){
        if(name==null)return true;
        String n=name.trim().toLowerCase(Locale.US);
        return n.startsWith(".pending-") || n.startsWith(".pending_") || n.equals(".pending")
                || n.endsWith(".tmp") || n.endsWith(".part");
    }

    private ArrayList<LogDuplicateEntry> collectLogFilesForDedup() throws Exception {
        ArrayList<LogDuplicateEntry> entries=new ArrayList<>();
        Uri tree=getSavedHistoryTree();
        if(tree!=null){
            Cursor c=null;
            try{
                String rootId=DocumentsContract.getTreeDocumentId(tree);
                Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,rootId);
                String[] projection={DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE};
                c=getContentResolver().query(children,projection,null,null,DocumentsContract.Document.COLUMN_DISPLAY_NAME+" ASC");
                if(c==null) throw new IOException("O provedor SAF não retornou a listagem da pasta selecionada");
                int idIdx=c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
                int nameIdx=c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
                int mimeIdx=c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
                while(c.moveToNext()){
                    String name=c.getString(nameIdx); String mime=mimeIdx>=0?c.getString(mimeIdx):"";
                    if(name==null||isTemporaryLogFileName(name)||!name.toLowerCase(Locale.US).endsWith(".csv")||DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) continue;
                    String id=c.getString(idIdx); Uri doc=DocumentsContract.buildDocumentUriUsingTree(tree,id);
                    try(InputStream in=getContentResolver().openInputStream(doc)){
                        if(in==null) throw new IOException("Leitura nula: "+name);
                        String hash=sha256Stream(in);
                        entries.add(new LogDuplicateEntry(doc,null,name,hash,0));
                    }catch(Exception ex){throw new IOException("Não foi possível verificar "+name,ex);}
                }
            }finally{if(c!=null)c.close();}
            return entries;
        }
        if(Build.VERSION.SDK_INT>=29){
            Cursor c=null;
            try{
                Uri collection=MediaStore.Files.getContentUri("external");
                String[] projection={MediaStore.MediaColumns._ID,MediaStore.MediaColumns.DISPLAY_NAME,MediaStore.MediaColumns.RELATIVE_PATH,MediaStore.MediaColumns.DATE_MODIFIED};
                c=getContentResolver().query(collection,projection,null,null,MediaStore.MediaColumns.DATE_MODIFIED+" ASC");
                if(c==null) throw new IOException("MediaStore não retornou a listagem da pasta LOG");
                int idIdx=c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID),nameIdx=c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME),pathIdx=c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH),modIdx=c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_MODIFIED);
                while(c.moveToNext()){
                    String name=c.getString(nameIdx),path=c.getString(pathIdx);
                    if(name==null||isTemporaryLogFileName(name)||!name.toLowerCase(Locale.US).endsWith(".csv")||!isVirtusLogsRelativePath(path))continue;
                    Uri u=ContentUris.withAppendedId(collection,c.getLong(idIdx));
                    try(InputStream in=getContentResolver().openInputStream(u)){
                        if(in==null)throw new IOException("Leitura nula: "+name);
                        entries.add(new LogDuplicateEntry(u,null,name,sha256Stream(in),c.getLong(modIdx)));
                    }catch(Exception ex){throw new IOException("Não foi possível verificar "+name,ex);}
                }
            }finally{if(c!=null)c.close();}
            return entries;
        }
        File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs");
        File[] files=dir.listFiles((d,n)->!isTemporaryLogFileName(n)&&n.toLowerCase(Locale.US).endsWith(".csv"));
        if(files==null)throw new IOException("Pasta LOG indisponível ou sem permissão");
        for(File f:files)if(f.isFile())try(InputStream in=new FileInputStream(f)){entries.add(new LogDuplicateEntry(null,f,f.getName(),sha256Stream(in),f.lastModified()));}catch(Exception ex){throw new IOException("Não foi possível verificar "+f.getName(),ex);}
        return entries;
    }
    private boolean deleteLogDuplicate(LogDuplicateEntry entry){
        try{
            if(entry.file!=null)return entry.file.delete();
            if(entry.uri!=null){
                if("com.android.externalstorage.documents".equals(entry.uri.getAuthority())||"com.android.providers.downloads.documents".equals(entry.uri.getAuthority()))
                    return DocumentsContract.deleteDocument(getContentResolver(),entry.uri);
                return getContentResolver().delete(entry.uri,null,null)>0;
            }
        }catch(Exception e){append("LOGS: não foi possível apagar "+entry.name+" — "+e.getClass().getSimpleName());}
        return false;
    }
    private void deduplicateIdenticalLogFiles(){
        final ArrayList<LogDuplicateEntry> entries;
        try{entries=collectLogFilesForDedup();}
        catch(Exception e){append("LOGS: verificação interrompida — "+e.getMessage());new AlertDialog.Builder(this).setTitle("VERIFICAÇÃO INCOMPLETA").setMessage("Não foi possível ler todos os CSVs da pasta selecionada. Nenhum arquivo foi alterado.\n\n"+e.getMessage()).setPositiveButton("OK",null).show();return;}
        HashMap<String,ArrayList<LogDuplicateEntry>> groups=new HashMap<>();
        for(LogDuplicateEntry entry:entries)groups.computeIfAbsent(entry.hash,k->new ArrayList<>()).add(entry);
        final ArrayList<ArrayList<LogDuplicateEntry>> duplicateGroups=new ArrayList<>();
        int duplicateCount=0;
        for(ArrayList<LogDuplicateEntry> group:groups.values())if(group.size()>1){
            Collections.sort(group,(a,b)->{boolean an=isNumberedDuplicateLogName(a.name),bn=isNumberedDuplicateLogName(b.name);if(an!=bn)return an?1:-1;if(a.modified!=b.modified)return Long.compare(a.modified,b.modified);return a.name.compareToIgnoreCase(b.name);});
            duplicateGroups.add(group);duplicateCount+=group.size()-1;
        }
        if(duplicateGroups.isEmpty()){
            new AlertDialog.Builder(this).setTitle("VERIFICAÇÃO DA PASTA LOG").setMessage("Foram verificados "+entries.size()+" CSV(s) acessíveis. Nenhum arquivo byte a byte idêntico foi encontrado. Nenhum arquivo foi alterado.").setPositiveButton("OK",null).show();return;
        }
        final int duplicateFilesCount=duplicateCount;
        StringBuilder report=new StringBuilder("CSV verificados: ").append(entries.size()).append("\nGrupos idênticos: ").append(duplicateGroups.size()).append("\nCópias excedentes: ").append(duplicateFilesCount).append("\n\nSerá preservado um arquivo de cada grupo:\n");
        for(ArrayList<LogDuplicateEntry> group:duplicateGroups){report.append("\n• PRESERVAR: ").append(group.get(0).name).append("\n  REMOVER: ");for(int i=1;i<group.size();i++){if(i>1)report.append(", ");report.append(group.get(i).name);}}
        report.append("\n\nDeseja apagar somente as cópias excedentes? Esta ação não pode ser desfeita.");
        new AlertDialog.Builder(this).setTitle("DUPLICADOS CONFIRMADOS").setMessage(report.toString())
            .setNegativeButton("NÃO",(d,w)->new AlertDialog.Builder(this).setTitle("DUPLICADOS MANTIDOS").setMessage("Existem "+duplicateFilesCount+" arquivo(s) duplicado(s) com conteúdo idêntico. Nenhum arquivo foi apagado.").setPositiveButton("OK",null).show())
            .setPositiveButton("SIM, APAGAR",(d,w)->{
                int deleted=0,failed=0;
                for(ArrayList<LogDuplicateEntry> group:duplicateGroups)for(int i=1;i<group.size();i++){if(deleteLogDuplicate(group.get(i)))deleted++;else failed++;}
                String result=deleted+" cópia(s) removida(s). "+failed+" falha(s). Foram preservados os arquivos canônicos de cada grupo.";
                new AlertDialog.Builder(this).setTitle("LIMPEZA DA PASTA LOG").setMessage(result).setPositiveButton("OK",(x,y)->refreshHistorySessions()).show();
            }).show();
    }
    private String logFileExtension(String name){int dot=name.lastIndexOf('.');return dot>0?name.substring(dot).toLowerCase(Locale.US):"";}
    private boolean isNumberedDuplicateLogName(String name){return name.matches("(?i).*\\s*\\(\\d+\\)(?=\\.[^.]+$).*") || name.matches("(?i).*_\\d+(?=\\.[^.]+$).*");}
    private int chooseCanonicalLogIndex(ArrayList<Integer> group,ArrayList<String> names){
        for(int i:group)if(!isNumberedDuplicateLogName(names.get(i)))return i;
        return group.get(0);
    }

    // Retorna true se pelo menos uma cópia exata já existe. Entre as cópias
    // idênticas, mantém o nome canônico quando disponível; caso contrário mantém
    // a primeira encontrada. Só examina/exclui arquivos com hash igual ao asset.
    private boolean dedupeBundledSeedCopies(String canonicalName,String expectedHash){
        ArrayList<Uri> matchingUris=new ArrayList<>();
        ArrayList<String> matchingNames=new ArrayList<>();
        if(Build.VERSION.SDK_INT>=29){
            Cursor c=null; boolean verified=false;
            try{
                String[] projection={MediaStore.Downloads._ID,MediaStore.Downloads.DISPLAY_NAME,MediaStore.Downloads.RELATIVE_PATH};
                String rel=Environment.DIRECTORY_DOWNLOADS+"/VirtusELM/logs/";
                c=getContentResolver().query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,projection,
                    MediaStore.Downloads.RELATIVE_PATH+"=?",new String[]{rel},MediaStore.Downloads.DATE_MODIFIED+" ASC");
                if(c!=null){ verified=true;
                    int idIdx=c.getColumnIndexOrThrow(MediaStore.Downloads._ID);
                    int nameIdx=c.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME);
                    while(c.moveToNext()){
                        long id=c.getLong(idIdx); String name=c.getString(nameIdx);
                        Uri uri=ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI,id);
                        try(InputStream in=getContentResolver().openInputStream(uri)){
                            if(in!=null && expectedHash.equals(sha256Stream(in))){matchingUris.add(uri);matchingNames.add(name==null?"":name);}
                        }catch(Exception ignored){}
                    }
                }
            }catch(Exception e){append("HISTÓRICO: verificação MediaStore indisponível — "+e.getClass().getSimpleName());}
            finally{if(c!=null)c.close();}
            // Fail closed: se não foi possível verificar o diretório, não importa
            // outro arquivo às cegas, pois isso poderia recriar duplicatas.
            if(!verified){append("HISTÓRICO: importação suspensa porque não foi possível verificar os arquivos existentes.");return true;}
            if(matchingUris.isEmpty()) return false;
            // Conteúdo já existe: não importar outra cópia e nunca apagar automaticamente.
            return true;
        }
        File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs");
        if(!dir.exists())return false;
        File[] files=dir.listFiles(); if(files==null){append("HISTÓRICO: importação suspensa porque não foi possível ler a pasta existente.");return true;}
        ArrayList<File> matches=new ArrayList<>();
        for(File file:files){
            if(!file.isFile())continue;
            try(InputStream in=new FileInputStream(file)){
                if(expectedHash.equals(sha256Stream(in)))matches.add(file);
            }catch(Exception ignored){}
        }
        if(matches.isEmpty())return false;
        // Conteúdo já existe: não importar outra cópia e nunca apagar automaticamente.
        return true;
    }

    private void openPerformanceHistory(){
        if(historyWriter!=null||!isPerformanceHistoryEnabled())return;
        try{
            String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
            String name="VirtusELM_Performance_"+stamp+".csv";
            OutputStream os=null;
            if(Build.VERSION.SDK_INT>=29){
                ContentValues v=new ContentValues(); v.put(MediaStore.Downloads.DISPLAY_NAME,name); v.put(MediaStore.Downloads.MIME_TYPE,"text/csv"); v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/VirtusELM/logs/"); v.put(MediaStore.Downloads.IS_PENDING,1);
                historyUri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v); if(historyUri==null)throw new IOException("Não foi possível criar o arquivo público de histórico"); os=getContentResolver().openOutputStream(historyUri,"w");
            }else{
                File base=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs"); if(!base.exists()&&!base.mkdirs())throw new IOException("Não foi possível criar Download/VirtusELM/logs"); historyLegacyFile=new File(base,name); os=new FileOutputStream(historyLegacyFile,false);
            }
            historyWriter=new BufferedWriter(new OutputStreamWriter(os,StandardCharsets.UTF_8)); historySamples=0;
            historyWriter.write("tipo;timestamp_ms;hora;rpm;speed_kmh;gps_speed_kmh;speed_source;map_kpa;baro_kpa;boost_bar;boost_max_bar;throttle_pct;load_pct;coolant_c;intake_c;oil_temp_c;oil_level;fuel_pct;voltage_v;vin;ethanol_pct;power_est_cv;torque_est_nm;zero60_s;zero100_s;quality_pct;pull_duration_s;gear_shifts;pedal_d_pct;pedal_e_pct;pedal_f_pct\n"); historyWriter.flush();
            append("HISTÓRICO DE PERFORMANCE: arquivo persistente iniciado em Download/VirtusELM/logs/");
        }catch(Exception e){
            try{if(historyUri!=null)getContentResolver().delete(historyUri,null,null);}catch(Exception cleanup){append("HISTÓRICO: não foi possível remover arquivo pendente — "+cleanup.getClass().getSimpleName());}
            try{if(historyWriter!=null)historyWriter.close();}catch(Exception ignored){}
            historyWriter=null; historyUri=null;
            append("AVISO: histórico de performance não pôde ser iniciado — "+e.getClass().getSimpleName());
        }
    }
    private void closePerformanceHistory(){
        try{if(historyWriter!=null){historyWriter.flush();historyWriter.close();}}catch(Exception e){append("HISTÓRICO: falha ao fechar CSV — "+e.getClass().getSimpleName());}
        historyWriter=null;
        if(Build.VERSION.SDK_INT>=29&&historyUri!=null){
            try{ContentValues v=new ContentValues();v.put(MediaStore.Downloads.IS_PENDING,0);int updated=getContentResolver().update(historyUri,v,null,null);if(updated<=0)append("HISTÓRICO: MediaStore não confirmou a publicação do CSV.");}
            catch(Exception e){append("HISTÓRICO: falha ao publicar CSV — "+e.getClass().getSimpleName());}
        }
        historyUri=null; historyLegacyFile=null;
    }
    private void writePerformanceHistorySample(){
        if(historyWriter==null)return; try{String now=new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date()); int ethanol=getPerformanceEthanolPct(); historyWriter.write("TELEMETRIA;"+System.currentTimeMillis()+";"+now+";"+fmt(lastRpm)+";"+fmt(lastSpeed)+";"+fmt(lastGpsSpeed)+";"+(isGpsSpeedValid()?"GPS":"CAN")+";"+fmt(lastMap)+";"+fmt(lastBaro)+";"+fmt(lastBoost)+";"+fmt(maxBoost)+";"+fmt(lastThrottle)+";"+fmt(lastLoad)+";"+fmt(lastCoolant)+";"+fmt(lastIntake)+";"+fmt(lastOilTemp)+";"+lastOilLevel+";"+fmt(lastFuel)+";"+fmt(lastVolt)+";"+(lastVin==null?"":lastVin)+";"+(ethanol>=0?ethanol:"")+";;;;;;\n"); historyWriter.flush(); historySamples++;}catch(Exception e){append("HISTÓRICO: erro de gravação — "+e.getClass().getSimpleName());}
    }
    private void persistPerformancePull(int samples,ArrayList<PerfGraphSample> graphSamples){
        long ts=System.currentTimeMillis();String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss_SSS",Locale.US).format(new Date(ts));String name="VirtusELM_Pull_"+stamp+".csv";
        String header="tipo;timestamp_ms;hora;rpm;speed_kmh;gps_speed_kmh;speed_source;map_kpa;baro_kpa;boost_bar;boost_max_bar;throttle_pct;load_pct;coolant_c;intake_c;oil_temp_c;oil_level;fuel_pct;voltage_v;vin;ethanol_pct;power_est_cv;torque_est_nm;zero60_s;zero100_s;quality_pct;pull_duration_s;gear_shifts;pedal_d_pct;pedal_e_pct;pedal_f_pct;speed_grid;samples;elapsed_s\n";
        String now=new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date(ts));int ethanol=getPerformanceEthanolPct();String row="PERFORMANCE_TEST;"+ts+";"+now+";"+fmt(lastPerfMaxRpm>=0?lastPerfMaxRpm:lastRpm)+";"+fmt(lastPerfMaxSpeed>=0?lastPerfMaxSpeed:lastSpeed)+";"+fmt(lastGpsSpeed)+";"+(isGpsSpeedValid()?"GPS":"CAN")+";"+fmt(lastMap)+";"+fmt(lastBaro)+";"+fmt(lastBoost)+";"+fmt(lastPerfMaxBoost>=0?lastPerfMaxBoost:maxBoost)+";"+fmt(lastThrottle)+";"+fmt(lastLoad)+";"+fmt(lastCoolant)+";"+fmt(lastIntake)+";"+fmt(lastOilTemp)+";"+lastOilLevel+";"+fmt(lastFuel)+";"+fmt(lastVolt)+";"+(lastVin==null?"":lastVin)+";"+(ethanol>=0?ethanol:"")+";"+fmt(lastPerfPower)+";"+fmt(lastPerfTorque)+";"+fmt(lastPerf0060)+";"+fmt(lastPerf0100)+";"+fmt(lastPerfQuality)+";"+fmt(lastPerfPullDuration)+";"+lastPerfGearShifts+";"+fmt(lastPedalD)+";"+fmt(lastPedalE)+";"+fmt(lastPedalF)+";"+lastPerfSpeedGrid+";"+samples+";\n";
        try{
            if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,"text/csv");v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/VirtusELM/logs/");v.put(MediaStore.Downloads.IS_PENDING,1);Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new IOException("não foi possível criar arquivo de puxada");try(OutputStream os=getContentResolver().openOutputStream(u,"w")){if(os==null)throw new IOException("saída nula");StringBuilder csv=new StringBuilder(header).append(row); for(PerfGraphSample gs:graphSamples){csv.append("PERFORMANCE_SAMPLE;").append(ts).append(";").append(now).append(";").append(fmt(gs.rpm)).append(";").append(fmt(gs.speed)).append(";;GPS;").append(fmt(lastMap)).append(";").append(fmt(lastBaro)).append(";").append(fmt(gs.boost)).append(";").append(fmt(lastPerfMaxBoost)).append(";").append(fmt(gs.pedal)).append(";" ).append(fmt(lastLoad)).append(";").append(fmt(lastCoolant)).append(";").append(fmt(lastIntake)).append(";").append(fmt(lastOilTemp)).append(";").append(lastOilLevel).append(";").append(fmt(lastFuel)).append(";").append(fmt(lastVolt)).append(";").append(lastVin==null?"":lastVin).append(";").append(ethanol>=0?ethanol:"").append(";").append(fmt(lastPerfPower)).append(";").append(fmt(lastPerfTorque)).append(";").append(fmt(lastPerf0060)).append(";").append(fmt(lastPerf0100)).append(";").append(fmt(lastPerfQuality)).append(";").append(fmt(lastPerfPullDuration)).append(";").append(lastPerfGearShifts).append(";").append(fmt(lastPedalD)).append(";").append(fmt(lastPedalE)).append(";").append(fmt(lastPedalF)).append(";").append(lastPerfSpeedGrid).append(";").append(graphSamples.size()).append(";").append(String.format(Locale.US,"%.3f",gs.t)).append("\n");} os.write(csv.toString().getBytes(StandardCharsets.UTF_8));}ContentValues done=new ContentValues();done.put(MediaStore.Downloads.IS_PENDING,0);getContentResolver().update(u,done,null,null);
            }else{File dir=new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),"VirtusELM/logs");if(!dir.exists()&&!dir.mkdirs())throw new IOException("pasta não disponível");try(Writer w=new OutputStreamWriter(new FileOutputStream(new File(dir,name)),StandardCharsets.UTF_8)){w.write(header);w.write(row); for(PerfGraphSample gs:graphSamples){w.write("PERFORMANCE_SAMPLE;"+ts+";"+now+";"+fmt(gs.rpm)+";"+fmt(gs.speed)+";;GPS;"+fmt(lastMap)+";"+fmt(lastBaro)+";"+fmt(gs.boost)+";"+fmt(lastPerfMaxBoost)+";"+fmt(gs.pedal)+";"+fmt(lastLoad)+";"+fmt(lastCoolant)+";"+fmt(lastIntake)+";"+fmt(lastOilTemp)+";"+lastOilLevel+";"+fmt(lastFuel)+";"+fmt(lastVolt)+";"+(lastVin==null?"":lastVin)+";"+(ethanol>=0?ethanol:"")+";"+fmt(lastPerfPower)+";"+fmt(lastPerfTorque)+";"+fmt(lastPerf0060)+";"+fmt(lastPerf0100)+";"+fmt(lastPerfQuality)+";"+fmt(lastPerfPullDuration)+";"+lastPerfGearShifts+";"+fmt(lastPedalD)+";"+fmt(lastPedalE)+";"+fmt(lastPedalF)+";"+lastPerfSpeedGrid+";"+samples+";"+String.format(Locale.US,"%.3f",gs.t)+"\n");}}}
            append("PUXADA ARQUIVADA: "+name+" • "+samples+" amostras");ui(()->{if(historyScreen!=null)loadHistorySessions();});
        }catch(Exception e){append("ERRO AO ARQUIVAR PUXADA: "+e.getClass().getSimpleName());ui(()->toast("Não foi possível arquivar a puxada: "+e.getClass().getSimpleName()));}
    }
    private void writePerformanceEvent(){
        if(historyWriter==null)return; try{String now=new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date()); int ethanol=getPerformanceEthanolPct(); historyWriter.write("PERFORMANCE_TEST;"+System.currentTimeMillis()+";"+now+";"+fmt(lastPerfMaxRpm>=0?lastPerfMaxRpm:lastRpm)+";"+fmt(lastPerfMaxSpeed>=0?lastPerfMaxSpeed:lastSpeed)+";"+fmt(lastGpsSpeed)+";"+(isGpsSpeedValid()?"GPS":"CAN")+";"+fmt(lastMap)+";"+fmt(lastBaro)+";"+fmt(lastBoost)+";"+fmt(lastPerfMaxBoost>=0?lastPerfMaxBoost:maxBoost)+";"+fmt(lastThrottle)+";"+fmt(lastLoad)+";"+fmt(lastCoolant)+";"+fmt(lastIntake)+";"+fmt(lastOilTemp)+";"+lastOilLevel+";"+fmt(lastFuel)+";"+fmt(lastVolt)+";"+(lastVin==null?"":lastVin)+";"+(ethanol>=0?ethanol:"")+";"+fmt(lastPerfPower)+";"+fmt(lastPerfTorque)+";"+fmt(lastPerf0060)+";"+fmt(lastPerf0100)+";"+fmt(lastPerfQuality)+";"+fmt(lastPerfPullDuration)+";"+lastPerfGearShifts+";"+fmt(lastPedalD)+";"+fmt(lastPedalE)+";"+fmt(lastPedalF)+";"+lastPerfSpeedGrid+"\n"); historyWriter.flush();}catch(Exception e){append("HISTÓRICO: erro ao registrar teste de performance — "+e.getClass().getSimpleName());}
    }
    private boolean isHapticEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_HAPTIC,true); }
    private void applyKeepScreenPreference(){ if(isKeepScreenOnEnabled()) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); }

    @Override protected void onDestroy(){intentionalDisconnect=true;monitoring=false;stopRequested=true;if(recordingActive){recordingActive=false;closeRecordingWriter();stopRecordingKeepAlive();}closePerformanceHistory();stopGpsTracking();closeSocket();io.shutdownNow();dashboardExec.shutdownNow();super.onDestroy();}
}
