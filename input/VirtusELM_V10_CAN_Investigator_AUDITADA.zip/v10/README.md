# VIRTUS ELM — V10 CAN INVESTIGATOR

Base Android nativa para o projeto do Marcelo.

## Objetivos da V10
- estabilizar a sessão Bluetooth/RFCOMM e impedir que falhas de uma operação derrubem a interface;
- serializar comunicação OBD;
- tratar explicitamente socket fechado e leituras negativas;
- normalizar respostas do ELM;
- manter o diagnóstico OBD somente leitura;
- adicionar investigação passiva de CAN para correlação de eventos LOCK/UNLOCK;
- manter o visual dashboard escuro da V9.

## Investigador CAN
A função `INICIAR CAPTURA CAN PASSIVA` usa `AT MA` (Monitor All). Ela não envia comandos de LOCK/UNLOCK.

Fluxo recomendado:
1. Ignição ON.
2. Conectar ao ELM.
3. Iniciar captura.
4. Pressionar TRAVAR no controle original.
5. Tocar `MARCAR LOCK` imediatamente depois.
6. Aguardar 2–3 s.
7. Pressionar DESTRAVAR no controle original.
8. Tocar `MARCAR UNLOCK` imediatamente depois.
9. Parar captura.
10. Copiar o log para análise.

Os marcadores são apenas eventos locais do aplicativo. Nenhuma função de Security Access, Coding, Adaptation, Actuation, Clear DTC ou Lock/Unlock é implementada.

## Estabilidade
A comunicação usa uma fila de I/O única para comandos OBD e um leitor dedicado somente durante o monitoramento. Operações incompatíveis são bloqueadas enquanto a captura está ativa. Erros de comunicação são registrados e apresentados no aplicativo.

## Compilação
Use GitHub Actions com Java 17 e Gradle/Android Gradle Plugin conforme os arquivos do projeto.
