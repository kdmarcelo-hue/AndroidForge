plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.marcelo.virtuselm"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.marcelo.virtuselm"
        minSdk = 23
        targetSdk = 34
        versionCode = 10
        versionName = "10.0"
    }
}
