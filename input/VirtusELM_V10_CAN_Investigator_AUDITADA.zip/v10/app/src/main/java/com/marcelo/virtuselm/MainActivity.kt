package com.marcelo.virtuselm

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var protocol: TextView
    private lateinit var ecuCount: TextView
    private lateinit var frameCount: TextView
    private lateinit var idCount: TextView
    private lateinit var log: TextView
    private lateinit var connect: Button
    private lateinit var monitor: Button
    private lateinit var markLock: Button
    private lateinit var markUnlock: Button
    private lateinit var stop: Button
    private lateinit var quick: Button
    private lateinit var copy: Button
    private lateinit var clear: Button

    private val io: ExecutorService = Executors.newSingleThreadExecutor()
    private val monitorExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var monitorTask: Future<*>? = null
    private val monitoring = AtomicBoolean(false)
    private val commLock = Any()
    private var seq = 0
    private var frameTotal = 0
    private val ids = linkedMapOf<String, Int>()
    private val eventMarkers = mutableListOf<EventMarker>()

    data class EventMarker(val type: String, val seq: Int, val uptimeMs: Long)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        restoreCrashNotice()
        installSafeExceptionHandler()
        append("V10.0 — CAN INVESTIGATOR")
        append("SOMENTE LEITURA • NENHUM LOCK/UNLOCK É TRANSMITIDO")
        setStatus("DESCONECTADO")
        setButtons(false, false)
        connect.setOnClickListener { safeLaunch { connectElm() } }
        monitor.setOnClickListener { safeLaunch { startPassiveMonitor() } }
        markLock.setOnClickListener { safeLaunch { markEvent("LOCK") } }
        markUnlock.setOnClickListener { safeLaunch { markEvent("UNLOCK") } }
        stop.setOnClickListener { safeLaunch { stopPassiveMonitor() } }
        quick.setOnClickListener { safeLaunch { obdQuickReadOnly() } }
        copy.setOnClickListener { copyLog() }
        clear.setOnClickListener { clearLog() }
        requestBtPermissions()
    }

    private fun bindViews() {
        status = findViewById(R.id.txtStatus)
        protocol = findViewById(R.id.txtProtocol)
        ecuCount = findViewById(R.id.txtEcus)
        frameCount = findViewById(R.id.txtFrames)
        idCount = findViewById(R.id.txtIds)
        log = findViewById(R.id.txtLog)
        connect = findViewById(R.id.btnConnect)
        monitor = findViewById(R.id.btnMonitor)
        markLock = findViewById(R.id.btnMarkLock)
        markUnlock = findViewById(R.id.btnMarkUnlock)
        stop = findViewById(R.id.btnStop)
        quick = findViewById(R.id.btnQuick)
        copy = findViewById(R.id.btnCopy)
        clear = findViewById(R.id.btnClear)
    }

    private fun requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN), 10)
        }
    }

    private fun connectElm() {
        io.execute {
            try {
                if (socket?.isConnected == true && input != null && output != null) {
                    ui { setStatus("ELM JÁ CONECTADO") }
                    return@execute
                }
                closeSession()
                val adapter = BluetoothAdapter.getDefaultAdapter() ?: throw IOException("Bluetooth indisponível")
                if (!adapter.isEnabled) throw IOException("Bluetooth desligado")
                val devices = adapter.bondedDevices ?: emptySet()
                val dev = devices.firstOrNull { d ->
                    val n = d.name?.uppercase(Locale.US) ?: ""
                    n.contains("ELM") || n.contains("OBD") || n.contains("V-LINK") || n.contains("OBDLINK")
                } ?: throw IOException("ELM/OBD não encontrado entre dispositivos conhecidos")
                ui { setStatus("CONECTANDO: ${dev.name ?: dev.address}") }
                val s = dev.createRfcommSocketToServiceRecord(spp)
                s.connect()
                socket = s
                input = s.inputStream
                output = s.outputStream
                synchronized(commLock) {
                    sendAndReadInternal("ATZ", 1800)
                    sendAndReadInternal("ATE0", 600)
                    sendAndReadInternal("ATL0", 600)
                    sendAndReadInternal("ATS1", 600)
                    sendAndReadInternal("ATH1", 600)
                    sendAndReadInternal("ATAT1", 600)
                    sendAndReadInternal("ATI", 800)
                    val dp = sendAndReadInternal("ATDP", 800)
                    sendAndReadInternal("ATSP0", 1200)
                    ui { protocol.text = "PROTOCOLO  $dp" }
                }
                ui {
                    setStatus("CONECTADO • ELM PRONTO")
                    setButtons(true, false)
                }
                append("ELM conectado e sessão inicializada sem comandos de atuação.")
            } catch (t: Throwable) {
                closeSession()
                append("ERRO CONEXÃO: ${t::class.java.simpleName}: ${t.message ?: "sem mensagem"}")
                ui {
                    setStatus("ERRO DE CONEXÃO")
                    setButtons(false, false)
                }
            }
        }
    }

    private fun startPassiveMonitor() {
        io.execute {
            try {
                if (!isConnected()) throw IOException("ELM não conectado")
                if (monitoring.get()) {
                    ui { setStatus("CAPTURA JÁ ATIVA") }
                    return@execute
                }
                resetCaptureStats()
                append("\n=== CAPTURA CAN PASSIVA — LOCK / UNLOCK ===")
                append("Use o controle original: TRAVAR → aguarde → DESTRAVAR.")
                append("Os botões MARCAR LOCK/UNLOCK apenas criam marcadores no log.")
                append("Nenhum comando de trava, destrava, security access, coding ou actuation é transmitido.")
                synchronized(commLock) {
                    // Reset receive address/filter state before Monitor All.
                    sendAndReadInternal("AT AR", 600)
                    sendAndReadInternal("AT CAF1", 600)
                    sendAndReadInternal("ATH1", 600)
                    sendAndReadInternal("ATS1", 600)
                    sendAndReadInternal("ATL0", 600)
                    writeRawInternal("AT MA\r")
                }
                monitoring.set(true)
                ui { setStatus("CAPTURA ATIVA • AGUARDANDO EVENTOS") }
                ui { setButtons(true, true) }
                monitorTask = monitorExecutor.submit { monitorLoop() }
            } catch (t: Throwable) {
                monitoring.set(false)
                append("FALHA AO INICIAR CAPTURA: ${t::class.java.simpleName}: ${t.message}")
                ui { setStatus("ERRO NO MONITOR") }
            }
        }
    }

    private fun monitorLoop() {
        val localInput = input ?: return
        val buf = ByteArray(1024)
        val sb = StringBuilder()
        try {
            while (monitoring.get() && !Thread.currentThread().isInterrupted) {
                val n = localInput.read(buf)
                if (n < 0) throw IOException("socket fechado durante captura")
                if (n == 0) continue
                sb.append(String(buf, 0, n, Charsets.US_ASCII))
                while (true) {
                    val r = sb.indexOf("\r")
                    val nline = sb.indexOf("\n")
                    val cut = when {
                        r >= 0 && nline >= 0 -> minOf(r, nline)
                        r >= 0 -> r
                        nline >= 0 -> nline
                        else -> -1
                    }
                    if (cut < 0) break
                    val line = sb.substring(0, cut).trim()
                    var delete = cut + 1
                    while (delete < sb.length && (sb[delete] == '\r' || sb[delete] == '\n')) delete++
                    sb.delete(0, delete)
                    if (line.isEmpty() || line == ">" || line.equals("STOPPED", true)) continue
                    consumeMonitorLine(line)
                }
            }
        } catch (t: Throwable) {
            if (monitoring.get()) {
                monitoring.set(false)
                append("CAPTURA ENCERRADA: ${t::class.java.simpleName}: ${t.message}")
                ui { setStatus("CAPTURA INTERROMPIDA • VER LOG") }
                ui { setButtons(isConnected(), false) }
            }
        }
    }

    private fun consumeMonitorLine(line: String) {
        val cleaned = line.replace("\u0000", " ").trim()
        val tokens = cleaned.split(Regex("\\s+"))
        val id = tokens.firstOrNull()?.uppercase(Locale.US)
        val looksLikeCan = id != null && id.matches(Regex("[0-9A-F]{3,8}")) && tokens.size > 1
        seq++
        append(String.format(Locale.US, "[%05d] RX %s", seq, cleaned))
        if (looksLikeCan) {
            frameTotal++
            ids[id!!] = (ids[id] ?: 0) + 1
            updateCounters()
        }
    }

    private fun markEvent(type: String) {
        if (!monitoring.get()) {
            append("MARCADOR $type ignorado: captura não está ativa.")
            return
        }
        val marker = EventMarker(type, seq, android.os.SystemClock.elapsedRealtime())
        eventMarkers += marker
        append("\n>>> MARCADOR $type • frame #${marker.seq} <<<")
        append("Pressione o controle original imediatamente antes/depois deste marcador para facilitar a correlação.")
        if (eventMarkers.size >= 2) summarizeMarkers()
    }

    private fun summarizeMarkers() {
        val last = eventMarkers.takeLast(2)
        if (last.size < 2) return
        val a = last[0]
        val b = last[1]
        append("CORRELAÇÃO TEMPORAL: ${a.type} → ${b.type} (${b.uptimeMs - a.uptimeMs} ms)")
        append("IDs observados até aqui: ${ids.size} • frames CAN: $frameTotal")
        append("Análise detalhada será feita sobre o log bruto, preservando todos os frames.")
    }

    private fun stopPassiveMonitor() {
        io.execute {
            try {
                if (!monitoring.get() && monitorTask == null) {
                    ui { setStatus("CAPTURA JÁ PARADA") }
                    return@execute
                }
                monitoring.set(false)
                synchronized(commLock) {
                    // Any character interrupts AT MA; wait briefly for ELM prompt.
                    writeRawInternal("\r")
                }
                monitorTask?.cancel(true)
                monitorTask = null
                append("=== FIM DA CAPTURA PASSIVA ===")
                append("FRAMES CAN: $frameTotal • IDs CAN: ${ids.size} • MARCADORES: ${eventMarkers.size}")
                if (ids.isNotEmpty()) append("TOP IDs: ${ids.entries.sortedByDescending { it.value }.take(12).joinToString { "${it.key}=${it.value}" }}")
                ui { setStatus("CAPTURA PARADA • LOG PRONTO") }
                ui { setButtons(isConnected(), false) }
            } catch (t: Throwable) {
                append("ERRO AO PARAR CAPTURA: ${t::class.java.simpleName}: ${t.message}")
                ui { setStatus("ERRO AO PARAR CAPTURA") }
            }
        }
    }

    private fun obdQuickReadOnly() {
        io.execute {
            try {
                if (!isConnected()) throw IOException("ELM não conectado")
                if (monitoring.get()) throw IOException("pare a captura CAN antes do diagnóstico OBD")
                append("\n=== OBD RÁPIDO — SOMENTE LEITURA ===")
                listOf("0100", "010C", "010D", "0105", "03", "0902").forEach { cmd ->
                    synchronized(commLock) { sendAndReadInternal(cmd, 1800) }
                }
                ui { setStatus("DIAGNÓSTICO OBD CONCLUÍDO") }
            } catch (t: Throwable) {
                append("ERRO OBD: ${t::class.java.simpleName}: ${t.message}")
                ui { setStatus("ERRO OBD • APP MANTIDO ABERTO") }
            }
        }
    }

    private fun sendAndReadInternal(cmd: String, timeoutMs: Long): String {
        writeRawInternal("$cmd\r")
        val ins = input ?: throw IOException("input ausente")
        val start = System.currentTimeMillis()
        val b = ByteArray(512)
        val out = StringBuilder()
        while (System.currentTimeMillis() - start < timeoutMs) {
            if (ins.available() > 0) {
                val n = ins.read(b)
                if (n < 0) throw IOException("socket fechado")
                if (n > 0) out.append(String(b, 0, n, Charsets.US_ASCII))
                if (out.contains(">")) break
            } else Thread.sleep(20)
        }
        val rx = normalize(out.toString())
        append("TX $cmd")
        append("RX ${if (rx.isEmpty()) "<SEM RESPOSTA>" else rx}")
        return rx
    }

    private fun writeRawInternal(s: String) {
        val o = output ?: throw IOException("ELM não conectado")
        o.write(s.toByteArray(Charsets.US_ASCII))
        o.flush()
    }

    private fun normalize(s: String): String =
        s.replace("\r\n", "\n").replace('\r', '\n').replace(Regex("\\n+"), "\n").replace(">", "").trim()

    private fun isConnected(): Boolean = socket?.isConnected == true && input != null && output != null

    private fun closeSession() {
        monitoring.set(false)
        try { monitorTask?.cancel(true) } catch (_: Throwable) {}
        monitorTask = null
        try { input?.close() } catch (_: Throwable) {}
        try { output?.close() } catch (_: Throwable) {}
        try { socket?.close() } catch (_: Throwable) {}
        input = null
        output = null
        socket = null
    }

    private fun resetCaptureStats() {
        seq = 0
        frameTotal = 0
        ids.clear()
        eventMarkers.clear()
        ui {
            frameCount.text = "FRAMES  0"
            idCount.text = "IDs CAN  0"
        }
    }

    private fun setButtons(connected: Boolean, active: Boolean) {
        connect.isEnabled = !active
        monitor.isEnabled = connected && !active
        markLock.isEnabled = active
        markUnlock.isEnabled = active
        stop.isEnabled = active
        quick.isEnabled = connected && !active
    }

    private fun updateCounters() {
        ui {
            frameCount.text = "FRAMES  $frameTotal"
            idCount.text = "IDs CAN  ${ids.size}"
        }
    }

    private fun setStatus(value: String) { status.text = value }

    private fun ui(block: () -> Unit) { main.post { runCatching(block) } }

    private fun append(s: String) { main.post { log.append(s + "\n") } }

    private fun copyLog() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("VIRTUS ELM V10 LOG", log.text.toString()))
        setStatus("LOG COPIADO")
    }

    private fun clearLog() {
        log.text = "V10.0 — LOG LIMPO\n"
        resetCaptureStats()
        setStatus(if (isConnected()) "CONECTADO" else "DESCONECTADO")
    }

    private fun safeLaunch(action: () -> Unit) {
        try { action() } catch (t: Throwable) {
            append("ERRO UI: ${t::class.java.simpleName}: ${t.message}")
            setStatus("ERRO CONTROLADO • APP MANTIDO ABERTO")
        }
    }

    private fun installSafeExceptionHandler() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            getPreferences(MODE_PRIVATE).edit()
                .putString("last_crash", "${thread.name}: ${error::class.java.name}: ${error.message}")
                .apply()
            previous?.uncaughtException(thread, error)
        }
    }

    private fun restoreCrashNotice() {
        val p = getPreferences(MODE_PRIVATE)
        val last = p.getString("last_crash", null)
        if (!last.isNullOrBlank()) {
            append("ÚLTIMO ENCERRAMENTO INESPERADO REGISTRADO:")
            append(last)
            p.edit().remove("last_crash").apply()
        }
    }

    override fun onDestroy() {
        closeSession()
        io.shutdownNow()
        monitorExecutor.shutdownNow()
        super.onDestroy()
    }
}
