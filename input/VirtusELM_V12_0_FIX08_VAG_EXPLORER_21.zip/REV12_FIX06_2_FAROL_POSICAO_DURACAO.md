# V12.0-FIX06.2 — AJUSTE DA PISCADA DO FAROL

Base: V12.0-FIX06.1 aprovado pelo usuário.

Alteração isolada solicitada:
- reposicionamento do efeito visual para os centros ópticos dos faróis da arte `v11_car_header_clean.png`;
- redução do tamanho das áreas luminosas para evitar brilho sobre capô/parabrisa;
- duração aumentada de aproximadamente 230 ms para 520 ms;
- subida suave de 90 ms, permanência de 210 ms e retorno em 220 ms;
- limpeza interna segura de cache permanece exatamente igual;
- nenhuma alteração em OBD, CAN, DTC, VAG Explorer, Performance, Histórico ou navegação.

Auditoria estrutural antes do build:
- chaves: 691/691
- parênteses: 5080/5080
- build local Android não executado; GitHub Actions permanece como validação final.
