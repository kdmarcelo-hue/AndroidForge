# V12.0-FIX05 — Histórico + Performance 2.0 + VAG Explorer 2.0 + DTC 2.0

## Base
V12.0-FIX04.1 — Build Fix.

## Implementações
- Histórico de sessões persistentes a partir dos CSV em `Download/VirtusELM/logs/`.
- Lista de até 30 sessões, resumo de amostras e testes de performance.
- Performance 2.0: RPM máximo, velocidade máxima, duração e contador de sessões, preservando 0–100, potência, torque e boost.
- VAG Diagnostic Explorer 2.0: protocolo, PIDs, status OBD, RPM, velocidade, throttle, tensão, DTC, VIN e respostas/IDs observados. Endereços VAG específicos não são declarados como detectados sem teste real.
- DTC 2.0: toque no código abre detalhes; descrição local somente para códigos conhecidos; nenhum diagnóstico inventado.
- Seleção/apagamento seletivo de DTC continua preservado; no veículo real não é enviado comando seletivo porque OBD-II padrão Mode 04 limpa todos.

## Segurança
Somente leitura para Explorer. Sem coding, adaptation, Security Access, escrita de módulo ou CAN arbitrário.

## Preservado
Simulação automática, gravação, CSV, configurações, navegação, gráficos, CAN bloqueado em simulação e demais funções do FIX04.1.

## Próxima ideia
V12.0-FIX06 poderá estudar efeito visual de “pisca de farol alto” no carro da interface, sem alterar aquisição/diagnóstico.


FIX05.2 — BUILD FIX: correção isolada da referência MUTED na rotina de Histórico de Sessões, sem alteração funcional nas demais áreas.
