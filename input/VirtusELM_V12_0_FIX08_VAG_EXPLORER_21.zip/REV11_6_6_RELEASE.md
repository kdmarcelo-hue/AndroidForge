# VIRTUS ELM — V11.6.6

## Objetivo
Segunda melhoria incremental após a V11.6.5 funcional, preservando a base estável e evitando alterações no CAN Investigator.

## Alterações
- versionCode 122 / versionName 11.6.6.
- Performance: adicionado campo **ETANOL NO TESTE** com entrada manual de 0 a 100%.
- O percentual informado é persistido localmente e reaparece na tela Performance.
- O resultado do teste 0–100 passa a identificar o teor de etanol informado manualmente.
- O aplicativo deixa explícito que o percentual não é inferido pela ECU.
- Botão para limpar o percentual informado.
- Cabeçalho e log de sessão atualizados para V11.6.6.

## Não alterado
- CAN Investigator 2.0 permanece intacto nesta versão.
- Monitor All / AT MA permanece intacto.
- Lógica do teste 0–100 permanece intacta.
- Telemetria, diagnóstico, gravação, dashboard e feedback tátil permanecem preservados.
- Arquitetura somente leitura preservada.

## Rastreamento
- Bloco V11.6.6: `PREF_PERF_ETHANOL`, `getPerformanceEthanolPct()`, `getPerformanceEthanolLabel()` e `showEthanolDialog()`.
- Alteração isolada para facilitar regressão e diagnóstico.
