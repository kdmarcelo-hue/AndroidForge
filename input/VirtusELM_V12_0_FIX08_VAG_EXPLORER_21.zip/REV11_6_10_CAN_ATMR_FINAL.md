# REV11_6_10 — TESTE FINAL CAN ATMR 07

## Objetivo
Teste final do modo Monitor Receiver do ELM327, isolando o comando MR/ATMR.

## Comando
- CAN 11/500: `ATSP6`
- Preparação: `ATE0`, `ATH1`, `ATS1`, `ATL0`, `ATAL`, `ATD1`, `ATCAF0`, `ATAT0`
- Monitor: `ATMR 07` por 10 s
- Interrupção: um único CR após 10 s
- Restauração: `ATCRA`

## Observação técnica
`ATMR` não recebe um CAN ID completo de 11 bits. No CAN 11-bit, o comando MR filtra os bits 8..10 do ID. Para `7E8`, esses bits são `111b`, portanto o teste usa `ATMR 07`. Isso cobre a faixa 0x700–0x7FF e é deliberadamente amplo.

## Segurança
Somente leitura/monitoramento. Nenhuma transmissão CAN arbitrária.

## Escopo
Somente o bloco CAN foi alterado. Demais funcionalidades e identidade visual preservadas.
