# VIRTUS ELM — V11.6.7

## Objetivo
CAN LAB / CAN Investigator 2.1 para diagnosticar de forma isolada a captura passiva do ELM327, sem alterar as demais funções.

## Base técnica
- Sequência de preparação inspirada em implementações abertas de sniffing ELM327: ATCAF0, ATAL, ATD1 e Monitor All.
- Três estratégias passivas: ATMA; ATMR 7E8; ATCRA 7E8 + ATMA.
- 7E8 foi escolhido como filtro de investigação porque já apareceu nas respostas CAN/OBD reais do Virtus nos logs anteriores.

## Alterações
- versionCode 123 / versionName 11.6.7.
- CAN Investigator passa a exibir CAN LAB / Investigator 2.1.
- Preparação CAN inclui ATDP/ATDPN, ATSP6/7, ATE0, ATH1, ATS1, ATL0, ATAL, ATD1, ATCAF0 e ATAT0.
- Resposta de cada comando é registrada no log.
- Se ATCAF0 não for confirmado, o aplicativo tenta ATCAF1 para compatibilidade.
- Tentativa A: ATMA.
- Tentativa B: ATMR 7E8.
- Tentativa C: ATCRA 7E8 + ATMA.
- Nenhuma dessas rotinas transmite frame CAN arbitrário; os filtros são somente de recepção.
- Parser continua aceitando formatos comuns/compactos de Monitor All.

## Não alterado
- Dashboard, telemetria, gravação, Performance/0–100, etanol manual, gráficos, diagnóstico OBD, configuração e feedback tátil.
- Arquitetura somente leitura.

## Critério de campo
O objetivo da versão é produzir evidência: primeiro frame CAN RAW real, ou registro claro de que as três estratégias foram rejeitadas/retornaram zero.
