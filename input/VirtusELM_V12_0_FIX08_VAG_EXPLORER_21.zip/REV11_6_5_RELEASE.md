# VIRTUS ELM — V11.6.5

## Objetivo
Primeira melhoria isolada após a V11.6.4 funcional.

## Alterações
- versionCode 121 / versionName 11.6.5.
- Configurações: adicionada opção **FEEDBACK TÁTIL** (ON/OFF).
- O feedback háptico dos controles passa a respeitar a preferência salva.
- O controle **MANTER TELA LIGADA** permanece preservado.
- Preferência padrão: feedback tátil ligado, preservando o comportamento anterior.
- Nenhuma alteração no CAN Investigator, Performance, telemetria, diagnóstico ou layout do dashboard.

## Rastreamento de alteração
- Bloco V11.6.5: preferência `PREF_HAPTIC`, `bindClick()` e nova linha de configuração.
- Alteração deliberadamente isolada para facilitar diagnóstico/regressão.

## Segurança
- Somente leitura preservada.
- Nenhum comando de atuação, coding, adaptation, Security Access ou transmissão CAN arbitrária foi adicionado.
