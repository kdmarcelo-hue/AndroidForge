# V11.6.11 FIX 02 — MENU INFERIOR COM ESTADO ATIVO

## Alteração
- Menu inferior agora mantém em azul somente o item correspondente à janela/módulo ativo.
- Ícone e texto do item selecionado recebem o azul ativo.
- Os demais itens retornam ao azul-claro inativo.
- Início, Dados, Diagnóstico, CAN e Config passam a refletir a tela selecionada.
- Gráficos é associado a Dados; Performance é associado a Início, pois são telas internas desses módulos.

## Preservado
- Posição, altura, largura e espaçamento do menu.
- Ícones, textos e dimensões.
- Funcionalidades OBD, CAN, aquisição, logging e navegação.
- Ajustes visuais da V11.6.11 anterior.

## Build
- Mantido versionName 11.6.11 / versionCode 127.
- Corrigido também o nome do artefato do GitHub Actions para `VirtusELM-V11.6.11-debug`.
