# V12.0-FIX04 — VAG Diagnostic Explorer + DTC seletivo

## Base
- V12.0-FIX03 validado pelo usuário.
- versionCode: 136
- versionName: 12.0-FIX04

## Implementações
### VAG Diagnostic Explorer
- Novo acesso em Diagnóstico.
- Leitura somente de protocolo/identificação, PIDs suportados, DTC e VIN.
- Identifica CAN IDs que apareçam explicitamente nas respostas OBD recebidas.
- Mantém RAW das respostas.
- Não executa coding, adaptation, Security Access, escrita de módulo ou transmissão CAN arbitrária.
- Em simulação, usa respostas simuladas claramente identificadas.

### DTC
- Quadro de falhas mantém scroll interno.
- Cada DTC reconhecido aparece individualmente.
- Modo `SELECIONAR DTCs` cria seleção linha a linha.
- Em simulação, DTCs selecionados podem ser removidos individualmente sem enviar nada ao veículo.
- `APAGAR TODOS` mantém limpeza total.
- No veículo real, `APAGAR TODOS` usa OBD-II Mode 04 após confirmação.
- Limpeza individual de DTC não é feita via OBD-II padrão: Mode 04 limpa todos. Para apagar individualmente no veículo real será necessário um procedimento VAG específico validado, que fica reservado para uma etapa posterior do VAG Explorer.

## Preservado
- Modo simulação automático.
- Gravação de telemetria.
- Histórico persistente.
- Configurações.
- Gráficos.
- Performance.
- CAN Investigator.
- Navegação e identidade visual.
