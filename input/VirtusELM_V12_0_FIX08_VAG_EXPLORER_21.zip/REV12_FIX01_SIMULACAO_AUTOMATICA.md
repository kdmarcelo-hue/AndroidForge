# V12 FIX 01 — SIMULAÇÃO AUTOMÁTICA / 3 TENTATIVAS

- Entra em MODO SIMULAÇÃO imediatamente na abertura.
- Inicia tentativa automática de conexão com ELM em paralelo.
- Realiza até 3 tentativas.
- Se o ELM conectar, abandona a simulação e assume MODO VEÍCULO.
- Se Bluetooth estiver desligado, permanece em simulação sem exigir desligar/ligar o Bluetooth manualmente.
- Se nenhuma conexão ocorrer após 3 tentativas, permanece em MODO SIMULAÇÃO.
- Botão manual de conexão permanece disponível.
- Desconexão manual cancela a sequência automática.
- CAN continua bloqueado no modo simulação.
- Nenhum comando de atuação, coding, adaptation ou Security Access foi adicionado.
