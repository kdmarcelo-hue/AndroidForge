# V11.6.8 — CAN LAB / TESTE ATMA ISOLADO

- Incrementa versionCode para 124 e versionName para 11.6.8.
- Mantém toda a aplicação existente e o modo somente leitura.
- Isola o primeiro teste do CAN LAB em `ATMA` (Monitor All).
- Mantém uma janela controlada de 10 segundos.
- Se o ELM não sair sozinho, envia um único CR para interromper o Monitor All.
- Remove, nesta revisão, a execução automática de `ATMR 7E8` e `ATCRA 7E8 + ATMA`; esses testes ficam para uma revisão posterior caso o ATMA isolado não entregue frames.
- Preserva contagem RAW/FRAMES/IDs/BYTES e o log técnico para diagnóstico.
