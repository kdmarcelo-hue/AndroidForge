# V11.6.12 — DADOS ORGANIZADOS

- versionCode 128 / versionName 11.6.12.
- Organização visual da tela DADOS em grupos: MOTOR, PRESSÃO, TEMPERATURA e ELÉTRICO/COMBUSTÍVEL.
- Painel de telemetria ao vivo usa exclusivamente os valores já adquiridos pela aplicação.
- Nenhuma mudança nos comandos OBD/CAN, aquisição, gravação, gráficos, performance ou navegação.
- Corrigidas identificações antigas V11.0 no Manifest/strings e cabeçalho para V11.6.12.
- Artefato GitHub Actions: VirtusELM-V11.6.12-debug.
