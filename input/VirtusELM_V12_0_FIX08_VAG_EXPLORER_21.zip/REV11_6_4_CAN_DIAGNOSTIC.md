# VirtusELM V11.6.4

CAN Investigator diagnostic instrumentation only.

- Visible CAN engine state: ELM, protocol, command, RX, state.
- Logs ATDP/ATSP and Monitor All startup responses.
- Detects and reports immediate ELM prompt rejection of `AT MA`.
- Reports first raw Monitor All payload received.
- No CAN actuation, coding, adaptation, Security Access or arbitrary CAN transmission added.
- Existing CAN Investigator 2.0 capture/ranking/filter/differential functions preserved.
- versionCode 120 / versionName 11.6.4.
