# V11.6.12 FIX 02.1 — MODO SIMULAÇÃO — BUILD FIX

Correção isolada do FIX 02 Simulation.

## Correção
- Removida a referência a `CYAN` fora do escopo de `buildUi()` nas três rotinas do modo simulação.
- Criada constante de classe `SIM_CYAN` para o status visual do modo simulação.

## Preservado
- Modo veículo real.
- Modo simulação automático sem ELM.
- Histórico persistente como fonte da simulação.
- DTC real/simulado pelo mesmo fluxo.
- CAN bloqueado em simulação.
- V11.6.12 FIX 01: log, histórico, configurações e demais telas.

## Validação
- Correção estática aplicada nos três pontos apontados pelo javac.
- ZIP será usado como entrada do GitHub Actions; o APK final somente é considerado aprovado após Debug/Release passarem.
