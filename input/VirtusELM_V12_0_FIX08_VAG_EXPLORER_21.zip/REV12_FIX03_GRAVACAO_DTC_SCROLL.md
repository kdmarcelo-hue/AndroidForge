# V12.0-FIX03 — GRAVAÇÃO + DTC

## Correções

1. **Gravação em MODO SIMULAÇÃO**
   - Não inicia mais o `RecordingKeepAliveService` foreground `connectedDevice` quando o app está em simulação.
   - A gravação simulada continua usando o mesmo CSV e a mesma rotina de amostragem.
   - Evita a queda do aplicativo causada pela política do Android para foreground service de dispositivo conectado sem dispositivo Bluetooth real.

2. **Quadro de falhas DTC**
   - A lista de códigos agora fica dentro de um `ScrollView` interno com altura fixa.
   - Muitos DTCs podem ser rolados dentro do quadro sem aumentar indefinidamente o cartão.
   - O restante da tela de Diagnóstico permanece com o mesmo layout.

## Preservado
- V12.0-FIX02 como base.
- Simulação automática.
- Conexão automática.
- Unidades bar/kPa e km/h/mph.
- Telemetria, gráficos, histórico, DTC, CAN e demais funções.
