# CONFIGURAÇÃO DE ASSINATURA — V12

A V12 foi preparada para assinatura permanente no GitHub Actions.

## Secrets do repositório
Em GitHub → Settings → Secrets and variables → Actions, criar estes Repository secrets:

1. `V12_KEYSTORE_BASE64`
   - conteúdo do arquivo `V12_release.keystore.b64`
2. `V12_KEYSTORE_PASSWORD`
   - senha do keystore
3. `V12_KEY_ALIAS`
   - `virtuselm-v12`
4. `V12_KEY_PASSWORD`
   - senha da chave

## Regra crítica
Nunca fazer commit de `V12_release.keystore` ou de sua senha no repositório.

A chave gerada para esta preparação fica fora do ZIP de código. Sem os quatro secrets, o workflow falha propositalmente em vez de gerar um APK que não poderá atualizar a V12 depois.
