# V12 FIX 02 — CONFIGURAÇÕES AVANÇADAS

- Simulação automática: ON por padrão.
- Conexão automática ELM: ON por padrão.
- Unidade de pressão: bar por padrão, com opção kPa.
- Unidade de velocidade: km/h por padrão, com opção mph.
- Restaurar configurações padrão.
- Preservados: manter tela ligada, feedback tátil, dados em tempo real, log técnico e histórico de performance.
- Não foram adicionados comandos de atuação, coding, adaptation, Security Access ou CAN arbitrário.
- CAN continua indisponível em simulação.
