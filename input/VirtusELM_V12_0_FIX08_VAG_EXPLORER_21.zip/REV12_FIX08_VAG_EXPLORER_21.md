# V12.0 FIX08 — VAG Diagnostic Explorer 2.1

## Objetivo
Corrigir a distinção entre veículo/ELM real e simulação no VAG Diagnostic Explorer e impedir que CAN IDs sejam apresentados como evidência quando vierem apenas do modo simulado.

## Ajustes
- VAG Diagnostic Explorer atualizado de 2.0 para 2.1.
- Modo explicitamente identificado como `VEÍCULO / ELM REAL`, `SIMULAÇÃO` ou `SEM ELM REAL`.
- `TRANSPORTE REAL` e `EVIDÊNCIA OBD` exibidos separadamente.
- CAN IDs somente são listados quando encontrados no retorno textual real da consulta.
- IDs 7E8/7E9 não são mais fabricados no parser durante simulação.
- Módulos 03 ABS, 17 Instruments e 19 CAN Gateway passam a ser classificados como `NÃO IDENTIFICADO` quando não houver evidência de resposta específica.
- Nenhum endereço específico VAG, coding, adaptation, Security Access, atuação ou escrita foi adicionado.
- VersionCode: 148.
- VersionName: 12.0-FIX08.

## Escopo
Somente leitura. Esta versão prepara a separação entre respostas OBD observadas e futura descoberta VAG baseada em evidência.
