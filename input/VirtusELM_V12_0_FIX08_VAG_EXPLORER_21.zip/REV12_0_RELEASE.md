# V12.0 — CONSOLIDAÇÃO DIAGNÓSTICA E GRÁFICOS TÉCNICOS

## Base
Derivada diretamente da V11.6.12 FIX 02.1 (simulação integrada), preservando Bluetooth/ELM, telemetria, histórico, Performance, CAN read-only e navegação.

## Implementado
- Quadro visual de falhas DTC na tela Diagnóstico.
- Leitura Mode 03 continua usando o parser existente.
- Botão APAGAR FALHAS / LIMPAR DTC incluído como preparação visual; não transmite comando de limpeza nesta versão.
- Gráficos com grade e escala vertical fixa por parâmetro.
- BOOST: 0–3,0 bar.
- THROTTLE: 0–100 %.
- RPM: 0–8000 rpm.
- VELOCIDADE: 0–200 km/h.
- Botões de gráfico com estado selecionado persistente por cor.
- Abas TELEMETRIA/GRÁFICOS/LOGS com estado visual.
- Menu inferior continua indicando a tela atual.
- Modo simulação preservado.

## Segurança funcional
Nenhum comando de atuação, coding, adaptation, Security Access ou limpeza DTC foi adicionado. CAN permanece bloqueado em simulação.

## Auditoria estática realizada
- versionCode 132 / versionName 12.0.
- Application label atualizado para V12.
- MainActivity com chaves balanceadas.
- Verificação de duplicidade de nomes de métodos.
- Verificação textual das novas funções e preservação de simulateResponse/parseDtcCodes.
- ZIP será entregue para validação pelo GitHub Actions; o ambiente desta sessão não possui o executável Gradle para uma compilação local.
