# VirtusELM V11.6.2

Patch visual/controlado sobre V11.6.1 funcional.

- Ajuste do card de combustível na tela Performance para impedir corte de texto.
- Texto de combustível reorganizado em duas linhas.
- Altura interna do card ampliada apenas para acomodar o conteúdo.
- Nenhuma alteração em CAN, OBD, telemetria, Performance 0–100, cálculo de potência/torque ou aquisição.
- versionCode 118 / versionName 11.6.2.
