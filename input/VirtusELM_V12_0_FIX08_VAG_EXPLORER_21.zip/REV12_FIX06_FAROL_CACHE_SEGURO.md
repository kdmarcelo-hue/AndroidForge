# VIRTUS ELM V12.0-FIX06 — PISCADA DO FAROL + LIMPEZA INTERNA SEGURA

## Base
- Base direta: V12.0-FIX05.3 aprovada pelo usuário.
- versionCode: 141
- versionName: 12.0-FIX06
- Nome do aplicativo preservado: VIRTUS ELM — DIAGNÓSTICO V12.

## Alteração isolada
Ao tocar na imagem do Virtus no cabeçalho:
1. executa uma piscada visual curta nos dois faróis, posicionada sobre a arte real do veículo;
2. inicia limpeza somente do cache temporário privado do próprio aplicativo (`cacheDir` e `externalCacheDir`);
3. não apaga SharedPreferences, histórico CSV, dados persistentes, configurações, logs persistentes ou banco de dados.

## Segurança
- Nenhum comando Bluetooth/OBD/CAN é enviado pelo toque.
- Nenhuma função do veículo é acionada.
- A ação é exclusivamente visual + limpeza interna de cache temporário.
- A imagem, tamanho e posição do carro no cabeçalho são preservados.

## Observação de build
Não foi executado build Android local neste ambiente. A validação final continua sendo pelo GitHub Actions.
