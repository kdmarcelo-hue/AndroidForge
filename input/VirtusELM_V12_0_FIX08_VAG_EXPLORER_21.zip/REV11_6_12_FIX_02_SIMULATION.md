# REV11.6.12 FIX 02.1 — MODO SIMULAÇÃO INTEGRADO

## Objetivo
Quando o aplicativo não localizar um ELM327 compatível entre os dispositivos Bluetooth pareados, o VirtusELM entra automaticamente em MODO SIMULAÇÃO. O modo real permanece inalterado quando um ELM é encontrado e conectado.

## Comportamento
- ELM327 encontrado e conectado → MODO VEÍCULO REAL.
- Nenhum ELM327 compatível encontrado → MODO SIMULAÇÃO.
- Bluetooth indisponível/desligado → MODO SIMULAÇÃO.
- Falha de conexão com um ELM que foi encontrado → mantém diagnóstico de falha real; não mascara o problema como simulação.
- Permissão Bluetooth não concedida → solicita permissão normalmente.

## Fonte da simulação
1. O app procura o CSV mais recente em `Download/VirtusELM/logs/`.
2. Se houver histórico compatível, carrega até 180 amostras com RPM, velocidade, MAP, BARO, throttle, carga, temperaturas, combustível, tensão e óleo.
3. Se o histórico não estiver acessível, usa um perfil interno de demonstração baseado na telemetria histórica já registrada do projeto.

A tela identifica explicitamente `MODO SIMULAÇÃO`; nenhuma amostra simulada é apresentada como leitura atual do veículo.

## DTC
O botão DTC existente passa pelo mesmo fluxo de operação e, em simulação, recebe uma resposta OBD simulada de Mode 03 (`43 01 33 00 00 00 00`), correspondente ao código P0133. Isso permite validar o fluxo DTC sem criar um botão de teste separado.

## Funções em simulação
- Dashboard / Dados / gráficos: ativos.
- Diagnóstico e DTC: ativos, com respostas simuladas.
- VIN: perfil do Virtus do projeto.
- Gravação de telemetria: ativa e identificada como sessão de simulação.
- Histórico de performance: continua persistente e registra dados da simulação quando habilitado.
- Performance / 0–100: pode ser executado com os dados simulados.
- CAN Investigator: bloqueado em simulação; exige ELM327 real.
- Nenhum comando de atuação, coding, adaptation, security access ou transmissão CAN arbitrária é implementado pelo modo simulação.

## Identificação visual
- Health chip: `MODO SIMULAÇÃO`.
- Conexão: `● MODO SIMULAÇÃO`.
- Botão: `◉ SAIR DA SIMULAÇÃO`.
- CAN no dashboard: `CAN OFF`.

## Controle de versão
- Base: V11.6.12 FIX 01.
- FIX 02: `versionCode 130` / `versionName 11.6.12`.
- Artefato GitHub Actions: `VirtusELM-V11.6.12-FIX02-debug`.

## Segurança
O modo simulação é somente leitura. Ele não usa o socket Bluetooth para gerar dados simulados e não transmite comandos ao veículo.
