# VirtusELM V11.6 — CLUSTER UNIFICADO / BASE LIMPA

## Objetivo
Primeira etapa incremental sobre a V11.5 funcional, para identificar qualquer regressão item a item.

## Alteração desta etapa
- Unificação visual do cluster superior de RPM, mantendo a lógica de telemetria da V11.5.
- RPM, barra de RPM, escala, temperatura do óleo, nível do óleo, temperatura do líquido e temperatura de admissão ficam no mesmo contorno.
- IG permanece como texto `IG: —/ON` nesta etapa; ícone dedicado fica para uma etapa posterior, somente após validação desta versão.

## Deliberadamente NÃO alterado nesta etapa
- CAN Investigator.
- UDS/ISO-TP.
- VAG Diagnostic Explorer.
- Performance/0–100.
- PID 015C/G266.
- lógica de aquisição OBD.
- demais módulos e navegação.

## Critério
A V11.6 deve ser testada primeiro apenas quanto à abertura e estabilidade. Depois cada nova alteração será adicionada individualmente.
