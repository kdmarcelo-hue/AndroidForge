# REV11.6.11 — AJUSTE VISUAL DA ESCALA DE RPM

Alteração exclusivamente visual, sem mudança de aquisição, CAN, OBD, cálculos ou navegação.

- Escala 0–8 da barra de RPM refeita como componente visual próprio.
- 0 alinhado ao centro da primeira barra.
- 8 alinhado ao centro da última barra vermelha.
- 1–7 distribuídos linearmente entre as posições de referência.
- Altura do espaço da escala mantida em 24dp.
- Nome `VIRTUS` no cabeçalho reduzido de 16sp para 10,5sp (aprox. 2/3).
- Posição, dimensões do cabeçalho, imagem do carro e demais elementos mantidos.
- Versão: 11.6.11 / versionCode 127.
