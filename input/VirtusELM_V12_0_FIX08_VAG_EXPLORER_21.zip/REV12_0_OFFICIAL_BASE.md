# V12.0 — BASE OFICIAL

## Identidade Android
- applicationId: `v12.marcelo.virtuselm`
- namespace mantido: `com.marcelo.virtuselm`
- versionCode: `145`
- versionName: `12.0`

## Objetivo
A V12.0 passa a ser uma instalação Android independente das versões legadas, permitindo coexistência no mesmo aparelho.

## Assinatura permanente
A V12 usa uma chave de assinatura dedicada, armazenada fora do código-fonte e injetada pelo GitHub Actions via Secrets.

Secrets necessários:
- `V12_KEYSTORE_BASE64`
- `V12_KEYSTORE_PASSWORD`
- `V12_KEY_ALIAS`
- `V12_KEY_PASSWORD`

A chave privada NÃO deve ser commitada no repositório.

## Regra de atualização
Todas as futuras versões V12.x/FIX devem manter:
- o mesmo `applicationId`: `v12.marcelo.virtuselm`
- a mesma chave de assinatura
- `versionCode` crescente

Assim, V12.0 -> V12.0-FIX01 será atualização normal, sem desinstalação.

## Base funcional
Baseada na V12 FIX06.3 aprovada, preservando funcionalidades existentes, incluindo simulação, diagnóstico, DTC, VAG Explorer, histórico, performance, CAN e easter egg do farol/cache.
