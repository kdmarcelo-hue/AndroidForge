# V12.0-FIX07 — VALIDAÇÃO NO VIRTUS REAL

## Correções baseadas nos testes reais de 06/10/2026

- Resultado dos comandos de diagnóstico agora possui painel próprio dentro da tela Diagnóstico; antes `showResult()` atualizava apenas componentes das telas Home/Dados, fazendo VIN, Readiness, Sonda, Ler Dados e outros parecerem sem resposta.
- VIN continua usando o parser ISO-TP existente; a resposta real observada do 0902 é apresentada no painel de resultado quando a operação termina.
- VAG Diagnostic Explorer recebeu área de resultado limitada e com rolagem interna, evitando que o bloco ocupe indefinidamente a tela.
- Resultado da gravação de telemetria recebeu área maior e rolagem para exibir amostras, BOOST máximo e arquivo.
- Resumo da gravação passa a informar explicitamente se houve amostras ou se a gravação terminou sem dados.
- A navegação/identidade visual V12 foi preservada.

## Dados reais já confirmados

- ECU respondeu aos PIDs OBD.
- CAN 11/500 foi observado.
- Respostas 7E8/7E9 foram observadas.
- VIN 0902 respondeu em múltiplos frames ISO-TP.
- Captura CAN passiva não apresentou frames no ELM utilizado.

## Regra de segurança

Nenhum comando de coding, adaptation, Security Access ou transmissão CAN arbitrária foi adicionado.
