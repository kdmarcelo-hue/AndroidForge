# REV11.6.12 FIX 01 — CONTROLE DE LOG + HISTÓRICO PERSISTENTE DE PERFORMANCE

## Objetivo
Reduzir o crescimento excessivo do log técnico e preservar um histórico de performance fora do armazenamento privado do aplicativo.

## Alterações
- Mantida a versão `11.6.12`.
- `versionCode` atualizado para `129`.
- Artefato do GitHub Actions: `VirtusELM-V11.6.12-debug`.
- Configurações adicionadas:
  - DADOS EM TEMPO REAL: liga/desliga atualização visual dos painéis e gráficos.
  - LOG TÉCNICO: liga/desliga o registro de comunicações/eventos internos, evitando log técnico infinito.
  - HISTÓRICO DE PERFORMANCE: liga/desliga gravação automática persistente.
- Histórico automático registra telemetria de desempenho já coletada pelo aplicativo: RPM, velocidade, MAP, BARO, BOOST, BOOST máximo, throttle, carga, temperaturas, óleo, combustível, tensão, VIN e percentual de etanol informado manualmente.
- Quando um teste de Performance 0–100 for concluído, o resultado de potência estimada, torque estimado e tempo 0–100 é registrado no mesmo histórico.
- No Android 10+ o arquivo é criado em armazenamento público via MediaStore em:
  `Download/VirtusELM/logs/`
  Essa área não pertence ao armazenamento privado do aplicativo e permanece disponível após desinstalação/reinstalação.
- Em Android anterior ao 10, é usado o diretório público `Download/VirtusELM/logs/`.

## Segurança / escopo
- Nenhum comando CAN arbitrário foi adicionado.
- Nenhuma função de atuação, coding, adaptation ou Security Access foi adicionada.
- A aquisição OBD existente foi preservada.
- O histórico persistente é separado do log técnico da interface.

## Observação Android
O Android moderno não permite que um aplicativo comum escreva livremente em qualquer pasta arbitrária da raiz do armazenamento. Por isso, a implementação usa a área pública `Download/VirtusELM/logs/`, que é persistente e acessível pelo usuário sem depender do armazenamento privado do aplicativo.
