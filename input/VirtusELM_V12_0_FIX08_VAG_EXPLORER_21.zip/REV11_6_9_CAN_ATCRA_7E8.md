# V11.6.9 — CAN LAB / ATCRA 7E8 + ATMA

## Objetivo
Teste passivo isolado para verificar se o ELM entrega tráfego CAN quando o recebimento é filtrado especificamente para o ID 7E8.

## Alteração desta revisão
- Mantém toda a aplicação e a interface da V11.6.8.
- Força CAN 11/500 quando `ATDP` indicar CAN 11/500 (`ATSP6`).
- Executa `ATCRA 7E8` antes de `ATMA`.
- Mantém `ATMA` por uma janela de 10 s.
- Não transmite frames CAN arbitrários.
- Após a captura, executa `ATCRA` sem argumento para restaurar o filtro de recepção antes do retorno ao OBD.
- Registra a resposta bruta do ELM e diferencia: frames recebidos, prompt imediato ou ausência de frames.

## Motivo técnico
A documentação do ELM327 indica `AT CRA hhh` como o comando apropriado para definir o CAN Receive Address de um ID específico, inclusive 7E8. Para CAN 11-bit, `AT MR` considera apenas parte do endereço e não é o teste adequado para um ID completo 7E8.

## Segurança
Somente leitura/passivo. Nenhuma mensagem CAN arbitrária é transmitida ao veículo.
