# VIRTUS ELM V12 — FIX05.1 BUILD FIX

Correção isolada de compilação da tela Histórico de Sessões.

- versionCode: 138
- versionName: 12.0-FIX05.1
- Base: V12.0-FIX05
- Não altera aquisição, simulação, Performance 2.0, VAG Explorer 2.0 ou DTC 2.0.
- Corrige apenas referências de cores que estavam fora do escopo em `loadHistorySessions()`.
- GitHub Actions permanece como autoridade para compilação final.
