# VIRTUS ELM V12 — FIX10.1

- versionCode: 159
- versionName: 12.0-FIX10.1
- Correção: variável `quality` usada dentro de lambda/UI foi tornada efetivamente final (`fQuality`), eliminando o erro de compilação Java em `MainActivity.java`.
- Nenhuma alteração de Secrets, workflow ou estrutura de Release foi feita nesta entrega.
- Base: FIX10.0 / Code 158.
