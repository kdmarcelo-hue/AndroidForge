# V12.0-FIX10.2 — UI / GRÁFICO COMBINADO

## Objetivo
Refino visual solicitado após validação do APK Code 159.

## Alterações
- Botões da área Diagnóstico passam a ter altura uniforme por seção.
- Botões com textos de duas linhas recebem espaço vertical compatível e ícone contextual.
- Último botão de grupos ímpares ocupa a largura disponível mantendo a mesma altura.
- Títulos das seções de diagnóstico ficam centralizados.
- Gráfico combinado deixa de usar escala normalizada única de 0–100.
- Eixos visuais independentes:
  - Velocidade: 0–200 km/h.
  - Throttle: 0–100%.
  - Boost: 0–3,0 bar.
  - RPM: 0–8.000 rpm.
- As cores das quatro grandezas permanecem: azul velocidade, branco throttle, amarelo boost e verde RPM.
- Removidos legenda textual e botões individuais de seleção do gráfico.
- Performance recebeu espaçamento vertical reduzido para melhor aproveitamento da tela.
- Ao abrir Performance, a tela é reposicionada no topo para evitar cabeçalho parcialmente oculto.
- versionCode: 160.
- versionName: 12.0-FIX10.2.

## Regra de dados
Nenhum valor físico é inventado. O gráfico somente plota os valores efetivamente disponíveis na telemetria; a escala é visual e fixa para correlação entre grandezas.
