# V11.6.12 FIX 02 — DTC READ

## Objetivo
Melhorar exclusivamente a leitura de DTC pela rotina OBD-II existente.

## Alterações
- Mantida a consulta somente leitura `03` (Mode 03).
- Decodificação dos pares de bytes após a resposta `43`.
- Reconhecimento das famílias P/C/B/U.
- Exibição da quantidade de DTC identificados.
- Exibição do RAW original do ELM para auditoria.
- Sem comando `04` e sem qualquer função de limpeza/atuação.

## Preservado
Bluetooth, telemetria, gráficos, Performance, histórico, gravação, CAN Investigator, navegação e demais telas não foram alterados intencionalmente.

## Limitação
A descrição textual específica de cada Pxxxx/Cxxxx/Bxxxx/Uxxxx não é inventada. O FIX 02 identifica e classifica o código; descrições específicas serão adicionadas somente com uma base confiável.
