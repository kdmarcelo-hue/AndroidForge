# Auditoria visual e funcional — Virtus ELM V12

Base analisada: `VirtusELM_V12_FIX10_24_PERFORMANCE_PALETA_ICONES_CODE184_FONTE_GIT.zip` (CODE184).
Entrega: `12.0-FIX10.25-PERFORMANCE-LIVE-UI-CODE185`.

## Comparação com a captura instalada

### O que já está correto e foi preservado
- A tela Performance usa fundo quase preto, moldura vermelha, cartões de métricas em duas colunas, painel de combustível, botões de teste/gráficos/histórico e navegação inferior.
- O tema esportivo é aplicado somente quando `screen == 6`; a função `applyPerformanceImmersive()` restaura a paleta azul ao sair da tela.
- O helper global `btn()` e os estilos dos outros menus não foram alterados.
- O teste continua exigindo ELM conectado e velocidade GPS válida; a origem GPS, os limiares de 0–60/0–100 e a lógica de consolidação foram preservados.

## Problemas identificados e correções aplicadas

1. **Indicadores não atualizavam durante a puxada.** Antes, a maior parte das métricas só era escrita na consolidação final. Agora potência/torque estimados, boost máximo, qualidade provisória, RPM máximo, velocidade GPS máxima, duração e tempos de 0–60/0–100 são atualizados durante o ensaio, a cada cinco amostras (aprox. 350 ms, conforme a latência da leitura OBD).
2. **Estado visual não indicava o início real da aceleração.** Antes, o status podia permanecer em `ARMADO • GPS...` até o fim. Agora fica amarelo enquanto aguarda a saída da imobilidade e muda para vermelho `TESTE EM ANDAMENTO • GPS` quando o cronômetro realmente começa, após o cruzamento de 1 km/h.
3. **Cor inicial dos cartões de métricas era azul-marinho no método construtor.** O tema imersivo corrigia isso depois, mas havia uma dependência desnecessária da ordem de aplicação do tema. O fundo-base local dos cartões agora é escuro; nenhuma cor global foi modificada.
4. **Rastreabilidade da versão.** `versionCode` foi incrementado de 184 para 185 e `versionName` para `12.0-FIX10.25-PERFORMANCE-LIVE-UI-CODE185`.

## Limitações da validação

- A captura enviada foi auditada visualmente, e as alterações de código foram conferidas estaticamente.
- **Não foi possível executar uma compilação Android neste ambiente** porque não há Android SDK/Gradle wrapper disponível localmente. Portanto, este ZIP é a fonte corrigida preparada para o workflow do GitHub Actions; não é uma afirmação de que um APK CODE185 já foi compilado ou testado no tablet.
- A qualidade de aquisição exibida durante o teste é provisória e segue os critérios existentes; a classificação final continua sendo consolidada ao terminar.
- Os números de potência/torque durante o teste são estimativas derivadas das amostras disponíveis, não medições de dinamômetro.

## Arquivos alterados
- `app/src/main/java/com/marcelo/virtuselm/MainActivity.java`
- `app/build.gradle`

## Próxima validação no GitHub Actions
Suba o ZIP completo na pasta `input/` do repositório `kdmarcelo-hue/AndroidForge`, rode o workflow de build e confira o artefato gerado. Só depois instale o APK CODE185 e valide visualmente no tablet e em uma puxada real, com o veículo parado em local seguro para iniciar e condução feita sem operar o tablet.
