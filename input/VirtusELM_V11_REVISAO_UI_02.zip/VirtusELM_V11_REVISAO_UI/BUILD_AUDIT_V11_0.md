# VIRTUS ELM V11.0 — Build Audit / Corrections

## Toolchain
- Android Gradle Plugin: 8.5.2
- Gradle: 8.7
- JDK: 17
- compileSdk: 34
- targetSdk: 34
- minSdk: 23

AGP 8.5 requires Gradle 8.7 and JDK 17. This project is pinned to that compatible combination.

## Corrections made
1. Added the missing `android.graphics.drawable.GradientDrawable` import used by `MainActivity.java`.
2. Added `gradle/wrapper/gradle-wrapper.properties` pointing to Gradle 8.7.
3. Added `.github/workflows/android-build.yml` so GitHub Actions installs Gradle 8.7 directly and builds `assembleDebug`, even if the repository does not contain the Gradle wrapper JAR.
4. Kept namespace/applicationId `com.marcelo.virtuselm`.
5. Kept compileSdk/targetSdk 34 and minSdk 23.
6. Kept versionCode 110 / versionName 11.0.

## Important
The source was statically audited here. A complete Android compilation could not be executed in this environment because the Android SDK/build-tools are not installed locally. The GitHub workflow is the reproducible build path and will fail loudly if any remaining Android compiler/resource issue exists.
