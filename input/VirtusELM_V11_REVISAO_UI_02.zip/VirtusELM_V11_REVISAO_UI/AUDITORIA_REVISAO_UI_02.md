# VIRTUS ELM — V11.0 — REVISÃO UI 02

## Objetivo
Correção de robustez da conexão Bluetooth sem alterar a base funcional OBD/CAN validada na V10.9/V11.0.

## Correções de runtime
- O estado de conexão passou a ser controlado por `connected`, evitando consultar `BluetoothSocket.isConnected()` diretamente no clique da interface.
- `toggleConnection()` passou a ter proteção contra exceções, evitando que uma falha no acionamento do botão derrube a Activity.
- Chamadas Bluetooth sensíveis ficam protegidas por verificação de permissão e `SecurityException`.
- `BLUETOOTH_CONNECT`/`BLUETOOTH_SCAN` continuam sendo permissões de runtime para Android 12+.
- Após concessão das permissões, `onRequestPermissionsResult()` inicia a conexão automaticamente.
- O botão fica temporariamente desabilitado durante a tentativa de conexão, evitando duplo acionamento.
- Falhas de conexão fecham apenas o socket e preservam a Activity/log.
- Reconexão automática continua preservada para perda inesperada.

## Base preservada
- OBD-II somente leitura.
- VIN.
- DTC / Freeze Frame.
- PIDs e telemetria.
- MAP/BARO/BOOST.
- CAN Investigator passivo.
- Stop de `AT MA` com um caractere e espera pelo prompt.
- Watchdog/reconexão automática.
- Interface V11.0 futurista.

## Limitação de auditoria
O ambiente local não possui Android SDK/build-tools para executar uma compilação Android completa. O projeto deve ser validado pelo workflow GitHub com Gradle 8.7/AGP 8.5.2/JDK 17.
