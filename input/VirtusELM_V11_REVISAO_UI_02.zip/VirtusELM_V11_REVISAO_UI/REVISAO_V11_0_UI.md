# VIRTUS ELM — V11.0 — REVISÃO VISUAL

Revisão exclusivamente visual/ergonômica da V11.0, preservando a base funcional da V10.9/V11.0.

## Objetivos desta revisão
- aproximar a tela do mockup aprovado: hero com logo V maior e veículo mais presente;
- aumentar ícones e rótulos da navegação inferior;
- eliminar textos cortados/engolidos em botões e cards;
- ampliar os cards dos módulos e usar título + subtítulo + seta;
- reorganizar o card de conexão para evitar overflow do status;
- reforçar hierarquia visual do dashboard de RPM e telemetria;
- manter as funções OBD-II, VIN, DTC, polling, watchdog/reconexão e CAN Investigator existentes.

## Regra de versão
O aplicativo continua sendo V11.0. Este pacote é uma revisão visual da V11.0; não é V11.1.

## Referência
Mockup visual aprovado pelo usuário e screenshots reais da V11.0 em dispositivo.
