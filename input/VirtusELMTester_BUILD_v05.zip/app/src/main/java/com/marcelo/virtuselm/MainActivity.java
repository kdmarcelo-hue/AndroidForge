package com.marcelo.virtuselm;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    BluetoothAdapter adapter;
    BluetoothSocket socket;
    InputStream in; OutputStream out;
    TextView log,status;
    Button connect, testEcu;
    Handler h=new Handler(Looper.getMainLooper());
    static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        log=findViewById(R.id.log);
        status=findViewById(R.id.status);
        connect=findViewById(R.id.btnConnect);
        testEcu=findViewById(R.id.btnTestEcu);
        adapter=BluetoothAdapter.getDefaultAdapter();

        connect.setOnClickListener(v->startConnection());
        testEcu.setOnClickListener(v->testEcu());
        findViewById(R.id.btnClear).setOnClickListener(v->log.setText(""));
        testEcu.setEnabled(false);
        requestBt();
    }

    void requestBt(){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},10);
    }

    void startConnection(){
        if(adapter==null){ msg("Bluetooth não disponível."); return; }
        if(!adapter.isEnabled()){ msg("Ative o Bluetooth do celular."); return; }
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED){requestBt();return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestBt();return;}

        new Thread(()->{
            try{
                setStatus("PROCURANDO ELM...");
                msg("Procurando ELM...");
                BluetoothDevice elm=null;

                if(Build.VERSION.SDK_INT<31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED){
                    Set<BluetoothDevice> paired=adapter.getBondedDevices();
                    for(BluetoothDevice d:paired){
                        String n=d.getName();
                        if(n!=null && isElmName(n)){elm=d;break;}
                    }
                }

                if(elm!=null){
                    msg("ELM encontrado entre dispositivos conhecidos: "+elm.getName());
                    adapter.cancelDiscovery();
                    socket=elm.createRfcommSocketToServiceRecord(SPP);
                    socket.connect();
                } else {
                    msg("ELM não está pareado. Iniciando descoberta Bluetooth...");
                    final Object lock=new Object();
                    final BluetoothDevice[] found={null};
                    BroadcastReceiver receiver=new BroadcastReceiver(){
                        public void onReceive(Context c,Intent i){
                            if(BluetoothDevice.ACTION_FOUND.equals(i.getAction())){
                                BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                                if(d!=null){
                                    String n=d.getName();
                                    if(n!=null && isElmName(n)){
                                        found[0]=d;
                                        synchronized(lock){lock.notifyAll();}
                                    }
                                }
                            }
                        }
                    };
                    IntentFilter f=new IntentFilter(BluetoothDevice.ACTION_FOUND);
                    registerReceiver(receiver,f);
                    adapter.startDiscovery();
                    synchronized(lock){lock.wait(12000);}
                    try{unregisterReceiver(receiver);}catch(Exception ignored){}
                    adapter.cancelDiscovery();
                    elm=found[0];
                    if(elm==null){ msg("Nenhum ELM identificado na descoberta Bluetooth."); setStatus("NÃO ENCONTRADO"); return; }
                    msg("ELM encontrado: "+elm.getName());
                    socket=elm.createRfcommSocketToServiceRecord(SPP);
                    socket.connect();
                }

                in=socket.getInputStream();
                out=socket.getOutputStream();
                msg("Bluetooth conectado.");

                send("ATZ"); Thread.sleep(1200); read();
                send("ATE0"); Thread.sleep(300); read();
                send("ATI"); Thread.sleep(500); read();
                send("ATDP"); Thread.sleep(500); read();
                send("ATSP0"); Thread.sleep(500); read();

                setStatus("CONECTADO AO ELM");
                setEcuButton(true);
                msg("Inicialização concluída. Pronto para testar a ECU.");
            }catch(Exception e){
                msg("Falha: "+e.getMessage());
                setStatus("NÃO CONECTADO");
                setEcuButton(false);
                close();
            }
        }).start();
    }

    boolean isElmName(String n){
        String u=n.toUpperCase(Locale.ROOT);
        return u.contains("ELM") || u.contains("OBD") || u.contains("V-LINK") || u.contains("OBDLINK");
    }

    void testEcu(){
        new Thread(()->{
            try{
                if(out==null || socket==null || !socket.isConnected()){
                    msg("ELM não está conectado.");
                    setStatus("NÃO CONECTADO");
                    setEcuButton(false);
                    return;
                }
                setEcuButton(false);
                setStatus("TESTANDO ECU...");
                msg("Teste OBD-II somente leitura.");
                msg(">> 0100");
                out.write("0100\r".getBytes(StandardCharsets.US_ASCII));
                out.flush();

                String response=readResponse(3500);
                msg("<< "+(response.length()>0?response.replace("\r","\n"):"(sem resposta)"));

                String normalized=response.toUpperCase(Locale.ROOT).replaceAll("[\\r\\n\\s]","");
                if(normalized.contains("4100")){
                    setStatus("ECU RESPONDEU");
                    msg("ECU/OBD-II respondeu ao PID 0100.");
                    msg("Nenhum comando de escrita/adaptação foi enviado.");
                }else if(normalized.contains("NO DATA") || normalized.contains("NODATA")){
                    setStatus("SEM RESPOSTA OBD-II");
                    msg("O ELM respondeu, mas não houve dados do PID 0100.");
                }else if(normalized.contains("7F01")){
                    setStatus("ECU RECUSOU O PID");
                    msg("A rede respondeu com rejeição ao serviço solicitado.");
                }else{
                    setStatus("RESPOSTA OBTIDA");
                    msg("Houve resposta ao teste; vamos analisar o conteúdo antes de avançar.");
                }
            }catch(Exception e){
                msg("Falha no teste da ECU: "+e.getMessage());
                setStatus("FALHA NO TESTE");
            }finally{
                setEcuButton(true);
            }
        }).start();
    }

    synchronized void send(String x)throws Exception{
        if(out==null)throw new Exception("ELM desconectado");
        msg(">> "+x);
        out.write((x+"\r").getBytes(StandardCharsets.US_ASCII));
        out.flush();
    }

    void read()throws Exception{
        String b=readResponse(1600);
        msg("<< "+(b.length()>0?b.replace("\r","\n"):"(sem resposta)"));
    }

    String readResponse(long timeoutMs)throws Exception{
        long end=System.currentTimeMillis()+timeoutMs;
        StringBuilder b=new StringBuilder();
        while(System.currentTimeMillis()<end){
            while(in!=null&&in.available()>0){
                int c=in.read();
                if(c>=0)b.append((char)c);
                if(c=='>'){
                    end=System.currentTimeMillis()+150;
                    break;
                }
            }
            Thread.sleep(25);
        }
        return b.toString();
    }

    void close(){
        try{if(socket!=null)socket.close();}catch(Exception e){}
        socket=null; in=null; out=null;
        setEcuButton(false);
    }

    void msg(String s){h.post(()->log.append(s+"\n"));}
    void setStatus(String s){h.post(()->status.setText("Status: "+s));}
    void setEcuButton(boolean enabled){h.post(()->testEcu.setEnabled(enabled));}

    protected void onDestroy(){close();super.onDestroy();}
}
