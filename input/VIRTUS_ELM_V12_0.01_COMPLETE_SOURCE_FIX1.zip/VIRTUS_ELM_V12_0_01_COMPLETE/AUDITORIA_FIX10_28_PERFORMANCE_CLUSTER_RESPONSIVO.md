# CODE188 — painel Performance responsivo

## Alterações
- Três instrumentos circulares: conta-giros, pressão do turbo (MAP − BARO) e velocidade.
- Ponteiros e escalas desenhados em Canvas; valores indisponíveis permanecem como traço e não simulam leituras.
- Layout adaptativo: 4 colunas de indicadores e ações em pares na horizontal; 2 colunas e botões de ação empilhados na vertical.
- Cartões mais compactos, com menos espaçamento e contornos menos pesados.
- Substituição do recurso `v12_car_header_motion.png` por um recorte do carro azul/vermelho da referência visual aprovada.
- O campo de versão existente continua derivado de `BuildConfig.VERSION_NAME` e `VERSION_CODE`.

## Validação
- Fonte editada a partir do pacote CODE188 atualizado.
- ZIP reaberto após a geração para conferir integridade e presença dos arquivos.
- Não foi executada compilação Android local; a compilação e o teste de toque/faróis precisam ser confirmados no GitHub Actions e no dispositivo.
