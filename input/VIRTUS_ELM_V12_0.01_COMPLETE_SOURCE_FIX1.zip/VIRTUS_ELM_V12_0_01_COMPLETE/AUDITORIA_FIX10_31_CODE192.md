# Auditoria V12 FIX10.31 / BUILD 192

## Alterações aplicadas nesta revisão
- Mantido o início em modo simulação no `onCreate`; Bluetooth permanece sob ação explícita do usuário.
- Mantido o fluxo de tentativa Bluetooth e retorno automático à simulação em caso de falha.
- Cabeçalho ampliado e alturas das linhas de texto aumentadas para reduzir corte do nome/versão.
- Imagem do Virtus reposicionada mais abaixo e área do cabeçalho ampliada.
- Fade lateral e inferior desenhado sobre a imagem para integrar a arte ao fundo escuro sem alterar o arquivo original.
- Coordenadas do efeito dos faróis recalculadas usando a proporção da arte original 453x170 e o retângulo FIT_CENTER, em vez de coordenadas do frame inteiro.
- VersionCode incrementado para 192 para permitir atualização Android sobre a Build 191; versionName 12.0-FIX10.31.

## Preservação
- Não foram alterados deliberadamente o armazenamento de histórico, os módulos de diagnóstico, o painel de Performance, as unidades configuráveis ou a lógica de coleta real OBD/CAN.
- A simulação não deve transmitir comandos ao veículo; a conexão Bluetooth continua sob solicitação do usuário.

## Limites de validação
- Verificação estrutural do ZIP e contagem de delimitadores Java realizada.
- Este ambiente não dispõe do Android SDK/Gradle do workflow nem das credenciais de assinatura do repositório; portanto, a compilação Release e o teste em aparelho precisam ser confirmados pela GitHub Action e no dispositivo. Não considerar o APK aprovado antes dessas verificações.


## FIX10.32 / BUILD 193 — integração da imagem e configuração da simulação
- Máscara alfa progressiva na imagem do cabeçalho: laterais, topo e base dissolvem-se no fundo sem moldura retangular. Centro da imagem preservado nítido.
- Imagem reposicionada para baixo e frame ligeiramente ampliado.
- Inicialização respeita `SIMULAÇÃO AUTOMÁTICA`: ON inicia em simulação; OFF não inicia automaticamente.
- Falhas de conexão só retornam à simulação quando a opção está ON.
- Indicador ON/OFF explícito no texto da configuração.
- Mantidos o handler de toque dos faróis e a rotina existente de limpeza de cache temporário.
- Compilação e teste em dispositivo ainda precisam ser confirmados pelo GitHub Actions e aparelho.
