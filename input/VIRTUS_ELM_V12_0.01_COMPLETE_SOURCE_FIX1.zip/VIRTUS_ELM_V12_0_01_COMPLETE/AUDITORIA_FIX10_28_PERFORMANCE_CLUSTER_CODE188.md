# Auditoria — FIX10.28 / CODE188

## Objetivo
Reorganizar a tela Performance como painel automotivo, reduzindo o excesso de vermelho e dando prioridade visual ao conta-giros e à pressão de turbo.

## Alterações
- Incluídos dois instrumentos desenhados em Canvas: conta-giros (0–8.000 rpm) e pressão de turbo (0–3 bar).
- Os instrumentos recebem valores de telemetria OBD disponíveis e mostram “— / AGUARDANDO DADO” quando a leitura não é válida; não simulam valores.
- Métricas anteriores, estimativas, tempos 0–60/0–100, qualidade, velocidade máxima, combustível, histórico, gráfico e comandos foram mantidos.
- Reduzida a saturação visual: fundos grafite, contornos discretos e vermelho reservado para destaque e ação principal.
- Atualizado versionCode para 188 e versionName para 12.0-FIX10.28-PERFORMANCE-CLUSTER-CODE188.
- Baseado na fonte CODE187 corrigida, incluindo a estrutura ZIP preparada para o workflow AndroidForge.

## Validação
A estrutura do ZIP e as alterações de texto foram verificadas localmente. Não foi executado build Android neste ambiente; a compilação e o teste no tablet ainda precisam ser confirmados pelo GitHub Actions.


## Ajustes adicionais nesta revisão do CODE188
- Substituída a imagem do carro no cabeçalho pela região do carro aprovada na montagem histórica fornecida pelo usuário, preservando os rastros de luz azul/vermelha e sem deformar a proporção.
- Reposicionada a camada de efeito dos faróis sobre os faróis visíveis na nova arte. O comportamento precisa ser confirmado visualmente no tablet.
- Incluída identificação de versão/build no cabeçalho, calculada de `BuildConfig.VERSION_NAME` e `BuildConfig.VERSION_CODE`, para distinguir instalações.
- Ajustado o `versionName` para `12.0-FIX10.28` mantendo `versionCode 188`.
- Definido nome de saída do APK no formato `V12-12.0-FIX10.28-BUILD188-<variant>.apk`. O rótulo instalado continua `V12`.

## Limites de validação
- Verificação estática do conteúdo e da estrutura do pacote ZIP.
- A compilação Android/Gradle e o posicionamento final do efeito dos faróis ainda dependem do GitHub Actions e do teste no dispositivo.
