# VIRTUS ELM V9 — Diagnóstico

Aplicativo Android para diagnóstico OBD-II via ELM327 Bluetooth, somente leitura.

## Base
- Package: `com.marcelo.virtuselm`
- Version: `0.9.1` / versionCode 91
- compileSdk 34 / targetSdk 34 / minSdk 23
- Bluetooth Classic RFCOMM SPP
- ISO 15765-4 CAN 11/500 / ISO-TP
- AGP 8.5.2 / Gradle 8.7 / JDK 17

## V9
- Sessão Bluetooth única e fila serializada.
- Sem reconexão automática durante operação.
- Tratamento de socket fechado e `read() == -1`.
- Parser CAN/ISO-TP separado por ECU.
- VIN Mode 09/02 multi-frame.
- DTC armazenado/pendente/permanente em leitura.
- Correção do PID 0x33 como pressão barométrica.
- Conclusão correta do teste com ignição desligada.
- Novo botão `DIAGNÓSTICO AUTOMÁTICO — SOMENTE LEITURA`.
- Dashboard de conexão, protocolo, ECUs e VIN.
- Ícone adaptativo próprio + fallback para API < 26.
- GitHub Actions para build debug.
- Bitmap de PIDs corrigido por faixa.

## Segurança
Nenhum comando de limpeza de DTC, atuação, codificação, adaptação, Security Access ou LOCK/UNLOCK é implementado.

## Auditoria
Consulte `AUDIT_V9.md`. O projeto precisa passar pelo build do GitHub Actions antes de ser considerado compilado/validado.
