# Auditoria V9 — 2026-10-03

## Resultado
A estrutura foi revisada antes da próxima evolução. A base não deve ser considerada validada como APK até passar por build real no Gradle/Android Studio.

## Correções aplicadas nesta base auditada
- Corrigido o mapeamento dos bitmaps de PIDs: 0100→01–20, 0120→21–40, 0140→41–60, 0160→61–80.
- Adicionado fallback de ícone para API < 26; o projeto já possui adaptive icon para API 26+.
- Adicionado GitHub Actions para build debug com JDK 17 e Gradle 8.7 (compatível com AGP 8.5.2).

## Pontos que ainda exigem validação em build/dispositivo
- Build Gradle completo e instalação do APK.
- Teste Bluetooth real com o ELM OBDII.
- Teste de cada operação na V9.
- Validação de crash/ANR em VIN, DTC+Freeze Frame e reconexão.
- Validação do ícone em launcher real.

## Observação
Este ambiente de auditoria não possui Gradle/Android SDK instalado, portanto não foi alegado um build executado localmente. O workflow CI foi incluído para que o GitHub faça essa validação de compilação.
