# V11 Performance Auto — FINAL AUDIT TEST

Minimal Android Auto test app. This build intentionally contains no ELM327, Bluetooth, CAN, database, or V11 main-app code.

Purpose: verify that a lightweight Android Auto `CarAppService` can be installed on the phone and exposed by Android Auto in the vehicle.

- Application ID: `com.marcelo.v11performanceauto`
- Android Auto category: `androidx.car.app.category.IOT`
- Car App Library: `androidx.car.app:app:1.7.0`
- compileSdk / targetSdk: 35
- minSdk: 23
- Android Gradle Plugin: 8.5.2
- Gradle: 8.7
- JDK: 17

GitHub Actions builds with Gradle 8.7 and uploads the debug APK as an artifact.

The `ALLOW_ALL_HOSTS_VALIDATOR` is intentionally limited to this development test build.
