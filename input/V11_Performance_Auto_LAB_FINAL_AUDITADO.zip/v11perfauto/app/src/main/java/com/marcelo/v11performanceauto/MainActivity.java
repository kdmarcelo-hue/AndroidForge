package com.marcelo.v11performanceauto;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public final class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView view = new TextView(this);
        view.setText("V11 Performance Auto\n\nConecte ao Android Auto e procure V11 Performance.");
        view.setTextSize(20f);
        view.setPadding(32, 32, 32, 32);
        setContentView(view);
    }
}
