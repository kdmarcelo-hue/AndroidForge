import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
JAVA = (ROOT / 'app/src/main/java/com/marcelo/virtuselm/MainActivity.java').read_text(encoding='utf-8')

class PerformanceScreenLiveGraphTests(unittest.TestCase):
    def test_performance_screen_contains_its_own_live_graph(self):
        self.assertIn('private CombinedGraphView performanceCombinedGraphView;', JAVA)
        self.assertIn('TELEMETRIA DA PUXADA • AO VIVO', JAVA)
        self.assertIn('performanceCombinedGraphView=new CombinedGraphView(this)', JAVA)

    def test_real_samples_are_published_during_the_pull(self):
        start = JAVA.index('private void startPerformanceTest()')
        end = JAVA.index('private String buildPullComparison', start)
        block = JAVA[start:end]
        self.assertIn('if(t0>0 && samples%2==0)', block)
        for token in ('combinedTimeValues.add(gt)', 'combinedRpmValues.add(gr)', 'combinedSpeedValues.add(gs)', 'combinedPedalValues.add(gp)', 'combinedBoostValues.add(gb)', 'performanceCombinedGraphView.invalidate()'):
            self.assertIn(token, block)

    def test_invalid_boost_is_not_shown_as_waiting_forever(self):
        self.assertIn('showingMaximum?"MÁXIMO ATINGIDO":"SEM DADO"', JAVA)

if __name__ == '__main__':
    unittest.main(verbosity=2)
