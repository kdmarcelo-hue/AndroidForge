# VirtusELM V11.6

- Unified the upper telemetry cluster into one full-width card.
- RPM value and segmented RPM bar now span the complete telemetry card width.
- Oil temperature, oil level, coolant temperature and intake temperature are grouped coherently below the RPM bar.
- Replaced textual ignition status with a compact ignition-key icon in the header area of the RPM cluster.
- Added a vehicle-style oil-level icon (oil can with drop) beside the oil level value.
- Preserved existing V11.6 functionality and versioned as V11.6.
