# V12 0.02 — evolução da aba Custom

Alterações nesta revisão:
- Aba CUSTOM usa o drawable `ic_tune`, distinto da engrenagem da aba Config.
- Itens de customização agora permitem seleção por checkbox.
- Botão `REVISAR SELEÇÃO` lista os itens escolhidos e informa explicitamente que a gravação na ECU ainda não está habilitada.
- Nenhum comando de escrita, coding, adaptation ou CAN arbitrário foi adicionado. A gravação real depende de validar módulo, protocolo, procedimento e compatibilidade do veículo.

Validação realizada: integridade do ZIP de origem verificada. A compilação Android não foi executada neste ambiente; o build deve ser confirmado pelo workflow do GitHub.
