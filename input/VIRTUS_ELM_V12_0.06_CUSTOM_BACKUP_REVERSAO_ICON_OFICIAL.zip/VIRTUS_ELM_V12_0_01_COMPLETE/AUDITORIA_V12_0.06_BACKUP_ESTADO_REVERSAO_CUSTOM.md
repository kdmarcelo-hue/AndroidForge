# V12 0.06 — backup de estado e base para reversão

## Implementado nesta revisão
- Versão 0.06 / versionCode 7 / applicationId `v12.marcelo.virtuselm.custom006`.
- Ações no menu CUSTOM para criar snapshot JSON e consultar/compartilhar o último snapshot.
- Snapshot local inclui VIN conhecido, estado de conexão/simulação, protocolo conhecido, telemetria disponível e DTCs já lidos.
- Diálogos distinguem conexão real, simulação e snapshot parcial.
- Ícone do launcher atualizado com a arte oficial aprovada (azul futurista predominante, detalhes vermelhos, lettering V12 e carro).

## Limites que não podem ser mascarados
- O backup não é uma imagem integral das ECUs nem captura automaticamente todas as codificações/adaptações.
- O botão de consultar/restaurar atualmente consulta o snapshot e permite compartilhá-lo; ele não grava parâmetros no veículo.
- Uma reversão real só pode ser habilitada por parâmetro depois que a leitura do valor original, o identificador do módulo, o procedimento de escrita e a verificação pós-escrita forem comprovados para aquele veículo/módulo.
- Não foi habilitada escrita genérica de ECU, pois isso seria inseguro sem procedimentos validados.

## Validação
- ZIP testado quanto à integridade após empacotamento.
- A compilação Android precisa ser confirmada pelo workflow GitHub Actions; este ambiente não dispõe de Gradle wrapper executável no projeto.
