# V12 0.05 — pacote consolidado e auditoria de implementação

## Alterações reunidas nesta versão
- Versão 0.05 / versionCode 6 / applicationId `v12.marcelo.virtuselm.custom005` para instalação paralela, sem substituir o pacote anterior.
- Ícone do aplicativo atualizado para paleta vermelha (preto, vermelho carmesim, vermelho vivo e detalhe vermelho-alaranjado), incluindo ícone adaptativo.
- Mantido o cabeçalho visual automotivo, a tela Performance e a distinção entre Custom (ícone de ajustes finos) e Config (engrenagem).
- Mantida a consolidação do diagnóstico em uma única área, com ferramentas OBD-II/VAG, DTC, readiness, VIN, dados do veículo, explorador VAG e CAN Investigator em modo de análise.
- Mantida a tela Custom expansível por categorias, seleção múltipla e revisão das funções selecionadas; o diálogo apresenta que a seleção não envia comandos ao veículo.
- Mantida a separação entre leitura OBD/UDS e qualquer operação de escrita.

## Estado técnico — não confundir interface com suporte confirmado
- Leitura OBD-II depende do adaptador ELM327, protocolo suportado e resposta real da ECU.
- O VAG Diagnostic Explorer possui caminho de leitura UDS para VIN (DID F190), e só deve declarar VIN confirmado após resposta positiva correspondente.
- CAN Investigator analisa tráfego observado; um identificador CAN não é, por si só, identificação comprovada de módulo ou função.
- O catálogo Custom continua em revisão/validação. Este pacote **não declara gravação de codificação/adaptação ECU funcional**: para habilitá-la são necessários endereços e serviços específicos, mapeamento do módulo correto, valores/limites, condições de segurança e validação no Virtus real. Não foram inventados comandos de escrita.
- Nenhuma função de codificação deve ser descrita como testada no carro apenas por compilar ou aparecer na interface.

## Verificações realizadas neste pacote
- ZIP validado estruturalmente após geração.
- Gradle local e wrapper Gradle não estão disponíveis neste ambiente; portanto, compilação Android não foi confirmada aqui. O build precisa ser confirmado pelo workflow GitHub Actions antes da instalação.

## Regra de entrega do projeto
Consolidar, na próxima versão, todas as correções e implementações já acordadas que sejam tecnicamente sustentadas; não dividir deliberadamente o trabalho em pequenas melhorias sucessivas. Bloqueios reais de hardware/protocolo devem ser documentados explicitamente, nunca mascarados com uma interface que pareça funcional.
