# Auditoria V12 0.04 — Customização e Diagnóstico

## Base
Derivada do ZIP VIRTUS_ELM_V12_0.03_FULL_AUDIT_CUSTOM_DIAGNOSTIC_ICON_PARALLEL.zip encontrado na pasta input do repositório AndroidForge.

## Correções desta revisão
- Melhorada a mensagem de revisão da Customização, explicitando o fluxo necessário antes de qualquer escrita real.
- Atualizado versionName para 0.04, versionCode para 5 e applicationId para v12.marcelo.virtuselm.custom004 para permitir instalação paralela às versões com IDs anteriores.
- Mantidos ícones distintos: ic_tune para Custom e ic_settings para Config.

## Auditoria de arquitetura
- Há transporte Bluetooth ELM327 e operações OBD-II de leitura, incluindo PIDs, VIN e DTC.
- A tela Diagnóstico liga ações a métodos para leitura rápida, dados, VIN, DTC, readiness, sonda, diagnóstico completo, ignição off e CAN Investigator.
- Customização atualmente mantém seleção local e apresenta revisão. O fluxo não comprova leitura do valor atual por função, validação de compatibilidade por módulo, envio de comando de adaptação/codificação e verificação pós-escrita. Essas etapas continuam pendentes de implementação e validação por módulo.
- Não declarar suporte universal a VAG ou escrita de ECU sem evidência. Respostas simuladas devem permanecer identificadas como simulação.

## Validação
ZIP validado estruturalmente; compilação Android e teste no veículo precisam ser realizados pelo GitHub Actions e no dispositivo.
