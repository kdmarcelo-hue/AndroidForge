# VIRTUS ELM V12 0.02 — scanner e catálogo de customização

- Preservada a interface interna existente e a animação de piscada dos faróis.
- Adicionado atalho CUSTOMIZAÇÃO VW na tela inicial.
- Adicionado catálogo inicial por categorias: iluminação, painel, climatização, travas/conforto, alertas e outras funções.
- Segurança: catálogo inicial é somente informativo e não envia comandos de escrita. Funções individuais exigem validação de módulo, procedimento, valor original e compatibilidade antes de habilitar gravação.
- Próxima etapa: consolidar duplicações de ações de diagnóstico e aprofundar interpretação de DTC/VIN/Freeze Frame com evidência bruta e estado de qualidade da captura.
