# Auditoria V12 0.03 — Custom, Diagnóstico e instalação paralela

## Verificado no código
- Navegação inferior: Config usa `R.drawable.ic_settings`; Custom usa `R.drawable.ic_tune` (ícones distintos).
- Custom: categorias expansíveis, seleção de itens e revisão das funções selecionadas. A interface informa que nenhuma escrita é enviada ao veículo.
- Diagnóstico: seções OBD-II, VAG, EPC, DTC e testes avançados. O atalho LER DTCs não está duplicado no grupo OBD-II; CAN Investigator permanece acessível em Diagnóstico.
- Identificador Android: `v12.marcelo.virtuselm.custom003`, versão 0.03, versionCode 4 para instalação paralela se o app antigo tiver outro applicationId.

## Correção aplicada nesta revisão
- Início: removido o cartão CAN Investigator duplicado na página inicial; o CAN Investigator continua acessível pela seção de Diagnóstico.
- Início: cartão Gravação de Dados movido para a segunda linha junto de Gráficos, removendo sua duplicação na terceira linha.

## Limitações
- A tela Custom ainda é um catálogo com seleção e revisão. Não executa codificação/adaptação ECU nem envia comandos de escrita.
- ZIP verificado; compilação Android e execução no dispositivo ainda precisam ser confirmadas pelo GitHub Actions e teste no aparelho.
