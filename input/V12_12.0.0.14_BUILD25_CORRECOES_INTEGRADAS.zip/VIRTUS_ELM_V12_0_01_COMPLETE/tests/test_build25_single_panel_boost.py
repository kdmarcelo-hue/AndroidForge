from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
JAVA=(ROOT/"app/src/main/java/com/marcelo/virtuselm/MainActivity.java").read_text(encoding="utf-8")
GRADLE=(ROOT/"app/build.gradle").read_text(encoding="utf-8")
def test_version_name_and_package_preserved_build_incremented():
    assert "applicationId 'v12.marcelo.virtuselm.v12_0_14'" in GRADLE
    assert "versionName '12.0.0.14'" in GRADLE
    assert "versionCode 25" in GRADLE
def test_diagnostic_results_use_one_shared_panel():
    method=JAVA.split("private LinearLayout buildDiagnosticScreen",1)[1].split("private final LinkedHashMap<String,CheckBox>",1)[0]
    assert "PAINEL ÚNICO • DTC / VAG / RAW / RESULTADOS" in method
    assert "vagExplorerResult=diagnosticResult" in method
    assert "QUADRO DE FALHAS • DTC" not in method
    assert "VAG DIAGNOSTIC EXPLORER • SOMENTE LEITURA" not in method
def test_boost_peak_is_drawn_after_all_series_and_in_foreground():
    start=JAVA.index("private class CombinedGraphView")
    end=JAVA.index("private static class RpmSegmentBar",start)
    graph=JAVA[start:end]
    assert graph.index("drawSeries(c,combinedRpmValues") < graph.index("PICO BOOST: %.2f bar")
    assert "Color.rgb(255,214,0)" in graph
