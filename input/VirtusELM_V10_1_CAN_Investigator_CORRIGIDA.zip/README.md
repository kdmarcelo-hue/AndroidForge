# VIRTUS ELM — V10 CAN INVESTIGATOR — AUDITADA

## Base comparativa
V10 foi reconstruída sobre a estrutura funcional da V9, preservando:
- package `com.marcelo.virtuselm`;
- AGP 8.5.2 / compileSdk 34 / targetSdk 34 / minSdk 23;
- Bluetooth Classic RFCOMM SPP;
- fila única de comunicação OBD;
- inicialização ELM ATZ/ATE0/ATL0/ATS0/ATH1/ATAT1/ATI/ATDP/ATSP0;
- parser CAN/ISO-TP;
- leitura de PIDs, DTC, readiness e VIN;
- dashboard escuro da V9;
- log por seção, copiar/limpar log.

## Correções V10
- Gradle do GitHub Actions explicitamente fixado em 8.7; não depende da versão instalada pelo runner/AndroidForge.
- JDK 17 explícito.
- Não há reconexão automática durante uma operação.
- `read() == -1` é tratado como perda de sessão.
- Operações OBD ficam bloqueadas durante a captura CAN.
- Captura CAN usa leitor dedicado e sessão exclusiva.
- A tela não recebe um `append()` para cada frame em alta frequência: o log completo é preservado no histórico interno e a UI é atualizada de forma amostrada.
- Janela de memória da análise CAN limitada a 6000 frames; o log copiado preserva os frames capturados.
- Marcadores LOCK/UNLOCK são somente eventos locais.
- Nenhum comando de LOCK, UNLOCK, Security Access, Coding, Adaptation, Actuation ou Clear DTC é implementado.
- Registro do último encerramento inesperado para diagnóstico pós-falha.

## Investigador CAN — TRAVAMENTO INTERNO
Teste recomendado para o Virtus:
1. Motor ligado.
2. Conectar ao ELM.
3. `INICIAR CAPTURA CAN PASSIVA`.
4. Pressionar o botão físico interno de LOCK.
5. Tocar `MARCAR LOCK INTERNO` imediatamente depois.
6. Aguardar 2–3 segundos.
7. Pressionar o botão físico interno de UNLOCK.
8. Tocar `MARCAR UNLOCK INTERNO`.
9. `PARAR CAPTURA`.
10. `ANALISAR EVENTOS LOCK / UNLOCK` e `COPIAR LOG`.

A captura usa `AT MA` (Monitor All) e é passiva. Os marcadores não transmitem qualquer comando ao veículo.

## Limitações intencionais
A correlação de um ID CAN com LOCK/UNLOCK não prova, sozinha, que aquele frame seja um comando de atuação ou identifica o módulo responsável. A V10 apenas coleta evidência para análise posterior.

## Compilação GitHub Actions
Workflow: `.github/workflows/build.yml`
- Ubuntu latest
- Temurin JDK 17
- Gradle 8.7 explicitamente configurado
- `gradle --no-daemon --stacktrace assembleDebug`
- artefato: `VirtusELM-V10-debug`
