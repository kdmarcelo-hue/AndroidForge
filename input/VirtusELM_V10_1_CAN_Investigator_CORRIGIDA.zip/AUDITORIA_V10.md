# AUDITORIA V10 — V8 x V9 x V10

## Resultado
V10 foi revisada estaticamente antes da entrega.

### Compatibilidade de build
- V8: AGP 8.5.2 / compileSdk 34 / targetSdk 34 / minSdk 23.
- V9: AGP 8.5.2 / compileSdk 34 / targetSdk 34 / minSdk 23.
- V10: mesma base.
- Correção adicional: GitHub Actions agora fixa Gradle 8.7 e JDK 17.

A documentação oficial do Android estabelece Gradle 8.7 como mínimo para AGP 8.5 e JDK 17 para AGP 8.5.

## Comunicação
V9 já tinha fila única de I/O. V10 preserva essa fila para OBD.
A captura CAN é uma operação exclusiva e bloqueia os comandos OBD enquanto ativa.

## Socket
V10 preserva:
- fechamento explícito de InputStream/OutputStream/BluetoothSocket;
- tratamento de `read() == -1`;
- ausência de reconexão automática em falha;
- um único leitor durante captura CAN.

## UI / estabilidade
V10 evita alimentar a Main Thread com todos os frames CAN em alta frequência. Todos os frames são preservados no log interno; a interface mostra apenas amostra e contadores.

Também foi incluído registro do último encerramento inesperado.

## OBD / ISO-TP
A base V9 de parsing foi preservada em vez de reescrever os decodificadores já testados:
- PIDs suportados por bitmap 0100/0120/0140/0160;
- decodificação por ECU;
- DTC;
- VIN 0902 multi-frame;
- readiness;
- teste de ignição desligada;
- diagnóstico automático e rápido.

## Segurança funcional
Busca textual do projeto não deve encontrar comandos de atuação/segurança/codificação. A única operação nova de transmissão específica do investigador é `AT MA` precedida pelos comandos ELM de configuração da captura. Não há implementação de Lock/Unlock.

## Auditoria de arquivos
- `build.gradle`
- `settings.gradle`
- `app/build.gradle`
- `app/src/main/AndroidManifest.xml`
- `app/src/main/java/com/marcelo/virtuselm/MainActivity.java`
- `app/src/main/res/layout/activity_main.xml`
- `app/src/main/res/values/colors.xml`
- `app/src/main/res/values/styles.xml`
- `.github/workflows/build.yml`

## Limitação da auditoria
O ambiente desta sessão não possui Android SDK/Gradle instalados para executar um build Android local completo. Portanto, esta entrega é uma auditoria estática e de estrutura; o build real deve ser validado pelo GitHub Actions. O workflow foi alterado para não depender do Gradle 8.0 do ambiente que causou a falha anterior.
