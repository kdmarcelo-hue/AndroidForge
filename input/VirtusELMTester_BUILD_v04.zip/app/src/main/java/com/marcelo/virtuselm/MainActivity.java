package com.marcelo.virtuselm;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.widget.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class MainActivity extends Activity {
    BluetoothAdapter adapter;
    BluetoothSocket socket;
    InputStream in; OutputStream out;
    TextView log,status;
    Button connect;
    Handler h=new Handler(Looper.getMainLooper());
    static final UUID SPP=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    public void onCreate(Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        log=findViewById(R.id.log); status=findViewById(R.id.status); connect=findViewById(R.id.btnConnect);
        adapter=BluetoothAdapter.getDefaultAdapter();
        connect.setOnClickListener(v->startConnection());
        findViewById(R.id.btnClear).setOnClickListener(v->log.setText(""));
        requestBt();
    }

    void requestBt(){
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT,Manifest.permission.BLUETOOTH_SCAN},10);
    }

    void startConnection(){
        if(adapter==null){ msg("Bluetooth não disponível."); return; }
        if(!adapter.isEnabled()){ msg("Ative o Bluetooth do celular."); return; }
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED){requestBt();return;}
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){requestBt();return;}
        new Thread(()->{
            try{
                msg("Procurando ELM...");
                BluetoothDevice elm=null;
                if(Build.VERSION.SDK_INT<31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED){
                    Set<BluetoothDevice> paired=adapter.getBondedDevices();
                    for(BluetoothDevice d:paired){
                        String n=d.getName();
                        if(n!=null && (n.toUpperCase().contains("ELM")||n.toUpperCase().contains("OBD")||n.toUpperCase().contains("V-LINK")||n.toUpperCase().contains("OBDLINK"))){elm=d;break;}
                    }
                }
                if(elm!=null){
                    msg("ELM encontrado entre dispositivos conhecidos: "+elm.getName());
                    adapter.cancelDiscovery();
                    socket=elm.createRfcommSocketToServiceRecord(SPP);
                    socket.connect();
                } else {
                    msg("ELM não está pareado. Iniciando descoberta Bluetooth...");
                    final Object lock=new Object();
                    final BluetoothDevice[] found={null};
                    BroadcastReceiver receiver=new BroadcastReceiver(){
                        public void onReceive(Context c,Intent i){
                            if(BluetoothDevice.ACTION_FOUND.equals(i.getAction())){
                                BluetoothDevice d=i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                                if(d!=null){
                                    String n=d.getName();
                                    if(n!=null && (n.toUpperCase().contains("ELM")||n.toUpperCase().contains("OBD")||n.toUpperCase().contains("V-LINK")||n.toUpperCase().contains("OBDLINK"))){
                                        found[0]=d; synchronized(lock){lock.notifyAll();}
                                    }
                                }
                            }
                        }
                    };
                    IntentFilter f=new IntentFilter(BluetoothDevice.ACTION_FOUND);
                    registerReceiver(receiver,f);
                    adapter.startDiscovery();
                    synchronized(lock){lock.wait(12000);}
                    try{unregisterReceiver(receiver);}catch(Exception ignored){}
                    adapter.cancelDiscovery();
                    elm=found[0];
                    if(elm==null){ msg("Nenhum ELM identificado na descoberta Bluetooth."); return; }
                    msg("ELM encontrado: "+elm.getName());
                    socket=elm.createRfcommSocketToServiceRecord(SPP);
                    socket.connect();
                }
                in=socket.getInputStream(); out=socket.getOutputStream();
                msg("Bluetooth conectado.");
                send("ATZ"); Thread.sleep(1200); read();
                send("ATE0"); Thread.sleep(300); read();
                send("ATI"); Thread.sleep(500); read();
                send("ATDP"); Thread.sleep(500); read();
                send("ATSP0"); Thread.sleep(500); read();
                msg("Teste concluído. Nenhum comando de escrita/adaptação foi enviado.");
                setStatus("CONECTADO");
            }catch(Exception e){msg("Falha: "+e.getMessage()); setStatus("NÃO CONECTADO"); close();}
        }).start();
    }

    synchronized void send(String x)throws Exception{
        if(out==null)throw new Exception("ELM desconectado");
        msg(">> "+x); out.write((x+"\r").getBytes(StandardCharsets.US_ASCII)); out.flush();
    }
    void read()throws Exception{
        long end=System.currentTimeMillis()+1600; StringBuilder b=new StringBuilder();
        while(System.currentTimeMillis()<end){
            while(in!=null&&in.available()>0){int c=in.read();if(c>=0)b.append((char)c);if(c=='>'){end=System.currentTimeMillis()+100;break;}}
            Thread.sleep(25);
        }
        msg("<< "+(b.length()>0?b.toString().replace("\r","\n"):"(sem resposta)"));
    }
    void close(){try{if(socket!=null)socket.close();}catch(Exception e){}socket=null;in=null;out=null;}
    void msg(String s){h.post(()->log.append(s+"\n"));}
    void setStatus(String s){h.post(()->status.setText("Status: "+s));}
    protected void onDestroy(){close();super.onDestroy();}
}