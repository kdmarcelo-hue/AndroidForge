package com.marcelo.virtuselm;

import android.Manifest;
import android.app.*;
import android.bluetooth.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.text.method.ScrollingMovementMethod;
import android.view.*;
import android.widget.*;
import android.text.TextUtils;
import android.content.Intent;
import android.os.Build;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.drawable.GradientDrawable;
import android.content.ClipData;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

public class MainActivity extends Activity {
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothAdapter bt; private BluetoothSocket socket; private InputStream in; private OutputStream out;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private TextView status, stats, log, result;
    private LinearLayout dataScreen, homeScreen, diagnosticScreen, canScreen, configScreen, graphScreen, performanceScreen;
    private ScrollView logScroll;
    private FrameLayout appContainer;
    private LinearLayout mainShell;
    private TextView resultHome;
    private int currentScreen=0;
    private TextView dashConn, dashVin, dashIgnition, dashRpm, dashFuel, dashVolt, dashMap, dashBaro, dashBoost, dashBoostMax, dashThrottle, dashCan, dashSpeed, dashLoad, dashCoolant, dashIntake, dashOilTemp, dashOilLevel;
    private RpmSegmentBar rpmBar;
    private Button connectButton;
    private TextView healthChip;
    private int noDataCycles = 0;
    private boolean recoveringSession = false;
    private final ScheduledExecutorService dashboardExec = Executors.newSingleThreadScheduledExecutor();
    private volatile boolean dashboardPolling = false;
    private volatile boolean stopRequested = false;
    private volatile long stopDeadline = 0;
    private String lastVin = "—";
    private static final String PROFILE_VIN = "9BWDH6BZ3RP002201";
    private double lastRpm = 0, lastFuel = -1, lastVolt = -1, lastThrottle = -1, lastMap = -1, lastBaro = -1, lastBoost = -1, maxBoost = -1, lastSpeed = -1, lastLoad = -1, lastCoolant = -1, lastIntake = -1, lastOilTemp = -1;
    private String lastOilLevel = "—";
    private boolean ecuResponding = false;
    private final StringBuilder technical = new StringBuilder();
    private final Object logLock = new Object();
    private volatile boolean monitoring = false;
    private volatile boolean operationRunning = false;
    private long rawCount=0, frameCount=0, rxBytes=0;
    private final LinkedHashSet<String> ids = new LinkedHashSet<>();
    private final LinkedHashMap<String,Long> idCounts = new LinkedHashMap<>();
    private long lastStatsUi=0, lastMonitorUi=0;
    private final List<Marker> markers = new ArrayList<>();
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);
    private String lastProtocol="";
    private volatile boolean intentionalDisconnect = false;
    private volatile boolean reconnecting = false;
    private volatile boolean connected = false;
    private volatile boolean connectAttempt = false;
    // Estado da gravação de telemetria — permanece independente da navegação V11.4.
    private volatile boolean recordingActive = false;
    private BufferedWriter recordingWriter = null;
    private File recordingFile = null;
    private long recordingStartMs = 0L;
    private int recordingSamples = 0;
    private int recordingTick = 0;
    private double recordingMaxBoost = -999.0;
    private static final String PREFS_UI = "virtus_elm_ui";
    private static final String PREF_KEEP_SCREEN = "keep_screen_on";
    private GraphView graphView;
    private String graphMetric = "BOOST";
    private TextView perfPower, perfTorque, perf0100, perfFuel, perfBoost, perfStatus, perfConfidence;
    private volatile boolean performanceRunning=false;
    private volatile boolean performanceStop=false;

    /** Barra de RPM segmentada: 0–4k verde, 4–6k amarelo, 6–8k vermelho; segmentos inativos permanecem na mesma família de cor em baixa intensidade. */
    private static class GraphView extends View {
        private final Paint line=new Paint(Paint.ANTI_ALIAS_FLAG); private final Paint grid=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final ArrayDeque<Float> values=new ArrayDeque<>(); private float min=0,max=1; private String metric="BOOST";
        GraphView(Context c){super(c); setBackgroundColor(Color.rgb(2,20,38)); line.setStyle(Paint.Style.STROKE); line.setStrokeWidth(5f); grid.setStyle(Paint.Style.STROKE); grid.setStrokeWidth(1f);}
        void setMetric(String m){metric=m; values.clear(); invalidate();}
        void add(float v){if(Float.isNaN(v)||v<-999)return; values.add(v); while(values.size()>120)values.removeFirst(); if(values.isEmpty())return; min=Float.MAX_VALUE;max=-Float.MAX_VALUE; for(float x:values){min=Math.min(min,x);max=Math.max(max,x);} if(max-min<1){float c=(min+max)/2f;min=c-1;max=c+1;} invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth(),h=getHeight(); grid.setColor(Color.rgb(25,70,105)); for(int i=1;i<5;i++){float y=i*h/5f;c.drawLine(0,y,w,y,grid);} if(values.size()<2)return; line.setColor(Color.rgb(0,210,255)); float dx=w/(values.size()-1f); float prevY=0; int i=0; for(float v:values){float x=i*dx; float y=h-(v-min)/(max-min)*h; if(i>0)c.drawLine((i-1)*dx,prevY,x,y,line); prevY=y;i++;} }
        String range(){return values.isEmpty()?"—":String.format(Locale.US,"%.1f–%.1f",min,max);}
    }

    private static class RpmSegmentBar extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); private float rpm=0f;
        private final int green=Color.rgb(120,235,150), greenDim=Color.rgb(18,62,42);
        private final int yellow=Color.rgb(255,210,80), yellowDim=Color.rgb(70,58,20);
        private final int red=Color.rgb(255,82,92), redDim=Color.rgb(70,24,30);
        RpmSegmentBar(Context c){super(c); paint.setStyle(Paint.Style.FILL); setWillNotDraw(false);}
        void setRpm(double v){rpm=(float)Math.max(0,Math.min(8000,v)); invalidate();}
        @Override protected void onDraw(Canvas c){super.onDraw(c); float w=getWidth(),h=getHeight(); float gap=dpLocal(3); int n=32; float sw=(w-gap*(n-1))/n; float active=(rpm/8000f)*n;
            for(int i=0;i<n;i++){ float x=i*(sw+gap); float center=(i+0.5f)/n*8000f; boolean on=i<active; int color=center<4000? (on?green:greenDim) : center<6000? (on?yellow:yellowDim) : (on?red:redDim); paint.setColor(color); c.drawRoundRect(new RectF(x,1,x+sw,h-1),2,2,paint); }
        }
        private float dpLocal(float v){return v*getResources().getDisplayMetrics().density;}
    }

    static class Marker {
        String type; long raw, frames, bytes, when; Map<String,Long> idsAt;
        Marker(String t,long r,long f,long b,Map<String,Long> counts){
            type=t; raw=r; frames=f; bytes=b; when=System.currentTimeMillis(); idsAt=new LinkedHashMap<>(counts);
        }
    }

    @Override public void onCreate(Bundle b){ super.onCreate(b); applyKeepScreenPreference(); buildUi(); try { bt=BluetoothAdapter.getDefaultAdapter(); } catch(Exception e) { bt=null; } resetSession(); append("[00] INÍCIO DE NOVA SESSÃO — V11.6"); append("BASE COMPLETA V10 + cluster unificado + boost real por BARO + captura CAN passiva exclusiva + análise diferencial de eventos."); append("SOMENTE LEITURA: nenhum comando de atuação, coding, adaptation, security access ou CAN arbitrário é transmitido."); startDashboardPolling(); }

    private static final int BLUE = Color.rgb(13, 71, 161);
    private static final int BLUE_DARK = Color.rgb(7, 45, 99);
    private static final int BLUE_LIGHT = Color.rgb(232, 240, 254);
    private static final int BLUE_BORDER = Color.rgb(144, 180, 220);
    private static final int TEXT = Color.rgb(35, 45, 55);

    private int dp(float v){ return Math.round(v * getResources().getDisplayMetrics().density); }

    /** Feedback padrão para toda área realmente interativa: resposta visual + toque háptico. */
    private void bindClick(View v, final Runnable action){
        v.setClickable(true);
        v.setFocusable(true);
        v.setHapticFeedbackEnabled(true);
        v.setOnClickListener(view->{
            view.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
            if(action!=null) action.run();
        });
    }

    private android.graphics.drawable.Drawable pressableBg(int normalColor,int pressedColor,int strokeColor,float radius){
        android.graphics.drawable.GradientDrawable normal=new android.graphics.drawable.GradientDrawable();
        normal.setColor(normalColor); normal.setCornerRadius(dp(radius)); normal.setStroke(dp(1),strokeColor);
        android.graphics.drawable.GradientDrawable pressed=new android.graphics.drawable.GradientDrawable();
        pressed.setColor(pressedColor); pressed.setCornerRadius(dp(radius)); pressed.setStroke(dp(2),Color.rgb(0,210,255));
        android.graphics.drawable.StateListDrawable states=new android.graphics.drawable.StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed},pressed);
        states.addState(new int[]{},normal);
        return states;
    }

    private TextView tv(String s,float size){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP,size); t.setTextColor(TEXT);
        t.setIncludeFontPadding(true); t.setPadding(dp(8),dp(5),dp(8),dp(5)); return t;
    }
    private Button btn(String s){
        Button b=new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextSize(11); b.setTextColor(Color.rgb(235,248,255));
        b.setGravity(Gravity.CENTER); b.setSingleLine(true); b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(dp(50)); b.setMinimumHeight(dp(50)); b.setPadding(dp(5),dp(1),dp(5),dp(1)); b.setIncludeFontPadding(false); b.setHorizontallyScrolling(false);
        if(Build.VERSION.SDK_INT>=26){ b.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP); }
        android.graphics.drawable.GradientDrawable normal=new android.graphics.drawable.GradientDrawable();
        normal.setColor(Color.rgb(7,38,70)); normal.setCornerRadius(dp(24)); normal.setStroke(dp(1), Color.rgb(25,125,195));
        android.graphics.drawable.GradientDrawable pressed=new android.graphics.drawable.GradientDrawable();
        pressed.setColor(Color.rgb(10,70,115)); pressed.setCornerRadius(dp(24)); pressed.setStroke(dp(2), Color.rgb(0,200,255));
        android.graphics.drawable.StateListDrawable states=new android.graphics.drawable.StateListDrawable();
        states.addState(new int[]{android.R.attr.state_pressed}, pressed); states.addState(new int[]{}, normal);
        b.setBackground(states); b.setStateListAnimator(null); b.setSoundEffectsEnabled(true);
        return b;
    }
    private void addFull(LinearLayout r, View v){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(dp(6),dp(3),dp(6),dp(3)); r.addView(v,lp);
    }
    private LinearLayout row(){
        LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL);
        r.setPadding(dp(4),0,dp(4),0); return r;
    }
    private void addHalf(LinearLayout r, Button b){
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(3),0,dp(3),0);
        r.addView(b,lp);
    }
    private LinearLayout section(String title){
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        android.graphics.drawable.GradientDrawable bg=new android.graphics.drawable.GradientDrawable();
        bg.setColor(BLUE);
        bg.setCornerRadius(dp(18));
        box.setBackground(bg);
        box.setPadding(dp(14),dp(12),dp(14),dp(12));
        TextView t=tv(title,20);
        t.setTextColor(Color.WHITE);
        t.setTypeface(null,android.graphics.Typeface.BOLD);
        box.addView(t,new LinearLayout.LayoutParams(-1,-2));
        return box;
    }
    private void buildUi(){
        final int BG = Color.rgb(1,10,22), CARD = Color.rgb(3,25,49), CARD2 = Color.rgb(4,31,60);
        final int CYAN = Color.rgb(0,194,255), CYAN2 = Color.rgb(45,142,255), WHITE = Color.rgb(242,248,255), MUTED = Color.rgb(145,181,210);

        // Estrutura V11.4: cabeçalho fixo + área central de conteúdo + menu fixo.
        appContainer=new FrameLayout(this); appContainer.setBackgroundColor(BG);
        LinearLayout shell=new LinearLayout(this); shell.setOrientation(LinearLayout.VERTICAL); shell.setBackgroundColor(BG);

        // CABEÇALHO FIXO — identidade do aplicativo permanece na tela durante toda a navegação.
        LinearLayout hero=card(Color.rgb(2,20,43));
        GradientDrawable hb=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(4,38,82),Color.rgb(2,12,28)});
        hb.setCornerRadius(dp(20)); hb.setStroke(dp(1),CYAN2); hero.setBackground(hb); hero.setPadding(dp(10),dp(3),dp(10),dp(3));
        LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo=icon(R.drawable.v11_logo,CYAN); logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE); brand.addView(logo,new LinearLayout.LayoutParams(dp(60),dp(60)));
        LinearLayout bt=new LinearLayout(this); bt.setOrientation(LinearLayout.VERTICAL); bt.setGravity(Gravity.CENTER_VERTICAL); bt.setPadding(dp(6),0,0,0);
        TextView title=tv("VIRTUS",16); title.setTextColor(WHITE); title.setTypeface(null,android.graphics.Typeface.BOLD); title.setSingleLine(true); title.setGravity(Gravity.CENTER); title.setIncludeFontPadding(false);
        TextView sub=tv("V11.5  •  DIAGNÓSTICO",9.5f); sub.setTextColor(CYAN); sub.setTypeface(null,android.graphics.Typeface.BOLD); sub.setSingleLine(true); sub.setGravity(Gravity.CENTER); sub.setIncludeFontPadding(false);
        TextView strap=tv("LEITURA  •  ANÁLISE  •  CAN",8.2f); strap.setTextColor(MUTED); strap.setSingleLine(true); strap.setGravity(Gravity.CENTER); strap.setIncludeFontPadding(false); strap.setPadding(0,0,0,0);
        bt.addView(title,new LinearLayout.LayoutParams(-1,dp(23))); bt.addView(sub,new LinearLayout.LayoutParams(-1,dp(20))); bt.addView(strap,new LinearLayout.LayoutParams(-1,dp(20))); bt.setTranslationY(-dp(1));
        brand.addView(bt,new LinearLayout.LayoutParams(0,dp(70),1));
        ImageView car=new ImageView(this); car.setImageResource(R.drawable.v11_car_header_clean); car.setScaleType(ImageView.ScaleType.FIT_CENTER); LinearLayout.LayoutParams carLp=new LinearLayout.LayoutParams(dp(145),dp(78)); carLp.gravity=Gravity.BOTTOM; car.setTranslationY(dp(1)); brand.addView(car,carLp); hero.addView(brand);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(100)); hp.setMargins(dp(8),dp(5),dp(8),dp(5)); shell.addView(hero,hp);

        // ÁREA CENTRAL — somente esta região troca de tela.
        FrameLayout contentHost=new FrameLayout(this); shell.addView(contentHost,new LinearLayout.LayoutParams(-1,0,1));

        homeScreen=buildHomeScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        diagnosticScreen=buildDiagnosticScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        canScreen=buildCanScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        configScreen=buildConfigScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        dataScreen=buildDataScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        graphScreen=buildGraphScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        performanceScreen=buildPerformanceScreen(BG,CARD,CARD2,CYAN,CYAN2,WHITE,MUTED);
        contentHost.addView(homeScreen,screenLp()); contentHost.addView(dataScreen,screenLp()); contentHost.addView(diagnosticScreen,screenLp()); contentHost.addView(canScreen,screenLp()); contentHost.addView(configScreen,screenLp()); contentHost.addView(graphScreen,screenLp()); contentHost.addView(performanceScreen,screenLp());
        dataScreen.setVisibility(View.GONE); diagnosticScreen.setVisibility(View.GONE); canScreen.setVisibility(View.GONE); configScreen.setVisibility(View.GONE); graphScreen.setVisibility(View.GONE); performanceScreen.setVisibility(View.GONE);

        // MENU FIXO — navegação troca somente o conteúdo central.
        LinearLayout nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setGravity(Gravity.CENTER); nav.setPadding(dp(4),dp(5),dp(4),dp(5)); nav.setBackground(cardBg(Color.rgb(3,24,47),24,CYAN2));
        addNav(nav,R.drawable.ic_home,"Início",CYAN,()->showHomeScreen());
        addNav(nav,R.drawable.ic_chart,"Dados",Color.rgb(175,205,230),()->showDataScreen());
        addNav(nav,R.drawable.ic_engine,"Diagnóstico",Color.rgb(175,205,230),()->showDiagnosticScreen());
        addNav(nav,R.drawable.ic_can,"CAN",Color.rgb(175,205,230),()->showCanScreen());
        addNav(nav,R.drawable.ic_settings,"Config",Color.rgb(175,205,230),()->showConfigScreen());
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,dp(104)); np.setMargins(dp(5),dp(4),dp(5),dp(8)); shell.addView(nav,np);

        mainShell=shell; setContentView(shell); currentScreen=0;
    }

    private LinearLayout.LayoutParams screenLp(){ return new LinearLayout.LayoutParams(-1,-1); }

    private LinearLayout buildHomeScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout wrap=new LinearLayout(this); wrap.setOrientation(LinearLayout.VERTICAL); wrap.setBackgroundColor(BG);
        ScrollView page=new ScrollView(this); page.setFillViewport(true); page.setBackgroundColor(BG); page.setClipToPadding(false);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(10),dp(4),dp(10),dp(16)); page.addView(root,new ScrollView.LayoutParams(-1,-2)); wrap.addView(page,new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout conn=card(CARD); conn.setPadding(dp(10),dp(8),dp(10),dp(8)); LinearLayout cr=row();
        healthChip=healthChip("● OFFLINE",Color.rgb(255,88,88),Color.rgb(61,16,24)); LinearLayout.LayoutParams healthLp=new LinearLayout.LayoutParams(0,dp(58),1.12f); healthLp.setMargins(0,0,dp(3),0); cr.addView(healthChip,healthLp);
        ImageView bti=icon(R.drawable.ic_bluetooth,CYAN); LinearLayout.LayoutParams btLp=new LinearLayout.LayoutParams(0,dp(58),0.48f); btLp.setMargins(dp(3),0,dp(3),0); cr.addView(bti,btLp);
        status=tv("Pronto",9); status.setTextColor(MUTED); status.setSingleLine(true); status.setVisibility(View.GONE);
        connectButton=btn("CONECTAR ELM"); connectButton.setTextSize(11); bindClick(connectButton,()->toggleConnection()); connectButton.setMinWidth(0); connectButton.setMinimumWidth(0); LinearLayout.LayoutParams connectLp=new LinearLayout.LayoutParams(0,dp(52),1.12f); connectLp.setMargins(dp(3),0,0,0); cr.addView(connectButton,connectLp); conn.addView(cr); addFull(root,conn);

        LinearLayout live=card(CARD); live.setPadding(dp(10),dp(9),dp(10),dp(10)); LinearLayout dashHead=row(); TextView dl=tv("ROTAÇÃO DO MOTOR",13); dl.setTextColor(WHITE); dl.setTypeface(null,android.graphics.Typeface.BOLD); dashHead.addView(dl,new LinearLayout.LayoutParams(0,dp(30),1));
        TextView model=tv("",10.5f); model.setSingleLine(true); if(Build.VERSION.SDK_INT>=26){ model.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP); } model.setTextColor(WHITE); model.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); model.setTag("vehicleProfile"); dashHead.addView(model,new LinearLayout.LayoutParams(dp(160),dp(30))); live.addView(dashHead);
        LinearLayout cluster=card(CARD2); cluster.setPadding(dp(10),dp(5),dp(10),dp(8));
        LinearLayout rpmTop=row(); dashRpm=tv("0 rpm",39); dashRpm.setTextColor(WHITE); dashRpm.setTypeface(null,android.graphics.Typeface.BOLD); dashRpm.setSingleLine(true); rpmTop.addView(dashRpm,new LinearLayout.LayoutParams(0,dp(72),1)); dashIgnition=tv("IG: —",12); dashIgnition.setTextColor(CYAN); dashIgnition.setTypeface(null,android.graphics.Typeface.BOLD); dashIgnition.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); rpmTop.addView(dashIgnition,new LinearLayout.LayoutParams(dp(72),dp(72))); cluster.addView(rpmTop);
        rpmBar=new RpmSegmentBar(this); cluster.addView(rpmBar,new LinearLayout.LayoutParams(-1,dp(18))); TextView scale=tv("0       1       2       3       4       5       6       7       8",9); scale.setTextColor(MUTED); scale.setGravity(Gravity.CENTER); cluster.addView(scale,new LinearLayout.LayoutParams(-1,dp(24)));
        LinearLayout oilRow=row(); dashOilTemp=tv("🛢️ — °C",12); dashOilTemp.setTextColor(CYAN); dashOilTemp.setTypeface(null,android.graphics.Typeface.BOLD); dashOilTemp.setGravity(Gravity.CENTER_VERTICAL); dashOilLevel=tv("NÍVEL —",10); dashOilLevel.setTextColor(Color.rgb(145,181,210)); dashOilLevel.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT); oilRow.addView(dashOilTemp,new LinearLayout.LayoutParams(0,dp(30),1)); oilRow.addView(dashOilLevel,new LinearLayout.LayoutParams(0,dp(30),1)); cluster.addView(oilRow);
        LinearLayout tempRow=row(); dashCoolant=tv("TEMP. LÍQUIDO\n— °C",11); dashCoolant.setTextColor(WHITE); tempRow.addView(dashCoolant,new LinearLayout.LayoutParams(0,dp(58),1)); dashIntake=tv("TEMP. ADMISSÃO\n— °C",11); dashIntake.setTextColor(WHITE); dashIntake.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); tempRow.addView(dashIntake,new LinearLayout.LayoutParams(0,dp(58),1)); cluster.addView(tempRow);
        live.addView(cluster,new LinearLayout.LayoutParams(-1,dp(270)));
        LinearLayout g1=row(); dashSpeed=metric("VELOCIDADE","— km/h",WHITE,CYAN); dashBoost=metric("BOOST","— bar",WHITE,CYAN); dashVolt=metric("TENSÃO","— V",WHITE,CYAN); dashLoad=metric("CARGA MOTOR","— %",WHITE,CYAN); addHalfView(g1,dashSpeed);addHalfView(g1,dashBoost);addHalfView(g1,dashVolt);addHalfView(g1,dashLoad); live.addView(g1);
        LinearLayout g2=row(); dashMap=metric("MAP","— kPa",WHITE,CYAN); dashBaro=metric("BARO","— kPa",WHITE,CYAN); dashThrottle=metric("THROTTLE","— %",WHITE,CYAN); dashFuel=metric("COMBUSTÍVEL","— %",WHITE,CYAN); addHalfView(g2,dashMap);addHalfView(g2,dashBaro);addHalfView(g2,dashThrottle);addHalfView(g2,dashFuel); live.addView(g2);
        LinearLayout vehicle=row(); dashVin=tv("VIN: —\nVEÍCULO NÃO IDENTIFICADO",10.5f); dashVin.setTextColor(WHITE); dashVin.setGravity(Gravity.CENTER_VERTICAL); dashVin.setBackground(cardBg(CARD2,16,CYAN2)); vehicle.addView(dashVin,new LinearLayout.LayoutParams(0,dp(62),2)); dashCan=tv("PROTOCOLO\nCAN 11/500",11); dashCan.setTextColor(WHITE); dashCan.setGravity(Gravity.CENTER); dashCan.setBackground(cardBg(CARD2,16,CYAN2)); vehicle.addView(dashCan,new LinearLayout.LayoutParams(0,dp(62),1)); live.addView(vehicle); addFull(root,live);

        LinearLayout modHeader=row(); TextView modHead=tv("MÓDULOS",22); modHead.setTextColor(WHITE); modHead.setTypeface(null,android.graphics.Typeface.BOLD); modHead.setPadding(dp(8),dp(10),dp(8),dp(2)); modHeader.addView(modHead,new LinearLayout.LayoutParams(0,dp(46),1)); TextView modHint=tv("SELECIONE UMA FUNÇÃO",10); modHint.setTextColor(CYAN); modHint.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); modHint.setPadding(dp(8),dp(10),dp(8),dp(2)); modHeader.addView(modHint,new LinearLayout.LayoutParams(dp(170),dp(46))); addFull(root,modHeader);
        LinearLayout m1=row(); addModule(m1,R.drawable.ic_engine,"DIAGNÓSTICO","Códigos de falhas (DTC)",CYAN,()->showDiagnosticScreen()); addModule(m1,R.drawable.ic_gauge,"PERFORMANCE","Potência • torque • testes",Color.rgb(0,220,180),()->showPerformanceScreen()); addFull(root,m1);
        LinearLayout m2=row(); addModule(m2,R.drawable.ic_chart,"GRÁFICOS","Análise e histórico",Color.rgb(150,100,255),()->showGraphScreen()); addModule(m2,R.drawable.ic_can,"CAN INVESTIGATOR","Captura e análise CAN",Color.rgb(255,190,0),()->showCanScreen()); addFull(root,m2);
        LinearLayout m3=row(); addModule(m3,R.drawable.ic_document,"GRAVAÇÃO DE DADOS","Logs e exportação (CSV)",Color.rgb(255,80,90),()->showDataScreen()); addModule(m3,R.drawable.ic_vehicle,"VIRTUS / VAG","Informações do veículo",CYAN2,()->{showHomeScreen();vehicleData();}); addFull(root,m3);
        resultHome=tv("RESULTADO: —",11); resultHome.setTextColor(WHITE); resultHome.setPadding(dp(12),dp(8),dp(12),dp(8)); resultHome.setBackground(cardBg(CARD2,16,CYAN2)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(80)); rp.setMargins(dp(6),dp(3),dp(6),dp(8)); root.addView(resultHome,rp);
        return wrap;
    }

    private LinearLayout buildDiagnosticScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG); ScrollView sv=new ScrollView(this); sv.setFillViewport(true); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); sv.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        diagSection=section("DIAGNÓSTICO OBD-II"); addFull(root,diagSection);
        LinearLayout r1=row(); Button quick=btn("DIAGNÓSTICO RÁPIDO"); bindClick(quick,()->quickDiagnostic()); addFull(r1,quick); addFull(root,r1);
        LinearLayout r2=row(); Button data=btn("LER DADOS"); bindClick(data,()->vehicleData()); Button auto=btn("DIAGNÓSTICO COMPLETO"); bindClick(auto,()->automaticDiagnostic()); addHalf(r2,data); addHalf(r2,auto); addFull(root,r2);
        LinearLayout r3=row(); Button dtc=btn("DTC"); bindClick(dtc,()->readDtc()); Button vin=btn("VIN"); bindClick(vin,()->readVin()); addHalf(r3,dtc); addHalf(r3,vin); addFull(root,r3);
        LinearLayout r4=row(); Button statusObd=btn("STATUS / READINESS"); bindClick(statusObd,()->obdStatus()); Button o2=btn("MONITORAMENTO SONDA"); bindClick(o2,()->o2Test()); addHalf(r4,statusObd); addHalf(r4,o2); addFull(root,r4);
        LinearLayout r5=row(); Button ignition=btn("IGNIÇÃO OFF"); bindClick(ignition,()->ignitionOffTest()); Button body=btn("ESTUDO DE MÓDULOS"); bindClick(body,()->bodyStudy()); addHalf(r5,ignition); addHalf(r5,body); addFull(root,r5);
        Button dtcff=btn("DTC + FREEZE FRAME"); bindClick(dtcff,()->dtcFreeze()); addFull(root,dtcff);
        return screen;
    }

    private LinearLayout buildCanScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG); ScrollView sv=new ScrollView(this); sv.setFillViewport(true); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); sv.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        canSection=section("CAN INVESTIGATOR • SOMENTE LEITURA"); addFull(root,canSection);
        LinearLayout canStatus=card(CARD2); canStatus.setPadding(dp(12),dp(10),dp(12),dp(10)); TextView cst=tv("STATUS DA CAPTURA CAN",12); cst.setTextColor(CYAN); cst.setTypeface(null,android.graphics.Typeface.BOLD); canStatus.addView(cst); stats=tv("RAW: 0 • FRAMES: 0 • IDs: 0 • BYTES: 0",18); stats.setTextColor(WHITE); stats.setTypeface(null,android.graphics.Typeface.BOLD); stats.setSingleLine(true); canStatus.addView(stats); TextView canHint=tv("Monitor All • sem transmissão CAN arbitrária",10); canHint.setTextColor(MUTED); canStatus.addView(canHint); addFull(root,canStatus);
        LinearLayout r6=row(); Button cap=btn("▶  CAPTURAR CAN"); bindClick(cap,()->startMonitor()); Button stop=btn("■  FINALIZAR"); bindClick(stop,()->stopMonitor()); addHalf(r6,cap); addHalf(r6,stop); addFull(root,r6);
        LinearLayout r7=row(); Button lock=btn("LOCK"); bindClick(lock,()->mark("LOCK")); Button unlock=btn("UNLOCK"); bindClick(unlock,()->mark("UNLOCK")); addHalf(r7,lock); addHalf(r7,unlock); addFull(root,r7);
        LinearLayout r8=row(); Button ss=btn("START / STOP"); bindClick(ss,()->mark("START-STOP")); Button trunk=btn("PORTA-MALAS"); bindClick(trunk,()->mark("PORTA-MALAS")); addHalf(r8,ss); addHalf(r8,trunk); addFull(root,r8);
        LinearLayout r9=row(); Button farol=btn("FAROL / OUTRO"); bindClick(farol,()->mark("FAROL-OUTRO")); Button analyze=btn("ANALISAR DIFERENÇAS"); bindClick(analyze,()->analyze()); addHalf(r9,farol); addHalf(r9,analyze); addFull(root,r9);
        return screen;
    }

    private LinearLayout buildConfigScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG); ScrollView sv=new ScrollView(this); sv.setFillViewport(true); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); sv.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        configSection=section("CONFIGURAÇÕES"); addFull(root,configSection);
        LinearLayout keepRow=card(CARD2); keepRow.setPadding(dp(12),dp(8),dp(12),dp(8)); LinearLayout keepInner=new LinearLayout(this); keepInner.setOrientation(LinearLayout.HORIZONTAL); keepInner.setGravity(Gravity.CENTER_VERTICAL); LinearLayout keepTexts=new LinearLayout(this); keepTexts.setOrientation(LinearLayout.VERTICAL); keepTexts.setGravity(Gravity.CENTER_VERTICAL);
        TextView keepTitle=tv("MANTER TELA LIGADA",13); keepTitle.setTextColor(WHITE); keepTitle.setTypeface(null,android.graphics.Typeface.BOLD); keepTitle.setSingleLine(true); TextView keepSub=tv("Evita o desligamento automático enquanto o VIRTUS ELM estiver aberto",9); keepSub.setTextColor(MUTED); keepSub.setSingleLine(false); keepTexts.addView(keepTitle); keepTexts.addView(keepSub); keepInner.addView(keepTexts,new LinearLayout.LayoutParams(0,-2,1));
        android.widget.Switch keepSwitch=new android.widget.Switch(this); keepSwitch.setText(""); keepSwitch.setChecked(isKeepScreenOnEnabled()); keepSwitch.setHapticFeedbackEnabled(true); keepSwitch.setOnCheckedChangeListener((buttonView,isChecked)->{ buttonView.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY); getSharedPreferences(PREFS_UI,MODE_PRIVATE).edit().putBoolean(PREF_KEEP_SCREEN,isChecked).apply(); applyKeepScreenPreference(); toast(isChecked ? "Tela permanecerá ligada" : "Desligamento automático restaurado"); }); keepInner.addView(keepSwitch,new LinearLayout.LayoutParams(dp(64),dp(52))); keepRow.addView(keepInner); addFull(root,keepRow);
        return screen;
    }

    private LinearLayout buildDataScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG);
        LinearLayout header=card(CARD); header.setPadding(dp(10),dp(8),dp(10),dp(8)); TextView h=tv("DADOS / LOGS",18); h.setTextColor(WHITE); h.setTypeface(null,android.graphics.Typeface.BOLD); h.setGravity(Gravity.CENTER); header.addView(h,new LinearLayout.LayoutParams(-1,dp(42))); LinearLayout tabs=row(); Button telemetry=btn("TELEMETRIA"); Button graphs=btn("GRÁFICOS"); Button logs=btn("LOGS"); bindClick(telemetry,()->showDataScreen()); bindClick(graphs,()->showGraphScreen()); bindClick(logs,()->showDataScreen()); addHalf(tabs,telemetry);addHalf(tabs,graphs);addHalf(tabs,logs); header.addView(tabs); addFull(screen,header);
        LinearLayout rec=card(CARD2); rec.setPadding(dp(12),dp(8),dp(12),dp(8)); TextView rt=tv("GRAVAÇÃO DE TELEMETRIA",12); rt.setTextColor(CYAN); rt.setTypeface(null,android.graphics.Typeface.BOLD); rec.addView(rt); TextView rs=tv("MAP / BARO / BOOST / RPM em alta frequência",10); rs.setTextColor(MUTED); rec.addView(rs); TextView rm=tv("BOOST MÁX.: — bar",15); rm.setTextColor(WHITE); rm.setTypeface(null,android.graphics.Typeface.BOLD); rm.setTag("recordMax"); rec.addView(rm); TextView rf=tv("Arquivo: —",9); rf.setTextColor(MUTED); rf.setTag("recordFile"); rec.addView(rf); screen.addView(rec,new LinearLayout.LayoutParams(-1,dp(105)));
        LinearLayout rr1=row(); Button recStart=btn("●  INICIAR GRAVAÇÃO"); bindClick(recStart,()->startRecording()); Button recStop=btn("■  FINALIZAR GRAVAÇÃO"); bindClick(recStop,()->stopRecording()); addHalf(rr1,recStart); addHalf(rr1,recStop); addFull(screen,rr1);
        LinearLayout rr2=row(); Button recSummary=btn("RESUMO DA SESSÃO"); bindClick(recSummary,()->showRecordingSummary()); Button recCopy=btn("COPIAR CSV"); bindClick(recCopy,()->copyCsv()); addHalf(rr2,recSummary); addHalf(rr2,recCopy); addFull(screen,rr2);
        LinearLayout logHeader=card(CARD2); logHeader.setPadding(dp(10),dp(6),dp(10),dp(6)); TextView lt=tv("LOG TÉCNICO — ATUALIZAÇÃO EM TEMPO REAL",11); lt.setTextColor(CYAN); lt.setTypeface(null,android.graphics.Typeface.BOLD); logHeader.addView(lt); screen.addView(logHeader,new LinearLayout.LayoutParams(-1,dp(42)));
        logScroll=new ScrollView(this); logScroll.setFillViewport(false); logScroll.setBackground(cardBg(Color.rgb(2,20,38),18,Color.rgb(25,80,120))); logScroll.setClipToPadding(true); log=tv("",10); log.setTextColor(Color.rgb(185,210,230)); log.setTextIsSelectable(true); log.setPadding(dp(12),dp(12),dp(12),dp(12)); logScroll.addView(log,new ScrollView.LayoutParams(-1,-2)); LinearLayout.LayoutParams lsp=new LinearLayout.LayoutParams(-1,0,1); lsp.setMargins(dp(6),dp(4),dp(6),dp(4)); screen.addView(logScroll,lsp);
        LinearLayout tools=row(); Button copy=btn("COPIAR LOG"); bindClick(copy,()->copyLog()); Button clear=btn("LIMPAR LOG"); bindClick(clear,()->clearLog()); addHalf(tools,copy); addHalf(tools,clear); addFull(screen,tools);
        result=tv("RESULTADO: —",11); result.setTextColor(WHITE); result.setPadding(dp(12),dp(8),dp(12),dp(8)); result.setBackground(cardBg(CARD2,16,CYAN2)); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(58)); rp.setMargins(dp(6),0,dp(6),dp(2)); screen.addView(result,rp);
        return screen;
    }

    private LinearLayout buildGraphScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG);
        LinearLayout header=card(CARD); header.setPadding(dp(10),dp(6),dp(10),dp(6)); TextView h=tv("GRÁFICOS • LIVE",18); h.setTextColor(WHITE); h.setTypeface(null,android.graphics.Typeface.BOLD); h.setGravity(Gravity.CENTER); header.addView(h,new LinearLayout.LayoutParams(-1,dp(38))); screen.addView(header,new LinearLayout.LayoutParams(-1,dp(52)));
        LinearLayout sel=row(); String[] ms={"RPM","BOOST","THROTTLE","VELOCIDADE"}; for(String m:ms){Button b=btn(m); b.setMinWidth(0); b.setMinimumWidth(0); b.setSingleLine(true); b.setTextSize(10); b.setPadding(dp(2),0,dp(2),0); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(0,dp(54),1); gp.setMargins(dp(2),dp(3),dp(2),dp(3)); sel.addView(b,gp); final String metricName=m; bindClick(b,()->{graphMetric=metricName; graphView.setMetric(metricName);});} addFull(screen,sel);
        graphView=new GraphView(this); graphView.setMetric(graphMetric); screen.addView(graphView,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout info=card(CARD2); info.setPadding(dp(12),dp(8),dp(12),dp(8)); TextView v=tv("LIVE • dados em tempo real",12); v.setTextColor(CYAN); v.setTypeface(null,android.graphics.Typeface.BOLD); info.addView(v); TextView r=tv("Faixa atual: —",10); r.setTextColor(MUTED); r.setTag("graphRange"); info.addView(r); screen.addView(info,new LinearLayout.LayoutParams(-1,dp(55)));
        Button back=btn("← DADOS"); bindClick(back,()->showDataScreen()); addFull(screen,back); return screen;
    }

    private LinearLayout buildPerformanceScreen(int BG,int CARD,int CARD2,int CYAN,int CYAN2,int WHITE,int MUTED){
        LinearLayout screen=new LinearLayout(this); screen.setOrientation(LinearLayout.VERTICAL); screen.setPadding(dp(10),dp(4),dp(10),dp(10)); screen.setBackgroundColor(BG);
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(0,0,0,dp(12)); sv.addView(root,new ScrollView.LayoutParams(-1,-2)); screen.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout h=card(CARD); h.setPadding(dp(12),dp(8),dp(12),dp(8)); TextView ht=tv("🏁 PERFORMANCE",19); ht.setTextColor(WHITE); ht.setTypeface(null,android.graphics.Typeface.BOLD); ht.setGravity(Gravity.CENTER); h.addView(ht,new LinearLayout.LayoutParams(-1,dp(34))); TextView hs=tv("Estimativa longitudinal • somente leitura",10); hs.setTextColor(MUTED); hs.setGravity(Gravity.CENTER); h.addView(hs,new LinearLayout.LayoutParams(-1,dp(25))); addFull(root,h);
        LinearLayout vals=row(); perfPower=perfValue("POTÊNCIA ESTIMADA","— cv",CYAN); perfTorque=perfValue("TORQUE ESTIMADO","— Nm",Color.rgb(0,220,180)); addHalfView(vals,perfPower); addHalfView(vals,perfTorque); addFull(root,vals);
        LinearLayout vals2=row(); perf0100=perfValue("0–100 km/h","— s",Color.rgb(150,100,255)); perfBoost=perfValue("BOOST MÁX.","— bar",Color.rgb(255,190,0)); addHalfView(vals2,perf0100); addHalfView(vals2,perfBoost); addFull(root,vals2);
        LinearLayout meta=card(CARD2); meta.setPadding(dp(12),dp(8),dp(12),dp(8)); perfFuel=tv("COMBUSTÍVEL: leitura disponível pela ECU / ajuste manual do teste",10); perfFuel.setTextColor(WHITE); perfFuel.setGravity(Gravity.CENTER_VERTICAL); meta.addView(perfFuel,new LinearLayout.LayoutParams(-1,dp(30))); perfConfidence=tv("CONFIANÇA: —",10); perfConfidence.setTextColor(MUTED); meta.addView(perfConfidence,new LinearLayout.LayoutParams(-1,dp(28))); perfStatus=tv("PRONTO PARA TESTE",10); perfStatus.setTextColor(CYAN); perfStatus.setTypeface(null,android.graphics.Typeface.BOLD); perfStatus.setGravity(Gravity.CENTER); meta.addView(perfStatus,new LinearLayout.LayoutParams(-1,dp(30))); addFull(root,meta);
        LinearLayout actions=row(); Button start=btn("🏁 INICIAR 0–100"); bindClick(start,()->startPerformanceTest()); Button stop=btn("■ FINALIZAR"); bindClick(stop,()->stopPerformanceTest()); addHalf(actions,start); addHalf(actions,stop); addFull(root,actions);
        Button data=btn("VER GRÁFICOS DO TESTE"); bindClick(data,()->showGraphScreen()); addFull(root,data);
        TextView note=tv("A potência é uma estimativa baseada na dinâmica longitudinal do veículo. Não substitui dinamômetro. O resultado depende de massa, inclinação, aderência e condições do teste.",9); note.setTextColor(MUTED); note.setGravity(Gravity.CENTER); note.setPadding(dp(10),dp(8),dp(10),dp(8)); addFull(root,note);
        return screen;
    }
    private TextView perfValue(String label,String value,int accent){ TextView t=tv("",10); t.setTextColor(Color.rgb(242,248,255)); t.setGravity(Gravity.CENTER); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setBackground(cardBg(Color.rgb(5,34,64),16,accent)); setPerfText(t,label,value); return t; }
    private void setPerfText(TextView t,String label,String value){ if(t==null)return; t.setText(label+"\n"+value); }

    private void showScreen(int screen){
        currentScreen=screen;
        if(homeScreen!=null)homeScreen.setVisibility(screen==0?View.VISIBLE:View.GONE);
        if(dataScreen!=null)dataScreen.setVisibility(screen==1?View.VISIBLE:View.GONE);
        if(diagnosticScreen!=null)diagnosticScreen.setVisibility(screen==2?View.VISIBLE:View.GONE);
        if(canScreen!=null)canScreen.setVisibility(screen==3?View.VISIBLE:View.GONE);
        if(configScreen!=null)configScreen.setVisibility(screen==4?View.VISIBLE:View.GONE);
        if(graphScreen!=null)graphScreen.setVisibility(screen==5?View.VISIBLE:View.GONE);
        if(performanceScreen!=null)performanceScreen.setVisibility(screen==6?View.VISIBLE:View.GONE);
        if(screen==1){ if(log!=null&&log.getText().length()==0){synchronized(logLock){log.setText(technical.toString());}} if(logScroll!=null)logScroll.post(()->logScroll.fullScroll(View.FOCUS_DOWN)); updateRecordingUi(); }
    }
    private void showHomeScreen(){showScreen(0);}
    private void showDataScreen(){showScreen(1);}
    private void showDiagnosticScreen(){showScreen(2);}
    private void showCanScreen(){showScreen(3);}
    private void showConfigScreen(){showScreen(4);}
    private void showGraphScreen(){showScreen(5);}
    private void showPerformanceScreen(){showScreen(6);}

    private LinearLayout diagSection, canSection, logSection, configSection, recordSection;
    private GradientDrawable cardBg(int color,float radius,int stroke){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); g.setStroke(dp(1),stroke); return g; }
    private LinearLayout card(int color){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setBackground(cardBg(color,22,Color.rgb(20,95,150))); return l; }
    private ImageView icon(int res,int tint){ ImageView v=new ImageView(this); v.setImageResource(res); v.setColorFilter(tint); v.setScaleType(ImageView.ScaleType.CENTER_INSIDE); return v; }
    private TextView metric(String label,String value,int fg,int accent){ TextView t=tv("",10); t.setTextColor(fg); t.setGravity(Gravity.CENTER); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setSingleLine(false); t.setIncludeFontPadding(false); t.setPadding(dp(2),dp(5),dp(2),dp(5)); t.setBackground(cardBg(Color.rgb(5,34,64),16,accent)); setMetricText(t,label,value,""); return t; }
    private void setMetricText(TextView t,String label,String value,String unit){ if(t==null)return; String v=value==null?"—":value; String u=unit==null?"":unit; android.text.SpannableStringBuilder b=new android.text.SpannableStringBuilder(); int a=b.length(); b.append(label); b.setSpan(new android.text.style.AbsoluteSizeSpan(dp(9)),a,b.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); b.setSpan(new android.text.style.ForegroundColorSpan(Color.rgb(150,190,220)),a,b.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); b.append("\n"); int c=b.length(); b.append(v); b.setSpan(new android.text.style.AbsoluteSizeSpan(dp(18)),c,b.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); b.append("\n"); int d=b.length(); b.append(u); b.setSpan(new android.text.style.AbsoluteSizeSpan(dp(9)),d,b.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE); t.setText(b); }
    private void addHalfView(LinearLayout r,TextView t){ LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(98),1); lp.setMargins(dp(3),dp(3),dp(3),dp(3)); r.addView(t,lp); }
    private void addModule(LinearLayout r,int iconRes,String title,String sub,int accent,final Runnable action){
        LinearLayout c=card(Color.rgb(4,28,55)); c.setPadding(dp(7),dp(6),dp(7),dp(6)); c.setBackground(pressableBg(Color.rgb(4,28,55),Color.rgb(8,58,92),accent,18));
        LinearLayout inner=new LinearLayout(this); inner.setOrientation(LinearLayout.HORIZONTAL); inner.setGravity(Gravity.CENTER_VERTICAL);
        ImageView ic=icon(iconRes,accent); ic.setScaleType(ImageView.ScaleType.CENTER_INSIDE); inner.addView(ic,new LinearLayout.LayoutParams(dp(46),dp(86)));
        LinearLayout texts=new LinearLayout(this); texts.setOrientation(LinearLayout.VERTICAL); texts.setGravity(Gravity.CENTER_VERTICAL); texts.setPadding(dp(5),0,dp(2),0);
        TextView a=tv(title,10.5f); a.setTextColor(Color.WHITE); a.setTypeface(null,android.graphics.Typeface.BOLD); a.setSingleLine(true); a.setEllipsize(TextUtils.TruncateAt.END); a.setGravity(Gravity.CENTER_VERTICAL);
        if(Build.VERSION.SDK_INT>=26){ a.setAutoSizeTextTypeUniformWithConfiguration(8,11,1,android.util.TypedValue.COMPLEX_UNIT_SP); }
        TextView b=tv(sub,8.2f); b.setTextColor(Color.rgb(165,195,220)); b.setSingleLine(true); b.setEllipsize(TextUtils.TruncateAt.END); b.setGravity(Gravity.CENTER_VERTICAL);
        if(Build.VERSION.SDK_INT>=26){ b.setAutoSizeTextTypeUniformWithConfiguration(7,9,1,android.util.TypedValue.COMPLEX_UNIT_SP); }
        texts.addView(a,new LinearLayout.LayoutParams(-1,dp(34))); texts.addView(b,new LinearLayout.LayoutParams(-1,dp(30)));
        inner.addView(texts,new LinearLayout.LayoutParams(0,dp(78),1));
        TextView arrow=tv("›",23); arrow.setTextColor(accent); arrow.setGravity(Gravity.CENTER); arrow.setIncludeFontPadding(false); inner.addView(arrow,new LinearLayout.LayoutParams(dp(16),dp(70)));
        c.addView(inner); bindClick(c,action); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(110),1); lp.setMargins(dp(4),dp(4),dp(4),dp(4)); r.addView(c,lp);
    }
    private void addNav(LinearLayout nav,int iconRes,String label,int accent,final Runnable action){ LinearLayout item=new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setGravity(Gravity.CENTER); ImageView i=icon(iconRes,accent); TextView n=tv(label,11); n.setTextColor(accent); n.setGravity(Gravity.CENTER); item.addView(i,new LinearLayout.LayoutParams(-1,dp(52))); item.addView(n,new LinearLayout.LayoutParams(-1,dp(30))); item.setPadding(dp(3),dp(2),dp(3),dp(2)); item.setBackground(pressableBg(Color.TRANSPARENT,Color.rgb(8,52,88),Color.TRANSPARENT,16)); bindClick(item,action); nav.addView(item,new LinearLayout.LayoutParams(0,-1,1)); }
    private void scrollToSection(LinearLayout root,View v){ if(v==null)return; v.post(()->{ ScrollView sv=(ScrollView)root.getParent(); if(sv!=null)sv.smoothScrollTo(0,Math.max(0,v.getTop()-16)); }); }

    private TextView healthChip(String text,int fg,int bg){ TextView t=tv(text,11); t.setTypeface(null,android.graphics.Typeface.BOLD); t.setTextColor(fg); t.setGravity(Gravity.CENTER); t.setPadding(dp(6),dp(5),dp(6),dp(5)); t.setSingleLine(false); t.setMaxLines(2); if(Build.VERSION.SDK_INT>=26){ t.setAutoSizeTextTypeUniformWithConfiguration(9,11,1,android.util.TypedValue.COMPLEX_UNIT_SP); } android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(bg); g.setCornerRadius(dp(30)); g.setStroke(dp(1),fg); t.setBackground(g); return t; }
    private void setHealth(String mode,String detail){ ui(()->{ if(healthChip==null)return; String text; int fg,bg; if("GREEN".equals(mode)){ text="● SISTEMA OK"; fg=Color.rgb(0,190,120); bg=Color.rgb(7,52,48); } else if("YELLOW".equals(mode)){ text="● ATENÇÃO"; fg=Color.rgb(255,184,45); bg=Color.rgb(61,45,9); } else { text="● OFFLINE"; fg=Color.rgb(255,88,88); bg=Color.rgb(61,16,24); } healthChip.setText(text); healthChip.setTextColor(fg); android.graphics.drawable.GradientDrawable g=new android.graphics.drawable.GradientDrawable(); g.setColor(bg); g.setCornerRadius(dp(30)); g.setStroke(dp(1),fg); healthChip.setBackground(g); }); }
    private void addHalfText(LinearLayout r, TextView t){ LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1); lp.setMargins(dp(2),0,dp(2),0); r.addView(t,lp); }
    private void resetSession(){ monitoring=false; operationRunning=false; markers.clear(); rawCount=frameCount=rxBytes=0; ids.clear(); noDataCycles=0; recoveringSession=false; closeSocket(); }
    private boolean hasBluetoothPermission(){
        if(Build.VERSION.SDK_INT<31) return true;
        try { return checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED; }
        catch(Throwable e){ return false; }
    }
    private void applyConnectStyle(boolean isConnected){ ui(()->{ if(connectButton==null)return; GradientDrawable g=new GradientDrawable(); g.setCornerRadius(dp(24)); if(isConnected){ g.setColor(Color.rgb(48,12,22)); g.setStroke(dp(2),Color.rgb(255,82,82)); connectButton.setText("⛓  DESCONECTAR"); connectButton.setTextColor(Color.WHITE); } else { g.setColor(Color.rgb(7,38,70)); g.setStroke(dp(1),Color.rgb(25,125,195)); connectButton.setText("CONECTAR ELM"); connectButton.setTextColor(Color.rgb(235,248,255)); } connectButton.setBackground(g); }); }

    private void toggleConnection(){
        try{
            if(connectAttempt || operationRunning){ setStatus("Conexão em andamento — aguarde a conclusão"); return; }
            if(connected){ if(monitoring){toast("Finalize a captura antes de desconectar");return;} if(recordingActive){toast("Finalize a gravação antes de desconectar");return;} disconnect(); }
            else connect();
        }catch(Throwable t){
            append("ERRO NO BOTÃO DE CONEXÃO: "+t.getClass().getSimpleName()+" — "+String.valueOf(t.getMessage()));
            setStatus("Falha de conexão — aplicativo mantido aberto");
            ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});
        }
    }
    private void disconnect(){
        try{io.execute(()->{
            operationRunning=true; intentionalDisconnect=true; monitoring=false; stopRequested=true; connected=false;
            try{closeSocket();}catch(Throwable ignored){} noDataCycles=0;
            setHealth("RED","DESCONECTADO"); setStatus("Bluetooth desconectado");
            ui(()->{if(connectButton!=null){connectButton.setEnabled(true);} applyConnectStyle(false);if(dashConn!=null){dashConn.setText("● ELM: DESCONECTADO");dashConn.setTextColor(Color.rgb(150,35,35));}});
            append("ELM desconectado pelo usuário."); operationRunning=false;
        });}catch(Throwable t){operationRunning=false;append("ERRO AO DESCONECTAR: "+t.getClass().getSimpleName());ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});}
    }
    private void connect(){
        try{
            if(connectAttempt||operationRunning){setStatus("Conexão já em andamento — aguarde");return;}
            connectAttempt=true;
            ui(()->{if(connectButton!=null)connectButton.setEnabled(false);});
            if(Build.VERSION.SDK_INT>=31&&!hasBluetoothPermission()){
                connectAttempt=false;
                ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});
                setStatus("Permissão 'Dispositivos por perto' necessária");
                requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},20); return;
            }
            if(bt==null){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});setStatus("Bluetooth indisponível neste aparelho");return;}
            boolean enabled; try{enabled=bt.isEnabled();}catch(Throwable e){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});setStatus("Permissão Bluetooth não concedida");return;}
            if(!enabled){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});setStatus("Bluetooth desligado — ative o Bluetooth e tente novamente");return;}
            try{io.execute(()->connectWorker());}catch(Throwable t){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});append("ERRO AO AGENDAR CONEXÃO: "+t.getClass().getSimpleName());}
        }catch(Throwable t){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});append("ERRO AO INICIAR CONEXÃO: "+t.getClass().getSimpleName()+" — "+String.valueOf(t.getMessage()));setStatus("Falha ao iniciar conexão — aplicativo mantido aberto");}
    }
    private void connectWorker(){
        if(operationRunning||monitoring){connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true);setStatus("Operação em andamento — finalize antes de reconectar");});return;}
        operationRunning=true;intentionalDisconnect=false;connected=false;
        try{
            closeSocket(); if(bt==null)throw new IOException("BluetoothAdapter indisponível");
            if(Build.VERSION.SDK_INT>=31&&!hasBluetoothPermission())throw new SecurityException("BLUETOOTH_CONNECT não concedida");
            BluetoothDevice dev=null; Set<BluetoothDevice> bonded=bt.getBondedDevices();
            if(bonded!=null)for(BluetoothDevice d:bonded){String n=null;try{n=d.getName();}catch(Throwable ignored){}if(n!=null){String u=n.toUpperCase(Locale.US);if(u.contains("OBD")||u.contains("ELM")||u.contains("V-LINK")||u.contains("OBDLINK")){dev=d;break;}}}
            if(dev==null){append("ELM não encontrado entre os dispositivos Bluetooth pareados.");setStatus("OBDII não encontrado — aplicativo mantido aberto");setHealth("YELLOW","ELM NÃO ENCONTRADO");return;}
            append("ELM encontrado: "+safeDeviceName(dev));
            socket=dev.createRfcommSocketToServiceRecord(SPP);socket.connect();in=socket.getInputStream();out=socket.getOutputStream();connected=true;
            setStatus("Bluetooth conectado — inicializando ELM");setHealth("YELLOW","ELM CONECTADO");
            ui(()->{applyConnectStyle(true);if(dashConn!=null){dashConn.setText("● ELM: CONECTADO");dashConn.setTextColor(BLUE);}});
            send("ATZ",2500);send("ATE0",1000);send("ATL0",1000);send("ATS1",1000);send("ATH1",1000);send("ATAT1",1000);String dp=send("ATDP",1800);lastProtocol=dp;send("ATSP0",2500);append("Inicialização concluída.");
            maxBoost=-1;lastBaro=-1;lastBoost=-1;lastOilTemp=-1;lastOilLevel="—";recordingMaxBoost=-999;noDataCycles=0;recoveringSession=false;setHealth("YELLOW","AGUARDANDO OBD");ui(()->updateDashboard());
        }catch(SecurityException e){connected=false;append("ERRO CONEXÃO/PERMISSÃO: "+String.valueOf(e.getMessage()));setStatus("Permissão Bluetooth não concedida — aplicativo mantido aberto");closeSocket();}
        catch(IOException e){connected=false;append("ERRO CONEXÃO: "+String.valueOf(e.getMessage()));setStatus("Falha de comunicação — ELM não conectado");closeSocket();}
        catch(Throwable t){connected=false;append("ERRO CONEXÃO: "+t.getClass().getSimpleName()+" — "+String.valueOf(t.getMessage()));setStatus("Falha inesperada — aplicativo mantido aberto");closeSocket();}
        finally{operationRunning=false;connectAttempt=false;ui(()->{if(connectButton!=null)connectButton.setEnabled(true); if(!connected){applyConnectStyle(false); if(dashConn!=null){dashConn.setText("● ELM: DESCONECTADO");dashConn.setTextColor(Color.rgb(150,35,35));}}});}
    }
    private String safeDeviceName(BluetoothDevice d){try{String n=d.getName();return n==null?"OBDII":n;}catch(Throwable t){return "OBDII";}}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] grantResults){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if(requestCode==20){
            boolean ok=false;
            for(int i=0;i<permissions.length&&i<grantResults.length;i++)if(Manifest.permission.BLUETOOTH_CONNECT.equals(permissions[i])){ok=grantResults[i]==PackageManager.PERMISSION_GRANTED;break;}
            if(ok){setStatus("Permissão concedida — conectando ao ELM");connect();}
            else{setStatus("Permissão Bluetooth não concedida");ui(()->{if(connectButton!=null)connectButton.setEnabled(true);});}
        }
    }

    private void dashboardSnapshot(){
        if(out==null||in==null||monitoring||operationRunning) return;
        try{
            String rpm=send("010C",900); String speed=send("010D",900); String load=send("0104",900); String coolant=send("0105",900); String intake=send("010F",900); String oil=send("015C",900); String fuel=send("012F",900); String volt=send("0142",900); String thr=send("0111",900); String map=send("010B",900); String baro=send("0133",900); String vin=send("0902",1500);
            boolean gotObd = rpm.matches("(?s).*41\\s*0C.*") || fuel.matches("(?s).*41\\s*2F.*") || map.matches("(?s).*41\\s*0B.*");
            if(gotObd){
                noDataCycles=0; ecuResponding=true;
                lastRpm=parseObdNumeric(rpm, "010C"); lastSpeed=parseObdNumeric(speed,"010D"); lastLoad=parseLoad(load); lastCoolant=parseCoolant(coolant); lastIntake=parseIntakeTemp(intake); lastOilTemp=parseOilTemp(oil); lastFuel=parseObdNumeric(fuel,"012F"); lastVolt=parseVoltage(volt); lastThrottle=parseThrottle(thr); lastMap=parseMap(map); lastBaro=parseBaro(baro); lastBoost=calculateBoost(lastMap,lastBaro); if(lastBoost>=0 && lastBoost>maxBoost) maxBoost=lastBoost;
                String pv=parseVin(vin); if(!pv.isEmpty()) lastVin=pv;
                setHealth("GREEN","OBD ATIVO");
            } else {
                noDataCycles++; ecuResponding=false;
                setHealth("YELLOW", "ELM CONECTADO • SEM DADOS");
                append("WATCHDOG OBD: ciclo sem resposta ("+noDataCycles+").");
                if(noDataCycles==2 && !recoveringSession){ recoverObdSession(); }
                else if(noDataCycles>=4 && !recoveringSession){ append("WATCHDOG OBD: sem recuperação após 4 ciclos; reconexão automática será iniciada."); intentionalDisconnect=false; closeSocket(); setHealth("RED","RECONEXÃO AUTOMÁTICA"); scheduleReconnect(); }
            }
            ui(()->updateDashboard());
        }catch(Exception e){ ecuResponding=false; setHealth("YELLOW","ELM CONECTADO • ERRO RX"); append("WATCHDOG OBD: erro de leitura — "+e.getClass().getSimpleName()); }
    }
    private void recoverObdSession(){
        recoveringSession=true;
        io.execute(()->{ try{ append("WATCHDOG OBD: recuperando sessão no mesmo socket."); send("AT AR",900); send("ATSP0",1200); send("ATAT1",700); append("WATCHDOG OBD: sessão OBD reinicializada."); }catch(Exception e){ append("WATCHDOG OBD: falha na recuperação — "+e.getMessage()); } finally { recoveringSession=false; } });
    }
    private double parseObdNumeric(String r,String pid){ try{String u=r.toUpperCase(Locale.US).replaceAll("[^0-9A-F ]"," ").replaceAll("\\s+"," ").trim(); Matcher m=Pattern.compile("41\\s*"+pid.substring(2)+"\\s*([0-9A-F]{2})(?:\\s*([0-9A-F]{2}))?").matcher(u); if(!m.find())return -1; int a=Integer.parseInt(m.group(1),16); int b=m.group(2)==null?0:Integer.parseInt(m.group(2),16); if(pid.equals("010C"))return (a*256+b)/4.0; if(pid.equals("012F"))return a*100.0/255.0; return a;}catch(Exception e){return -1;} }
    private double parseVoltage(String r){ try{Matcher m=Pattern.compile("41\\s*42\\s*([0-9A-F]{2})\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return (Integer.parseInt(m.group(1),16)*256+Integer.parseInt(m.group(2),16))/1000.0; }catch(Exception ignored){} return -1;}
    private double parseLoad(String r){ return parseObdNumeric(r,"0104")*100.0/255.0; }
    private double parseCoolant(String r){ double v=parseObdNumeric(r,"0105"); return v<0?-1:v-40; }
    // PID 010F = Intake Air Temperature: A - 40 °C. Não reutilizar o parser de 0105 semanticamente.
    private double parseIntakeTemp(String r){ double v=parseObdNumeric(r,"010F"); return v<0?-1:v-40; }

    private double parseOilTemp(String r){ double v=parseObdNumeric(r,"015C"); return v<0?-1:v-40; }
    private double oilColorTemp(double t){ return t; }
    private double oilTextColor(double t){ return t; }
    private void updateOilUi(){ if(dashOilTemp==null||dashOilLevel==null)return; if(lastOilTemp<0){dashOilTemp.setText("🛢️ — °C");dashOilTemp.setTextColor(Color.rgb(145,181,210));} else {dashOilTemp.setText(String.format(Locale.US,"🛢️ %.0f °C",lastOilTemp)); int c=lastOilTemp<70?Color.rgb(70,170,255):lastOilTemp<120?Color.rgb(242,248,255):lastOilTemp<130?Color.rgb(255,180,60):Color.rgb(255,70,70);dashOilTemp.setTextColor(c);} dashOilLevel.setText("NÍVEL "+lastOilLevel); }
    private double parseThrottle(String r){ try{Matcher m=Pattern.compile("41\\s*11\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return Integer.parseInt(m.group(1),16)*100.0/255.0;}catch(Exception ignored){} return -1;}
    private double parseMap(String r){ try{Matcher m=Pattern.compile("41\\s*0B\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return Integer.parseInt(m.group(1),16);}catch(Exception ignored){} return -1;}
    private double parseBaro(String r){ try{Matcher m=Pattern.compile("41\\s*33\\s*([0-9A-F]{2})",Pattern.CASE_INSENSITIVE).matcher(r); if(m.find()) return Integer.parseInt(m.group(1),16);}catch(Exception ignored){} return -1;}
    private double calculateBoost(double mapKpa,double baroKpa){ if(mapKpa<0||baroKpa<0) return -1; return (mapKpa-baroKpa)/100.0; }
    private void startPerformanceTest(){
        if(performanceRunning){toast("Teste já está em andamento");return;}
        if(!connected||in==null||out==null){toast("Conecte o ELM antes do teste");return;}
        performanceRunning=true; performanceStop=false; ui(()->{perfStatus.setText("ARMADO • ACELERE DE FORMA SEGURA"); perfStatus.setTextColor(Color.rgb(255,190,0));});
        io.execute(()->{
            long t0=0,t100=0; double prevSpeed=-1,prevT=0; double bestPower=0,bestTorque=0; double maxB=0; int samples=0;
            final double massKg=1200.0, crr=0.012, cdA=0.62, rho=1.225, g=9.80665;
            try{
                while(performanceRunning && !performanceStop && connected && samples<500){
                    long now=System.nanoTime();
                    double speed=parseObdNumeric(send("010D",220),"010D");
                    double rpm=parseObdNumeric(send("010C",220),"010C");
                    double map=parseMap(send("010B",220)); double baro=parseBaro(send("0133",220));
                    double boost=calculateBoost(map,baro); if(boost>maxB)maxB=boost;
                    if(speed>=0){
                        if(t0==0 && speed>=1){t0=now;prevT=now/1e9;prevSpeed=speed;}
                        if(t0>0 && prevSpeed>=0){ double curT=now/1e9; double dt=curT-prevT; if(dt>0.03&&dt<1.0){ double v=speed/3.6, vp=prevSpeed/3.6; double a=(v-vp)/dt; if(a>0){double force=massKg*a + massKg*g*crr + 0.5*rho*cdA*v*v; double pw=force*v/745.699872; double tq=rpm>200?force*(v/(rpm*2*Math.PI/60.0))/0.92:0; if(pw>bestPower)bestPower=pw; if(tq>bestTorque)bestTorque=tq;} } prevT=curT; prevSpeed=speed; }
                        if(t0>0 && speed>=100 && t100==0)t100=now;
                    }
                    samples++; if(t100>0)break; Thread.sleep(70);
                }
            }catch(Exception e){append("PERFORMANCE: erro no teste — "+e.getClass().getSimpleName());}
            performanceRunning=false; final long f0=t0,f100=t100; final double fp=bestPower*1.15, ft=bestTorque, fb=maxB;
            ui(()->{ if(f100>f0 && f0>0){double sec=(f100-f0)/1e9; setPerfText(perf0100,"0–100 km/h",String.format(Locale.US,"%.2f s",sec));} else setPerfText(perf0100,"0–100 km/h","não concluído"); if(fp>0){setPerfText(perfPower,"POTÊNCIA ESTIMADA",String.format(Locale.US,"%.0f cv",fp)); setPerfText(perfTorque,"TORQUE ESTIMADO",String.format(Locale.US,"%.0f Nm",ft)); perfConfidence.setText("CONFIANÇA: estimativa preliminar • massa 1200 kg • sem correção de inclinação");} else {setPerfText(perfPower,"POTÊNCIA ESTIMADA","dados insuficientes"); setPerfText(perfTorque,"TORQUE ESTIMADO","dados insuficientes"); perfConfidence.setText("CONFIANÇA: baixa — teste não concluído");} setPerfText(perfBoost,"BOOST MÁX.",fb>0?String.format(Locale.US,"%.2f bar",fb):"— bar"); perfStatus.setText("TESTE FINALIZADO • DADOS PRESERVADOS"); perfStatus.setTextColor(Color.rgb(0,220,180)); perfFuel.setText("COMBUSTÍVEL: percentual de etanol não é inferido pela ECU neste modo; identifique o combustível do teste manualmente."); });
        });
    }
    private void stopPerformanceTest(){ if(!performanceRunning){toast("Nenhum teste em andamento");return;} performanceStop=true; ui(()->{perfStatus.setText("FINALIZANDO TESTE…");perfStatus.setTextColor(Color.rgb(255,190,0));}); }

    private void updateGraph(){ if(graphView==null)return; float v=-1; if("RPM".equals(graphMetric))v=(float)lastRpm; else if("BOOST".equals(graphMetric))v=(float)lastBoost; else if("THROTTLE".equals(graphMetric))v=(float)lastThrottle; else if("VELOCIDADE".equals(graphMetric))v=(float)lastSpeed; if(v>=0)graphView.add(v); TextView r=graphScreen==null?null:(TextView)graphScreen.findViewWithTag("graphRange"); if(r!=null)r.setText("Faixa atual: "+graphView.range()); }
    private void updateDashboard(){ if(!connected) setHealth("RED","DESCONECTADO"); else if(monitoring) setHealth("YELLOW","CAN CAPTURANDO • OBD PAUSADO"); else if(ecuResponding) setHealth("GREEN","OBD ATIVO"); else setHealth("YELLOW","ELM CONECTADO • SEM DADOS"); boolean ownVehicle = PROFILE_VIN.equalsIgnoreCase(lastVin == null ? "" : lastVin.trim()); String vehicleLabel = ownVehicle ? "Volkswagen Virtus 1.0 TSI • Stage 2" : (lastVin == null || lastVin.isEmpty() || "—".equals(lastVin) ? "VEÍCULO NÃO IDENTIFICADO" : "VEÍCULO IDENTIFICADO"); dashVin.setText("VIN: "+(lastVin==null||lastVin.isEmpty()?"—":lastVin)+"\n"+vehicleLabel); TextView profile=(TextView)dashVin.getRootView().findViewWithTag("vehicleProfile"); if(profile!=null) profile.setText(ownVehicle ? "VIRTUS 1.0 TSI • STAGE 2" : ""); String ig=ecuResponding?(lastRpm>0?"IG: ON • RUN":"IG: ON • ECU") : "IG: —"; dashIgnition.setText(ig); dashRpm.setText(lastRpm>=0?String.format(Locale.US,"%.0f rpm",lastRpm):"— rpm"); setMetricText(dashSpeed,"VELOCIDADE",lastSpeed>=0?String.format(Locale.US,"%.0f",lastSpeed):"—","km/h"); setMetricText(dashBoost,"BOOST",lastMap>=0&&lastBaro>=0?String.format(Locale.US,"%.2f",lastBoost):"—","bar"); if(dashBoost!=null){ dashBoost.append("\nMAX "+(maxBoost>=0?String.format(Locale.US,"%.2f",maxBoost):"—")+" bar"); } setMetricText(dashLoad,"CARGA MOTOR",lastLoad>=0?String.format(Locale.US,"%.0f",lastLoad):"—","%"); setMetricText(dashFuel,"COMBUSTÍVEL",lastFuel>=0?String.format(Locale.US,"%.0f",lastFuel):"—","%"); setMetricText(dashVolt,"TENSÃO",lastVolt>=0?String.format(Locale.US,"%.2f",lastVolt):"—","V"); setMetricText(dashMap,"MAP",lastMap>=0?String.format(Locale.US,"%.0f",lastMap):"—","kPa"); setMetricText(dashBaro,"BARO",lastBaro>=0?String.format(Locale.US,"%.0f",lastBaro):"—","kPa"); setMetricText(dashThrottle,"THROTTLE",lastThrottle>=0?String.format(Locale.US,"%.0f",lastThrottle):"—","%"); dashCoolant.setText(lastCoolant>=0?String.format(Locale.US,"TEMP. LÍQUIDO\n%.0f °C",lastCoolant):"TEMP. LÍQUIDO\n— °C"); dashIntake.setText(lastIntake>=0?String.format(Locale.US,"TEMP. ADMISSÃO\n%.0f °C",lastIntake):"TEMP. ADMISSÃO\n— °C"); updateOilUi(); rpmBar.setRpm(lastRpm); updateGraph(); dashCan.setText(String.format(Locale.US,"PROTOCOLO\nCAN 11/500\n%s",monitoring?"LIVE":"PRONTO")); }
    private void startDashboardPolling(){
        dashboardExec.scheduleAtFixedRate(()->{
            if(connected&&!monitoring&&!operationRunning){
                // Toda leitura Bluetooth passa pelo executor único de I/O.
                // Isso elimina concorrência entre dashboard, gravação, diagnóstico e CAN Monitor.
                io.execute(()->{
                    if(!connected||monitoring||operationRunning)return;
                    if(recordingActive) recordingSnapshot();
                    else { recordingTick++; if(recordingTick%3==0) dashboardSnapshot(); else ui(()->updateDashboard()); }
                });
            }else{
                ui(()->{ if(!connected){ applyConnectStyle(false); if(dashConn!=null){dashConn.setText("● ELM: DESCONECTADO"); dashConn.setTextColor(Color.rgb(150,35,35));} setHealth("RED","DESCONECTADO"); } updateDashboard(); });
            }
        },0,1,TimeUnit.SECONDS);
    }

    private void startRecording(){
        if(recordingActive){ toast("Gravação já está ativa"); return; }
        if(!connected||in==null||out==null){ toast("Conecte o ELM antes de gravar"); return; }
        try{
            File dir=new File(getFilesDir(),"recordings"); if(!dir.exists()&&!dir.mkdirs()) throw new IOException("Não foi possível criar a pasta de gravações");
            String stamp=new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());
            recordingFile=new File(dir,"VirtusELM_"+stamp+".csv");
            recordingWriter=new BufferedWriter(new FileWriter(recordingFile,false));
            recordingWriter.write("timestamp_ms;hora;rpm;speed_kmh;map_kpa;baro_kpa;boost_bar;boost_max_bar;throttle_pct;load_pct;coolant_c;intake_c;oil_temp_c;oil_level;fuel_pct;voltage_v;vin\n"); recordingWriter.flush();
            recordingStartMs=System.currentTimeMillis(); recordingSamples=0; recordingMaxBoost=-999; recordingActive=true; recordingTick=0;
            append("=== INÍCIO DA GRAVAÇÃO DE TELEMETRIA ==="); append("CSV: "+recordingFile.getAbsolutePath());
            startRecordingKeepAlive(); setStatus("GRAVANDO TELEMETRIA • MAP/BARO/BOOST/RPM"); setHealth("GREEN","GRAVAÇÃO ATIVA"); updateRecordingUi();
        }catch(Exception e){ append("ERRO AO INICIAR GRAVAÇÃO: "+e.getMessage()); closeRecordingWriter(); toast("Não foi possível iniciar a gravação"); }
    }
    private void stopRecording(){
        if(!recordingActive){ toast("Nenhuma gravação ativa"); return; }
        recordingActive=false; closeRecordingWriter(); stopRecordingKeepAlive();
        append("=== FIM DA GRAVAÇÃO DE TELEMETRIA ==="); append("AMOSTRAS: "+recordingSamples+" | BOOST MÁX.: "+(recordingMaxBoost>-900?String.format(Locale.US,"%.2f bar",recordingMaxBoost):"não disponível"));
        setStatus(connected?"Gravação finalizada — dados preservados":"Gravação finalizada — ELM desconectado"); updateRecordingUi(); showRecordingSummary();
    }
    private void closeRecordingWriter(){ try{if(recordingWriter!=null){recordingWriter.flush();recordingWriter.close();}}catch(Exception ignored){} recordingWriter=null; }
    private void recordingSnapshot(){
        if(!recordingActive||out==null||in==null||monitoring) return;
        try{
            String rpm=send("010C",700); String map=send("010B",700); String baro=send("0133",700);
            lastRpm=parseObdNumeric(rpm,"010C"); lastMap=parseMap(map); lastBaro=parseBaro(baro); lastBoost=calculateBoost(lastMap,lastBaro);
            if(lastBoost>=0){ if(lastBoost>recordingMaxBoost) recordingMaxBoost=lastBoost; if(lastBoost>maxBoost) maxBoost=lastBoost; }
            // Dados secundários a cada 3 segundos para manter alta frequência no conjunto MAP/BARO/BOOST/RPM.
            if(recordingSamples%3==0){
                lastSpeed=parseObdNumeric(send("010D",700),"010D"); lastThrottle=parseThrottle(send("0111",700)); lastLoad=parseLoad(send("0104",700)); lastCoolant=parseCoolant(send("0105",700)); lastIntake=parseIntakeTemp(send("010F",700)); lastOilTemp=parseOilTemp(send("015C",700)); lastFuel=parseObdNumeric(send("012F",700),"012F"); lastVolt=parseVoltage(send("0142",700));
                String pv=parseVin(send("0902",1200)); if(!pv.isEmpty()) lastVin=pv;
            }
            ecuResponding=true; noDataCycles=0;
            String now=new SimpleDateFormat("HH:mm:ss.SSS",Locale.US).format(new Date());
            if(recordingWriter!=null){ recordingWriter.write(System.currentTimeMillis()+";"+now+";"+fmt(lastRpm)+";"+fmt(lastSpeed)+";"+fmt(lastMap)+";"+fmt(lastBaro)+";"+fmt(lastBoost)+";"+fmt(recordingMaxBoost)+";"+fmt(lastThrottle)+";"+fmt(lastLoad)+";"+fmt(lastCoolant)+";"+fmt(lastIntake)+";"+fmt(lastOilTemp)+";"+lastOilLevel+";"+fmt(lastFuel)+";"+fmt(lastVolt)+";"+(lastVin==null?"":lastVin)+"\n"); recordingWriter.flush(); }
            recordingSamples++;
            ui(()->{updateDashboard();updateRecordingUi();});
        }catch(Exception e){ append("GRAVAÇÃO: erro de amostragem — "+e.getClass().getSimpleName()); }
    }
    private String fmt(double v){ return v<0?"":String.format(Locale.US,"%.3f",v); }
    private void updateRecordingUi(){ ui(()->{
        if(dataScreen==null)return;
        View rootView=dataScreen;
        if(recordingFile!=null){ TextView f=rootView.findViewWithTag("recordFile"); if(f!=null)f.setText("Arquivo: "+recordingFile.getName()+" • amostras: "+recordingSamples); }
        TextView m=rootView.findViewWithTag("recordMax"); if(m!=null)m.setText("BOOST MÁX.: "+(recordingMaxBoost>-900?String.format(Locale.US,"%.2f bar",recordingMaxBoost):"— bar"));
    }); }
    private void showRecordingSummary(){ String file=recordingFile==null?"—":recordingFile.getName(); String max=recordingMaxBoost>-900?String.format(Locale.US,"%.2f bar",recordingMaxBoost):"não registrado"; showResult("GRAVAÇÃO DE TELEMETRIA\n\nAmostras: "+recordingSamples+"\nBOOST MÁX.: "+max+"\nArquivo: "+file+"\n\nMAP e BARO são registrados para reconstruir o BOOST = MAP − BARO."); }
    private void copyCsv(){ if(recordingFile==null||!recordingFile.exists()){toast("Nenhuma gravação disponível");return;} try{StringBuilder b=new StringBuilder(); BufferedReader r=new BufferedReader(new FileReader(recordingFile)); String line; while((line=r.readLine())!=null)b.append(line).append('\n'); r.close(); ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("VIRTUS ELM CSV",b.toString())); toast("CSV copiado para a área de transferência");}catch(Exception e){toast("Erro ao copiar CSV");} }
    private void startRecordingKeepAlive(){ try{ Intent i=new Intent(this,RecordingKeepAliveService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i); }catch(Exception e){ append("AVISO: serviço de gravação não iniciado — "+e.getClass().getSimpleName()); } }
    private void stopRecordingKeepAlive(){ try{ stopService(new Intent(this,RecordingKeepAliveService.class)); }catch(Exception ignored){} }

    private String send(String cmd,long timeout){ if(out==null||in==null){append("ERRO: ELM não conectado para "+cmd);return "";} try{out.write((cmd+"\r").getBytes(StandardCharsets.US_ASCII));out.flush(); append(">> "+cmd); return readUntilPrompt(timeout);}catch(Exception e){append("ERRO TX/RX: "+e); if(!intentionalDisconnect && !monitoring) safeUnexpectedDisconnect(e); return "";} }
    private String readUntilPrompt(long timeout){ long end=System.currentTimeMillis()+timeout; ByteArrayOutputStream b=new ByteArrayOutputStream(); try{while(System.currentTimeMillis()<end){if(in.available()>0){int x=in.read(); if(x<0)break; b.write(x); if(x=='>')break;} else Thread.sleep(4);}}catch(Exception e){append("ERRO LEITURA: "+e);} String raw=new String(b.toByteArray(),StandardCharsets.US_ASCII); String n=normalize(raw); if(!n.isEmpty())append("<< "+n); return n; }
    private String normalize(String s){ return s.replace("\u0000","").replace("\r","\n").replace("\n\n","\n").replaceAll("\n+","\n").trim(); }
    private void runOp(String name, Runnable op){ if(operationRunning){setStatus("Já existe uma operação em andamento");return;} io.execute(()->{operationRunning=true; try{ if(out==null||in==null) throw new IOException("ELM não conectado"); append("=== "+name+" ==="); op.run(); append("=== FIM: "+name+" ==="); }catch(Exception e){append("ERRO "+name+": "+e);setStatus("Erro na operação — aplicativo mantido aberto");}finally{operationRunning=false;}}); }
    private void showResult(String s){ui(()->{ if(result!=null) result.setText("RESULTADO:\n"+s); if(resultHome!=null) resultHome.setText("RESULTADO:\n"+s); });}

    private String firstPayload(String resp){ String[] ls=resp.split("\\n"); for(String l:ls){String u=l.trim().toUpperCase(Locale.US); if(u.matches("^(7E[0-9A-F]|[0-9A-F]{3,8})\\s+41\\s+.*")||u.matches("^41\\s+.*")||u.matches("^43\\s+.*")||u.matches("^47\\s+.*")||u.matches("^49\\s+.*")) return u;} return resp.trim(); }
    private void queryPid(String pid,String label){ String r=send(pid,1500); String[] lines=r.split("\\n"); StringBuilder outv=new StringBuilder(); for(String l:lines){String t=l.trim(); if(t.isEmpty())continue; if(t.matches("(?i).*(41|43|47|49)\\s+.*")){outv.append(t).append("\\n");}} if(outv.length()>0) append(label+": "+outv.toString().trim()); else append(label+": sem resposta estruturada"); }

    private void quickDiagnostic(){ runOp("DIAGNÓSTICO RÁPIDO — SOMENTE LEITURA",()->{String p=send("0100",1800); StringBuilder r=new StringBuilder(); r.append("0100 / PIDs 01–20:\n").append(p).append("\n"); queryPid("010C","RPM"); queryPid("010D","VELOCIDADE"); queryPid("0105","TEMPERATURA ARREFECIMENTO"); String d=send("03",1800); append("DTC: "+d); r.append("DTC:\n").append(d); showResult(r.toString());}); }
    private void automaticDiagnostic(){ runOp("DIAGNÓSTICO COMPLETO — SOMENTE LEITURA",()->{StringBuilder r=new StringBuilder(); String[] pids={"0100","0120","0140","0160","0104","0105","010B","010C","010D","010F","015C","0111","011F","012F","0133","0142","03","07","0A","0902","0101"}; for(String p:pids){String x=send(p,p.equals("0902")?2500:1600); append(p+": "+x); r.append(p).append(" -> ").append(x).append("\n");} r.append("\nG266/NÍVEL DO ÓLEO: leitura VAG não padronizada via OBD-II; nenhum valor é inventado.\n"); showResult(r.toString());}); }
    private void vehicleData(){ runOp("LER DADOS DO VEÍCULO",()->{StringBuilder r=new StringBuilder(); String[] pids={"0100","0120","0140","0160","0104","0105","010B","010C","010D","010F","015C","0111","011F","012F","0133","0142"}; for(String p:pids){String x=send(p,1600); append(p+": "+x); r.append(p).append(" -> ").append(x).append("\n");} showResult(r.toString());}); }
    private void readDtc(){ runOp("LER CÓDIGOS DE FALHA — DTC",()->{String r=send("03",2000); if(r.contains("43 00")||r.matches("(?s).*\\b43\\s+00\\b.*")){append("DTC: nenhum código reportado pela resposta OBD recebida.");} else append("DTC RAW: "+r); showResult(r);}); }
    private void readVin(){ runOp("LER VIN — SE DISPONÍVEL",()->{String r=send("0902",3000); String vin=parseVin(r); append("VIN: "+(vin.isEmpty()?"não identificado no parser; RAW preservado":vin)); showResult("VIN: "+(vin.isEmpty()?"não identificado":vin)+"\nRAW:\n"+r);}); }
    private String parseVin(String r){
        if(r==null||r.isEmpty()) return "";
        String[] lines=r.toUpperCase(Locale.US).replace('\r','\n').split("\n");
        StringBuilder vinHex=new StringBuilder(); boolean found=false;
        for(String rawLine:lines){
            String line=rawLine.trim(); if(line.isEmpty()) continue;
            ArrayList<String> tok=new ArrayList<>(); Matcher m=Pattern.compile("[0-9A-F]{2}").matcher(line);
            while(m.find()) tok.add(m.group());
            if(tok.size()<3) continue;
            int svc=-1;
            for(int i=0;i+2<tok.size();i++) if(tok.get(i).equals("49")&&tok.get(i+1).equals("02")&&tok.get(i+2).equals("01")){svc=i;break;}
            if(svc>=0){ found=true; for(int j=svc+3;j<tok.size();j++) vinHex.append(tok.get(j)); continue; }
            if(found){
                // Multi-frame ISO-TP continuation: 7E8 21 ... / 7E8 22 ...
                // Ignore the CAN header and PCI byte; keep only payload bytes.
                int pci=-1;
                for(int i=0;i<tok.size();i++){ if(tok.get(i).equals("21")||tok.get(i).equals("22")||tok.get(i).equals("23")||tok.get(i).equals("24")){pci=i;break;} }
                if(pci>=0){ for(int j=pci+1;j<tok.size();j++) vinHex.append(tok.get(j)); }
            }
        }
        StringBuilder vin=new StringBuilder();
        for(int i=0;i+1<vinHex.length()&&vin.length()<17;i+=2){
            try{int v=Integer.parseInt(vinHex.substring(i,i+2),16); if(v>=32&&v<=126) vin.append((char)v);}catch(Exception ignored){}
        }
        String out=vin.toString().trim();
        return out.length()==17?out:"";
    }
    private void dtcFreeze(){ runOp("DTC + FREEZE FRAME — SOMENTE LEITURA",()->{String a=send("03",2000); String b=send("0200",2000); String c=send("0201",2000); append("MODE 03: "+a); append("FREEZE FRAME 0200: "+b); append("FREEZE FRAME 0201: "+c); showResult("MODE 03:\n"+a+"\n\n0200:\n"+b+"\n\n0201:\n"+c);}); }
    private void obdStatus(){ runOp("STATUS OBD / READINESS",()->{StringBuilder r=new StringBuilder(); for(String p:new String[]{"0101","0102","0106","0107","0110"}){String x=send(p,1600);append(p+": "+x);r.append(p).append(" -> ").append(x).append("\n");}showResult(r.toString());}); }
    private void o2Test(){ runOp("TESTAR MONITORAMENTO DA SONDA",()->{StringBuilder r=new StringBuilder();for(String p:new String[]{"05","06","07","0A"}){String x=send(p,1800);append(p+": "+x);r.append(p).append(" -> ").append(x).append("\n");}showResult(r.toString());}); }
    private void ignitionOffTest(){ runOp("TESTE COM IGNIÇÃO DESLIGADA",()->{String a=send("ATI",1500);String b=send("ATDP",1500);String c=send("0100",2200);boolean ecu=c.matches("(?s).*(41\\s+00|41 00).*");String conclusion=ecu?"ELM respondeu e houve resposta OBD/CAN com a condição testada.":"ELM respondeu, mas nenhuma resposta CAN/ECU foi identificada para 0100. Isso não significa que não existam outros módulos.";append("CONCLUSÃO: "+conclusion);showResult(a+"\n"+b+"\n0100:\n"+c+"\n\n"+conclusion);}); }
    private void bodyStudy(){ runOp("ESTUDO DE MÓDULOS — SOMENTE LEITURA",()->{String a=send("ATDP",1600);String b=send("0100",2200);append("PROTOCOLO: "+a);append("0100: "+b);showResult("PROTOCOLO:\n"+a+"\n\n0100:\n"+b+"\n\nNenhum comando de atuação, segurança, coding ou lock/unlock foi transmitido.");}); }

    private volatile boolean monitorRejected = false;
    private long monitorStartedAt = 0;

    private void startMonitor(){
        if(operationRunning||monitoring){setStatus(operationRunning?"Finalize a operação atual antes de capturar":"Captura já ativa");return;}
        if(out==null||in==null||!connected){setStatus("Conecte o ELM primeiro");return;}

        // Reserva o único canal de I/O ANTES de enfileirar a captura.
        // Isso impede que o polling OBD entre no socket enquanto o Monitor All é preparado.
        operationRunning=true;
        monitoring=true;
        stopRequested=false;
        monitorRejected=false;
        monitorStartedAt=System.currentTimeMillis();
        rawCount=frameCount=rxBytes=0; ids.clear(); idCounts.clear(); markers.clear();
        setHealth("YELLOW","CAN CAPTURANDO • OBD PAUSADO");
        setStatus("PREPARANDO MONITOR CAN — OBD pausado");

        io.execute(()->{
            try{
                append("=== INÍCIO DA CAPTURA CAN PASSIVA — V11.0 REV08 ===");
                append("MODO EXCLUSIVO: polling OBD bloqueado durante toda a captura.");
                append("SOMENTE LEITURA — nenhum frame CAN arbitrário é transmitido.");

                // Descobre o protocolo sem disparar uma nova bateria de PIDs.
                String dp=send("ATDP",1500);
                String proto=dp.toUpperCase(Locale.US);
                if(proto.contains("29/500")||proto.contains("29")){
                    append("Protocolo detectado: CAN 29/500 — fixando protocolo 7 para a captura.");
                    send("ATSP7",1200);
                }else{
                    append("Protocolo detectado: CAN 11/500 — fixando protocolo 6 para a captura.");
                    send("ATSP6",1200);
                }

                // Configuração mínima do monitor. Não há 0100/010C/0902 aqui:
                // esses PIDs pertencem ao modo OBD e não podem disputar o socket com AT MA.
                send("ATE0",700);
                send("ATH1",700);
                send("ATS1",700);
                send("ATL0",700);
                send("ATAT1",700);
                drainInput(150);

                append("AT MA será usado em Monitor All. O aplicativo não transmite mensagens CAN ao veículo.");
                out.write("AT MA\r".getBytes(StandardCharsets.US_ASCII));
                out.flush();
                append(">> AT MA");
                setStatus("MONITORAMENTO CAN ATIVO — OBD pausado");
                monitorLoop();
            }catch(Exception e){
                append("ERRO MONITOR: "+e);
                setStatus("Captura interrompida — dados preservados");
                monitoring=false;
                operationRunning=false;
                if(!intentionalDisconnect){
                    connected=false;
                    closeSocket();
                    setHealth("RED","RECONEXÃO AUTOMÁTICA");
                    scheduleReconnect();
                }
            }finally{
                monitoring=false;
                operationRunning=false;
            }
        });
    }

    private void drainInput(long quietMs){
        if(in==null)return;
        long end=System.currentTimeMillis()+quietMs;
        int drained=0;
        try{
            while(System.currentTimeMillis()<end){
                if(in.available()>0){
                    int x=in.read();
                    if(x<0)break;
                    drained++;
                    end=System.currentTimeMillis()+40;
                }else Thread.sleep(4);
            }
        }catch(Exception e){ append("AVISO: falha ao drenar buffer antes do Monitor All: "+e.getClass().getSimpleName()); }
        if(drained>0) append("Buffer ELM drenado antes da captura: "+drained+" bytes.");
    }

    private void monitorLoop() throws IOException {
        ByteArrayOutputStream line=new ByteArrayOutputStream();
        ByteArrayOutputStream binary=new ByteArrayOutputStream();
        byte[] buf=new byte[1024]; long lastUi=0;
        while(monitoring){
            int n=in.read(buf);
            if(n<0) throw new IOException("socket fechado durante Monitor All");
            if(n==0) continue;
            rxBytes+=n;
            for(int i=0;i<n;i++){
                int x=buf[i]&0xFF;
                // ELM returns the prompt as a single '>' character; detect it immediately
                // so FINALIZAR CAPTURA does not depend on a trailing CR/LF.
                if(x=='>'){
                    if(line.size()>0) flushMonitorLine(line);
                    if(binary.size()>0) flushMonitorBinary(binary);
                    processMonitorRaw(">");
                    if(stopRequested) break;
                    continue;
                }
                if(x=='\r'||x=='\n'){
                    flushMonitorBinary(binary);
                    flushMonitorLine(line);
                } else if(x>=32&&x<=126){
                    if(binary.size()>0) flushMonitorBinary(binary);
                    line.write(x);
                    if(line.size()>2048) flushMonitorLine(line);
                } else {
                    if(line.size()>0) flushMonitorLine(line);
                    binary.write(x);
                    if(binary.size()>=256) flushMonitorBinary(binary);
                }
            }
            if(System.currentTimeMillis()-lastUi>200){ lastUi=System.currentTimeMillis(); updateStats(); }
        }
        if(line.size()>0) flushMonitorLine(line);
        if(binary.size()>0) flushMonitorBinary(binary);
    }
    private void flushMonitorLine(ByteArrayOutputStream line){ if(line.size()==0)return; String s=new String(line.toByteArray(),StandardCharsets.US_ASCII).trim();line.reset();if(s.isEmpty())return;processMonitorRaw(s); }
    private void flushMonitorBinary(ByteArrayOutputStream binary){
        if(binary.size()==0)return;
        byte[] b=binary.toByteArray(); binary.reset();
        StringBuilder h=new StringBuilder();
        for(byte v:b){ if(h.length()>0) h.append(' '); h.append(String.format(Locale.US,"%02X",v&0xFF)); }
        rawCount++;
        synchronized(logLock){ technical.append("[MONITOR HEX] ").append(h).append('\n'); }
        if(rawCount<=8||rawCount%50==0) append("RAW HEX #"+rawCount+": "+h);
    }
    private void processMonitorRaw(String s){
        String u=s.toUpperCase(Locale.US).trim();
        // ELM control responses are not CAN frames and must never inflate the CAN counters.
        if(u.equals("OK")||u.equals(">")||u.equals("STOPPED")||u.contains("SEARCHING")||u.contains("NO DATA")){
            append("ELM CONTROL (fora da captura CAN): "+u);
            if(u.equals(">") && stopRequested){ monitoring=false; append("<< > — ELM retornou ao prompt; captura encerrada corretamente."); append("=== FIM DA CAPTURA CAN PASSIVA ==="); append("RAW RECEBIDOS: "+rawCount+" | FRAMES DECODIFICADOS: "+frameCount+" | IDS: "+ids.size()+" | BYTES: "+rxBytes); setStatus("Captura finalizada — retomando OBD"); setHealth("YELLOW","RETOMANDO OBD"); updateStats(); return; }
            if(u.equals(">") && !stopRequested && System.currentTimeMillis()-monitorStartedAt<2500){
                monitorRejected=true;
                append("ERRO: AT MA retornou o prompt imediatamente — Monitor All não permaneceu ativo.");
                setStatus("AT MA não permaneceu ativo — captura não iniciada");
                monitoring=false;
            }
            return;
        }
        rawCount++;
        synchronized(logLock){technical.append("[MONITOR RAW] ").append(s).append('\n');}
        if(u.contains("BUFFER FULL")){append("!! ELM REPORTOU BUFFER FULL — RAW preservado.");updateStats();return;}
        ParsedCan pc=parseCan(s);
        if(pc.ok){frameCount++;ids.add(pc.id);idCounts.put(pc.id,idCounts.getOrDefault(pc.id,0L)+1L);if(frameCount<=8||frameCount%50==0)append("CAN "+pc.id+" DLC="+pc.dlc+" DATA="+pc.data);}
        else if(rawCount<=8||rawCount%100==0){append("RAW não classificado #"+rawCount+": "+s);}
        updateStats();
    }
    static class ParsedCan {boolean ok;String id="",data="";int dlc;}
    private ParsedCan parseCan(String s){
        ParsedCan p=new ParsedCan();
        String clean=s.replaceAll("[^0-9A-Fa-f ]"," ").trim().replaceAll("\\s+"," ");
        if(clean.isEmpty())return p;
        String[] a=clean.split(" ");
        // Clone ELMs may emit compact Monitor All lines such as 7E803412FCD.
        if(a.length==1){
            String z=a[0].toUpperCase(Locale.US);
            Matcher cm=Pattern.compile("^([0-9A-F]{3}|[0-9A-F]{8})([0-8])([0-9A-F]{2,16})$").matcher(z);
            if(cm.matches()){
                int d=Integer.parseInt(cm.group(2),16); String data=cm.group(3);
                if(data.length()==d*2){p.ok=true;p.id=cm.group(1);p.dlc=d;StringBuilder db=new StringBuilder();for(int i=0;i<data.length();i+=2){if(db.length()>0)db.append(' ');db.append(data.substring(i,i+2));}p.data=db.toString();return p;}
            }
            return p;
        }
        // Common ELM CAN monitor forms: header followed by DLC and data.
        for(int i=1;i<a.length;i++){try{int d=Integer.parseInt(a[i],16);if(d>=0&&d<=8&&a.length>=i+1+d){String id=String.join(" ",Arrays.copyOfRange(a,0,i)); if(id.length()>=2&&id.length()<=12){p.ok=true;p.id=id;p.dlc=d;StringBuilder db=new StringBuilder();for(int j=i+1;j<a.length;j++){if(db.length()>0)db.append(' ');db.append(a[j]);}p.data=db.toString();return p;}}}catch(Exception ignored){}}
        return p;
    }
    private void updateStats(){long now=System.currentTimeMillis();if(now-lastStatsUi<250)return;lastStatsUi=now;ui(()->stats.setText("RAW: "+rawCount+" • FRAMES: "+frameCount+" • IDs: "+ids.size()+" • BYTES: "+rxBytes));}
    private void mark(String type){
        if(!monitoring){append("MARCADOR ignorado: captura não está ativa");return;}
        Marker m=new Marker(type,rawCount,frameCount,rxBytes,idCounts); markers.add(m);
        append("*** MARCADOR "+type+" | RAW="+m.raw+" | FRAMES="+m.frames+" | BYTES="+m.bytes+" | IDS="+m.idsAt.size()+" | "+sdf.format(new Date(m.when))+" ***");
    }
    private void stopMonitor(){
        if(!monitoring){ toast("Nenhuma captura CAN ativa"); return; }
        stopRequested=true; stopDeadline=System.currentTimeMillis()+8000;
        try{ if(out!=null){ out.write('\r'); out.flush(); append(">> [INTERRUPÇÃO] 1 caractere enviado ao ELM"); } }catch(Exception e){ append("ERRO AO ENVIAR INTERRUPÇÃO: "+e); }
        setStatus("Finalizando captura CAN…");
        main.postDelayed(()->{
            if(monitoring && System.currentTimeMillis()>=stopDeadline){
                monitoring=false; operationRunning=false;
                append("TIMEOUT: ELM não retornou o prompt. A conexão será reiniciada automaticamente; log e marcadores serão preservados.");
                intentionalDisconnect=false; closeSocket();
                append("=== FIM DA CAPTURA CAN PASSIVA — TIMEOUT ===");
                setStatus("Captura finalizada — reconectando ELM"); setHealth("RED","RECONEXÃO AUTOMÁTICA");
                scheduleReconnect(); updateStats();
            }
        },8100);
    }
    private void analyze(){
        if(markers.isEmpty()){append("=== ANÁLISE DIFERENCIAL DE EVENTOS ===");append("Nenhum marcador registrado.");return;}
        append("=== ANÁLISE DIFERENCIAL DE EVENTOS ===");
        for(int i=0;i<markers.size();i++){
            Marker m=markers.get(i); append("EVENTO "+(i+1)+": "+m.type+" | RAW="+m.raw+" | FRAMES="+m.frames+" | BYTES="+m.bytes+" | IDS="+m.idsAt.size()+" | "+sdf.format(new Date(m.when)));
            if(i>0){
                Marker prev=markers.get(i-1);
                LinkedHashMap<String,Long> delta=new LinkedHashMap<>();
                for(Map.Entry<String,Long> e:m.idsAt.entrySet()){long before=prev.idsAt.getOrDefault(e.getKey(),0L);long d=e.getValue()-before;if(d>0)delta.put(e.getKey(),d);}
                ArrayList<Map.Entry<String,Long>> top=new ArrayList<>(delta.entrySet()); top.sort((a,b)->Long.compare(b.getValue(),a.getValue()));
                if(top.isEmpty()) append("  DIFERENCIAL: nenhum ID CAN novo entre os marcadores.");
                else {StringBuilder z=new StringBuilder("  IDS ATIVOS NO INTERVALO: ");int lim=Math.min(12,top.size());for(int j=0;j<lim;j++){if(j>0)z.append(", ");z.append(top.get(j).getKey()).append("(").append(top.get(j).getValue()).append("x)");}append(z.toString());}
            }
        }
        append("A análise identifica candidatos por mudança de tráfego entre marcadores; ela NÃO envia quadros CAN nem tenta acionar funções do veículo.");
        showResult("Marcadores: "+markers.size()+"\nRAW: "+rawCount+"\nFrames: "+frameCount+"\nIDs: "+ids.size()+"\nVeja no LOG os IDs que mudaram entre cada evento.");
    }

    private void copyLog(){String text; synchronized(logLock){text=technical.toString();} if(text.isEmpty()){toast("Log vazio");return;} ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(ClipData.newPlainText("VIRTUS ELM V11.4 — LOG",text));toast("LOG COPIADO");}
    private void clearLog(){ if(monitoring||operationRunning){toast("Finalize a operação antes de limpar o log");return;} synchronized(logLock){technical.setLength(0);} log.setText(""); if(result!=null)result.setText("RESULTADO: —"); if(resultHome!=null)resultHome.setText("RESULTADO: —"); rawCount=frameCount=rxBytes=0;ids.clear();markers.clear();stats.setText("RAW: 0 • FRAMES: 0 • IDs: 0 • BYTES: 0");append("[00] LOG LIMPO — V11.4 • conexão Bluetooth preservada"); if(logScroll!=null)logScroll.post(()->logScroll.fullScroll(View.FOCUS_DOWN)); setStatus(connected?"Conectado — log limpo":"Bluetooth não conectado"); }
    private void toast(String s){ui(()->Toast.makeText(this,s,Toast.LENGTH_SHORT).show());}
    private void setStatus(String s){ui(()->{ if(status!=null) status.setText("Status: "+s); });}
    private void ui(Runnable r){main.post(r);}
    private void append(String s){String line="["+sdf.format(new Date())+"] "+s; synchronized(logLock){technical.append(line).append('\n');} ui(()->{if(log!=null){log.append(line+"\n"); if(logScroll!=null)logScroll.post(()->logScroll.fullScroll(View.FOCUS_DOWN));}});}
    private void safeUnexpectedDisconnect(Exception cause){ if(intentionalDisconnect) return; boolean wasConnected=connected || socket!=null; connected=false; try{closeSocket();}catch(Exception ignored){} if(wasConnected){ append("CONEXÃO PERDIDA — preservando log e tentando reconexão automática."); setStatus("Conexão perdida — reconectando automaticamente"); scheduleReconnect(); } }
    private void scheduleReconnect(){ if(reconnecting||intentionalDisconnect||bt==null) return; reconnecting=true; dashboardExec.schedule(()->{ reconnecting=false; if(!intentionalDisconnect && !connected && !monitoring && !operationRunning) io.execute(()->connectWorker()); },1500,TimeUnit.MILLISECONDS); }
    private void closeSocket(){ connected=false; try{if(in!=null)in.close();}catch(Exception ignored){}try{if(out!=null)out.close();}catch(Exception ignored){}try{if(socket!=null)socket.close();}catch(Exception ignored){}in=null;out=null;socket=null;}
    @Override protected void onResume(){ super.onResume(); applyKeepScreenPreference(); }

    private boolean isKeepScreenOnEnabled(){ return getSharedPreferences(PREFS_UI,MODE_PRIVATE).getBoolean(PREF_KEEP_SCREEN,true); }
    private void applyKeepScreenPreference(){ if(isKeepScreenOnEnabled()) getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); else getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); }

    @Override protected void onDestroy(){intentionalDisconnect=true;monitoring=false;stopRequested=true;if(recordingActive){recordingActive=false;closeRecordingWriter();stopRecordingKeepAlive();}closeSocket();io.shutdownNow();dashboardExec.shutdownNow();super.onDestroy();}
}
