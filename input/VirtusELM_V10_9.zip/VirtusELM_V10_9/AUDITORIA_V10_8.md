# AUDITORIA V10.9

Base de desenvolvimento: V10.7. A V10.9 preserva as funções OBD-II e a investigação CAN passiva e corrige os pontos identificados no teste anterior.

## Identidade e versão
- Projeto: `VirtusELM_V10_9`
- Package: `com.marcelo.virtuselm`
- VersionCode: 108
- VersionName: 10.8
- Launcher icon próprio em azul, com V estilizado, adaptive icon e camada monocromática.

## Telemetria
- PID 0133 interpretado como BARO em kPa.
- BOOST relativo calculado por `(MAP - BARO) / 100`.
- BOOST MÁX. reiniciado a cada nova conexão e atualizado apenas para valores positivos.

## CAN passivo
- Monitor All continua sem transmissão de quadros CAN arbitrários.
- Prompt `>` é detectado imediatamente durante a leitura.
- Bytes não ASCII são preservados em hexadecimal no log.
- Finalização continua enviando apenas um caractere de interrupção e aguardando o prompt; reconexão forçada somente em timeout/perda real.

## Segurança
A aplicação permanece SOMENTE LEITURA para diagnóstico e investigação. Não implementa atuação, lock/unlock, coding, adaptation, security access ou envio arbitrário de CAN.
